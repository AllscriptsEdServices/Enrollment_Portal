<!DOCTYPE HTML>
<html lang="en" >
<head>
<meta charset="utf-8" />
<meta name="author" content="Vishwajit Menon" />
<title>i-Learn - Internal Admin</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">


<!-- Loading commonly used CSS -->
<!-- <link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'> -->
<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/css/admin_utilities.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/select2-4.0.1/dist/css/select2.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/formvalidation-master/dist/css/formValidation.css"); ?>" rel="stylesheet">

<script src="<?php echo base_url("assets/js/modernizr.custom.26324.js"); ?>"></script>
<!--<script src="<?php echo base_url("assets/js/css3-mediaqueries.js"); ?>"></script>-->

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->


<script src="<?php echo base_url("assets/js/jquery-1.11.0.js"); ?>"></script> 
<script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>"></script> 

  
</head>

<body>
<div class="container-fluid top-buffer">
    
    <!--<div class="row">
    	<div class="col-xs-12 text-right">
         <?php echo json_encode($message); ?>
      </div>
    </div>-->

    <div class="row">   

      <?php $attributes = array('id' => 'defaultForm'); echo form_open_multipart('/edit_content/update_content_details', $attributes );?>

         <input type="hidden" class="form-control" id="contentId" name="contentId" value="<?php echo  $content_details["Id"] ?>">
         <input type="hidden" class="form-control" id="current_url" name="current_url" value="<?php echo  $content_details["FileURL"] ?>">

         <table class="table table-bordered table-condensed">
            <tr>
                <td>
                    <label class="control-label" for="contentTitle">Content Type</label>
                </td>
                <td>
                  <div class="form-group">
                    <input type="text"  class="form-control" readonly id="contentType" name="contentType" placeholder="Enter Title" value="<?php echo $content_details["CourseType"]; ?>">
                  </div>
                </td>
            </tr>
            
            <tr>
                <td>
                    <label class="control-label" for="contentTitle">Content Title</label>
                </td>
                <td>
                  <div class="form-group">
                    <input type="text" class="form-control" id="contentTitle" name="contentTitle" placeholder="Enter Title" value="<?php echo $content_details["CourseTitle"]; ?>">
                  </div>
                </td>
            </tr>

            <?php if($content_details["CourseType"]!="HotTopic") {?> 
               <tr>
                   <td style="width:150px">
                       <label class="control-label" for="screen_selector">Screen Names</label>
                   </td>
                   <td>
                     <div class="form-group">
                       <select id="screen_selector" name="screen_selector[]" style="width:90%" multiple class="form-control" >                       
                          <?php                            
                              foreach($all_screen_names as $screen_name){ 
                                 if(strpos($content_details["ScreenName"], $screen_name) !== false){                                 
                                    echo '<option value="'.$screen_name.'" selected="selected">'.$screen_name.'</option>';
                                 }else{
                                    echo '<option value="'.$screen_name.'">'.$screen_name.'</option>';
                                 }                        
                              }
                           ?>
                         
                      </select>                   
                     </div>
                   </td>
               </tr>  
                      
               <tr>
                   <td style="width:150px">
                       <label class="control-label" for="sub_screen_selector">Sub Screen Name</label>
                   </td>
                   <td>
                     <div class="form-group">
                       <select id="sub_screen_selector" name="sub_screen_selector[]" style="width:90%" multiple class="form-control" >                       
                          <?php                            
                              foreach($sub_screen_names as $sub_screen){ 
                                 if(strpos($content_details["SubScreenName"], $sub_screen) !== false){                                 
                                    echo '<option value="'.$sub_screen.'" selected="selected">'.$sub_screen.'</option>';
                                 }else{
                                    echo '<option value="'.$sub_screen.'">'.$sub_screen.'</option>';
                                 }                        
                              }
                           ?>
                         
                      </select>                   
                     </div>
                   </td>
               </tr> 


               <tr>
                   <td>
                       <label class="control-label" for="version_selector">Version</label>
                   </td>
                   <td>
                     <div class="form-group">
                       <select id="version_selector" name="version_selector" style="width:90%" class="form-control" >                       
                          <?php 
                              $screenssad = "";
                              foreach($VERSIONS_ARRAY as $default_version){ 
                                 if($content_details["ProductVersion"] == $default_version){                                 
                                    echo '<option value="'.$default_version.'" selected="selected">'.$default_version.'</option>';
                                 }else{
                                    echo '<option value="'.$default_version.'">'.$default_version.'</option>';
                                 }                        
                              }
                           ?>
                         
                      </select>                  
                     </div>
                   </td>
               </tr>              

               <tr>
                  <td>
                     <label class="control-label" for="duration">Duration <code>(mm:ss)</code></label>
                  </td>
                  <td>
                     <div class="form-group">
                        <input type="text" class="form-control" id="duration" name="duration" placeholder="Enter Duration" value="<?php echo $content_details["Duration"]; ?>">
                     </div>
                  </td>
               </tr>

            <?php } ?> 

            <tr>
                <td>
                    <label class="control-label" for="keyword_selector">Keywords</label>
                </td>
                <td>
                  <div class="form-group">
                    <select id="keyword_selector" name="keyword_selector[]" style="width:90%" multiple class="form-control" >                       
                       <?php 
                           $screenssad = "";
                           foreach($all_keyword_names as $keyword){ 
                              if(strpos($content_details["Keywords"], $keyword) !== false){
                                 
                                 echo '<option value="'.$keyword.'" selected="selected">'.$keyword.'</option>';
                              }else{
                                 echo '<option value="'.$keyword.'">'.$keyword.'</option>';
                              }                        
                           }
                        ?>
                      
                   </select>                   
                  </div>
                </td>
            </tr>  


            <tr>
               <td>
                  <label class="control-label" for="userfile">File</label>
               </td>
               <td>                             
                     <input type="file" id="userfile"  name="userfile" accept=".zip" size="20" />            
               </td>
            </tr>

            
            <tr>
               <td colspan="2" class="text-center">
                  <button type="submit" class="btn btn-primary center-block">Update Details</button>
               </td>
            </tr>

        </table>
       
      </form> 

   </div>

   <?php if($message["status"] != -1) { ?>
      <div class="row">      

         <?php 

            if($message["status"] == 1) 
            { 
               
               echo '<div class="column col-xs-12 bg-success feedback_div">';

               if($message["update_type"] == "content_and_file"){
                  echo 'The file and content details are sucessfully updated!';
               }else{
                  echo 'The content details are sucessfully updated!';
               }  

               echo '</div>';

            }
            elseif($message["status"] == 0)
            {
              
               $display_text = "";               
               switch($message["reason"]){
                  case "upload_error":
                     $display_text = "There was an error in uploading the file. Please try again.";
                     break;
                  case "extract_error":
                     $display_text = "The zip was not formed well. Please re-zip and try uploading again.";
                     break;
                  case "zip_format_error":
                     $display_text = "The zip is not in the expected format of the HTML5 videos. Please check and re-upload.";
                     break;
                  default:
                     $display_text = "An error occured. Please try again.";
                     break;
               }

               echo '<div class="column col-xs-12 bg-danger feedback_div">';
               echo $display_text;
               echo '</div>';

            }

         ?>         

 <?php } ?> <!-- End of checking if feedback message present   -->

</div>





<link rel="stylesheet" href="<?php echo base_url("assets/plugins/tablesorter-master/dist/css/theme.dropbox.min.css") ?>">
<script type="text/javascript" src="<?php echo base_url("assets/plugins/tablesorter-master/dist/js/jquery.tablesorter.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/tablesorter-master/dist/js/jquery.tablesorter.widgets.min.js") ?>"></script>
<script src="<?php echo base_url("assets/plugins/select2-4.0.1/dist/js/select2.js"); ?>"> </script>
<script src="<?php echo base_url("assets/plugins/formvalidation-master/dist/js/formValidation.js"); ?>"></script> 
<script src="<?php echo base_url("assets/plugins/formvalidation-master/dist/js/framework/bootstrap.js"); ?>"></script>

<script type="text/javascript">
	var baseURL = <?php echo json_encode($baseURL) ?>;
  var message = <?php echo json_encode($message) ?>;
   
   //If the course has been updated, then pass the updated content details to the main page, so that display row can be updated.
   if(message.status>=0){
      var content_details = <?php echo json_encode($content_details) ?>;
      window.parent.update_content_display_row(content_details);
   }

   // Initiate the Select 2 plugin for the dropdowns
   $("#keyword_selector").select2({
        placeholder: "Select keywords..",       
        allowClear: true,        
    }); 

    $("#screen_selector").select2({
        placeholder: "Select screen..",               
        closeOnSelect:true     
    }); 

    $("#sub_screen_selector").select2({
        placeholder: "Select sub screen..",               
        closeOnSelect:true     
    });   

    $("#version_selector").select2({
        placeholder: "Select version..",               
        closeOnSelect:true     
    });


    $(document).ready(function() {
      
       $('#defaultForm')
          .formValidation({

              message: 'This value is not valid',
              icon: {
                  valid: 'glyphicon glyphicon-ok',
                  invalid: 'glyphicon glyphicon-remove',
                  validating: 'glyphicon glyphicon-refresh'
              },

              fields: {
                  contentTitle: {
                      validators: {
                          notEmpty: {
                              message: 'The content title is required'
                          }
                      }
                  },
                  duration: {
                      validators: {
                          notEmpty: {
                              message: 'The duration field is required'
                          }
                      }
                  },
                  screen_selector: {
                      validators: {
                          notEmpty: {message: 'The screen name is required'}
                      }
                  },
                  version_selector: {
                      validators: {
                          notEmpty: {message: 'The version field is required'}
                      }
                  }
             
              }
          })   
         .on('success.form.fv', function(e) {
            // If you want to prevent the default handler (formValidation._onSuccess(e))
               //console.log('success.form.fv');
               //e.preventDefault();           

               //fnSendProjectDetails();          
               
           });
   });

    	

   function fnSendProjectDetails(){
      alert("fnSendProjectDetails");
   }

	
</script>


</body>