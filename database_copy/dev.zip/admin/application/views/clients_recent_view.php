<div class="container-fluid top-buffer">
	<div class="row" style="background-color:#fff; padding:5px; margin:5px;">
		<div class="column col-xs-12 text-center">
			<h3 style="margin-top:5px">Add Meaningful Use Client</h3>
		</div>

		<form id="defaultForm" method="" action="javascript:add_client()">
			<div class="column col-sm-5">
				<div class="form-group">
					<label class="control-label" for="client_name">Client Name</label>
	            	<input type="text" class="form-control" id="client_name" name="client_name" placeholder="Example Client Name" value="">
	          	</div>
			</div>

			<div class="column col-sm-3">
				<div class="form-group">
					<label class="control-label" for="account_number">Account Number</label>
	            	<input type="text" class="form-control" id="account_number" name="account_number" placeholder="1039XXXX" value="">
	          	</div>
			</div>

			<div class="column col-sm-3">
				<div class="form-group">
					<label class="control-label" for="cdh_number">CDH Number</label>
	            	<input type="text" class="form-control" id="cdh_number" name="cdh_number" placeholder="103XXXXX" value="">
	          	</div>
			</div>
			<div class="column col-sm-1">
				<div class="form-group" style="margin-top:22px">
					<button class="btn btn-primary" type="submit">Activate</button>
	          	</div>
			</div>
		</form>

		<div class="column col-xs-12" >

		    <div id="successBox" class="msgBox bg-success text-center">
		      The client has been successfully added.        
		    </div>

		    <div id="errorBox" class="msgBox bg-danger text-center">
		     	This client already exists.
		    </div>

		</div> 

	


		<div class="column col-xs-12" style="margin-top:20px; border-top:4px solid #008896;">
			<h4>The last 30 clients added for the Meaningful Use Packages are listed below. To check earlier clients, visit the Client Search Tab. </h4>

			<table id="recent_clients_table" class="table table-bordered table-condensed">
				<thead>
					<tr>
						<th>Client Name</th>
						<th>Account Number</th>
						<th>CDH Number</th>
						<th>Package</th>
						<th>Activation Date</th>
						<th>Check Live</th>
						<th colspan="2">Actions</th>
					</tr>
				</thead>

				<tbody>
					<?php 
						foreach ($recent_clients as $client) {
							echo '<tr id="client_row_'.$client["Id"].'">';
							echo '<td>'.$client["ClientName"].'</td>';
							echo '<td>'.$client["ClientId"].'</td>';
							echo '<td>'.$client["CDHNumber"].'</td>';
							echo '<td>'.$client["Package"].'</td>';
							echo '<td>'.$client["Date"].'</td>';
							echo '<td><a href="#">Check Live</a></td>';
							echo '<td> <a href="#" data-toggle="modal" data-target="#edit_client_modal"  onclick="open_edit_content_window('.$client["Id"].')"> <img src="'.base_url("assets/img/edit.png").'" alt="Edit" title="Edit"  /> </a></td>';
							echo '<td> <a href="javascript: delete_client('.$client["Id"].')" > <img src="'.base_url("assets/img/delete.png").'" alt="Delete" title="Delete"  /> </a></td>';
							echo '</tr>';
						}
					?>
				</tbody>
			</table>

		</div>		
	</div>
</div>


<div class="modal fade" id="edit_client_modal" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 id="edit_client_modal_title" class="modal-title">Edit Client</h4>
      </div>
      <div class="modal-body">
	      	<iframe id="edit_client_frame" width="100%" height="400px" src="" frameborder="0"></iframe>
      </div>
      <div class="modal-footer">	        
        <!-- <button id="forgot_submit_btn" type="button" class="btn btn-primary" onclick="fnForgotPassword()">Submit</button> -->
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



<script src="<?php echo base_url("assets/plugins/formvalidation-master/dist/js/formValidation.js"); ?>"></script> 
<script src="<?php echo base_url("assets/plugins/formvalidation-master/dist/js/framework/bootstrap.js"); ?>"></script>


<script type="text/javascript">
	var baseURL = <?php echo json_encode($baseURL) ?>;
	var img_path = <?php echo json_encode(base_url("assets/img") ) ?>;

	$('#defaultForm')
	    .formValidation({

	        message: 'This value is not valid',
	        icon: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },

	        fields: {
	        	client_name: {
	                validators: {
	                    notEmpty: {
	                        message: 'The client name is required'
	                    }
	                }
	            },	         
	            cdh_number: {
		                validators: {
		                    notEmpty: {},
		                    digits: {},
		                    greaterThan: {
		                        value: 10000000,
		                        message: 'Enter a valid 8 digit cdh number'
		                    }
		                }
		            },
	            account_number: {
	                validators: {
	                    notEmpty: {
	                        message: 'The account number is required'
	                    }
	                }
	            }
	            

	            	            
	           
	        }
	    })	
		.on('success.form.fv', function(e) {
            //console.log('success.form.fv');
            e.preventDefault();
            add_client();

            // If you want to prevent the default handler (formValidation._onSuccess(e))
            // 
        });
	

	function add_client(){
		$('#errorBox').hide();
		$('#successBox').hide();

		$.ajax({
	        type: "POST",
	        url: baseURL + "/clients/add_clients",
	        data: {
		        'client_name': $("#client_name").val(),
		        'account_number': $("#account_number").val(),
		        'cdh_number': $("#cdh_number").val()	        
	      	},
	        success: function(response)
	        {
	        	var responseObj = $.parseJSON(response);

	        	if(responseObj.status == "fail"){
	        		$('#errorBox').fadeIn();
	        	}else{      			
	        		var new_row = '<tr id="client_row_' + responseObj.client_details.Id + '">';
	        		new_row += '<td>' +  responseObj.client_details.ClientName + '</td>';
	        		new_row += '<td>' +  responseObj.client_details.ClientId + '</td>';
	        		new_row += '<td>' +  responseObj.client_details.CDHNumber + '</td>';
	        		new_row += '<td>MU2</td>';
	        		new_row += '<td>' +  responseObj.client_details.Date + '</td>';
	        		new_row += '<td><a href="#">Check Live</a></td>';
	        		new_row += '<td> <a href="javascript: fnEditClient(' + responseObj.client_details.Id + ')" > <img src="' + img_path +'/edit.png" alt="Edit" title="Edit"  /> </a></td>';
	        		new_row += '<td> <a href="javascript: delete_client(' + responseObj.client_details.Id + ')" > <img src="' + img_path +'/delete.png" alt="Delete" 	title="Delete"  /> </a></td>';
	        		new_row += '<tr>';

	        		$('#recent_clients_table > tbody > tr:first').before(new_row);
	        		
	        		$('#successBox').fadeIn();
	        		$('#defaultForm').get(0).reset();

	        	}
	    
	        }
	    });

	}


	function open_edit_content_window(client_id){  

	    var url = baseURL + "/clients/open_edit_client_window/" + client_id;    
	    console.log(url);
	    $("#edit_client_frame").attr('src', url);
	   
	}


	function delete_client(client_id){
		var confirm = window.confirm("Deleting the client is an irreversible action. Do you want to proceed?");

		if(confirm){

			$.ajax({
	          type: "POST",
	          url: baseURL + "/clients/delete_client",
	          data: {
	            'client_id': client_id	                   
	          },
	          success: function(response)
	          {	           
	            $('#client_row_' + response).remove();	            
	      
	          }
	      });


		}
	}
</script>