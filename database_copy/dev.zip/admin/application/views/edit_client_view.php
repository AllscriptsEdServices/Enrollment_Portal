<!DOCTYPE HTML>
<html lang="en" >
<head>
<meta charset="utf-8" />
<meta name="author" content="Vishwajit Menon" />
<title>i-Learn - Internal Admin</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">


<!-- Loading commonly used CSS -->
<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/css/admin_layout.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/formvalidation-master/dist/css/formValidation.css"); ?>" rel="stylesheet">

<script src="<?php echo base_url("assets/js/modernizr.custom.26324.js"); ?>"></script>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->


<script src="<?php echo base_url("assets/js/jquery-1.11.0.js"); ?>"></script> 
<script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>"></script> 

  
</head>

<body>
<div class="container-fluid top-buffer">
    
    <!--<div class="row">
    	<div class="col-xs-12 text-right">
         <?php echo json_encode($message); ?>
      </div>
    </div>-->

    <div class="row">   

      
      <form id="edit_client_form" method="" action="javascript:update_client()">

         <input type="hidden" class="form-control" id="client_id" name="client_id" value="<?php echo  $client_details["Id"] ?>">
         
         <table class="table table-bordered">
            <tr>
                <td>
                    <label class="control-label" for="client_name">Client Name</label>
                </td>
                <td>
                  <div class="form-group">
                    <input type="text"  class="form-control" id="client_name" name="client_name" placeholder="Enter Title" value="<?php echo $client_details["ClientName"]; ?>">
                  </div>
                </td>
            </tr>
            
            <tr>
                <td>
                    <label class="control-label" for="account_number">Account Number</label>
                </td>
                <td>
                  <div class="form-group">
                    <input type="text" class="form-control" id="account_number" name="account_number" placeholder="1000XXXX" value="<?php echo $client_details["ClientId"]; ?>">
                  </div>
                </td>
            </tr>

            <tr>
                <td>
                    <label class="control-label" for="cdh_number">CDH Number</label>
                </td>
                <td>
                  <div class="form-group">
                    <input type="text" class="form-control" id="cdh_number" name="cdh_number" placeholder="1000XXXX" value="<?php echo $client_details["CDHNumber"]; ?>">
                  </div>
                </td>
            </tr>
            
                 
            <tr>
               <td colspan="2" class="text-center">
                  <button type="submit" class="btn btn-primary center-block">Update Details</button>
               </td>
            </tr>

        </table>
       
      </form> 

   </div>


      <div class="row">      
        <div class="column col-xs-12" >

            <div id="successBox" class="feedback_div bg-success text-center" style="display:none">
              The client has been successfully updated.        
            </div>

            <div id="errorBox" class="feedback_div bg-danger text-center" style="display:none">
              This client number already exists.
            </div>

        </div> 
                
      </div>


</div>




<script src="<?php echo base_url("assets/plugins/formvalidation-master/dist/js/formValidation.js"); ?>"></script> 
<script src="<?php echo base_url("assets/plugins/formvalidation-master/dist/js/framework/bootstrap.js"); ?>"></script>

<script type="text/javascript">
	var baseURL = <?php echo json_encode($baseURL) ?>;   
  

    $(document).ready(function() {
      
       $('#edit_client_form')
        .formValidation({

            message: 'This value is not valid',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },

            fields: {
              client_name: {
                    validators: {
                        notEmpty: {
                            message: 'The client name is required'
                        }
                    }
                },           
                cdh_number: {
                      validators: {
                          notEmpty: {},
                          digits: {},
                          greaterThan: {
                              value: 10000000,
                              message: 'Enter a valid 8 digit cdh number'
                          }
                      }
                  },
                account_number: {
                    validators: {
                        notEmpty: {
                            message: 'The account number is required'
                        }
                    }
                }                           
               
            }
        })  
      .on('success.form.fv', function(e) {
          //console.log('success.form.fv');
          e.preventDefault();
          update_client(); 
      });
  

   });

    	

   function update_client(){

      $('#errorBox').hide();
      $('#successBox').hide();
      $.ajax({
          type: "POST",
          url: baseURL + "/clients/update_clients",
          data: {
            'client_id': $("#client_id").val(),
            'client_name': $("#client_name").val(),
            'account_number': $("#account_number").val(),
            'cdh_number': $("#cdh_number").val()          
          },
          success: function(response)
          {
            $('#successBox').fadeIn(); 
            /*var responseObj = $.parseJSON(response);

            if(responseObj.status == "fail"){
              $('#errorBox').fadeIn();
            }else{   
              
              $('#successBox').fadeIn();         

            }*/
            //  window.parent.update_content_display_row(content_details);
      
          }
      });

   }

	
</script>


</body>