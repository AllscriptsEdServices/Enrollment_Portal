<div class="container-fluid top-buffer">
	<div class="row content-holder">
		<div class="column col-sm-12 text-center">			
				<h3>Add Internal User</h3>
				<form id="site_user_form" action="javascript:add_site_user()" > 		


					<div class="column col-lg-3 col-xs-6">
						<div class="form-group">
							<label class="control-label" for="first_name">First Name</label>
							<input type="text" class="form-control" id="first_name" name="first_name" placeholder="e.g. John" value="">
						</div>
					</div>

					<div class="column col-lg-3 col-xs-6">
						<div class="form-group">
							<label class="control-label" for="last_name">Last Name</label>
							<input type="text" class="form-control" id="last_name" name="last_name" placeholder="e.g. Doe" value="">
						</div>
					</div>

					<div class="column col-lg-3 col-xs-6">
						<div class="form-group">
							<label class="control-label" for="email">Email</label>
							<input type="text" class="form-control" id="email" name="email" placeholder="e.g. john.doe@example.com" value="">
						</div>
					</div>

					<div class="column col-lg-3 col-xs-6">
						<div class="form-group">
							<label class="control-label" for="phone">User Rights</label>
							<select id="rights" name="rights" class="form-control" >
								<option value="content">Content</option>
								<option value="support">Support</option>
								<option value="super">Super</option>
							</select>							
						</div>
					</div>
					<div class="column col-xs-12 text-center">
						<button type="submit" id="add_admin_btn" class="btn btn-primary" >Add User</button>
						<div id="notify_success" class="bg-success text-center msgBox" style="margin-top:5px; padding:3px;"> 
							User added successfully!				
						</div>
					</div>

				</form>	
		</div>

		<div class="row" style="margin-top:220px">

			<div class="column col-sm-12">

				<table id="site_users_table" class="table table-bordered">
					<thead>
						<tr>
							<th>First Name</th>
							<th>Last Name</th>
							<th>Email</th>
							<th>Rights</th>
							<th>Action</th>
						</tr>
					</thead>				
					<tbody>
						<?php foreach ($all_site_users as $user) {
							echo '<tr id="user_row_'.$user["id"].'">';
							echo '<td>'.$user["first_name"].'</td>';
							echo '<td>'.$user["last_name"].'</td>';
							echo '<td>'.$user["email"].'</td>';
							echo '<td>'.$user["rights"].'</td>';
							echo '<td><a href="javascript:delete_site_user('.$user["id"].')" title="Delete user" name="Delete user"><img src="'.base_url("assets/img/delete.png").'" ></a></td>';
							echo '</tr>';
						}


						?>
					</tbody>
				</table>

			</div>

		</div>

	</div>

</div>

<script src="<?php echo base_url("assets/plugins/formvalidation-master/dist/js/formValidation.js"); ?>"></script> 
<script src="<?php echo base_url("assets/plugins/formvalidation-master/dist/js/framework/bootstrap.js"); ?>"></script>

<link rel="stylesheet" href="<?php echo base_url("assets/plugins/tablesorter-master/dist/css/theme.dropbox.min.css") ?>">
<script type="text/javascript" src="<?php echo base_url("assets/plugins/tablesorter-master/dist/js/jquery.tablesorter.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/tablesorter-master/dist/js/jquery.tablesorter.widgets.min.js") ?>"></script>

<script type="text/javascript">
	
	var baseURL = <?php echo json_encode($baseURL) ?>;
	var img_path = <?php echo json_encode(base_url("assets/img") ) ?>;
	
	

	$(function(){
		$("#site_users_table").tablesorter(
		{
			theme : 'dropbox',
		 
			//sortList : [[1,0],[2,0],[3,0]],
			//sortList : [[0,0]],
		 
		    // header layout template; {icon} needed for some themes
		    headerTemplate : '{content}{icon}',
		 
			// initialize column styling of the table
		    widgets : ["columns"],
			widgetOptions : {
		      // change the default column class names
		      // primary is the first column sorted, secondary is the second, etc
		      columns : [ "primary", "secondary", "tertiary" ]
			}
		});
	});

	$('#site_user_form')
	    .formValidation({

	        message: 'This value is not valid',
	        icon: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },

	        fields: {	        	
	            first_name: {
	                validators: {
	                    notEmpty: {
	                        message: 'The first name is required'
	                    }
	                }
	            },	
	            last_name: {
	                validators: {
	                    notEmpty: {
	                        message: 'The last name is required'
	                    }
	                }
	            },
	            rights: {
	                validators: {
	                    notEmpty: {
	                        message: 'The user rights need to be selected'
	                    }
	                }
	            },
	            email: {
		                validators: {
		                    notEmpty: {
		                        message: 'The email address is required'
		                    },
		                    emailAddress: {
		                        message: 'The input is not a valid email address'
		                    }
		                }
		            }		

	            	            
	           
	        }
	    })	
		.on('success.form.fv', function(e) {
            //console.log('success.form.fv');
            e.preventDefault();
            add_site_user();

            // If you want to prevent the default handler (formValidation._onSuccess(e))
            // 
        });



	function add_site_user(){

		console.log($("#rights").val())	  

	    $.ajax({
	      	type: "POST",
	      	url: baseURL + "/site_management/add_site_user",
	      	data: {	
		      'first_name': $("#first_name").val(),
		      'last_name': $("#last_name").val(),
		      'email': $("#email").val(),
		      'rights': $("#rights").val()		      
		    },
	      	success: function(response)
	      	{		      		
	      		if(response > 0){
	      			var new_user_row = '<tr id="user_row_' + response + '">';
	      			new_user_row += '<td>' + $("#first_name").val() + '</td>';
	      			new_user_row += '<td>' + $("#last_name").val() + '</td>';
	      			new_user_row += '<td>' + $("#email").val() + '</td>';
	      			new_user_row += '<td>' + $("#rights").val() + '</td>';
	      			new_user_row += '<td><a href="javascript:delete_site_user(' + response + ')" title="Delete user" name="Delete user" > <img src="' + img_path + '/delete.png" > </a> </td>';
	      			new_user_row += '</tr>'

	      			$('#site_users_table > tbody > tr:first').before(new_user_row);

	      			$('#notify_success').fadeIn();
	          		$('#notify_success').fadeOut(1600);

	      			$("#site_user_form").get(0).reset();

	      		}else{

	      			alert("A user with this email already exists in the system.");

	      		}	      				      		
	      		
	      	}

	    });
	}


	function delete_site_user(user_id){  	
	  	var confirm = window.confirm("Are you sure you want to delete this user?");

	  	if(confirm){
	  		$.ajax({
		        type: "POST",
		        url: baseURL + "/site_management/delete_site_user",
		        data: {
			        'user_id': user_id
		      	},
		        success: function(response)
		        {	  
		          if(response ){
		          	$('#user_row_' + user_id).remove();	
		          }
		        }
		    });

	  	}

	}

</script>