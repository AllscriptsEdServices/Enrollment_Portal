<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="utf-8" />
<meta name="author" content="Vishwajit Menon" />
<title>i-Learn MAVERICK</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/css/learn_new.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/select2-4.0.1/dist/css/select2.css"); ?>">


<style type="text/css">
  
</style>

</head>


<body>

<!-- navbar -->
<nav class="navbar navbar-default" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
      <!-- <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-main"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
      <a class="navbar-brand" id="brandName" ><img src="<?php echo base_url("assets/img/title.png"); ?>"/></a> 
      <div style="position:absolute; right:20px; top:30px" class="hidden-xs"><img src="<?php echo base_url("assets/img/powered_by.png"); ?>"></div>
      
    </div>
  

  </div>
</nav>
<!-- /navbar --> 


<div class="container-fluid mobile-offset-container">
  <div class="row">
  
    <div class="column col-md-8 col-sm-7" >

      <div class="left_main_body" >

        <ul class="nav nav-tabs nav-tabs-main" role="tablist">

          <?php foreach ($VERSIONS_ARRAY as $default_version):
              if($default_version == $url_version){ ?>

                <li role="presentation" class="active"><a href="#" onclick="version_tab_changed('<?php echo ($default_version); ?>')"  aria-controls="" role="tab" data-toggle="tab"><?php echo ($default_version); ?></a></li>

              <?php }else{ ?>

                <li role="presentation"><a href="#" onclick="version_tab_changed('<?php echo ($default_version); ?>')" aria-controls="" role="tab" data-toggle="tab"><?php echo ($default_version); ?></a></li>
              
            <?php }
            endforeach ?>
          
          <?php if($mu_status){ ?>
            <li role="presentation"><a href="#" aria-controls="" onclick = "show_mu_videos()" role="tab" data-toggle="tab">MU2</a></li>
          <?php } ?>
          <li role="presentation"><a href="#" aria-controls="" onclick = "show_master_videos_tab()" role="tab" data-toggle="tab">All Videos</a></li>
       
        </ul>

        <div class="sub_left_panel" >

          <div id="version_sub_menu">
            <ul class="nav nav-tabs nav-tabs-sub" role="tablist">
              <li id="screen_sub_tab"  role="presentation" class="nav_sub_tabs active"><a href="#" aria-controls="" onclick="show_version_urlscreen_tab()" role="tab" data-toggle="tab"><?php echo $url_screen_name ?></a></li>
              <li id="all_videos_sub_tab"  class="nav_sub_tabs" role="presentation"><a href="#" aria-controls="" onclick = "show_version_all_videos_tab()" role="tab" data-toggle="tab">View All</a></li>
              <li id="recommended_sub_tab" class="nav_sub_tabs" role="presentation"><a href="#" aria-controls="" onclick="show_version_recommended_tab()"  role="tab" data-toggle="tab" class="reco-sub-tab"><img width="16px" class="" src="<?php echo base_url("assets/img/recomm.png"); ?>"> <span class="hidden-xs" >Recommended Content</span></a></li>  
              <li id="recommended_sub_tab"  class="nav_sub_tabs" role="presentation"><a href="http://google.com" target="_blank" style="min-width:10px"  title="Manage Recommended Content" ><img width="16px" class=""  src="<?php echo base_url("assets/img/manage.png"); ?>"></a></li>             
            </ul>
          </div>

          <div id="mu_sub_menu">
            <ul class="nav nav-tabs nav-tabs-sub" role="tablist">
              <li id="mu2_first_sub_tab"  role="presentation" class="nav_sub_tabs active"><a href="#home" aria-controls="home" onclick="show_mu_videos()" role="tab" data-toggle="tab">Meaningful Use Stage 2</a></li>             
              <li id="mu2_recommended_sub_tab" class="nav_sub_tabs" role="presentation"><a href="#messages" aria-controls="messages" onclick="show_mu_recommended_tab()"  role="tab" data-toggle="tab" class="reco-sub-tab"><img width="16px" class=""  src="<?php echo base_url("assets/img/recomm.png"); ?>"> <span class="hidden-xs">Recommended Content</span></a></li>   
              <li id="recommended_sub_tab"  class="nav_sub_tabs" role="presentation"><a href="http://google.com" target="_blank" style="min-width:10px" title="Manage Recommended Content" ><img width="16px" class=""  src="<?php echo base_url("assets/img/manage.png"); ?>"></a></li>           
            </ul>
          </div>



          <div id="video_container" class="video_container" style="">

              <!-- <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="tab_13_0">Content 13.0</div>
                <div role="tabpanel" class="tab-pane" id="tab_14_1">Content 14.1</div>
                <div role="tabpanel" class="tab-pane" id="tab_14_2">Content 14.2</div>
                <div role="tabpanel" class="tab-pane" id="tab_all">Content All</div>
              </div> -->

            <div id="all_videos_filters_div" class="row all_videos_filters_div">

              <div class="column col-md-7 form-group" style="">
                  
                    <label for="version_keyword_selector" class="control-label hidden-sm hidden-xs" >Keywords</label>
                 
                    <select id="version_keyword_selector"  style="width:90%" multiple class="form-control">
                      <?php foreach($all_keyword_names as $keyword): ?>
                        <option value="<?php echo $keyword; ?>"><?php echo $keyword; ?></option>
                     <?php endforeach ?>
                  </select>
               
              </div>
                
              <div class="column col-md-5 form-group">
                <label for="version_screen_selector" class="control-label hidden-sm hidden-xs">Screen</label>
                <select id="version_screen_selector" style="width:90%" class="form-control" >
                    <option value="%%">All</option>
                    <?php foreach($all_screen_names as $screen_name): ?>
                      <option value="<?php echo $screen_name; ?>"><?php echo $screen_name; ?></option>
                   <?php endforeach ?>
                </select>
                </div>

            </div> <!-- End of /all_videos_filters_div  -->

            <div id="master_filters_div" class="row all_videos_filters_div">
              <div class="column col-xs-12 master_instruction_div">
                <p>You can use the filters below to narrow down on the videos as per your requirement.</p>
              </div>
              
              <div class="column col-md-5 form-group" style="">
                  <label for="master_keyword_selector" class="control-label hidden-sm hidden-xs" >Keywords</label>
                  <select id="master_keyword_selector" style="width:90%" multiple class="form-control">
                    <?php foreach($all_keyword_names as $keyword): ?>
                      <option value="<?php echo $keyword; ?>"><?php echo $keyword; ?></option>
                   <?php endforeach ?>
                </select>
              </div>
                
              <div class="column col-md-4 form-group">
                <label for="master_screen_selector" class="control-label hidden-sm hidden-xs">Screen</label>
                <select id="master_screen_selector" style="width:90%" class="form-control" >
                    <option value="%%">All</option>
                    <?php foreach($all_screen_names as $screen_name): ?>
                      <option value="<?php echo $screen_name; ?>"><?php echo $screen_name; ?></option>
                   <?php endforeach ?>
                </select>
              </div>

              <div class="column col-md-3 form-group">
                <label for="master_version_selector" class="control-label hidden-sm hidden-xs">Version</label>
                <select id="master_version_selector" style="width:90%" class="form-control" >
                    <option value="%%">All</option>
                    <?php foreach($VERSIONS_ARRAY as $default_version): ?>
                      <option value="<?php echo $default_version; ?>"><?php echo $default_version; ?></option>
                   <?php endforeach ?>
                </select>
              </div>


            

            </div> <!-- End of /all_videos_filters_div  -->



            <div id="videos_loader" style="display:none; position:absolute; top:60px; width:100%; height:100%; background-color:transparent; opacity:1; margin:-8px">
              <div style="width:32px; height:32px; position:absolute; top:100px; margin-top:16px; left:50%; margin-left:16px">
                <img src="<?php echo base_url("assets/img/facebook.gif"); ?>">
              </div>
            </div>

            <div id="video_dynamic_area">

              <!--  ALL VIDEOS WILL BE LOADED IN THIS CONTAINER     --> 
              
            </div>
              

          </div> <!-- End of video container -->

        </div >

      </div>

    </div> <!-- End of left column -->




  <!-- ********************************************  RIGHT COLUMN *************************************-->
    <div class="column col-md-4 col-sm-5" id="right_container">

      <div id="proSupDiv" class="right_sub_panels" style="">
        <h2 class="section_titles">Hot Topics</h2>
        <div id="hot_topic_container" class="video_container_hot_topic" style="">       

              <?php  foreach ($hot_topics as $video) : ?>
                  <a name="FALSE" id="98_course_HotTopic"  class="video_link_a" onclick="openContent()" data-toggle ="modal" data-target ="#video_modal"  data-courseid="8" data-coursetype="HotTopic"  data-link="../CourseLibrary/November-21-2013-191142/PEHR_MU_2_Subscription_Manager_ilearn.swf">
                    <div class="videoLink">
                      <table width="100%">
                        <tbody>
                          <tr>
                            <td width="40px" >
                              <div class="videoLinkImage">
                                <img src="<?php echo base_url("assets/img/play.png"); ?>" />
                              </div>
                            </td>
                            <td width="400px" class="hot_topic_text" ><?php echo $video["CourseTitle"] ?></td>                             
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </a>
                
              <?php endforeach?>
        </div>
      </div> 

      <div id="proSupDiv" class="right_sub_panels" style="">
        <h2 class="section_titles">Practice Recommended Resources</h2>
        <div id="video_container_2" class="video_container_hot_topic" style="">
            <?php echo var_dump($recommended_videos_MU2); ?>
        </div>
      </div> 


    </div> <!-- End of Main Right Column -->

  </div> <!-- End of main row -->

</div>   


<div class="modal fade autoModal" id="video_modal" data-keyboard="false" >
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->

      <!-- <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 id="" class="modal-title">Video Name</h4>
      </div> -->

      <div class="modal-body" id="video-modal-body">
          <!-- <iframe id="video_play_frame" width="100%" height="658px" src="" style="padding:10px" frameborder="0px"></iframe> -->
      </div>

     <!--  <div class="modal-footer"> 

        <form style="display: none;" action="recordComments.php" method="POST">
          <input name="courseId" disabled="" id="courseId" type="text" value="98"><input name="screenName" id="screenName" type="text" value="disabled"><input name="productVersion" id="productVersion" type="text" value="disabled"><input name="clientId" disabled="" id="clientId" type="text" value="500"><input name="user" disabled="" id="user" type="text" value="VMenon"><input name="usertype" disabled="" id="usertype" type="text" value="admin"><input name="clientScreen" disabled="" id="clientScreen" type="text" value="Appointments"><input name="clientVersion" disabled="" id="clientVersion" type="text" value="14.2"><input name="courseType" disabled="" id="courseType" type="text" value="HotTopic"><input name="courseTitle" disabled="" id="courseTitle" type="text" value="Mapping Italicized DX Codes">
        </form>

        <div id="divTable"><table width="100%" height="40" border="0"><tbody><tr><td width="10"></td><td width="73"><div id="aLike" style="margin: 0px; border: currentColor; border-image: none; cursor: pointer;"><img id="likeDiv" src="<?php echo base_url('assets/');?>/img/likeBTN_active.png"></div></td><td width="73"><div id="aDislike" style="margin: 0px; border: currentColor; border-image: none; cursor: pointer;"><img id="dislikeDiv" src="<?php echo base_url('assets/');?>/img/DislikeBTN_active.png"></div></td><td width="240"></td><td width="60" style="text-align: right; color: rgb(51, 51, 51); font-family: Arial; font-size: 15px;"><span id="totalViews_98_HotTopic">2540</span>&nbsp;views</td><td width="55" style="color: rgb(127, 127, 127); font-size: 11px;"><div style="margin-left: 5px; display: table;"><img class="tableImg" src="<?php echo base_url('assets/');?>/img/grey-like.png">&nbsp;<div id="likes_span_98_HotTopic" style="vertical-align: middle; display: table-cell;">36</div></div></td><td width="55" style="color: rgb(127, 127, 127); font-size: 11px;"><div style="margin-left: 5px; display: table;"><img class="tableImg" src="<?php echo base_url('assets/');?>/img/grey-dislike.png">&nbsp;<div id="dislikes_span_98_HotTopic" style="vertical-align: middle; display: table-cell;">5</div></div></td><td width="10"></td></tr></tbody></table></div>

      </div> -->
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



<!-- footer -->
<footer>
  <div class="container-fluid">
    <div class="row">
      <div class="col-xs-12 footer-div">
        <a href="http://www.surveymonkey.com/s/VN8LTDR" target="_blank">Let us know what you think.</a>
      </div>
    </div>    
  </div>
</footer>
<!-- /footer --> 


<!-- js --> 
<script src="<?php echo base_url("assets/js/jquery-1.11.0.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/home.js"); ?>"></script>
<script src="<?php echo base_url("assets/plugins/select2-4.0.1/dist/js/select2.js"); ?>"> </script>

<script type="text/javascript">
  var baseURL = <?php echo json_encode($baseURL); ?>;
  var img_path = <?php echo json_encode(base_url("assets/img") ) ?>;
  var course_library_path = <?php echo json_encode(base_url("course_library") ) ?>;

  var url_screen_name = <?php echo json_encode($url_screen_name); ?>;
  var url_version = <?php echo json_encode($url_version); ?>;
  var current_selected_version = <?php echo json_encode($url_version); ?>;
  var analytic_model_flag = <?php echo json_encode($analytic_model_flag); ?>;


  $(document).ready(function() { 
    //http://select2.github.io/select2/
    $("#version_keyword_selector").select2({
        placeholder: "Select keywords..",       
        allowClear: true
    }); 
    $("#version_screen_selector").select2({
        placeholder: "Select screen..",        
        closeOnSelect:true     
    });    


    $("#master_keyword_selector").select2({
        placeholder: "Select keywords..",
        allowClear: true
    }); 
    $("#master_screen_selector").select2({
        placeholder: "Select screen..",        
        closeOnSelect:true     
    }); 
    $("#master_version_selector").select2({
        placeholder: "Select version..",       
        closeOnSelect:true     
    });


    $(document).on('click','.video_link_a',function() {
    
      /*var coursetype = $(this).attr("data-coursetype");
      var courseid = $(this).attr("data-courseid");      
      openContent(coursetype, courseid);   */

      var fileurl = course_library_path + "/" + $(this).attr("data-fileurl");
      open_video_directly(fileurl);

    });
   
    show_version_urlscreen_tab();
  });
  

</script>

</body>
</html>