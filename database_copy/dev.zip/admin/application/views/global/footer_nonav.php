<footer class='bottom-footer'>
	<!-- Allscripts Education Services -->
</footer>

</body>

</html>