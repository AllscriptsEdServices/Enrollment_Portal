<div class="container-fluid top-buffer">
	<div class="row content-holder">
		<div class="column col-sm-4">

			<form id="add_screen_form" action="javascript:add_screen()">
				<div class="text-center" style="width:100%">
					<h4>Screen Names</h4>
					<div class="input-group">
				      <input type="text" class="form-control" id="new_screen" name="new_screen" placeholder="Screen name">
				      <span class="input-group-btn">
				        <button id="add_screen_btn" class="btn btn-primary" type="submit" disabled>Add Screen</button>
				      </span>
				    </div><!-- /input-group -->			

				</div>
			</form>

			<div id="notify_screen" class="bg-success text-center msgBox" style="margin-top:5px; padding:3px;"> 
				Screen added successfully!				
			</div>

			<table class="table table-bordered table-condensed top-buffer" >
				<thead>
					<tr>
						<th>Screen Name</th>
						<th>Action</th>
					</tr>
				</thead>
			<?php 
				foreach ($all_screen_names as $single_screen) {
					echo '<tr id="screen_'.$single_screen.'">';
					echo '<td>'.$single_screen.'</td>';
					echo '<td align="center"><a href="javascript:delete_screen(\''.$single_screen.'\')" title="Delete screen" name="Delete screen"><img src="'.base_url("assets/img/delete.png").'" ></a></td>';
					echo '</tr>';
				}
			?>
			</table>
		</div>


		<div class="column col-sm-4">

			<form id="add_sub_screen_form" action="javascript:add_sub_screen()">
				<div class="text-center" style="width:100%">
					<h4>Sub Screen Names</h4>
					<div class="input-group">
				      <input type="text" class="form-control" id="new_sub_screen" name="new_sub_screen" placeholder="Sub screen name">
				      <span class="input-group-btn">
				        <button id="add_sub_screen_btn" class="btn btn-primary" type="submit" disabled>Add Sub Screen</button>
				      </span>
				    </div><!-- /input-group -->			

				</div>
			</form>

			<div id="notify_sub_screen" class="bg-success text-center msgBox" style="margin-top:5px; padding:3px;"> 
				Sub screen added successfully!				
			</div>

			<table class="table table-bordered table-condensed top-buffer" >
				<thead>
					<tr>
						<th>Sub Screen Name</th>
						<th>Action</th>
					</tr>
				</thead>
			<?php 
				foreach ($sub_screen_names as $single_sub_screen) {
					echo '<tr id="sub_'.$single_sub_screen.'">';
					echo '<td>'.$single_sub_screen.'</td>';					
					echo '<td align="center"><a href="javascript:delete_sub_screen(\''.$single_sub_screen.'\')" title="Delete sub screen" name="Delete sub screen"><img src="'.base_url("assets/img/delete.png").'" ></a></td>';
					echo '</tr>';
				}
			?>
			</table>
		</div>


		<div class="column col-sm-4">

			<form id="add_keyword_form" action="javascript:add_keyword()">
				<div class="text-center" style="width:100%">
					<h4>Keywords</h4>
					<div class="input-group">
				      <input type="text" class="form-control" id="new_keyword" name="new_keyword" placeholder="Keyword">
				      <span class="input-group-btn">
				        <button id="add_keyword_btn" class="btn btn-primary" type="submit" disabled>Add Keyword</button>
				      </span>
				    </div><!-- /input-group -->			

				</div>
			</form>

			<div id="notify_keyword" class="bg-success text-center msgBox" style="margin-top:5px; padding:3px;"> 
				Keyword added successfully!				
			</div>

			<table class="table table-bordered table-condensed top-buffer" >
				<thead>
					<tr>
						<th>Keyword Name</th>
						<th>Action</th>
					</tr>
				</thead>
			<?php 
				foreach ($all_keyword_names as $keyword) {
					echo '<tr id="keyword_'.$keyword.'">';
					echo '<td>'.$keyword.'</td>';
					echo '<td align="center"><a href="javascript:delete_keyword(\''.$keyword.'\')" title="Delete keyword" name="Delete keyword"><img src="'.base_url("assets/img/delete.png").'" ></a></td>';
					echo '</tr>';
				}
			?>
			</table>


			

		</div>

		

	</div>

</div>


<script type="text/javascript">
	var baseURL = <?php echo json_encode($baseURL) ?>;

	$(document).ready(function(){

		$("#new_screen").keyup(function(){			
			var enable_flag = ($.trim($("#new_screen").val())!="") ? false: true;
			$("#add_screen_btn").attr("disabled", enable_flag);
		});

		$("#new_sub_screen").keyup(function(){			
			var enable_flag = ($.trim($("#new_sub_screen").val())!="") ? false: true;
			$("#add_sub_screen_btn").attr("disabled", enable_flag);
		})

		$("#new_keyword").keyup(function(){			
			var enable_flag = ($.trim($("#new_keyword").val())!="") ? false: true;
			$("#add_keyword_btn").attr("disabled", enable_flag);
		})



	})
	function add_screen(){
		
	  	$.ajax({
	        type: "POST",
	        url: baseURL + "/configuration/add_screen",
	        data: {
		        'screen': $("#new_screen").val()
	      	},
	        success: function(response)
	        {

	         //alert(response)
	          if(response>0){
	          	$('#notify_screen').html("Screen successfully added!");
	          	$('#notify_screen').addClass("bg-success");
	          	$('#notify_screen').fadeIn();
	          	$('#notify_screen').fadeOut(1600);
	          	$("#add_screen_form").get(0).reset();
	          }else{
	          	$('#notify_screen').html("This screen already exists.");
	          	$('#notify_screen').addClass("bg-danger");
	          	$('#notify_screen').fadeIn();
	          	$('#notify_screen').fadeOut(1600);
	          }
	        }
	    });
   }


   function add_sub_screen(){		

	  	$.ajax({
	        type: "POST",
	        url: baseURL + "/configuration/add_sub_screen",
	        data: {
		        'sub_screen': $("#new_sub_screen").val()
	      	},
	        success: function(response)
	        {
	          console.log("here");
	          if(response>0){
	          	$('#notify_sub_screen').html("Sub screen successfully added!");
	          	$('#notify_sub_screen').addClass("bg-success");
	          	$('#notify_sub_screen').fadeIn();
	          	$('#notify_sub_screen').fadeOut(1600);
	          	$("#add_sub_screen_form").get(0).reset();
	          }else{
	          	$('#notify_sub_screen').html("This sub screen already exists.");
	          	$('#notify_sub_screen').addClass("bg-danger");
	          	$('#notify_sub_screen').fadeIn();
	          	$('#notify_sub_screen').fadeOut(1600);
	          }
	        }
	    });
   }


	function add_keyword(){
		
	  	$.ajax({
	        type: "POST",
	        url: baseURL + "/configuration/add_keyword",
	        data: {
		        'keyword': $("#new_keyword").val()
	      	},
	        success: function(response)
	        {
	         //alert(response)
	          if(response>0){
	          	$('#notify_keyword').html("Keyword successfully added!");
	          	$('#notify_keyword').addClass("bg-success");
	          	$('#notify_keyword').fadeIn();
	          	$('#notify_keyword').fadeOut(1600);
	          	$("#add_keyword_form").get(0).reset();
	          }else{
	          	$('#notify_keyword').html("This keyword already exists.");
	          	$('#notify_keyword').addClass("bg-danger");
	          	$('#notify_keyword').fadeIn();
	          	$('#notify_keyword').fadeOut(1600);
	          }
	        }
	    });
  }


  function delete_screen(screen_name){  	
  	var confirm = window.confirm("Are you sure you want to delete the screen - " + screen_name + "?");

  	if(confirm){
  		$.ajax({
	        type: "POST",
	        url: baseURL + "/configuration/delete_screen",
	        data: {
		        'screen': screen_name
	      	},
	        success: function(response)
	        {	  
	          if(response == "success"){
	          	$('#screen_' + screen_name).remove();	          	
	          }else{
	          	alert("Some error occured. Please try again.")
	          }
	        }
	    });

  	}

  }


  function delete_sub_screen(sub_screen_name){  	
  	var confirm = window.confirm("Are you sure you want to delete the sub screen - " + sub_screen_name + "?");

  	if(confirm){
  		$.ajax({
	        type: "POST",
	        url: baseURL + "/configuration/delete_sub_screen",
	        data: {
		        'sub_screen': sub_screen_name
	      	},
	        success: function(response)
	        {	  
	          if(response == "success"){
	          	$('#sub_' + sub_screen_name).remove();	          	
	          }else{
	          	alert("Some error occured. Please try again.")
	          }
	        }
	    });

  	}

  }

  function delete_keyword(keyword){  	
  	var confirm = window.confirm("Are you sure you want to delete the keyword - " + keyword + "?");

  	if(confirm){
  		$.ajax({
	        type: "POST",
	        url: baseURL + "/configuration/delete_keyword",
	        data: {
		        'keyword': keyword
	      	},
	        success: function(response)
	        {	  
	          if(response == "success"){
	          	$('#keyword_' + keyword).remove();	          	
	          }else{
	          	alert("Some error occured. Please try again.")
	          }
	        }
	    });

  	}

  }


</script>