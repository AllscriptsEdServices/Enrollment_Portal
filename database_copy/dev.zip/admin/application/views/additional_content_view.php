
<div class="container-fluid top-buffer">

    <div id="notification-div" class="notify-green">
      Content published successfully
    </div>

    <div class="row">
    	<div class="col-xs-12 text-right"><button class="btn btn-primary" data-toggle="modal" data-target="#edit_content_modal" onclick="open_add_content_window()">Add MU Content</button></div>
    </div>

    <div class="row content-holder">
    	<table id="content_table" class="table table-bordered">
    		<thead>
    			<tr>
    				<th>Content Title</th>
    				<th>Screen Name</th>
    				<th>Content Type</th>
            <th class="hidden-sm hidden-xs">Keywords</th>
    				<th>Version</th>
    				<th class="hidden-sm hidden-xs">Duration</th>
    				<th class="hidden-sm hidden-xs">SWF File</th>
            <!-- <th class="hidden-sm hidden-xs">Likes</th>
            <th class="hidden-sm hidden-xs">Dislikes</th> -->
    				<th colspan="3">Actions</th>
    			</tr>
    		</thead>
    		<tbody>
    			<?php 
    				foreach ($all_videos as $single_video) {
    					echo '<tr id="row_'.$single_video["Id"].'">';
              if($single_video["FileURL"]=="Not Set"){
                echo '<td id="cell_CourseTitle_'.$single_video["Id"].'">'.$single_video["CourseTitle"].'</td>';
              }else{
                echo '<td id="cell_CourseTitle_'.$single_video["Id"].'"><a id="content_link_'.$single_video["Id"].'" href="#" onclick="load_play_content('.$single_video["Id"].')" data-location="'.$single_video["FileURL"].'" data-title="'.$single_video["CourseTitle"].'" data-toggle="modal" data-target="#content_play_modal">'.$single_video["CourseTitle"].' </a></td>';
              }

    					//echo '<td id="cell_CourseTitle_'.$single_video["Id"].'"><a id="content_link_'.$single_video["Id"].'" href="#" onclick="load_play_content('.$single_video["Id"].')" data-location="'.$single_video["FileURL"].'" data-title="'.$single_video["CourseTitle"].'" data-toggle="modal" data-target="#content_play_modal">'.$single_video["CourseTitle"].' </a></td>';
    					echo '<td id="cell_ScreenName_'.$single_video["Id"].'">'.$single_video["ScreenName"].'</td>';
    					echo '<td id="cell_CourseType_'.$single_video["Id"].'">'.$single_video["CourseType"].'</td>';
              echo '<td id="cell_Keywords_'.$single_video["Id"].'" class="hidden-sm hidden-xs">'.$single_video["Keywords"].'</td>';
    					echo '<td id="cell_ProductVersion_'.$single_video["Id"].'">'.$single_video["ProductVersion"].'</td>';
    					echo '<td id="cell_Duration_'.$single_video["Id"].'" class="hidden-sm hidden-xs">'.$single_video["Duration"].'</td>';
    					$swf_url = "../../".$single_video["oldURL"];
              echo '<td class="hidden-sm hidden-xs"><a href="'.$swf_url.'" target="_blank">Open</a></td>';
              /*echo '<td class="hidden-sm hidden-xs"></td>';
              echo '<td class="hidden-sm hidden-xs"></td>';*/
    					echo '<td><a href="#" id="edit_content_btn_'.$single_video["Id"].'" title="Edit Content" name="Edit Content" data-toggle="modal" data-target="#edit_content_modal" data-content-title="'.$single_video["CourseTitle"].'" onclick="open_edit_content_window('.$single_video["Id"].')"><img src="'.base_url("assets/img/edit.png").'" ></a></td>';
    					echo '<td><a href="javascript:delete_content('.$single_video["Id"].')" title="Delete Content" name="Delete Content"><img src="'.base_url("assets/img/delete.png").'" ></a></td>';
    					if($single_video["Status"] == 1){
    						echo '<td id="cell_Status_'.$single_video["Id"].'" ><a href="javascript:un_publish_content('.$single_video["Id"].')" title="Unpublish" name="Unpublish"><img src="'.base_url("assets/img/unpublish.png").'" ></a></td>';
    					}else{
    						echo '<td id="cell_Status_'.$single_video["Id"].'" ><a href="javascript:publish_content('.$single_video["Id"].')" title="Publish" name="Publish"><img src="'.base_url("assets/img/publish.png").'" ></a></td>';
    					}
    					
    					echo '</tr>';
    				}
    			?>
    		</tbody>
    	</table>
    </div>

</div>

<div class="modal fade" id="edit_content_modal" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 id="edit_content_modal_title" class="modal-title">Edit</h4>
      </div>
      <div class="modal-body">
	      	<iframe id="edit_content_frame" width="100%" height="560px" src="" frameborder="0"></iframe>
      </div>
      <div class="modal-footer">	        
        <!-- <button id="forgot_submit_btn" type="button" class="btn btn-primary" onclick="fnForgotPassword()">Submit</button> -->
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<div class="modal fade" id="content_play_modal" width="1500px" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-lg custom-modal">
    <div class="modal-content ">
      <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <!-- <h4 id="content_play_modal_title" class="modal-title">Edit</h4> -->
      </div>
      <div id="video_container" class="modal-body content-modal-body">
          <iframe id="content_play_frame" width="100%" height="650px" src="" style="overflow:hidden"frameborder="0"></iframe>
      </div>
      <!-- <div class="modal-footer">          
        
      </div> -->
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!-- Preload the hover images -->
<div class="hidden">
  
</div>



<link rel="stylesheet" href="<?php echo base_url("assets/plugins/tablesorter-master/dist/css/theme.green.min.css") ?>">
<script type="text/javascript" src="<?php echo base_url("assets/plugins/tablesorter-master/dist/js/jquery.tablesorter.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/tablesorter-master/dist/js/jquery.tablesorter.widgets.min.js") ?>"></script>

<script type="text/javascript">
	var baseURL = <?php echo json_encode($baseURL) ?>;
	var img_path = <?php echo json_encode(base_url("assets/img") ) ?>;
  var course_library = <?php echo json_encode(base_url("course_library") ) ?>;
  var blank_page =  course_library + "/blank/main.html";

	$(function(){
		$("#content_table").tablesorter(
		{
			 theme : 'green',
		 
			 //sortList : [[1,0],[2,0],[3,0]],
			 //sortList : [[0,0]],
		 
		    // header layout template; {icon} needed for some themes
		    headerTemplate : '{content}{icon}',
		 
			 //initialize column styling of the table
		    widgets : ["columns"],
			  widgetOptions : {
		    // change the default column class names
		    // primary is the first column sorted, secondary is the second, etc
		    columns : [ "primary", "secondary", "tertiary" ]
			}
		});
		
	});
	
  $(document).ready(function(){
    $('#content_play_modal').on('hidden.bs.modal', function () {
      // # CODE TO EXECUTE UPON MODAL CLOSE+
      //  Loading the iframe with a blank page to enable clearing
      //$("#content_play_frame").attr('src', blank_page);   

      //Removing the iframe altogether, upon modal close
      var frame = document.getElementById("content_play_frame");
      frame.parentNode.removeChild(frame);      
    })
  })



	function open_edit_content_window(contentId){	   
    var content_title = $("#edit_content_btn_"+contentId).attr('data-content-title');
    $("#edit_content_modal_title").html("<b>Edit | "+content_title + "</b>");

    var url = baseURL + "/edit_content/open_mu_update_window/" + contentId;    
    console.log(url);
    $("#edit_content_frame").attr('src', url);   
  }


  function load_play_content(contentId){
    var content_title = $("#content_link_"+contentId).attr('data-title');
     $("#content_play_modal_title").html("<b>"+content_title + "</b>");

    var content_location = $("#content_link_"+contentId).attr('data-location');
    //var url =  "/iLearn_Maverick/course_library/" + content_location ;

    $("#video_container").html('<iframe id="content_play_frame" width="100%" height="650px" src="" style="overflow:hidden"frameborder="0"></iframe>');

    //var url =  course_library + "/" + content_location;
    var url =  "../../course_library/" + content_location;
    console.log(url);
    $("#content_play_frame").bind("load", video_frame_loaded); 
    $("#content_play_frame").attr('src', url);   

  }



  function video_frame_loaded(){
    //alert("video loaded");
    $("#content_play_frame").unbind("load", video_frame_loaded); 
    var _theframe = document.getElementById("content_play_frame");
    _theframe.contentWindow.location.href = _theframe.src;

    //document.getElementById("content_play_frame").contentWindow.location.reload(true); 
  }


  function publish_content(contentId){   

  	$.ajax({
        type: "POST",
        url: baseURL + "/additional_content/change_status_value",
        data: {
	        'contentId': contentId,
	        'contentType': "MU2",
	        'action': "publish"       
      	},
        success: function(response)
        {
          $("#cell_Status_" + contentId).html('<a href="javascript:un_publish_content('+contentId+')"> <img src="' + img_path + '/unpublish.png" > </a>');
          var this_div_x = getOffset( document.getElementById('edit_content_btn_'+contentId) ).left; 
          var this_div_y = getOffset( document.getElementById('edit_content_btn_'+contentId) ).top;     
          show_notification_bar(this_div_x, this_div_y, "publish");
        }
    });
  }


  function un_publish_content(contentId){
    
  	$.ajax({
        type: "POST",
        url: baseURL + "/additional_content/change_status_value",
        data: {
	        'contentId': contentId,
	        'contentType': "MU2",
	        'action': "unpublish"	        
      	},
        success: function(response)
        {
          $("#cell_Status_" + contentId).html('<a href="javascript:publish_content('+contentId+')"><img src="' + img_path + '/publish.png" ></a>');
          var this_div_x = getOffset( document.getElementById('edit_content_btn_'+contentId) ).left; 
          var this_div_y = getOffset( document.getElementById('edit_content_btn_'+contentId) ).top;           
          show_notification_bar(this_div_x, this_div_y, "unpublish");
        }
    });
  }

  function delete_content(contentId){
    var confirm = window.confirm("This action cannot be reversed. Proceed to delete content?");

    if(confirm){
      $.ajax({
          type: "POST",
          url: baseURL + "/additional_content/delete_content",
          data: {
            'contentId': contentId,
            'contentType': "MU2"               
          },
          success: function(response)
          {           
            $('table#content_table tr#row_' + contentId).remove();
          }
      });
    }
    
  }


  // If course is updated in modal, update main page table row with json obejct passed. Cells identified by Id
  function update_content_display_row(content_details){
  	var course_link = '<a id="content_link_' + content_details.Id + '" href="#" onclick="load_play_content(' + content_details.Id + ')" data-location="' + content_details.FileURL + '" data-title="' + content_details.CourseTitle + '" data-toggle="modal" data-target="#content_play_modal">' + content_details.CourseTitle + ' </a>';

  	$("#cell_CourseTitle_" + content_details.Id).html(course_link);
  	$("#cell_ScreenName_" + content_details.Id).html(content_details.ScreenName);
    $("#cell_Keywords_" + content_details.Id).html(content_details.Keywords);
  	$("#cell_ProductVersion_" + content_details.Id).html(content_details.ProductVersion);
  	$("#cell_Duration_" + content_details.Id).html(content_details.Duration);
  	//$("#cell_CourseType_").html(content_details.CourseType); 		

  }
	

  function add_content_display_row(content_details){
    var new_row = '<tr id="row_' + content_details.Id + '">';
    new_row += '<a id="content_link_' + content_details.Id + '" href="#" onclick="load_play_content(' + content_details.Id + ')" data-location="' + content_details.FileURL + '" data-title="' + content_details.CourseTitle + '" data-toggle="modal" data-target="#content_play_modal">' + content_details.CourseTitle + ' </a>';

    new_row += '<td id="cell_ScreenName_'+ content_details.Id + '">' + content_details.ScreenName + '</td>';
    new_row += '<td id="cell_CourseType_'+ content_details.Id + '">' + content_details.CourseType + '</td>';
    new_row += '<td id="cell_Keywords_'+ content_details.Id + '" class="hidden-sm hidden-xs" >' + content_details.Keywords + '</td>';
    new_row += '<td id="cell_ProductVersion_'+ content_details.Id + '">' + content_details.ProductVersion + '</td>';
    new_row += '<td id="cell_Duration_'+ content_details.Id + '" class="hidden-sm hidden-xs" >' + content_details.Duration + '</td>';
    new_row += '<td class="hidden-sm hidden-xs"></td>';
    new_row += '<td class="hidden-sm hidden-xs"></td>';
    new_row += '<td><a href="#" id="edit_content_btn_'+ content_details.Id + '" data-toggle="modal" data-target="#edit_content_modal" data-content-title="' + content_details.CourseTitle + '" onclick="open_edit_content_window('+ content_details.Id + ')"><img src="' + img_path + '/edit.png" ></a></td>';
    new_row += '<td><a href="#"><img src="' + img_path + '/delete.png" ></a></td>';
    new_row += '<td id="cell_Status_'+ content_details.Id + '" ><a href="javascript:publish_content(' + content_details.Id + ')" ><img src="' + img_path + '/publish.png" ></a></td>';
    new_row += '<tr>';

    $('#content_table > tbody > tr:first').before(new_row);
    
  }


  function getOffset(el) {
    var _x = 0;
    var _y = 0;
    while( el && !isNaN( el.offsetLeft ) && !isNaN( el.offsetTop ) ) {
        _x += el.offsetLeft - el.scrollLeft;
        _y += el.offsetTop - el.scrollTop;
        el = el.offsetParent;
    }
    return { top: _y, left: _x };
  }

  //Show notification floating div for status of the publish/unpublish function
  function show_notification_bar(div_left_pos, div_top_pos, action){ 

    $("#notification-div").css({top: (div_top_pos-8), left: (div_left_pos-150), position:'absolute', display:'none'});

    if(action=="publish"){
      $("#notification-div").removeClass("notify-red");
      $("#notification-div").addClass("notify-green");
      $("#notification-div").html("Content published successfully.");
    }else{
      $("#notification-div").removeClass("notify-green");
      $("#notification-div").addClass("notify-red");
      $("#notification-div").html("Content unpublished. No longer visible to clients.");
    }
    
 
    $("#notification-div").show();
    $("#notification-div").animate({ left: "-=50px",}, 400 );
    $("#notification-div").fadeOut(1800);

  }


</script>
