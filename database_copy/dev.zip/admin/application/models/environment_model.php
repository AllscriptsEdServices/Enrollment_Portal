<?php
Class Environment_Model extends CI_Model
{

  var $client_selected_roles = array(); 
  var $ilearn_meta_file;
  //base_url("index.php/");
  var $all_screens_array = array();
 
  public function __construct()
  {
    $this->load->database();
    $this->ilearn_meta_file = base_url("meta_data/ilearn_config.xml");
    $this->load->helper('xml');
  }

  function get_screen_names(){
    $query = $this->db->get('screen_names');
    $resultArray = $query->result_array();

    $all_screens_array = array();
    foreach ($resultArray as $single_result) {
      array_push($all_screens_array, $single_result["screen_name"]);      
    }
    usort($all_screens_array, 'strcasecmp');

    return $all_screens_array;
  }

  function get_sub_screen_names(){
    $query = $this->db->get('sub_screen_names');
    $resultArray = $query->result_array();

    $sub_screens_array = array();
    foreach ($resultArray as $single_result) {
      array_push($sub_screens_array, $single_result["sub_screen_name"]);      
    }
    usort($sub_screens_array, 'strcasecmp');

    return $sub_screens_array;
  }

   function get_keyword_names(){
    $query = $this->db->get('keywords_tb');
    $resultArray = $query->result_array();
    $all_keywords_array = array();
    foreach ($resultArray as $single_result) {
      array_push($all_keywords_array, $single_result["keyword_name"]);
    }
    usort($all_keywords_array, 'strcasecmp');

    return $all_keywords_array;
  }

  

  function add_screen($screen){
    $query = $this->db->get_where('screen_names', array('screen_name'=>$screen));

    if($query->num_rows() > 0){
      return 0;
    }else{
      $insert_array =array(
                        "screen_name"=>$screen
                      );
      $this->db->insert("screen_names", $insert_array);
      return $this->db->insert_id();

    }
    
  }
  
  function add_sub_screen($sub_screen){
    $query = $this->db->get_where('sub_screen_names', array('sub_screen_name'=>$sub_screen));

    if($query->num_rows() > 0){
      return 0;
    }else{
      $insert_array =array(
                        "sub_screen_name"=>$sub_screen
                      );
      $this->db->insert("sub_screen_names", $insert_array);
      return $this->db->insert_id();

    }
    
  }

  function add_keyword($keyword){
    $query = $this->db->get_where('keywords_tb', array('keyword_name'=>$keyword));

    if($query->num_rows() > 0){
      return 0;
    }else{
      $insert_array =array(
                        "keyword_name"=>$keyword
                      );         
      $this->db->insert("keywords_tb", $insert_array);
      return $this->db->insert_id();

    }
    
  }


   function delete_screen($screen){
    $query = $this->db->get_where('screen_names', array('screen_name'=>$screen));

    if($query->num_rows() > 0){

        $this->db->where(array('screen_name' => $screen));
        $this->db->delete("screen_names");
        return "success";

    }else{

        return "fail";
        
    }
    
  }


  function delete_sub_screen($sub_screen){
    $query = $this->db->get_where('sub_screen_names', array('sub_screen_name'=>$sub_screen));

    if($query->num_rows() > 0){

        $this->db->where(array('sub_screen_name' => $sub_screen));
        $this->db->delete("sub_screen_names");
        return "success";

    }else{

        return "fail";

    }
    
  }


  function delete_keyword($keyword){
    $query = $this->db->get_where('keywords_tb', array('keyword_name'=>$keyword));

    if($query->num_rows() > 0){

        $this->db->where(array('keyword_name' => $keyword));
        $this->db->delete("keywords_tb");
        return "success";

    }else{

        return "fail";
        
    }
    
  }

  


}  // End of Class Declaration


?>