<?php
Class Analytics_Model extends CI_Model
{

  
  public function __construct()
  {
    $this->load->database();
  }

  
  function get_videos_visited_status($videos_array, $user, $client_number){

    foreach ($videos_array as $key => $single_video) {
      $this->db->select('Id');
      $this->db->from('recordcomments');    
      $this->db->where(array('courseId' => $single_video['Id'], 'courseType'=>$single_video['CourseType'], 'user'=>$user, 'clientId'=>$client_number));
      $query = $this->db->get();
      if($query->num_rows()>0){
        $videos_array[$key]["viewed"] = true;
      }else{
        $videos_array[$key]["viewed"] = false;
      }

    }

    return $videos_array;
  }


  


}  // End of Class Declaration


?>