<?php
Class Recommend_Model extends CI_Model
{

  var $client_selected_roles = array();
 
  public function __construct()
  {
    $this->load->database();
  }


  function get_recommended_content_user($user, $client_number){
    $recommended_courses_array = array();

    //Find current user id by the username in the url
    $this->db->select('UserId');  
    $query = $this->db->get_where('clientuserstb', array('UserName' => $user, 'ClientID'=>$client_number));  

    if($query->num_rows() > 0)  {

        $result_array =  $query->row_array();
        $current_user_id = $result_array["UserId"];
    
        //List of videos specifically/individually recommended to the user
        $this->db->select('CourseID');  
        $query = $this->db->get_where('rolestb', array('UserType'=>"User", 'LearnerId' => $current_user_id, 'ClientID'=>$client_number));    
        $recommended_courses_array =  $query->result_array();

        //List of groups that the User is part of
        $this->db->select('GroupId');  
        $query = $this->db->get_where('usermappingtb', array('UserId' => $current_user_id, 'ClientID'=>$client_number));
        $user_mappings_array =  $query->result_array();

        // Loop through each Group to find out the videos recommended to each of those groups
        foreach ($user_mappings_array as $group) {

          $this->db->select('CourseID');
          $query = $this->db->get_where('rolestb', array('UserType'=>"Group", 'LearnerId' => $group["GroupId"], 'ClientID'=>$client_number));
          $this_group_reco_array =  $query->result_array();

          //Loop through each video recommended to this Group
          foreach ($this_group_reco_array as $single_reco) {
            //Check if the recommendation is already present because of the specific/individual recommendation searched previously
            if(!in_array($single_reco["CourseID"], $recommended_courses_array)){
              array_push($recommended_courses_array, $single_reco);
            }
          }

        }
          
        //Query for any exceptions of videos recommended to the User specifically
        $this->db->select('CourseId');  
        $query = $this->db->get_where('exceptionstb', array('UserId'=>$current_user_id, 'ClientID'=>$client_number));
        $exception_courses =  $query->result_array();

        $exception_courses = array_map('current', $exception_courses);
        foreach ($recommended_courses_array as $key => $course_reco) {      
            if(in_array($course_reco["CourseID"], $exception_courses)){
              unset($recommended_courses_array[$key]);
            }      
        }

        //Convert Multi-dimensional array to single dimension array
        //Convert array from array( array('CourseID'=>1), array('CourseID'=>2), array('CourseID'=>3)) TO array(1, 2, 3)    
        $recommended_courses_array = array_map('current', $recommended_courses_array);

    }  //End of User is Defined in table condition
    

    return $recommended_courses_array;

  }


  function get_recommended_content_user_MU2($user, $client_number){
    $recommended_courses_array = array();

    $this->db->select('UserId');  
    $query = $this->db->get_where('clientuserstb', array('UserName' => $user, 'ClientID'=>$client_number));   

    if($query->num_rows() > 0)  { 
        $result_array =  $query->row_array();
        $current_user_id = $result_array["UserId"];

        //List of videos specifically/individually recommended to the user
        $this->db->select('CourseID');  
        $query = $this->db->get_where('mu2recotb', array('UserType'=>"User", 'LearnerId' => $current_user_id, 'ClientID'=>$client_number));    
        $recommended_courses_array =  $query->result_array();

        //List of groups that the User is part of
        $this->db->select('GroupId');  
        $query = $this->db->get_where('usermappingtb', array('UserId' => $current_user_id, 'ClientID'=>$client_number));
        $user_mappings_array =  $query->result_array();

        // Loop through each Group to find out the videos recommended to each of those groups
        foreach ($user_mappings_array as $group) {

          $this->db->select('CourseID');
          $query = $this->db->get_where('mu2recotb', array('UserType'=>"Group", 'LearnerId' => $group["GroupId"], 'ClientID'=>$client_number));
          $this_group_reco_array =  $query->result_array();

          //Loop through each video recommended to this Group
          foreach ($this_group_reco_array as $single_reco) {
            //Check if the recommendation is already present because of the specific/individual recommendation searched previously
            if(!in_array($single_reco["CourseID"], $recommended_courses_array)){
              array_push($recommended_courses_array, $single_reco);
            }
          }

        }
          
        //Query for any exceptions of videos recommended to the User specifically
        $this->db->select('CourseId');  
        $query = $this->db->get_where('muexceptionstb', array('UserId'=>$current_user_id, 'ClientID'=>$client_number));
        $exception_courses =  $query->result_array();

        $exception_courses = array_map('current', $exception_courses);
        foreach ($recommended_courses_array as $key => $course_reco) {      
            if(in_array($course_reco["CourseID"], $exception_courses)){
              unset($recommended_courses_array[$key]);
            }      
        }

        //Convert Multi-dimensional array to single dimension array
        //Convert array from array( array('CourseID'=>1), array('CourseID'=>2), array('CourseID'=>3)) TO array(1, 2, 3)
        $recommended_courses_array = array_map('current', $recommended_courses_array);

    }  //End of User is Defined in table condition

    return $recommended_courses_array;

  }



}  // End of Class Declaration


?>