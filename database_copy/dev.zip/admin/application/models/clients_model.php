<?php
Class Clients_Model extends CI_Model
{

 
  public function __construct()
  {
    $this->load->database();
  }

  
  function get_recent_clients_added(){    
    $this->db->order_by("Id", "desc"); 
    $this->db->limit(30);
    $query = $this->db->get('mu2activationtb');

    return $query->result_array();
  }


  function add_clients($client_name, $account_number, $cdh_number){
    $query = $this->db->get_where('mu2activationtb', array('ClientId'=>$account_number));
    $return_array = array("status"=>"fail", "client_details"=>array());

    if($query->num_rows()>0)
    {
      $return_array["status"] =  "fail";
    }
    else
    {
      $clientArray = array(                   
        'ClientName' =>$client_name,
        'ClientId' => $account_number,
        'CDHNumber' => $cdh_number,           
        'Package' => "MU2",
        'Date' => date("F-j-Y"),
        'Status' => 1,
        'recordDate' => date('Y-m-d')
      );

      $this->db->insert('mu2activationtb', $clientArray);

      $clientArray["Id"] = $this->db->insert_id();
      $return_array["status"] =  "success";
      $return_array["client_details"] =  $clientArray;
      
    }

    return $return_array;

  }


  function get_client_details($client_id){
    $query = $this->db->get_where('mu2activationtb', array('Id'=>$client_id));
    return $query->row_array();
  }



  function update_clients($client_id, $client_name, $account_number, $cdh_number){
    $update_array =array(
                        'ClientName' =>$client_name,
                        'ClientId' => $account_number,
                        'CDHNumber' => $cdh_number
                      );

   
    $this->db->where('Id', $client_id);
    $this->db->update('mu2activationtb', $update_array ); 

    return true;

  }

   function delete_client($client_id){
    $this->db->where(array('Id' => $client_id));
    $this->db->delete('mu2activationtb');
    return $client_id;
  }


}  // End of Class Declaration


?>