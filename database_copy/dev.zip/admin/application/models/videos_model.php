<?php
Class Videos_Model extends CI_Model
{

   
  public function __construct()
  {
    $this->load->database();
  }

  
  function get_all_normal_videos(){    
    //$this->db->order_by("CourseTitle", "asc"); 
    $query = $this->db->get('coursetb');

    return $query->result_array();
  }

  function get_all_mu_videos(){   
    //$this->db->order_by("CourseTitle", "asc"); 
    $query = $this->db->get('mu2tb');

    return $query->result_array();
  }


  function get_hot_topics(){
    $this->db->select('Id, CourseTitle, CourseType, FileURL');
    $this->db->from('coursetb');    

    $this->db->where(array('Status' => 1, 'CourseType'=>"HotTopic"));
    $query = $this->db->get();

    return $query->result_array();
  }

  
  function get_videos_by_params($version=false, $screen=false, $keywords=false, $mu_status=false, $reco_videos_array=false, $reco_videos_mu2_array=false){
    $normal_videos_array = array();
    $mu_videos_array = array();
    $all_videos_array = array();

    $this->db->select('Id, CourseTitle, CourseType, FileURL, Duration');
    $this->db->from('coursetb');
    $this->db->order_by("CourseTitle", "asc"); 
    $this->db->where(array('Status' => 1, 'CourseType'=>"EducationMaterial"));

    if($version!=false && $version!=null && $version!="%%"){
      $this->db->where('ProductVersion', $version);
    }

    if($screen != "false" && $screen != null && $screen != "%%"){
      $this->db->like(array('ScreenName'=>$screen)); 
    }

    if($keywords!="false" && $keywords!=null && $keywords!=""){
      //$keywords_array = explode(",", $keywords);
      //foreach ($keywords_array as $single_keyword) {
      foreach ($keywords as $single_keyword) {
        $this->db->like(array('Keywords'=>$single_keyword));
      }

    }

    $query = $this->db->get();  
    $normal_videos_array = $query->result_array();
    foreach ($normal_videos_array as $key => $video) {      
      if(in_array($video["Id"], $reco_videos_array)){
        $normal_videos_array[$key]["recommended"] = true;
      }else{
        $normal_videos_array[$key]["recommended"] = false;
      }     
    }
    

    if($mu_status){

      $this->db->select('Id, CourseTitle, CourseType, FileURL, Duration');
      $this->db->from('mu2tb');
      $this->db->order_by("CourseTitle", "asc"); 
      $this->db->where(array('Status' => 1, 'CourseType'=>"MU2"));
      if($version!=false && $version!=null){
        $this->db->where('ProductVersion', $version);
      }

      if($screen != "false" && $screen != null && $screen != "%%"){
        $this->db->like(array('ScreenName'=>$screen)); 
      }

      if($keywords!="false" && $keywords!=null && $keywords!=""){        
        foreach ($keywords as $single_keyword) {
          $this->db->like(array('Keywords'=>$single_keyword));
        }
      }

      $query = $this->db->get(); 
      $mu_videos_array = $query->result_array();

      foreach ($mu_videos_array as $key => $video) {      
        if(in_array($video["Id"], $reco_videos_mu2_array)){
          $mu_videos_array[$key]["recommended"] = true;
        }else{
          $mu_videos_array[$key]["recommended"] = false;
        }     
      }

    } // End of MU Check
    

    if(count($mu_videos_array)>0){
      $all_videos_array = array_merge($mu_videos_array, $normal_videos_array);
    }else{
      $all_videos_array = $normal_videos_array;
    }

    //usort($all_videos_array, '$this->sort_array_by_title');
    
    return $all_videos_array;    
  }


  function get_recommended_videos_by_version($version, $reco_videos_array){
    $reco_videos_details = array();
    
    if(count($reco_videos_array)>0){
        $this->db->select('Id, CourseTitle, CourseType, FileURL, Duration');
        $this->db->from('coursetb');
        $this->db->order_by("CourseTitle", "asc"); 
        $this->db->where(array('Status' => 1, 'CourseType'=>"EducationMaterial", 'ProductVersion'=>$version));   
        $this->db->where_in('Id', $reco_videos_array); 
        $query = $this->db->get();  
        $reco_videos_details = $query->result_array();
        foreach ($reco_videos_details as $key => $value) {
          $reco_videos_details[$key]["recommended"] = true;
        }
    }
  

    return $reco_videos_details;
  }


  function get_mu_videos($reco_videos_mu2_array){

      $this->db->select('Id, CourseTitle, CourseType, FileURL, Duration');
      $this->db->from('mu2tb');
      $this->db->order_by("CourseTitle", "asc"); 
      $this->db->where(array('Status' => 1, 'CourseType'=>"MU2"));
      $query = $this->db->get(); 
      $mu_videos_array = $query->result_array();

      foreach ($mu_videos_array as $key => $video) {      
        if(in_array($video["Id"], $reco_videos_mu2_array)){
          $mu_videos_array[$key]["recommended"] = true;
        }else{
          $mu_videos_array[$key]["recommended"] = false;
        }     
      }

      return $mu_videos_array;
  }

  function get_mu_recommended_videos($reco_videos_mu2_array){

      $this->db->select('Id, CourseTitle, CourseType, FileURL, Duration');
      $this->db->from('mu2tb');
      $this->db->order_by("CourseTitle", "asc"); 
      $this->db->where(array('Status' => 1, 'CourseType'=>"MU2"));
      $this->db->where_in('Id', $reco_videos_mu2_array); 
      $query = $this->db->get(); 
      $mu_reco_videos_array = $query->result_array();

      foreach ($mu_reco_videos_array as $key => $value) {
          $mu_reco_videos_array[$key]["recommended"] = true;
      }

      
      return $mu_reco_videos_array;
  }


  function sort_array_by_title($a, $b) {
      return strcmp($a->CourseTitle, $this->sort_array_by_title->CourseTitle);
  }  

 /* function get_video_details($content_id){
    $query = $this->db->get_where('coursetb', array('Id'=>$content_id));
    return $query->row_array();
  }*/


  function get_video_details($content_type, $content_id){
    if($content_type == "normal"){
      $query = $this->db->get_where('coursetb', array('Id'=>$content_id));
    }else if($content_type == "MU2"){
      $query = $this->db->get_where('mu2tb', array('Id'=>$content_id));
    }

    return $query->row_array();
  }


  function change_status_value($content_type, $content_id, $status_value){

    if($content_type == "normal"){
      $this->db->where('Id', $content_id);
      $this->db->update('coursetb', array("Status"=>$status_value) );
    }
    else if($content_type == "MU2"){
      $this->db->where('Id', $content_id);
      $this->db->update('mu2tb', array("Status"=>$status_value)  );
    }

  }



  // Update the normal video (EducationMaterial/HotTopic) details with the FileURL as an optional parameter
  function update_video_details($video_details, $video_url=false){
    $update_array =array(
                        "CourseTitle"=>$video_details["CourseTitle"],
                        "ScreenName"=>$video_details["ScreenName"],
                        "SubScreenName"=>$video_details["SubScreenName"],                        
                        "ProductVersion"=>$video_details["ProductVersion"],
                        "Keywords"=>$video_details["Keywords"],
                        "Duration"=>$video_details["Duration"],
                        "CourseType"=>$video_details["CourseType"]
                      );

    if($video_url != false){
      $update_array["FileURL"] = $video_url;
    }

    $this->db->where('Id', $video_details["Id"]);

    $update_table_name = ($video_details["CourseType"]=="MU2") ? "mu2tb":"coursetb";

    $this->db->update($update_table_name, $update_array ); 

    return true;

  }


  function add_new_video($video_details){
    $insert_array =array(
                        "CourseTitle"=>$video_details["CourseTitle"],
                        "CourseType"=>$video_details["CourseType"],
                        "ScreenName"=>$video_details["ScreenName"],
                        "SubScreenName"=>$video_details["SubScreenName"],
                        "ProductVersion"=>$video_details["ProductVersion"],
                        "Keywords"=>$video_details["Keywords"],
                        "Duration"=>$video_details["Duration"],                        
                        "Status"=>0,
                        "Date"=>date("F-j-Y")
                      );   

    $update_table_name = ($video_details["CourseType"]=="MU2") ? "mu2tb":"coursetb";

    $this->db->insert($update_table_name, $insert_array);
    //$clientArray["Id"] = $this->db->insert_id();

    return $this->db->insert_id();

  }

  function update_video_url($content_id, $content_type, $video_url){

    $this->db->where('Id', $content_id);
    $update_table_name = ($content_type=="MU2") ? "mu2tb":"coursetb";

    $this->db->update($update_table_name, array("FileURL"=>$video_url) ); 

    return true;
  }


   function delete_video($content_type, $content_id){
    $update_table_name = ($content_type=="MU2") ? "mu2tb":"coursetb";
   

    $this->db->where(array('Id' => $content_id));
    $this->db->delete($update_table_name);
    return true;
    
  }

  

}  // End of Class Declaration


?>