<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {
	var $all_screen_names;
	var $all_keyword_names;
	var $analytic_model_flag;

	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('environment_model');
		$this->load->model('videos_model');
		$this->load->model('user_model');
		$this->load->model('recommend_model');
		$this->load->model('analytics_model');

		$this->all_screen_names = $this->environment_model->get_screen_names();
		$this->all_keyword_names = $this->environment_model->get_keyword_names();
		$this->analytic_model_flag = false;
	}

	public function index()
	{
		$page_data = "";			
		$this->fnLoadPage($page_data, "home_view");
	}

	public function get($screen_name, $version, $client_number, $user=false, $user_type=false)
	{	
		
		$page_data["url_screen_name"] = $screen_name;
		$page_data["url_version"] = $version;
				

		$page_data["VERSIONS_ARRAY"] = unserialize (VERSIONS_ARRAY);
		$page_data["all_screen_names"] = $this->all_screen_names;
		$page_data["all_keyword_names"] = $this->all_keyword_names;

		$page_data["mu_status"] = $this->user_model->check_mu_status($client_number);
		$page_data["recommended_videos"] = $this->recommend_model->get_recommended_content_user($user, $client_number);
		if($page_data["mu_status"]){
			$page_data["recommended_videos_MU2"] = $this->recommend_model->get_recommended_content_user_MU2($user, $client_number);
		}else{
			$page_data["recommended_videos_MU2"] = array();
		}
		

		$this->user_model->set_params_session_details($user, $user_type, $screen_name, $client_number, $page_data["recommended_videos"], $page_data["recommended_videos_MU2"], $page_data["mu_status"]);
		
		//$page_data["launch_videos"] = $this->videos_model->get_videos_by_params($version, $screen_name, "false", $page_data["mu_status"], $page_data["recommended_videos"]);
		$hot_topics_array = $this->videos_model->get_hot_topics();

		$page_data["hot_topics"] = $this->analytics_model->get_videos_visited_status($hot_topics_array, $user, $client_number);

		$page_data["analytic_model_flag"] = $this->analytic_model_flag;

		$this->fnLoadPage($page_data, "home_view");
	}
	


	function get_recommended_videos_by_version(){
		$version = $this->input->post('version');
		$current_session_params = $this->user_model->get_params_session_details();

		$result = $this->videos_model->get_recommended_videos_by_version($version, $current_session_params["details"]["recommended_videos"]);
		if($this->analytic_model_flag){
			$analytics_passed_result = $this->analytics_model->get_videos_visited_status($result, $current_session_params["details"]["user"], $current_session_params["details"]["client_number"]);
			echo json_encode($analytics_passed_result);
		}else{
			echo json_encode($result);
		}
	}


	function get_videos_by_params(){
		$version = $this->input->post('version');
		$screen_name = $this->input->post('screen_name');
		$keywords = $this->input->post('keywords');

		$current_session_params = $this->user_model->get_params_session_details();

		$result = $this->videos_model->get_videos_by_params($version, $screen_name, $keywords, $current_session_params["details"]["mu_status"], $current_session_params["details"]["recommended_videos"], $current_session_params["details"]["recommended_videos_mu2"]);

		if($this->analytic_model_flag){
			$analytics_passed_result = $this->analytics_model->get_videos_visited_status($result, $current_session_params["details"]["user"], $current_session_params["details"]["client_number"]);
			echo json_encode($analytics_passed_result);
		}else{
			echo json_encode($result);
		}
		
		
		
	}

	function get_mu_videos(){
		$current_session_params = $this->user_model->get_params_session_details();

		$result = $this->videos_model->get_mu_videos($current_session_params["details"]["recommended_videos_mu2"]);
		if($this->analytic_model_flag){
			$analytics_passed_result = $this->analytics_model->get_videos_visited_status($result, $current_session_params["details"]["user"], $current_session_params["details"]["client_number"]);
			echo json_encode($analytics_passed_result);
		}else{
			echo json_encode($result);
		}
	}

	function get_mu_recommended_videos(){
		$current_session_params = $this->user_model->get_params_session_details();

		$result = $this->videos_model->get_mu_recommended_videos($current_session_params["details"]["recommended_videos_mu2"]);
		if($this->analytic_model_flag){
			$analytics_passed_result = $this->analytics_model->get_videos_visited_status($result, $current_session_params["details"]["user"], $current_session_params["details"]["client_number"]);
			echo json_encode($analytics_passed_result);
		}else{
			echo json_encode($result);
		}
	}


	function fnLoadPage($page_data, $view_name){		
		$page_data["baseURL"] = base_url("index.php/");		

		//$this->load->view('global/header', $header_data);
   		$this->load->view($view_name, $page_data);
   		//$this->load->view('global/footer', $footer_data);
	}


	
	
	
}