<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Configuration extends CI_Controller {

	var $all_screen_names;
	var $sub_screen_names;
	var $all_keyword_names;


	public function __construct()
	{
		parent::__construct();		
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('user_model');
		$this->load->model('videos_model');
		$this->load->model('environment_model');

		$this->all_screen_names = $this->environment_model->get_screen_names();
		$this->sub_screen_names = $this->environment_model->get_sub_screen_names();
		$this->all_keyword_names = $this->environment_model->get_keyword_names();
	}

	public function index()
	{			
   		$content = "";   		
   		$page_data["all_screen_names"] = $this->all_screen_names;
   		$page_data["sub_screen_names"] = $this->sub_screen_names;
		$page_data["all_keyword_names"] = $this->all_keyword_names;
		$page_data["VERSIONS_ARRAY"] = unserialize (VERSIONS_ARRAY);
   		$this->load_page($page_data);
	}


	function load_page($page_data){

		$session_data = $this->user_model->getSessionDetails();
		//Check if a valid session is active. Else redirect to login page.
		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}
		
		$headerfiles = array(
			//'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'
		);

		$header_data['userDetails'] = $session_data["userDetails"];

		$header_data['headerfiles'] = $headerfiles;
		$page_data["baseURL"] = base_url("index.php/");
		$footer_data["activeTab"] = "configuration";

		$this->load->view('global/header', $header_data);
   		$this->load->view('configuration_view', $page_data);
   		$this->load->view('global/footer', $footer_data);
	}


	public function add_screen(){		
		$screen = $this->input->post('screen');

		$process = $this->environment_model->add_screen($screen);
		echo $process;
	}

	public function add_sub_screen(){		
		$sub_screen = $this->input->post('sub_screen');

		$process = $this->environment_model->add_sub_screen($sub_screen);
		echo $process;
	}


	public function add_keyword(){		
		$keyword = $this->input->post('keyword');

		$process = $this->environment_model->add_keyword($keyword);
		echo $process;
	}


	public function delete_screen(){
		$screen = $this->input->post('screen');

		$process = $this->environment_model->delete_screen($screen);
		echo $process;
	}

	public function delete_sub_screen(){
		$sub_screen = $this->input->post('sub_screen');

		$process = $this->environment_model->delete_sub_screen($sub_screen);
		echo $process;
	}

	public function delete_keyword(){
		$keyword = $this->input->post('keyword');

		$process = $this->environment_model->delete_keyword($keyword);
		echo $process;
	}



}