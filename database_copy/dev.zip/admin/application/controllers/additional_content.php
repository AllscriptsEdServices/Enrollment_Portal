<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Additional_Content extends CI_Controller {

	public function __construct()
	{
		parent::__construct();		
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('user_model');
		$this->load->model('videos_model');
	}

	public function index()
	{			
   		$content = "";
   		$content["all_videos"] = $this->videos_model->get_all_mu_videos();
   		$this->load_page($content);
	}


	function load_page($page_data){

		$session_data = $this->user_model->getSessionDetails();
		//Check if a valid session is active. Else redirect to login page.
		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}
		
		$headerfiles = array(
			//'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'
		);

		$header_data['userDetails'] = $session_data["userDetails"];

		$header_data['headerfiles'] = $headerfiles;
		$page_data["baseURL"] = base_url("index.php/");
		$footer_data["activeTab"] = "additional_content";

		$this->load->view('global/header', $header_data);
   		$this->load->view('additional_content_view', $page_data);
   		$this->load->view('global/footer', $footer_data);
	}

	public function change_status_value(){
		
		$contentId = $this->input->post('contentId');
		$contentType = $this->input->post('contentType');
		$action = $this->input->post('action');

		$status_value = ($action=="publish") ? 1:0;
		
		$this->videos_model->change_status_value($contentType, $contentId, $status_value);
		echo true;
	}

	function delete_content(){
		$contentId = $this->input->post('contentId');
		$contentType = $this->input->post('contentType');

		$this->videos_model->delete_video($contentType, $contentId);
		echo true;
	}
	

}
