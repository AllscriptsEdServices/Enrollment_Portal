<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Add_Content extends CI_Controller {

	var $all_screen_names;
	var $sub_screen_names;
	var $all_keyword_names;

	public function __construct()
	{
		parent::__construct();		
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('user_model');
		$this->load->model('videos_model');
		$this->load->model('environment_model');

		$this->all_screen_names = $this->environment_model->get_screen_names();
		$this->sub_screen_names = $this->environment_model->get_sub_screen_names();
		$this->all_keyword_names = $this->environment_model->get_keyword_names();

		$this->load->helper("file");
	}

	public function index()
	{			
   		$content = "";   		
   		//$this->load_page($content);
	}

	public function open_window(){
		//$page_data["content_details"] = $this->videos_model->get_video_details("normal", $content_id);		
		$page_data["all_screen_names"] = $this->all_screen_names;
		$page_data["sub_screen_names"] = $this->sub_screen_names;
		$page_data["all_keyword_names"] = $this->all_keyword_names;
		$page_data["VERSIONS_ARRAY"] = unserialize (VERSIONS_ARRAY);

		$feedback_message = array("status"=>-1, "update_type"=>"", "reason"=>"");	

		$page_data["message"] = $feedback_message;

		$this->load_page("add_content_view", $page_data);
	}


	public function open_mu_update_window($content_id){
		//$page_data["content_details"] = $this->videos_model->get_video_details("MU2", $content_id);
		$page_data["all_screen_names"] = $this->all_screen_names;
		$page_data["sub_screen_names"] = $this->sub_screen_names;
		$page_data["all_keyword_names"] = $this->all_keyword_names;
		$page_data["VERSIONS_ARRAY"] = unserialize (VERSIONS_ARRAY);

		$feedback_message = array("status"=>-1, "update_type"=>"", "reason"=>"");	

		$page_data["message"] = $feedback_message;

		$this->load_page("edit_content_view", $page_data);
	}


	function load_page($page_name, $page_data){

		$session_data = $this->user_model->getSessionDetails();
		//Check if a valid session is active. Else redirect to login page.
		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}
		
		$headerfiles = array(
			//'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'
		);

		$header_data['userDetails'] = $session_data["userDetails"];

		$header_data['headerfiles'] = $headerfiles;
		$page_data["baseURL"] = base_url("index.php/");
		$footer_data["activeTab"] = "login";

		//$this->load->view('global/header', $header_data);
   		$this->load->view($page_name, $page_data);
   		//$this->load->view('global/footer', $footer_data);
	}


	function add_new_content(){
		$feedback_message = array("status"=>"", "update_type"=>"", "reason"=>"");	
		$contentType = $this->security->xss_clean( $this->input->post('contentType') );
		$contentTitle = $this->security->xss_clean( $this->input->post('contentTitle') );
		$keyword_selector = $this->security->xss_clean( $this->input->post('keyword_selector') );
		$keywords = "";
		
		if(sizeof($keyword_selector) > 0){
			foreach ($keyword_selector as $single_keyword) {
				$keywords .= $single_keyword.",";
			}
			$keywords = rtrim($keywords, ',');
		}
		

		
		if($contentType != "HotTopic"){
			$screen_selector = $this->security->xss_clean( $this->input->post('screen_selector') );		
			$sub_screen_selector = $this->security->xss_clean( $this->input->post('sub_screen_selector') );	
			$version_selector = $this->security->xss_clean( $this->input->post('version_selector') );
			$duration = $this->security->xss_clean( $this->input->post('duration'));
			$screen_names = "";
			foreach ($screen_selector as $single_screen) {
				$screen_names .= $single_screen.",";
			}
			$screen_names = rtrim($screen_names, ',');

			$sub_screen_names = "";
			foreach ($sub_screen_selector as $single_sub_screen) {
				$sub_screen_names .= $single_sub_screen.",";
			}
			$sub_screen_names = rtrim($sub_screen_names, ',');

		}else{
			$screen_names = "";
			$sub_screen_names = "";
			$version_selector = "";
			$duration = "";			
		}
		

		$content_details =  array("CourseTitle"=>$contentTitle, 
								"CourseType"=>$contentType, 
								"ScreenName"=>$screen_names,  
								"SubScreenName"=>$sub_screen_names,
								"Keywords"=>$keywords, 
								"ProductVersion"=>$version_selector, 
								"Duration"=>$duration);

		$new_content_id = $this->videos_model->add_new_video($content_details);

		//Check if user has posted a file.
		if($new_content_id>0){
			$feedback_message["status"] = 1;
			$content_details["Id"] = $new_content_id;

			$FILE_IS_POSTED = (empty($_FILES['userfile']['tmp_name'])) ? false:true;

			if($FILE_IS_POSTED){

				$upload_details = $this->upload_and_move_file($contentType, $new_content_id);
				if($upload_details["status"]){
					$this->videos_model->update_video_url($new_content_id, $contentType, $upload_details["database_url"]);

					$content_details["FileURL"] = $upload_details["database_url"];
					$feedback_message["status"] = 2;
				}else{					
					$feedback_message["reason"] = $upload_details["reason"];
					$content_details["FileURL"] = "";
				}

			}

		}
		
		$page_data["content_details"] =  $content_details;
		$page_data["all_screen_names"] = $this->all_screen_names;
		$page_data["sub_screen_names"] = $this->sub_screen_names;
		$page_data["all_keyword_names"] = $this->all_keyword_names;
		$page_data["VERSIONS_ARRAY"] = unserialize (VERSIONS_ARRAY);


		$page_data["message"] = $feedback_message;		

		$this->load_page("add_content_view", $page_data);

	}

	


	function upload_and_move_file($contentType, $contentId){
		$return_array = array("status"=>false, "reason"=>"", "database_url"=>"");

		//Relative path from the index.php of this application
		if($contentType == "EducationMaterial" || $contentType == "HotTopic"){
			$target_directory = "../course_library/general_content_".$contentId;
			$url_for_database = 'general_content_'.$contentId.'/index.html';
		}else if($contentType == "MU2"){
			$target_directory = "../course_library/mu_content_".$contentId;
			$url_for_database = 'general_content_'.$contentId.'/index.html';
		}
		

		if(!is_dir($target_directory)){
			mkdir($target_directory, 0700);
		}else{
			delete_files($target_directory, true);
		}		
		
		$config['upload_path'] = $target_directory;
		$config['allowed_types'] = 'zip';
		$config['max_size'] = '';
		$this->load->library('upload', $config);

		if ( !$this->upload->do_upload() )
		{
			$error = array('error' => $this->upload->display_errors());							
			$return_array["status"] = false;
			$return_array["reason"] = "upload_error";
		}
		else
		{
			$data = array('upload_data' => $this->upload->data());
			$zip = new ZipArchive;
			$file = $data['upload_data']['full_path'];
			chmod($file,0777);
			if ($zip->open($file) === TRUE) {				     
			     $zip->extractTo($target_directory);
			     $zip->close();
			     
			} else {
			    $return_array["status"] = false;
				$return_array["reason"] = "extract_error";
			}

			

			if(file_exists($target_directory."/index.html")){
				$return_array["status"] = true;
				$return_array["reason"] = "";
				$return_array["database_url"] = $url_for_database;
			}else{
				$return_array["status"] = false;
				$return_array["reason"] = "zip_format_error";				
			}
						

		}


		return $return_array;
	}
	

}