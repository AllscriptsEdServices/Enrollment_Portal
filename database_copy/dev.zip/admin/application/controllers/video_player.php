<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Video_Player extends CI_Controller {
	

	public function __construct()
	{
		parent::__construct();		
		
		$this->load->model('videos_model');
		$this->load->model('user_model');	
	}

	public function index()
	{
		$page_data = "";			
		//$this->fnLoadPage($page_data, "home_view");
	}

	public function open_video($video_type, $video_id){
		$current_session_params = $this->user_model->get_params_session_details();
		$page_data["video_details"] = $this->videos_model->get_video_details($video_type, $video_id);

		$this->fnLoadPage($page_data, "video_player_view");
	}

	

	function fnLoadPage($page_data, $view_name){		
		$page_data["baseURL"] = base_url("index.php/");

		//$this->load->view('global/header', $header_data);
   		$this->load->view($view_name, $page_data);
   		//$this->load->view('global/footer', $footer_data);
	}


	
	
	
}