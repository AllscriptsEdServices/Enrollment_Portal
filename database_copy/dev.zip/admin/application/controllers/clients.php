<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Clients extends CI_Controller {

	public function __construct()
	{
		parent::__construct();		
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('user_model');
		$this->load->model('clients_model');
	}

	public function index()
	{			
   		$content = "";   		
	}

	public function recent()
	{		   		
   		$content["recent_clients"] = $this->clients_model->get_recent_clients_added();
   		$this->load_page("clients_recent_view", $content);
	}


	function load_page($page_name, $page_data){

		$session_data = $this->user_model->getSessionDetails();
		//Check if a valid session is active. Else redirect to login page.
		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}
		
		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/admin_utilities.css").'">',
			'2'=>'<link rel="stylesheet" href="'.base_url("assets/plugins/formvalidation-master/dist/css/formValidation.css").'">'
		);


		$header_data['userDetails'] = $session_data["userDetails"];

		$header_data['headerfiles'] = $headerfiles;
		$page_data["baseURL"] = base_url("index.php/");
		$footer_data["activeTab"] = "client_activation";

		$this->load->view('global/header', $header_data);
   		$this->load->view($page_name, $page_data);
   		$this->load->view('global/footer', $footer_data);
	}

	function add_clients(){
		
		$client_name = $this->input->post('client_name');
		$account_number = $this->input->post('account_number');
		$cdh_number = $this->input->post('cdh_number');
	

		$response = $this->clients_model->add_clients($client_name, $account_number, $cdh_number);
		echo json_encode($response);

	}


	public function open_edit_client_window($client_id){
		$page_data["client_details"] = $this->clients_model->get_client_details($client_id);
		$page_data["baseURL"] = base_url("index.php/");

		$this->load->view("edit_client_view", $page_data);
	}


	function update_clients(){
		$client_id = $this->input->post('client_id');
		$client_name = $this->input->post('client_name');
		$account_number = $this->input->post('account_number');
		$cdh_number = $this->input->post('cdh_number');
	

		$response = $this->clients_model->update_clients($client_id, $client_name, $account_number, $cdh_number);
		echo ($response);

	}


	function delete_client(){
		$client_id = $this->input->post('client_id');

		$response = $this->clients_model->delete_client($client_id);
		echo ($response);
	}

}
