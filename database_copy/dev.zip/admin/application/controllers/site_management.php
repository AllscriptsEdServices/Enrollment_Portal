<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site_Management extends CI_Controller {


	public function __construct()
	{
		parent::__construct();		
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('user_model');	
	}
	

	public function index()
	{			
   		$page_data = "";   
   		$page_data["all_site_users"] = $this->user_model->get_all_site_users();
   		$this->load_page($page_data);
	}


	function load_page($page_data){

		$session_data = $this->user_model->getSessionDetails();
		//Check if a valid session is active. Else redirect to login page.
		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}
		
		$headerfiles = array(
			//'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'
		);

		$header_data['userDetails'] = $session_data["userDetails"];

		$header_data['headerfiles'] = $headerfiles;
		$page_data["baseURL"] = base_url("index.php/");
		$footer_data["activeTab"] = "site_management";

		$this->load->view('global/header', $header_data);
   		$this->load->view('site_management_view', $page_data);
   		$this->load->view('global/footer', $footer_data);
	}


	public function add_site_user(){		
		$first_name = $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$email = $this->input->post('email');
		$rights = $this->input->post('rights');		 

		$process = $this->user_model->add_site_user($first_name, $last_name, $email, $rights);
		echo $process;
	}

	public function delete_site_user(){
		$user_id = $this->input->post('user_id');

		$process = $this->user_model->delete_site_user($user_id);
		echo $process;
	}



}