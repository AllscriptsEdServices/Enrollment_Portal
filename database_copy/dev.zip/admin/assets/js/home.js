
 	function openContent(course_type, course_id){

    var url = img_path + "/iLearn_HTML5_sample/index.html";
    var url = baseURL + "/video_player/open_video/" + course_type + "/" + course_id;


    var max_modal_height = $("#video_modal").height();
    var single_height_unit = Math.round((max_modal_height-200)/10);
    var new_modal_width = (single_height_unit*17);

    //$("#video_modal").attr('width', (new_modal_width+50) );
   /* if($(window).height()<650){
 			$("#video_play_frame").attr('height', (max_modal_height-220) );
    }else{
    	 $("#video_play_frame").attr('height', 650 );
    }*/
    $("#video_play_frame").attr('height', (max_modal_height-220) );
    $("#video_play_frame").attr('src', url);

    //$('#video_play_frame')[0].contentWindow.location.reload(true);
    //$("#video_play_frame").attr('width', (new_modal_width) );
  }


  function open_video_directly(course_url){
  	//	alert(course_url);
  	/*var max_modal_height = $("#video_modal").height();
    var single_height_unit = Math.round((max_modal_height-200)/10);
    var new_modal_width = (single_height_unit*17);

    $("#video_play_frame").attr('height', (max_modal_height-220) );*/
    //$("#video_play_frame").attr('src', course_url);
    //$("#video_play_frame").bind("load", video_frame_loaded); 
    //$("#video_play_frame").attr('src', 'http://localhost/ilearn_maverick/course_library/iLearn_HTML5_sample/index.html');
       
    //$(".modal-body").html('http://localhost/ilearn_maverick/course_library/iLearn_HTML5_sample/index.html');
    //alert(course_url);
    $(".modal-body").load('../course_library/iLearn_HTML5_sample/index.html');

    //$('#video_play_frame').contentWindow.location.reload(true);
  }

  /*$('#video_modal').on('show.bs.modal', function () {
       $(this).find('.modal-body').css({
              width:'auto', //probably not needed
              height:'auto', //probably not needed 
              'max-height':'100%'
       });
  });*/

  $('#video_modal').on('hidden.bs.modal', function () {
    // # CODE TO EXECUTE UPON MODAL CLOSE
    $("#video_play_frame").attr('src', "");         
  })


  function video_frame_loaded(){
    //alert("here");
    console.log("here");
    $("#video_play_frame").unbind("load", video_fram_loaded);
    $('#video_play_frame').attr('src', $('#video_play_frame').attr('src'));
  }

	
  function version_tab_changed(clicked_version){  	
	  current_selected_version = clicked_version;

    show_version_tabs_sub_elements();    
    hide_mu_tabs_sub_elements();

	  show_version_urlscreen_tab();  	
	}
 

	function show_version_urlscreen_tab(){
  	$("#videos_loader").show();
  	$('#video_dynamic_area').html("");
    
  	$.ajax({
        type: "POST",
        url: baseURL + "/home/get_videos_by_params",
        data: {
          'version': current_selected_version,
          'screen_name': url_screen_name,
          'keywords': false       
      	},
        success: function(response)
        {             
          var responseObj = $.parseJSON(response);
          load_new_videos(responseObj);           

        }
    });
    reset_sub_tabs();
	}

	
  function show_version_all_videos_tab(){ 
  	$("#videos_loader").show(); 
  	$('#video_dynamic_area').html("");
  	enable_version_all_videos_filters();

    $("#all_videos_filters_div").show();     

    $.ajax({
        type: "POST",
        url: baseURL + "/home/get_videos_by_params",
        data: {
	        'version': current_selected_version,
	        'screen_name': false,
	        'keywords': false
      	},
        success: function(response)
        {
          var responseObj = $.parseJSON(response);
          load_new_videos(responseObj);
        }
    });
  }


  function version_all_videos_filter_change(){
    
    $("#videos_loader").show();
    $('#video_dynamic_area').html("");    

    $.ajax({
        type: "POST",
        url: baseURL + "/home/get_videos_by_params",
        data: {
          'version': current_selected_version,
          'screen_name': $("#version_screen_selector").val(),
          'keywords': $("#version_keyword_selector").val()
      	},
        success: function(response)
        {             
          var responseObj = $.parseJSON(response);
          load_new_videos(responseObj);           

        }
    });
    
  }


  function show_version_recommended_tab(){
	  disable_version_all_videos_filters();
	  $("#videos_loader").show();
	  $('#video_dynamic_area').html(""); 

    $.ajax({
        type: "POST",
        url: baseURL + "/home/get_recommended_videos_by_version",
        data: {
	        'version': current_selected_version
	      },

        success: function(response)
        {
          var responseObj = $.parseJSON(response);
          load_new_videos(responseObj);
        }
    });
  }


  function show_mu_videos(){
    $("#videos_loader").show();
    $('#video_dynamic_area').html("");
    hide_version_tabs_sub_elements();
    disable_version_all_videos_filters();
    disable_master_videos_filters();
    show_mu_tabs_sub_elements();
    make_sub_tab_active("mu2_first_sub_tab");

    $.ajax({
        type: "POST",
        url: baseURL + "/home/get_mu_videos",
        data: {          
        },

        success: function(response)
        {
          var responseObj = $.parseJSON(response);
          load_new_videos(responseObj);
        }
    });

  }
  

  function show_mu_recommended_tab(){
    $("#videos_loader").show();
    $('#video_dynamic_area').html("");


    $.ajax({
        type: "POST",
        url: baseURL + "/home/get_mu_recommended_videos",
        data: {          
        },

        success: function(response)
        {
          var responseObj = $.parseJSON(response);
          load_new_videos(responseObj);
        }
    });

  }


  function show_master_videos_tab(){    
    $('#video_dynamic_area').html("");
    hide_version_tabs_sub_elements();
    disable_version_all_videos_filters();
    hide_mu_tabs_sub_elements();

    $("#master_filters_div").show();
    enable_master_videos_filters();
  }

  function master_videos_filter_changed(){
    $("#videos_loader").show();
    $('#video_dynamic_area').html("");    

    $.ajax({
        type: "POST",
        url: baseURL + "/home/get_videos_by_params",
        data: {
          'version': $("#master_version_selector").val(),
          'screen_name': $("#master_screen_selector").val(),
          'keywords': $("#master_keyword_selector").val()
        },
        success: function(response)
        {             
          var responseObj = $.parseJSON(response);
          load_new_videos(responseObj);           

        }
    });

  }


  function load_new_videos(video_list){
    var video_container_body = '';

    if(video_list.length > 0){      

      for(Id in video_list){
        //console.log(video_list[Id] );

        //video_container_body += '<a name="FALSE" id="122_course_EducationMaterial"  class="video_link_a"  data-toggle ="modal" data-target ="#video_modal" data-courseid="'+video_list[Id].Id+'" data-coursetype="'+video_list[Id].CourseType+'"  >';
        video_container_body += '<a id="'+video_list[Id].Id+'_'+video_list[Id].CourseType+'"  class="video_link_a"  data-toggle ="modal" data-target ="#video_modal" data-courseid="'+video_list[Id].Id+'" data-coursetype="'+video_list[Id].CourseType+'" data-fileurl="'+video_list[Id].FileURL+'" >';
         
          //videoLink-visited - the other bg color
          video_container_body += '<div class="videoLink">';
          
            video_container_body += '<table>';
              video_container_body += '<tbody>';
                video_container_body += '<tr>';
                  video_container_body += '<td width="40px" valign="middle">';
                    video_container_body += '<div class="videoLinkImage">';
                      if(analytic_model_flag){

                        if(video_list[Id].viewed){  
                        video_container_body += '<img src="'+img_path+'/play.png">';
                        }else{
                          video_container_body += '<img src="'+img_path+'/play_over.png">';
                        }

                      }else{
                        video_container_body += '<img src="'+img_path+'/play.png">';
                      }
                      
                    video_container_body += '</div>';
                  video_container_body += '</td>';
                  video_container_body += '<td class="videoLinkText">' + video_list[Id].CourseTitle + '</td>';

                  video_container_body += '<td valign="middle"><div class="muIcon">';
                  if(video_list[Id].CourseType=="MU2"){
                  	video_container_body += ' <img src="'+img_path+'/MU.png"> ';                  	
                  }                   
                  video_container_body += '</div></td>';

                  
                  if(video_list[Id].recommended==true){
                  	video_container_body += '<td valign="middle">';
                  	video_container_body += '<div class="requiredIcon"> <img src="'+img_path+'/recomm.png"> </div>';  
                  	video_container_body += '</td>';
                  }
                  

                  video_container_body += '<td align="right" class="duration">' + video_list[Id].Duration + '</td>';
                video_container_body += '</tr>';
              video_container_body += '</tbody>';
            video_container_body += '</table>';
          video_container_body += '</div>';
        video_container_body += '</a>';

      }

    }else{
      video_container_body += '<p>No videos for this version.</p>';
    }

    $('#video_dynamic_area').hide();
    $('#video_dynamic_area').html(video_container_body);
    $('#video_dynamic_area').fadeIn();
    $("#videos_loader").hide();
  }


  function reset_sub_tabs(){
    $(".nav_sub_tabs").removeClass("active");
    $("#screen_sub_tab").addClass("active");
    disable_version_all_videos_filters();
    disable_master_videos_filters();
  }

  function disable_version_all_videos_filters(){
  	$("#all_videos_filters_div").hide();
    $("#version_keyword_selector, #version_screen_selector").unbind("change", version_all_videos_filter_change);     
    $("#version_keyword_selector, #version_screen_selector").select2("val", "");    
  }

  function enable_version_all_videos_filters(){
  	$("#version_keyword_selector, #version_screen_selector").bind("change", version_all_videos_filter_change);    
  }


  function disable_master_videos_filters(){
    $("#master_filters_div").hide();  
    $("#master_keyword_selector, #master_screen_selector, #master_version_selector").unbind("change", master_videos_filter_changed);        
    $("#master_keyword_selector, #master_screen_selector, #master_version_selector").select2("val", "");
  }

  function enable_master_videos_filters(){
    $("#master_keyword_selector, #master_screen_selector, #master_version_selector").bind("change", master_videos_filter_changed); 
  }

  function hide_version_tabs_sub_elements(){
    $("#version_sub_menu").hide();
  }

  function show_version_tabs_sub_elements(){
    $("#version_sub_menu").show();
  }

  function hide_mu_tabs_sub_elements(){
    $("#mu_sub_menu").hide();
  }

  function show_mu_tabs_sub_elements(){
    $("#mu_sub_menu").show();
  }


  function make_sub_tab_active(to_active_tab){
    $(".nav_sub_tabs").removeClass("active");
    $("#" + to_active_tab).addClass("active");
  }