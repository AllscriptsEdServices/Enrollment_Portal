#Found a bug?

###Please include the following when opening an issue:

1. jquery-placeholder version
2. jquery version
3. Browser vendor and versions where you are seeing the issue
4. Example code to reproduce the issue (using jsfiddle is best)
