<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Deactivate_Learners extends CI_Controller {

	var $session_data = array();

	public function __construct()
	{
		parent::__construct();		
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('learners_model');
		$this->load->model('clients_model');
		$this->load->model('programs_model');
		$this->load->model('request_model');	
		//$this->load->model('assign_program_model');			
	}

	public function index()
	{
		$this->session_data = $this->user_model->getSessionDetails();
   		if(!$this->session_data["active_status"]){
			redirect('login', 'refresh');
		}

		$content["learners_list"] = $this->learners_model->getClientLearners($this->session_data["userDetails"]["clientId"]); 

		$request_session = $this->request_model->get_current_request();
		if($request_session["active_status"]){   		
   			$content["requestId"] = $request_session["request_details"]["requestId"];   			
   		}

		$this->fnLoadPage($content, "deactivate_learners_view");

	}


	

	
	function fnLoadPage($page_data, $page_name){
		//$session_data = $this->user_model->getSessionDetails();
		//Check if a valid session is active. Else redirect to login page.
		if(!$this->session_data["active_status"]){
			redirect('login', 'refresh');
		}


		$header_data['userDetails'] = $this->session_data["userDetails"];
		$header_data['orgName'] = $this->clients_model->get_org_name_for_header($this->session_data["userDetails"]["clientId"]);	
		$header_data['headerfiles'] = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/requests.css").'">'
		);
		$page_data["baseURL"] = base_url("index.php/");
		$footer_data["activeTab"] = "nav_requests";

		$this->load->view('global/header', $header_data);
   		$this->load->view($page_name, $page_data);
   		$this->load->view('global/footer', $footer_data);

	}

	function submit_request(){
		$selected_learners = $this->input->post('selected_learners');		
		
		$session_user_data = $this->user_model->getSessionDetails();
		$request_session = $this->request_model->get_current_request();

		if($request_session["active_status"]){   		
   			$requestId = $request_session["request_details"]["requestId"];
   			$this->learners_model->deactivate_learners($selected_learners, $requestId);
   			$process_status = $this->request_model->submit_request($requestId, $session_user_data["userDetails"]["userId"]);
   		}else{
			$process_status = false;
   		}
		

		$request_details = $this->request_model->get_request_details($requestId);
		$client_details = $this->clients_model->get_client_details($request_details["clientId"]);

		//Commented for now - Sends the mail to the Allscripts Team notifying about the request submission
		$this->request_model->send_request_notify_mail($requestId, $client_details, "Deactivate Learners");
		
		echo $process_status;

	}



}