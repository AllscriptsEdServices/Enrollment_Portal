<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Export_Module extends CI_Controller {
	

	public function __construct()
	{
		parent::__construct();		
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('learners_model');
		$this->load->model('clients_model');
		$this->load->model('programs_model');
		$this->load->model('request_model');	
		$this->load->model('assign_program_model');	
	}

	public function index()
	{			
   		
	}


	function excel_internal_summary($requestId){
		$content = "";
		$request_details = $this->request_model->get_request_details($requestId);

		if($request_details != "Invalid"){
			$client_details = $this->clients_model->get_client_details($request_details["clientId"]);

			$contact_details = $this->user_model->get_user_details($request_details["submitted_by"]);

			$all_enrollments = $this->assign_program_model->get_summary_details($requestId, "learnerId");

			$export_array = array();
			foreach ($all_enrollments as $enrollment) {
				$program_name = $this->programs_model->get_program_name($enrollment["programId"]);
				$learner_detail = $this->learners_model->get_learner_details($enrollment["learnerId"]);
				$single_enrollment_array = array("program_details"=>$program_name, "learner_details"=>$learner_detail);
				array_push($export_array, $single_enrollment_array);
			}

			//$unique_learners = $this->assign_program_model->get_unique_learners($requestId);
			$new_learners_details = $this->learners_model->get_new_learners($requestId);


			$content["request_details"] = $request_details;
			$content["client_details"] = $client_details;
			$content["contact_details"] = $contact_details;
			$content["new_learners"] = $new_learners_details;
			$content["all_enrollments"] = $export_array;

			$this->load->view("excel_templates/excel_export_view", $content);

		}else{
			$headerfiles = array();
			$header_data['headerfiles'] = $headerfiles;
			
			$this->load->view('global/header_nonav', $header_data);
	   		$this->load->view('export_error_view', "");
	   		$this->load->view('global/footer_nonav', "");
		}		

	}	



	function excel_client_summary($requestId){
		$request_details = $this->request_model->get_request_details($requestId);
		
		$client_details = $this->clients_model->get_client_details($request_details["clientId"]);

		if($request_details["submission_status"] == 1){
			$contact_details = $this->user_model->get_user_details($request_details["submitted_by"]);
		}else{
			$contact_details = "Not Submitted";
		}
	

		$all_enrollments = $this->assign_program_model->get_summary_details($requestId, "learnerId");

		$export_array = array();
		foreach ($all_enrollments as $enrollment) {
			$program_name = $this->programs_model->get_program_name($enrollment["programId"]);
			$learner_detail = $this->learners_model->get_learner_details($enrollment["learnerId"]);
			$single_enrollment_array = array("program_details"=>$program_name, "learner_details"=>$learner_detail);
			array_push($export_array, $single_enrollment_array);
		}

		


		$content["request_details"] = $request_details;
		$content["client_details"] = $client_details;
		$content["contact_details"] = $contact_details;			
		$content["all_enrollments"] = $export_array;

		$this->load->view("excel_templates/excel_export_client_view", $content);		

	}
	


	function excel_learner_list($clientId){
		$content["learner_list"] = $this->learners_model->getClientLearners($clientId);
		$content["client_details"] = $this->clients_model->get_client_details($clientId);

		$this->load->view("excel_templates/excel_export_learners_view", $content);
	}


	function excel_deactivate_report($requestId){
		
		$request_details = $this->request_model->get_request_details($requestId);
		if($request_details != "Invalid"){
			$client_details = $this->clients_model->get_client_details($request_details["clientId"]);
			$contact_details = $this->user_model->get_user_details($request_details["submitted_by"]);
			$learner_list = $this->learners_model->get_deactivated_learners($requestId);

			$content["learner_list"] = $learner_list;
			$content["request_details"] = $request_details;
			$content["client_details"] = $client_details;
			$content["contact_details"] = $contact_details;

			$this->load->view("excel_templates/excel_export_deactivate_view", $content);
		}else{
			$headerfiles = array();
			$header_data['headerfiles'] = $headerfiles;
			
			$this->load->view('global/header_nonav', $header_data);
	   		$this->load->view('export_error_view', "");
	   		$this->load->view('global/footer_nonav', "");
		}

	}


}