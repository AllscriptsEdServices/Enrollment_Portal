<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Learners extends CI_Controller {

	public $data;

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('clients_model');
		$this->load->model('learners_model');
		$this->load->model('assign_program_model');
	}

	public function index()
	{		
   		$content = "";
   		$session_data = $this->user_model->getSessionDetails();
   		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}

   		$learners_list = $this->learners_model->getClientLearners($session_data["userDetails"]["clientId"]);

   		$content["clientId"] = $session_data["userDetails"]["clientId"];

   		$programs_array = array();
   		if(count($learners_list)<=0){
   			$content["learners_list"] = array();

   			//$this->load_page("no_learners_view", $content);
   			$this->load_page("learners_view", $content);
   		}else{
   			
   			for($i=0; $i<count($learners_list); $i++){
   				$learner_assigned_programs = $this->assign_program_model->get_learner_assignments($learners_list[$i]["learnerId"]);
   				$learners_list[$i]["programs"] = $learner_assigned_programs;
   			}

   			$content["learners_list"] = $learners_list;   			
   			
   			$this->load_page("learners_view", $content);
   		}
   		
	}


	
	function load_page($page_name, $page_data){	
		$session_data = $this->user_model->getSessionDetails();
		//Check if a valid session is active. Else redirect to login page.
		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}
		
		$header_data['userDetails'] = $session_data["userDetails"];	
		$header_data['orgName'] = $this->clients_model->get_org_name_for_header($session_data["userDetails"]["clientId"]);		
		$header_data['headerfiles'] = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/learners.css").'">'
		);
		$page_data["baseURL"] = base_url("index.php/");
		$footer_data["activeTab"] = "nav_users";

		$this->load->view('global/header', $header_data);
   		$this->load->view($page_name, $page_data);
   		$this->load->view('global/footer', $footer_data);

	}


	function addLearners(){		

		$learner_list = $this->input->post('learner_list');

		$session_data = $this->user_model->getSessionDetails();

		$process_status = $this->learners_model->addLearners($learner_list,  $session_data["userDetails"]["clientId"], $session_data["userDetails"]["userId"]);
		echo json_encode($process_status);
	}


	function edit_learner_window($learnerId){
		$content["baseURL"] = base_url("index.php/");
		$content["learnerId"] = $learnerId;
		$content["learner_data"] = $this->learners_model->get_learner_details($learnerId);
		$this->load->view("edit_learner_view", $content);
	}

	function save_learner_changes(){
		$learner_details = array();	

		$learner_details["first_name"] = $this->input->post('first_name');
		$learner_details["last_name"] = $this->input->post('last_name');
		$learner_details["email"] = $this->input->post('email');
		$learner_details["user_name"] = $this->input->post('user_name');
		$learner_details["phone"] = $this->input->post('phone');
		$learner_details["department"] = $this->input->post('department');
		$learner_details["role"] = $this->input->post('role');		
		$learner_details["learnerId"] = $this->input->post('learnerId');		
		$learner_details["force_update_username"] = $this->input->post('force_update_username');
		

		$this->learners_model->set_learner_details($learner_details);

		echo json_encode($learner_details);

	}


	function open_csv_import_window(){
		$content["csv_upload_status"] = array();
		$this->load->view("csv_import_view", $content);
		
	}


	function upload_learner_csv(){
		$session_data = $this->user_model->getSessionDetails();

		$content['csv_upload_status']=$this->learners_model->upload_learner_csv( $session_data["userDetails"]["userId"], $session_data["userDetails"]["clientId"]);
		//$data['query']=$this->learners_model->get_car_features_info();
		$this->load->view('csv_import_view',$content);
	}



} 