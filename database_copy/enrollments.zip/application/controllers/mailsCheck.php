<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MailsCheck extends CI_Controller {

	public function __construct()
	{
		parent::__construct();		
		/*$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('request_model');*/
	}

	public function index()
	{			
		$this->load->library('email');
		//$this->email->set_newline("\r\n");
        //$this->email->set_mailtype("text");
        $this->email->from('enroll@eduserv.myallscripts.com', 'Program Enrollment Portal');        
        $this->email->to('vishwajitrmenon@gmail.com, vishwajit.menon@allscripts.com');
        //$this->email->to("zahrah.shaikh@allscripts.com");
        
        //$this->email->bcc('vishwajit.menon@allscripts.com');
        
        //$report_url = base_url("index.php/export_module/excel_internal_summary/")."/".$requestId;
       	$mailBody = "This is the email body.";
        $this->email->subject("Program Enrollment Portal - Request E0");
        $this->email->message($mailBody);

        $this->email->send();

        /*$headers = "Reply-To: Eduserv Email Test <vishwajit.menon@allscripts.com>\r\n"; 
		$headers .= "Return-Path: Eduserv Email Test <vishwajit.menon@allscripts.com>\r\n"; 
		$headers .= "From: Eduserv Email Test <vishwajit.menon@allscripts.com>\r\n";
		$headers .= "Organization: Allscripts\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "X-Priority: 3\r\n";
		$headers .= "X-Mailer: PHP". phpversion() ."\r\n";
		$headers .= "X-Confirm-Reading-To: <vishwajit.menon@allscripts.com>\r\n";
		$headers .= "Disposition-Notification-To:<vishwajit.menon@allscripts.com>\r\n";
		$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
		
		$subj =  'Testing Delivery report';
		$message = "This is the email body";
		$mailsend=mail("vishwajitrmenon@gmail.com","$subj","$message","$headers");
		echo $mailsend;*/
	}

	function sendMail()
	{
	    $config = Array(
		  'protocol' => 'smtp',
		  'smtp_host' => 'ssl://smtp.googlemail.com',
		  'smtp_port' => 465,
		  'smtp_user' => 'xxx@gmail.com', // change it to yours
		  'smtp_pass' => 'xxx', // change it to yours
		  'mailtype' => 'html',
		  'charset' => 'iso-8859-1',
		  'wordwrap' => TRUE
		);

	      $message = '';
	      //$this->load->library('email', $config);
	      $this->load->library('email');
	      $this->email->set_newline("\r\n");
	      $this->email->from('enroll@eduserv.myallscripts.com', 'Enrollments'); // change it to yours
	      $this->email->to('vishwajitrmenon@gmail.com, vishwajit.menon@allscripts.com');// change it to yours
	      $this->email->subject('Checking Mail from Hostgator');
	      $this->email->message("Test Message");
	      if($this->email->send())
	      {
	      	echo 'Email sent.';
	      }
	      else
	      {
	      	show_error($this->email->print_debugger());
	      }

	}

	
	/*function fnLoadPage($page_data){		
		$session_data = $this->user_model->getSessionDetails();
		//Check if a valid session is active. Else redirect to login page.
		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}

		$header_data['userDetails'] = $session_data["userDetails"];
		$header_data['headerfiles'] = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/requests.css").'">'
		);
		$page_data["baseURL"] = base_url("index.php/");
		$footer_data["activeTab"] = "nav_requests";

		$this->load->view('global/header', $header_data);
   		$this->load->view('requests_view', $page_data);
   		$this->load->view('global/footer', $footer_data);

	}
*/


	


}