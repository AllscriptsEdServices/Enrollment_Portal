<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Introduction extends CI_Controller {

	public function __construct()
	{
		parent::__construct();		
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('clients_model');
	}

	public function index()
	{			
   		//echo "here";
   		$session_data = $this->user_model->getSessionDetails();  
   		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}
		  		
   		$content["user_details"] = $session_data["userDetails"];
   		$content["client_details"] = $this->clients_model->get_client_details($session_data["userDetails"]["clientId"]);
   		//echo "<br> - ".$session_data["userDetails"]["is_multi_client"];
   		$all_clients_array = array();
   		if($session_data["userDetails"]["is_multi_client"]){
   			$split_id_array = explode("$", $session_data["userDetails"]["all_clients_string"]);
   			

   			foreach ($split_id_array as $single_client) {
   				//$this->clients_model->get_client_details($single_client);
   				array_push($all_clients_array, $this->clients_model->get_client_details($single_client));
   			}
   		}

   		//Sort the multiple clients by organization Name
   		/*usort($all_clients_array, function($a, $b) {
		    return $a['orgName'] - $b['orgName'];
		});*/

   		$content["all_clients_array"] = $all_clients_array;

   		$this->load_page($content);
	}


	
	function load_page($page_data){	
		$session_data = $this->user_model->getSessionDetails();
		//Check if a valid session is active. Else redirect to login page.
		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}


		$header_data['userDetails'] = $session_data["userDetails"];
		$header_data['orgName'] = $this->clients_model->get_org_name_for_header($session_data["userDetails"]["clientId"]);		
		$header_data['headerfiles'] = array(
			//'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'
		);
		$page_data["baseURL"] = base_url("index.php/");
		$footer_data["activeTab"] = "nav_intro";

		$this->load->view('global/header', $header_data);
   		$this->load->view('introduction_view', $page_data);
   		$this->load->view('global/footer', $footer_data);

	}


	function change_account(){
		$new_clientId = $this->input->post('new_clientId');
		$process_status = $this->user_model->change_current_clientId($new_clientId);
		echo true;
	}

}