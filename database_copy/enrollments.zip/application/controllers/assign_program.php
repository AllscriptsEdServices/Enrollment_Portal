<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Assign_Program extends CI_Controller {

	var $session_data = array();

	public function __construct()
	{
		parent::__construct();		
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('learners_model');
		$this->load->model('clients_model');
		$this->load->model('programs_model');
		$this->load->model('request_model');	
		$this->load->model('assign_program_model');			
	}

	public function index()
	{			
		$session_data = $this->user_model->getSessionDetails();
   		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}
	}



	public function display_assign_request(){
		$content = "";   		  		
   		$this->session_data = $this->user_model->getSessionDetails(); 
   		$request_session = $this->request_model->get_current_request();

   		$learners_list = $this->learners_model->getClientLearners($this->session_data["userDetails"]["clientId"]);   		
   		
   		//foreach($learners_list as $learner){
   		$learner_list_length = count($learners_list);
   		for($i=0; $i<$learner_list_length; $i++){
   			$learners_list[$i]["current_assignments"] = $this->assign_program_model->get_this_request_assignments($request_session["request_details"]["requestId"], $learners_list[$i]["learnerId"]);
   		}

   		$content["learners_list"] = $learners_list;
   		$content["all_products"] = $this->programs_model->get_all_products();

   		
   		if($request_session["active_status"]){   		
   			$content["requestId"] = $request_session["request_details"]["requestId"];   			
   			//$content["requestId"] = 14;
   		} 

   		$this->fnLoadPage($content, "assign_program_view");
	}

	
	function fnLoadPage($page_data, $page_name){		
		//$session_data = $this->user_model->getSessionDetails();
		//Check if a valid session is active. Else redirect to login page.
		if(!$this->session_data["active_status"]){
			redirect('login', 'refresh');
		}

		$header_data['userDetails'] = $this->session_data["userDetails"];
		$header_data['orgName'] = $this->clients_model->get_org_name_for_header($this->session_data["userDetails"]["clientId"]);	
		$header_data['headerfiles'] = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/requests.css").'">'
		);
		$page_data["baseURL"] = base_url("index.php/");
		$footer_data["activeTab"] = "nav_requests";

		$this->load->view('global/header', $header_data);
   		$this->load->view($page_name, $page_data);
   		$this->load->view('global/footer', $footer_data);

	}


	function get_category_versions(){		

		$productId = $this->input->post('productId');

		$process_status = $this->programs_model->get_category_versions($productId);

		echo json_encode($process_status);

	}


	function get_programs(){
		$productId = $this->input->post('productId');
		$categoryId = $this->input->post('categoryId');
		$versionId = $this->input->post('versionId');

		$process_status = $this->programs_model->get_programs($productId, $categoryId, $versionId);

		echo json_encode($process_status);
	}

	
	function set_assignments(){				

		$selected_learners = $this->input->post('selected_learners');
		$selected_programs = $this->input->post('selected_programs');

		$request_session = $this->request_model->get_current_request();
		$this->session_data = $this->user_model->getSessionDetails(); 
		$process_status = $this->assign_program_model->set_assignments($selected_learners, $selected_programs, $this->session_data["userDetails"]["clientId"], $request_session["request_details"]["requestId"]);

		//echo json_encode($process_status);
		echo json_encode($process_status);
	}


	function delete_assignment(){
		$enrollmentId = $this->input->post('enrollmentId');
		$process_status = $this->assign_program_model->delete_assignment($enrollmentId);
		echo $process_status;
	}


	function check_view_summary_active(){
		$request_session = $this->request_model->get_current_request();
		$process_status = $this->assign_program_model->check_view_summary_active($request_session["request_details"]["requestId"]);
		echo $process_status;
	}


	function show_assign_summary(){
		$this->session_data = $this->user_model->getSessionDetails(); 
		$request_session = $this->request_model->get_current_request();
		$all_enrollments = $this->assign_program_model->get_summary_details($request_session["request_details"]["requestId"], "programId");

		$summary_array = array();
		$each_program_array = array();
		$previous_program_id = 0;

		foreach ($all_enrollments as $enrollment) {

			if($enrollment["programId"] != $previous_program_id){

				if($previous_program_id != 0 ){
					array_push($summary_array, $each_program_array);
				}

				$previous_program_id = $enrollment["programId"];
				$each_program_array = array();
				$each_program_array["programId"] = $enrollment["programId"];
				$each_program_array["programName"] = $this->programs_model->get_program_name($enrollment["programId"]);	
				$each_program_array["learner_list"] = array();
			}	

			$learner_array = array();			
			$learner_array = $this->learners_model->get_learner_details($enrollment["learnerId"]);

			array_push($each_program_array["learner_list"], $learner_array);

		}

		//Push the last program array as well. This is because If loop is in the beginning
		array_push($summary_array, $each_program_array);

		$content["summary_details"] = $summary_array;
		$content["requestId"] = $request_session["request_details"]["requestId"];
		$this->fnLoadPage($content, "assign_summary_view");
	}


	function submit_request(){
		$requestId = $this->input->post('requestId');		
		
		$unique_learners = $this->assign_program_model->get_unique_learners($requestId);
		$new_learners_details = $this->learners_model->set_lms_new_learners($unique_learners, $requestId);
		$contains_hsg_program = $this->assign_program_model->check_hsg_program($requestId);

		//$all_enrollments = $this->assign_program_model->get_summary_details($requestId, "learnerId");				

		$session_user_data = $this->user_model->getSessionDetails();
		$process_status = $this->request_model->submit_request($requestId, $session_user_data["userDetails"]["userId"]);

		$request_details = $this->request_model->get_request_details($requestId);
		$client_details = $this->clients_model->get_client_details($request_details["clientId"]);

		//Commented for now - Sends the mail to the Allscripts Team notifying about the request submission
		$this->request_model->send_request_notify_mail($requestId, $client_details, "Assign Program", $contains_hsg_program);
		
		echo $process_status;

	}



}