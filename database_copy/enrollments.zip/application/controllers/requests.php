<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Requests extends CI_Controller {

	public function __construct()
	{
		parent::__construct();		
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->model('request_model');
		$this->load->model('clients_model');
	}

	public function index()
	{			
		$session_data = $this->user_model->getSessionDetails();
		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}
		
   		$content = "";
   		$content["all_requests"] = $this->request_model->get_all_requests($session_data["userDetails"]["clientId"]);
   		$this->fnLoadPage($content);

	}

	
	function fnLoadPage($page_data){		
		$session_data = $this->user_model->getSessionDetails();
		//Check if a valid session is active. Else redirect to login page.
		if(!$session_data["active_status"]){
			redirect('login', 'refresh');
		}

		$header_data['userDetails'] = $session_data["userDetails"];
		$header_data['orgName'] = $this->clients_model->get_org_name_for_header($session_data["userDetails"]["clientId"]);	
		$header_data['headerfiles'] = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/requests.css").'">'
		);
		$page_data["baseURL"] = base_url("index.php/");
		$footer_data["activeTab"] = "nav_requests";

		$this->load->view('global/header', $header_data);
   		$this->load->view('requests_view', $page_data);
   		$this->load->view('global/footer', $footer_data);

	}

	function create_request(){
		$request_type = $this->input->post('request_type');

		$session_data = $this->user_model->getSessionDetails();

		$request_session = $this->request_model->create_request($session_data["userDetails"]["clientId"], $request_type,  $session_data["userDetails"]["userId"]);
   		
   		return $request_session;

	}

	function set_current_request_session(){		
		$requestId = $this->input->post('requestId');
		$request_type = $this->input->post('request_type');

		$process_status = $this->request_model->set_current_request($requestId, $request_type, true);

		echo $process_status;
	}


	function delete_request(){
		$requestId = $this->input->post('requestId');
		$request_type = $this->input->post('request_type');

		switch ($request_type) {
			case 'assign_program':
				$this->load->model('assign_program_model');
				$this->assign_program_model->delete_request_data($requestId);
				$this->request_model->delete_request($requestId);
				break;
			
			default:
				# code...
				break;
		}

		echo true;
	}


}