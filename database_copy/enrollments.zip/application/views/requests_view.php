

<div class="container top-buffer">
	<div class="row bg-header-green" style="padding-bottom:10px">
		<div class="column col-xs-4 ">
			<h2>Requests</h2>
		</div>
		<div class="column col-xs-8 text-right" style="margin-top:12px">			
			<!-- <a class="btn btn-enrollment" href="<?php echo base_url("index.php/assign_program/create_assign_request"); ?>">Assign Programs</a> -->
			<!-- <div class="white-lead">Create New Request - </div>	 -->
			<!-- <div style="display:inline"> -->
				<a class="btn btn-enrollment" href="javascript:create_request('assign_program');" data-toggle="tooltip" data-placement="bottom" title="Assign education programs to learners">Assign Programs</a>
				<button class="btn btn-enrollment" disabled>Remove Programs</button>
				<a class="btn btn-enrollment" href="javascript:create_request('deactivate_learners');" data-toggle="tooltip" data-placement="bottom" title="Remove learners who have left your organization">Deactivate Learners</a>
			<!-- </div> -->
		</div>

		<!-- <div class="column col-xs-12" style="margin-top:10px">
			<p class="white-lead">Here are your organization's requests:</p>
		</div> -->

	</div>

	<div class="row ">
		<div class="column col-sm-12" style="padding:0px">
			<?php if(count($all_requests)>0) {?>
				
				<table class="table table-bordered green-table">
					<thead>
						<tr>
							<th>Created Date</th>
							<th>Request Id</th>						
							<th>Type</th>
							<th>Status</th>
							<th>Submitted Date</th>
							<th>Actions</th>
						</tr>
					</thead>

					<tbody>
						<?php 
							foreach($all_requests as $request){
								echo '<tr id="request_row_'.$request["requestId"].'">';
								
								echo '<td>'.$request["created_date"].'</td>';
								echo '<td>E0'.$request["requestId"].'</td>';

								switch ($request["request_type"]) {
									case 'assign_program':
										echo '<td>Assign Programs</td>';
										break;
									
									case 'deactivate_learners':
										echo '<td>Deactivate Learners</td>';
										break;
									default:
										echo '<td>'.$request["request_type"].'</td>';
										break;

								}
								
								
								if($request["submission_status"]==0){
									echo '<td>Draft</td>';
									echo '<td></td>';	

									echo '<td><a id="edit_btn_'.$request["requestId"].'" data-req_type="'.$request["request_type"].'" href="javascript:view_request_draft('.$request["requestId"].')" >Edit</a> &nbsp;&nbsp; <a id="delete_btn_'.$request["requestId"].'" data-req_type="'.$request["request_type"].'" href="javascript:delete_request_draft('.$request["requestId"].')" >Delete</a>  </td>';
								}else{
									echo '<td>Submitted</td>';
									echo '<td>'.$request["submitted_date"].'</td>';
									switch ($request["request_type"]) {
										case 'assign_program':
											echo '<td><a href="'.base_url("/index.php/export_module/excel_client_summary/")."/".$request["requestId"].'" target="_blank">Download Excel Report</a></td>';
											break;
										case 'deactivate_learners':
											echo '<td><a href="'.base_url("/index.php/export_module/excel_deactivate_report/")."/".$request["requestId"].'" target="_blank">Download Excel Report</a></td>';
											break;
									}
									
								}

								echo '</tr>';

							}

						?>

					</tbody>

				</table>

			<?php }else{ ?>
				<p style="font-size:16px;" class="top-buffer">You have not created any requests yet.</p>	

			<?php } ?>
		</div>

	</div>

</div>


<script type="text/javascript">
	var baseURL = <?php echo json_encode($baseURL) ?>;

	$(function () {
	    $('[data-toggle="tooltip"]').tooltip();
	})

	function create_request(request_type){
		var form_data = {
			'request_type': request_type	      	   	
	    };

	    $.ajax({
	      	type: "POST",
	      	url: baseURL + "/requests/create_request",
	      	data: form_data,
	      	success: function(response)
	      	{		      		
	      		//var responseObj = $.parseJSON(response);
	      		//alert(responseObj.successful);
	      		//display_successful_assignments(selected_learners, selected_programs);
	      		
	      		switch (request_type){
	      			case "assign_program":
	      				window.location.href = baseURL + "/assign_program/display_assign_request";
	      				break;
	      			case "deactivate_learners":
	      				window.location.href = baseURL + "/deactivate_learners";
	      				break;
	      		}
	      	}
	    });
	}
	

	
	function view_request_draft(requestId){		
		var requestType = $('#edit_btn_' + requestId).attr("data-req_type");
		var form_data = {
			'requestId': requestId,
			'request_type': requestType
	    };

	    $.ajax({
	      	type: "POST",
	      	url: baseURL + "/requests/set_current_request_session",
	      	data: form_data,
	      	success: function(response)
	      	{      		
	      		//window.location.href = baseURL + "/assign_program/display_assign_request";
	      		switch (requestType){
	      			case "assign_program":
	      				window.location.href = baseURL + "/assign_program/display_assign_request";
	      				break;
	      			case "deactivate_learners":
	      				window.location.href = baseURL + "/deactivate_learners";
	      				break;
	      		}
	      	}
	    });

	}



	function delete_request_draft(requestId){

		var confirm_delete = confirm("This will permanently delete this request. Would you like to proceed?");
		if(confirm_delete){

			var form_data = {
				'requestId': requestId,
				'request_type': $('#delete_btn_' + requestId).attr("data-req_type")
		    };

		    $.ajax({
		      	type: "POST",
		      	url: baseURL + "/requests/delete_request",
		      	data: form_data,
		      	success: function(response)
		      	{     
		      		if(response) {
		      			$("#request_row_" + requestId).hide();
		      		}
		      		
		      	}
		    });

		}

	}


</script>