<div class="container">
	<div class="row">
		<div class="column col-sm-6 col-sm-offset-3 well">
			<h3>Users - No Learners</h3>
			Home page for the user transactions.
		</div>
	</div>

	<button class="btn btn-default" onclick="fnAddUsers()">Add Users</button>
</div>

<script type="text/javascript">
	var baseURL = <?php echo json_encode($baseURL) ?>;



	var usersString = '';
	function fnAddUsers(){
		var action = baseURL + "/learners/addLearners";
	    var form_data = {
	      'learner_list': 'Wayne$Rooney$wayne.rooney@manc.com$9000120340$Casualty$Physician|#|Roy$Keane$roy.keane@manc.com$2000123987$Casualty$Physician|#|Nemanja$Vidic$nemanja.vidic@manc.com$8000123345$Billing$Analyst|#|Patrice$Evra$patrice.evra@manc.com$9000666777$Ortho$Nurse'	   
	    };

	    $.ajax({
	      	type: "POST",
	      	url: action,
	      	data: form_data,
	      	success: function(response)
	      	{		
	      		

	      		var responseObj = $.parseJSON(response);
	      		alert(responseObj.successful);
	      		window.location.href = <?php echo json_encode(base_url("index.php/learners/")) ?>;
	      		/*$('#loadingDiv').hide();
	      		if(responseObj.status=="Fail"){
	      			$('#errorBox').html("A client with this CDH number already exists in the system.");
	      			$('#errorBox').fadeIn();
	      		}else if(responseObj.status=="Success"){
	      			$('#errorBox').hide();
	      			window.location.href = <?php echo json_encode(base_url("index.php/introduction/")) ?>;
	      		}*/
	      			
	      	}
	    });
	}


</script>