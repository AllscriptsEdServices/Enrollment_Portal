<div class="container-fluid">
	<div id="loader_div" class="row" style="display:none">
		<div class="col-xs-12 text-center" style="position:fixed; top:0px; left:0px; width:100%; height:100%; display:block; background-color:#666; z-index:1000; opacity: 0.8">
			 <div style="position:absolute; height:180px; margin-top:-90px; top:50%; width:190px; margin-left:-95px; left:50%; font-size:20px; color:#fff">
			 	<img width="150px"src="<?php echo base_url("assets/img/loader_circle.gif"); ?>" /> Processing..
			 </div>
			 
		</div>

	</div>
	
	<div class="row">

		<div class="column col-sm-8 "  >
			<h2 style="color:#3f4450; margin-top:0px; font-weight:bold">Assign Programs - E0<?php echo $requestId?></h2>	
			<ol>
				<li>In the <strong>Learners</strong> table, select all learners who should be enrolled in a specific program or programs.</li>
				<li>In the <strong>Programs List</strong>, identify which program(s) to assign to the selected learners.</li>
				<li>When you are done assigning programs to learners, click <strong>Review and Submit</strong>.</li>
			</ol>
		</div>

		<div class="column col-sm-4 text-right" >
			<!-- Once you have made your selections, you can view the summary and submit the request. --> 
			<button class="btn btn-lg btn-enrollment" onclick="show_request_summary()">Review and Submit</button>
		</div>

	</div>

	<div class="row">
		
		<div class="column col-sm-7" >	

			<div class="margin-holder" style="margin:15px">	 
				<div class="row bg-header-green">
					<h3 style="margin-top:10px" class="text-center ">Learners</h3>
				</div>

				<div class="row bg-light-green" style="padding:5px">				
					<div class="col-xs-6">	
						<label>Search By Column</label>
						<select class="form-control" id="search_by_drop" name="search_by_drop">
							<option value="2">First Name</option>
							<option value="3">Last Name</option>
							<option value="4">Department</option>
							<option value="5">Role</option>				
						</select>				
					</div>

					<div class="col-xs-6">	
						<label>Search Text</label>	
				        <input type="text" class="form-control" id="search_org_all" placeholder="Your search term"></input>		     
			        </div>
		        </div>

		        <div class="row" style="">
					<table id="users_table" class="table table-bordered green-table">
						<thead>
							<tr>
								<th><input type="checkbox" id="select_all_users_checkbox" name="users" value="all"></input></th>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Department</th>
								<th>Role</th>
								<th>Programs Requested</th>
							</tr>
						</thead>

						<tbody>					
							<?php $counter=0; foreach($learners_list as $learner): ?>
								<tr>
									<td><input type="checkbox" class="users_checkbox" name="users_checkbox" value="<?php echo $learner['learnerId'] ?>"></input></td>
									<td><?php echo $learner['first_name'] ?></td>
									<td><?php echo $learner['last_name'] ?></td>
									<td><?php echo $learner['department'] ?></td>
									<td ><?php echo $learner['role'] ?></td>
									<?php
										echo '<td id="programs_requested_div_'.$learner['learnerId'].'">';

										if(count($learner['current_assignments'])>0){
											foreach($learner['current_assignments'] as $single_assignment){
												echo '<table id="temp_assign_table_'.$single_assignment["enrollmentId"].'"class="learner_assigned_table"><tr><td class="assigned_program_name">'.$single_assignment["programName"].'</td> <td class="text-right"> <a href="javascript:delete_assignment('.$single_assignment["enrollmentId"].')"> <span class="glyphicon glyphicon-remove-circle" style="font-weight:bold" aria-hidden="true" data-toggle="tooltip" data-placement="bottom" title="Delete this assignment" ></span> </a>  </td> </tr> </table>';
											}
										}
											

										echo '</td>';
									?>							

									<!-- <td id="programs_requested_div_<?php echo $learner['learnerId'] ?>"></td> -->
								</tr>

							<?php endforeach; ?>


							
						</tbody>

					</table>

				</div>

			</div>

		</div>

		

		
			<div class="column col-sm-5" >		
				<div class="margin-holder" style="margin:15px">		
					<div class="row bg-header-green"	>
						<h3 style="margin-top:10px" class="text-center ">Programs List</h3>
					</div>

					<div class="row bg-light-green">
						<div class="col-xs-12">
							<div id="breadcrumb_div" class="breadcrumb_div">
								<a href="javascript:display_home()">Home</a>
							</div>
						</div>
					</div>

					<div class="row">
						<div id="products_list" class="col-xs-12 bg-white" style="padding-top:20px; padding-bottom:30px">
							<!-- <p>Select the required product you want to assign to the selected learners.</p> -->
							<table id="products_table" style="width:400px" align="center">
								<?php 
									$counter = 0;
									foreach ($all_products as $product){
										if($counter%2==0){
											echo '<tr>';
										}

										echo '<td style="padding:10px"><button class="btn btn-success btn" onclick="get_category_versions('.$product['productId'].')" style="width:180px">'.$product['productName'].'</button></td>';

										if($counter%2!=0){
											echo '</tr>';
										}

										$counter++;

									} 

								?>

							</table>

						</div>


						<div id="category_version_div" class="col-xs-12 bg-white hidden" style="padding-top:20px; padding-bottom:20px">
							<!-- Just placeholder to check alignments. Will be populated through JS -->

							<!-- <h5 class="text-center">Product Categories and Versions</h5>
							<table class="table table-bordered bg-white" style="width:60%" align="center"><tbody><tr><td><input name="category_drop" type="radio">  Acute</td><td><select><option value="14.2">14.2</option></select></td></tr><tr><td><input name="category_drop" type="radio">  Ambulatory</td><td><select><option value="14.2">14.2</option><option value="14.3">14.3</option></select></td></tr></tbody></table>

							<button class="btn btn-enrollment center-block" onclick="javascript:display_programs()">Go To Programs</button> -->

						</div>


						<div id="programs_div" class="col-xs-12 hidden">
							<div class="row bg-light-green" style="padding:5px 0px">
								<div class="col-xs-6">	
									<label>Search Programs</label>	
							        <input type="text" class="form-control" id="search_program_all" placeholder="Your search term"></input>		     
						        </div>
						        <div class="col-xs-6 text-right">	
									<button class="btn btn-success btn-lg" onclick="assign_programs()">Assign</button>		     
						        </div>
						    </div>

							
							<div id="programs_list" class="row">
								<table class="table table-bordered bg-white">
									<thead>
										<th><input type="radio" name="programs_radio" value="all"></th>
										<th>Program Name</th>							
									</thead>
								</table>
							</div>
						</div>


					</div> <!-- End of Right Section ROW -->

				</div>

			</div> <!-- End of Right Section parent column -->

		

	</div> <!-- End of Main Row -->

</div> <!-- End of Container -->


<div class="modal fade" id="warning_modal" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title">Warnings</h4>
      </div>
      <div class="modal-body">
	      	<p>Some of the learners you selected for these assignments are already enrolled in some of the program/s.<p>
	      	<p>Here are the duplicate assignments that were identified.</p>
	      	<div id="warning_content_div">

	      	</div>
      </div>
      <div class="modal-footer">	        
        <!-- <button id="forgot_submit_btn" type="button" class="btn btn-enrollment" onclick="fnForgotPassword()">Submit</button> -->
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="modal fade" id="program_description_modal" >
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title">Program Description</h4>
      </div>
      <div class="modal-body">
	      	<h3 id="program_description_title">Ed Services Physician Program</h3>
	      	<p id="program_description_text">All Nurses should complete this program prior to Activation (Go-Live) and all New Hire Nurses, prior to their first day with patients. Courses include Introducing Ambulatory Care, Starting Your Shift, Managing the Patient Visit, Managing Orders, Managing Immunizations and Wellness, Working with Prescriptions, Working with Super Bills, Ending the Patient Visit and Setting up Accounts and User Preferences.</p>
	      	
      </div>
      <div class="modal-footer">	        
        <!-- <button id="forgot_submit_btn" type="button" class="btn btn-enrollment" onclick="fnForgotPassword()">Submit</button> -->
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script type="text/javascript">
	var baseURL = <?php echo json_encode($baseURL) ?>;
	var all_products = <?php echo json_encode($all_products) ?>;
	var current_product = 0;
	var current_programs_array = Array();

	//$('input, textarea').placeholder();

	$(function () {
	    $('[data-toggle="tooltip"]').tooltip();
	})
	
</script>

<script src="<?php echo base_url("assets/js/assign_program.js"); ?>"></script>

