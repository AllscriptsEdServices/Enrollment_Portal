<div class="container">
	<div class="row">
		<div class="column col-sm-8 col-sm-offset-2 well">
			<p>Some error occured when trying to export this report.</p>
			<p>Either this request does not exist currently or the system is facing issues connecting right now.</p>
			<p>Please contact the administrator for further assisstance: <a href="mailto:vishwajit.menon@allscripts.com">Enrollment Adminstrator</a></p>
		</div>
	</div>
</div>