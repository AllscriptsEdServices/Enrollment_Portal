<div class="container-fluid" style="">

	<div id="loader_div" class="row" style="">
		<div class="col-xs-12 text-center" style="position:fixed; top:0px; left:0px; width:100%; height:100%; display:block; background-color:#666; z-index:1000; opacity: 0.8">
			 <div style="position:absolute; height:180px; margin-top:-90px; top:50%; width:190px; margin-left:-95px; left:50%; font-size:20px; color:#fff">
			 	<img width="150px"src="<?php echo base_url("assets/img/loader_circle.gif"); ?>" /> Processing..
			 </div>
			 
		</div>

	</div>

	<div class="row">
		<div class="column col-sm-12 "  >
			<h2 style="color:#3f4450; margin-top:0px; font-weight:bold">
				Welcome to the Program Enrollment Portal!
			</h2>	
			<p>This portal allows you to view and add <strong>learners</strong> from your organization to the Allscripts Learning Center. In addition, you can generate <strong>requests</strong> to assign or remove education programs for any learner, group of learners, or every learner in your organization. You can also request to deactivate a learner who is no longer with your  organization, and review previous requests.</p>
			<p></p>
		</div>
		
	</div>

	<?php if(!$user_details["is_multi_client"]){ ?>
		<div class="row top-buffer">
			<div class="column col-sm-6 " >
				<p class="lead"><strong>Your details:</strong></p>
				<table class="table table-bordered bg-white">
					<tr>
						<th>Organization Name</th>
						<td><?php echo $client_details["orgName"] ?> </td>
					</tr>
					<tr>
						<th>Account Number Name</th>
						<td><?php echo $client_details["accountNumber"] ?> </td>
					</tr>				
				</table>
			</div>
		</div>

	<?php }else{ ?>

		<div class="row top-buffer">
			<div class="column col-sm-9 col-md-7" >
				<p class="lead"><strong><span class="glyphicon glyphicon-check" style="color:#4A7C14; font-weight:bolder" aria-hidden="true"></span>&nbsp; Currently Selected Account:</strong></p>
				<p>Your credentials are associated with multiple organizations. Your currently selected organization is:</p>
				<table class="table table-bordered bg-white">
					<tr>
						<th>Organization Name</th>
						<td><?php echo $client_details["orgName"] ?> </td>
					</tr>
					<tr>
						<th>Account Number Name</th>
						<td><?php echo $client_details["accountNumber"] ?> </td>
					</tr>				
				</table>
			</div>

		</div>

		<div class="row top-buffer">
			<div class="column col-sm-9 col-md-7 top-buffer" >
				<p class="lead"><strong><span class="glyphicon glyphicon-random" style="color:#4A7C14; font-weight:bolder" aria-hidden="true"></span>&nbsp; Switch Your Account</strong></p>
				<p>Your credentials are associated with multiple organizations. The currently selected organization appears in the table above. To manage the learners and requests for another organization, use the drop-down list to select the organization, then click the <strong>Change Account</strong> button.</p>

				<table class="table table-bordered bg-white">
					<tr>
						<td>
							<select id="clients_drop_down" class="form-control">
								<?php 
									foreach ($all_clients_array as $single_client){

										if($single_client["clientId"] == $user_details["clientId"]){
											echo '<option value="'.$single_client["clientId"].'" selected>'.$single_client["orgName"].' ('.$single_client["accountNumber"].')</option>';
										}else{
											echo '<option value="'.$single_client["clientId"].'">'.$single_client["orgName"].' ('.$single_client["accountNumber"].')</option>';
										}
										
									}
								?>
							</select>

						</td>
						<td>
							<button class="btn btn-enrollment" style="margin-top:0px" onclick="change_account()">Change Account</button>
						</td>	
					</tr>
				</table>
			
				<?php
					//echo json_encode($user_details);
					if($user_details["is_multi_client"]){
						//echo '<br></br>';
						//echo json_encode($all_clients_array);
					}
				?>
			</div>
		</div>

	<?php } ?>



</div> <!-- /end of container -->


<script type="text/javascript">
	var baseURL = <?php echo json_encode($baseURL) ?>;

	$(window).load(function(){
		$("#loader_div").hide();
	});

	function change_account(requestId){	
		var confirm_change = window.confirm("This will change the account you are handling currently. Proceed?");

		if(confirm_change){
			$("#loader_div").show();

			var form_data = {		
				new_clientId:$("#clients_drop_down").val()
		    };

		    $.ajax({
		      	type: "POST",
		      	url: baseURL + "/introduction/change_account",
		      	data: form_data,
		      	success: function(response)
		      	{      		
		      		//window.location.href = baseURL + "/assign_program/display_assign_request";
		      		//alert("here");
		      		window.location.reload(true);
		      	}
		    });
		}
		

	}
	
</script>