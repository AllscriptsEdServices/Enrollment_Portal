
<!-- Div when no learners have been added -->
<?php if(count($learners_list) <= 0 ){ ?>
	<div id="no_learners_div" class="container">
		<div class="row vertical-offset-150">
		    <section id="learnerpage">
		     	<div class="col-xs-12">
					<!-- <p>This is the list of employees who require training in your organization.</p> -->
		   			<p>Looks like you haven’t added any employees to the system. You can add them using one of the two methods below:</p>
		  		</div>
		 	</section>
	     
	   	  	<div class="col-md-4 ">
	   		  	<div class="custom-panel p">
				  	<div class="custom-panel-heading">
				    	<h2 class="panel-title">Add Learner</h2>
				 	</div>
	                <div class="add_learner">
	                	You can add them manually immediately by clicking on The Single Learner(s) button.
	                </div>
	            	<input type = "button" onclick = "addhidden()" data-toggle ="modal" data-target ="#myTable" class="btn btn-lg btn-success center-block"   value="Singler Learner(s)">
	  			</div>
			</div>


	    	<div class="col-md-8 ">
	    		<div class="custom-panel ">
				  	<div class="custom-panel-heading">
				    	<h2 class="panel-title">Add Multiple Learners</h2>
				 	</div>
	                <div class="row">
	                	<div class="col-md-6">
	                		<div class="add_learner">
	               				In case of a huge list, you can alternatively populate a csv file with the list of employees and other corresponding data as per the sample csv. You can download the sample csv.
							</div>
	             		</div>
	        
	        			<div class="col-md-1">
			               <img src="<?php echo base_url("assets/img/line.jpg"); ?>">
			            </div>
			               
			            <div class="col-md-4">
			                <div class="add_learner">
			              		Fill in all required details in the CSV and upload it.
			              	</div>
			            </div>

					</div>

					<div class="row">
						<div class="col-sm-5 col-xs-12 text-center">
							<input class="btn btn-lg btn-success" style="margin-left:20px;"  type="submit" onclick="download_sample_csv()" value="Download Sample CSV
						">
						</div>

						<div class=" col-sm-2 col-xs-12 text-center">
							<!--<p  >
					          <span class="glyphicon glyphicon-arrow-right fa-lg"></span>
					        </p>-->
					        <img  class="glyphicon glyphicon-arrow-right" src="<?php echo base_url("assets/img/arrow.png"); ?>">
					      
						</div>
						<div class="col-sm-5 col-xs-12 text-center">
					        <input class="btn btn-lg btn-success"  type="button"  data-toggle ="modal" data-target ="#csv_upload_modal" value="Upload Your CSV">
					        <!-- <button type = "button" class="btn btn-enrollment"  data-toggle ="modal" data-target ="#myTable">Upload CSV</button> -->
						</div>
					</div>
	        	</div>
	        </div>
		</div>
	</div>

<?php } ?>


<?php if(count($learners_list) > 0 ){ ?>
	<div class="container top-buffer " id = "learners_div">
<?php }else{ ?>
	<div class="container top-buffer hidden" id = "learners_div">
<?php } ?>

	<div id="loader_div" class="row" style="">
		<div class="col-xs-12 text-center" style="position:fixed; top:0px; left:0px; width:100%; height:100%; display:block; background-color:#666; z-index:1000; opacity: 0.8">
			 <div style="position:absolute; height:180px; margin-top:-90px; top:50%; width:190px; margin-left:-95px; left:50%; font-size:20px; color:#fff">
			 	<img width="150px"src="<?php echo base_url("assets/img/loader_circle.gif"); ?>" /> Processing..
			 </div>
			 
		</div>

	</div>

	<div class="row bg-header-green" style="padding-bottom:10px">	
		<div class="col-xs-6" >	
			<h2>Learners</h2>
		</div>

		<div class="col-xs-6 text-right" style="padding-top:12px">	
			<button type = "button" class="btn btn-enrollment" data-toggle="tooltip" data-placement="bottom" title="Export list current learners (shown in table below)" onclick = "export_learners_list()" >Export Learner List</button>			
			<button class="btn btn-enrollment" data-toggle="tooltip" data-placement="bottom" title="Download a template to use when adding new learners" onclick="download_sample_csv()" >Sample CSV</button>
			<button class="btn btn-enrollment" onclick="" data-toggle ="modal" data-target ="#csv_upload_modal"><span data-toggle="tooltip" data-placement="bottom" title="Upload completed learner list">Upload CSV</span></button>
			<button type = "button" class="btn btn-enrollment" onclick = "addhidden()"  data-toggle ="modal" data-target ="#myTable"><span data-toggle="tooltip" data-placement="bottom" title="Open a window to add learners one by one">Add Learners</span></button>
		</div>

	</div>

	<div class="row bg-light-green" style = "padding: 10px 0px 10px 10px">				
		<div class="col-xs-4" style ="padding-left:0px">	
				<label>Search By Column</label>
				<select class="form-control" id="search_by_drop" name="search_by_drop">
					<option value="1">First Name</option>
					<option value="2">Last Name</option>
					<option value="3">Email</option>
					<option value="4">Phone</option>
					<option value="5">Department</option>
					<option value="6">Role</option>				
					<!-- <option value="6">Programs Assigned</option> -->				
				</select>				
		</div>

		<div class="col-xs-4">	
			<label>Search Text</label>	
			     <!-- <input type="text" class="form-control search" onkeyup = "search(this)" id="search" placeholder="Your search term"></input>	 -->	     
			     <input type="text" class="form-control search"  id="search" placeholder="Your search term"></input>	
		 </div>
	 </div>
	
	
	<div class=" row usertable">
		<table id = "users_table"class="table table-bordered green-table hidden">
			<thead>
				<tr>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Email </th>
					<th>Phone number</th>
					<th>Department</th>
					<th>Role</th>
					<th>Programs Assigned</th>
					<th></th>
				</tr>
			</thead>

			<tbody>
				<?php				
					foreach($learners_list as $learner){
						echo '<tr>';
						echo '<td id="first_name_'.$learner["learnerId"].'">'.$learner["first_name"].'</td>';
						echo '<td id="last_name_'.$learner["learnerId"].'">'.$learner["last_name"].'</td>';
						echo '<td id="email_'.$learner["learnerId"].'">'.$learner["email"].'</td>';
						echo '<td id="phone_'.$learner["learnerId"].'">'.$learner["phone"].'</td>';
						echo '<td id="department_'.$learner["learnerId"].'">'.$learner["department"].'</td>';
						echo '<td id="role_'.$learner["learnerId"].'">'.$learner["role"].'</td>';

						echo '<td style="font-size:12px"> <ul>';
						foreach($learner["programs"] as $program_assigned){
							echo "<li>".$program_assigned["programName"]."</li>";
						}
						echo '</ul> </td>';

						echo '<td> <a id="edit_learner_btn_'.$learner["learnerId"].'" href="#" onclick="open_edit_learner_window('.$learner["learnerId"].')" data-learner_name="'.$learner["first_name"]." ".$learner["last_name"].'" data-toggle="modal" data-target="#edit_learner_modal" > <span data-toggle="tooltip" data-placement="bottom" title="Edit Learner Details" class = "glyphicon glyphicon-pencil"  title="Edit Learner Details"> </span> </a> </td>';

						//echo '<b>'.$learner["first_name"]." ".$learner["last_name"].'</b>';
						echo "</tr>";
					}
					
				?>
			</tbody>
		</table>

	</div>	


</div>  <!-- End of container -->
	
	


	<!-- My Table -->

	<div id="myTable" class = "modal fade" role = "dialog" data-keyboard="false" data-backdrop="static" >
		<div class="modal-dialog modal-lg">
			
			<!-- Table Content -->
				<div class="modal-content">
					 <div class="modal-header" >
						  <button  onclick = "alertClose()" type="button" class="close" data-dismiss= "" >&times;</button>
						  <h4 class="modal-title">Add Learners</h4>
					</div>
					
					<div class="modal-body">
						<div id = "confirmBox" class=" erase panel panel-danger hidden">
								
								<div class="panel-heading">Alert!</div>
								  <div class="panel-body"> You have not entered any users yet. Would you like to leave this Add users window? </div>
								  <div id = "alertfooter" class="panel-footer">
									<button onclick = "alertinput(this)" class="btn btn-danger" value = "no" >No</button>
									<button onclick = "alertinput(this)" value = "yes" class="btn btn-success">Yes</button>
								  </div>
						</div>
						<div id = "ErrorBox" class=" erase panel panel-danger hidden">
								
								<div class="panel-heading">Alert!</div>
								  <div class="panel-body"> Your changes have not been saved. Please fill in all required information before clicking "Save"  </div>
								  <div id = "errorfooter" class="panel-footer">
									<button  onclick = "alertinput(this)" value = "no" class="btn btn-success"> Close </button>
								  </div>
						</div>
						<div id = "SuccessBox" class="erase panel panel-success hidden">
								
								<div class="panel-heading">SUCCESS!</div>
								<div class="panel-body"> Your changes have been saved. </div>
								<div id = "successfooter" class="panel-footer">
									<!-- <button  onclick = "refreshPage(this)" value = "yes" class="btn btn-enrollment"> Done </button> -->
									<button  onclick = "refreshPage()" value = "yes" class="btn btn-primary"> Done </button>
									<button  onclick = "alertinput(this)" value = "no" class="btn btn-success"> Not Done</button>
								</div>

						</div>						
						<div id = "closeconfirmBox" class="erase panel panel-danger hidden">
								
								<div class="panel-heading">Alert!</div>
								<div class="panel-body"> You have not saved your changes!! What would you like to do with your entries? </div>
								<div id = "successfooter" class="panel-footer">
									<!-- <button  onclick = "refreshPage(this)" value = "yes" class="btn btn-enrollment"> Done </button> -->
									<button  onclick = "refreshPage()" value = "yes" class="btn btn-primary"> Discard and Close </button>
									<button  onclick = "alertinput(this)" value = "no" class="btn btn-success"> Keep and Stay </button>
								</div>

						</div>	
						
				

												
							<table id = "Table" class = "table table-bordered">
							  <thead>
								<tr>
									<th>First Name</th>
									<th>Last Name</th>
									<th>Email</th>
									<th>Phone number</th>
									<th>Department</th>
									<th>Role</th>								
								</tr>
							   
							  </thead>
							  <tbody>
							  	  	
							 <?php 	for($i=1; $i<=5; $i++){	?>	
							 	<tr>
							 		<td>
										<div id = "row_<?php echo $i ?>_first_name_div" class="form-group has-feedback">
											<input type="text" class="form-control" id = "row_<?php echo $i ?>_first_name" onkeyup = "removeerror(this)" onblur = "checkempty(this)" />
											<span id = "spanerror_<?php echo $i ?>_first_name" class="erase glyphicon glyphicon-exclamation-sign form-control-feedback hidden"></span>
											<span id = "spanok_<?php echo $i ?>_first_name" class="erase glyphicon glyphicon-ok form-control-feedback hidden"></span>
										</div>
										<div  id = "row_<?php echo $i ?>_first_name_error" class=" erase alert alert-danger hidden">
												
												<strong>Error:</strong> Please fill this box.
										</div>
										</td>

									<td > 
										<div id = "row_<?php echo $i ?>_last_name_div" class="has-feedback form-group">
											<input type="text" class="form-control " id = "row_<?php echo $i ?>_last_name" onkeyup = "removeerror(this)" onblur = "checkempty(this)" />
											<span id = "spanerror_<?php echo $i ?>_last_name" class=" erase glyphicon glyphicon-exclamation-sign form-control-feedback hidden"></span>
											<span id = "spanok_<?php echo $i ?>_last_name" class="erase glyphicon glyphicon-ok form-control-feedback hidden"></span>
										</div>
										<div id = "row_<?php echo $i ?>_last_name_error" class="erase alert alert-danger hidden">
												
												<strong>Error:</strong> Please fill this box.
										</div>
									
									</td>

									<td>
										<div id = "row_<?php echo $i ?>_email_div" class="has-feedback form-group">
											<input type="text" class="form-control" id = "row_<?php echo $i ?>_email"  onblur = "phoneemail(this)" onkeyup = "emailvalidate(this)"/>
											<span id = "spanerror_<?php echo $i ?>_email"class="glyphicon glyphicon-exclamation-sign form-control-feedback hidden erase"></span>
											<span id = "spanok_<?php echo $i ?>_email" class="erase glyphicon glyphicon-ok form-control-feedback hidden"></span>	<span id = "spanwarn_<?php echo $i ?>_email" class="erase glyphicon glyphicon-warning-sign form-control-feedback hidden"></span>
											
										</div>
										<div id = "row_<?php echo $i ?>_email_error" class="erase alert alert-danger hidden">
												
												<strong>Error:</strong> Please fill this box.
										</div>
										<div id = "row_<?php echo $i ?>_email_warning" class="erase alert alert-warning hidden">
												
												Invalid Email 
										</div>
									</td>

									<td>
										<div id = "row_<?php echo $i ?>_phone_div" class="has-feedback form-group">
											<input type="text" class="form-control" id = "row_<?php echo $i ?>_phone" onkeyup = "phonevalidate(this)"  onblur = "phoneemail(this)" />
											<span id = "spanerror_<?php echo $i ?>_phone" class="erase glyphicon glyphicon-exclamation-sign form-control-feedback hidden"></span>
											<span id = "spanok_<?php echo $i ?>_phone" class="erase glyphicon glyphicon-ok form-control-feedback hidden"></span>
											<span id = "spanwarn_<?php echo $i ?>_phone" class="erase glyphicon glyphicon-warning-sign form-control-feedback hidden"></span>
											<span id = "spanwarnmore_<?php echo $i ?>_phone" class="erase glyphicon glyphicon-warning-sign form-control-feedback hidden"></span><span id = "spanwarnless_<?php echo $i ?>_phone" class="erase glyphicon glyphicon-warning-sign form-control-feedback hidden"></span>
										</div>
										<div id = "row_<?php echo $i ?>_phone_error" class="erase alert alert-danger hidden">
												
												<strong>Error:</strong> Please fill this box.
										</div>
										<div id = "row_<?php echo $i ?>_phone_warning" class="erase alert alert-warning hidden">
												<strong>Error:</strong> Only numbers, please.
										</div>
										<div id = "row_<?php echo $i ?>_phone_warningmore" class="erase alert alert-warning hidden">
												
												Phone number exceeds normal.
												</div>
												
												<div id = "row_<?php echo $i ?>_phone_warningless" class="erase alert alert-warning hidden">
												
												Invalid phone format. Length is less than normal.
												</div>
									</td>
										
									
									<td>
										<div id = "row_<?php echo $i ?>_department_div" class="has-feedback form-group">
											<input type="text" class="form-control" id = "row_<?php echo $i ?>_department"onkeyup = "removeerror(this)"  onblur = "checkempty(this)"/>
											<span id = "spanerror_<?php echo $i ?>_department" class="erase glyphicon glyphicon-exclamation-sign form-control-feedback hidden"></span>
											<span id = "spanok_<?php echo $i ?>_department" class="erase glyphicon glyphicon-ok form-control-feedback hidden"></span>
										</div>
										<div id = "row_<?php echo $i ?>_department_error" class="erase alert alert-danger hidden">
												
												<strong>Error:</strong> Please fill this box.
										</div>
										</td>
										<td>
										<div id = "row_<?php echo $i ?>_role_div" class="has-feedback form-group">
											<input type="text" class="form-control" id = "row_<?php echo $i ?>_role"onkeyup = "removeerror(this)"  onblur = "checkempty(this)"/>
											<span id = "spanerror_<?php echo $i ?>_role"class="erase glyphicon glyphicon-exclamation-sign form-control-feedback hidden"></span>
											<span id = "spanok_<?php echo $i ?>_role" class="erase glyphicon glyphicon-ok form-control-feedback hidden"></span>
										</div>
										<div id = "row_<?php echo $i ?>_role_error" class="erase alert alert-danger hidden">
												
												<strong>Error:</strong> Please fill this box.
										</div>
									</td>

							 	</tr>

							 <?php	}	 ?>	


							 
						
						  </div>
							  </tbody>
							</table> 
							
						<form id = "bottom">							
							<button type="button" onclick = "addnewrows()"class="btn btn-success">Add New Rows</button>
						<!--	<p class = "erase hidden">Add <input type = "text" > </input> rows <button type="button" class="btn btn-default">Go</button> </p> -->
							
						</form>
				
						

						
					</div>
					
				
					
					
					<div class="modal-footer">
						
					
						<button type="button" class="btn btn-success" data-dismiss = "" onclick = "checkempty('all')">Save</button>
					 
					</div>
					
					</div>
						
				</div>
				
				
			
			
		</div>
	
		
		

<div class="modal fade" id="edit_learner_modal" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 id="edit_learner_modal_title" class="modal-title">Edit</h4>
      </div>
      <div class="modal-body">
	      	<iframe id="edit_learner_frame" width="100%" height="450px" src="" frameborder="0"></iframe>
      </div>
      <div class="modal-footer">	        
        <!-- <button id="forgot_submit_btn" type="button" class="btn btn-enrollment" onclick="fnForgotPassword()">Submit</button> -->
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<div class="modal fade" id="csv_upload_modal" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 id="" class="modal-title">Import Learners - CSV</h4>
      </div>
      <div class="modal-body">
	      	<iframe id="csv_upload_frame" width="100%" height="300px" src="<?php echo (base_url('index.php/learners/open_csv_import_window')) ?>" frameborder="0"></iframe>
      </div>
      <div class="modal-footer">	        
        <!-- <button id="forgot_submit_btn" type="button" class="btn btn-enrollment" onclick="fnForgotPassword()">Submit</button> <?php echo json_encode(base_url('index.php/learners/open_csv_import_window')) ?> -->
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script src="<?php echo base_url("assets/js/jquery-ui.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/paging.js"); ?>"></script>


<script type="text/javascript">
	var baseURL = <?php echo json_encode($baseURL) ?>;	
	var clientId = <?php echo json_encode($clientId) ?>;	
	var csv_successfully_uploaded = false;

	$(document).ready(function() {
		//$('input, textarea').placeholder();
        // Check whether it's a browser which supports HTML5
		// If yes, enable paging plugin
		if(document.addEventListener){
			$('#users_table').paging({limit:12});
		}
        $("#users_table").removeClass("hidden");  
        $("#loader_div").hide();
    });


	$(function () {
	    $('[data-toggle="tooltip"]').tooltip();
	})

	function open_edit_learner_window(learnerId){
	   
	    var learner_name = $("#edit_learner_btn_"+learnerId).attr('data-learner_name');
	    $("#edit_learner_modal_title").html("<b>Edit | "+learner_name + "</b>");
	    
	    var url = <?php echo json_encode(base_url("index.php/learners/edit_learner_window")) ?> +"/" + learnerId ;
	    $("#edit_learner_frame").attr('src', url);
	   
	}

	  function update_learner_row(learner_changes){
	  	
	  	$("#first_name_" + learner_changes.learnerId).html(learner_changes.first_name);
	  	$("#last_name_" + learner_changes.learnerId).html(learner_changes.last_name);
	  	$("#email_" + learner_changes.learnerId).html(learner_changes.email);
	  	$("#phone_" + learner_changes.learnerId).html(learner_changes.phone);
	  	$("#department_" + learner_changes.learnerId).html(learner_changes.department);
	  	$("#role_" + learner_changes.learnerId).html(learner_changes.role);
	  }

	  function export_learners_list(){		
		window.open(baseURL + "/export_module/excel_learner_list/"+clientId);
	  }	



	  function download_sample_csv(){
	  	var sample_csv_path = <?php echo json_encode(base_url("assets/docs/allscripts_enrollment_import_users.csv") ) ?>;	  	
	  	window.open(sample_csv_path);
	  }


	  $('#csv_upload_modal').on('hidden.bs.modal', function () {
	    // # CODE TO EXECUTE UPON MODAL CLOSE
	    $("#csv_upload_modal").attr('src', ""); 
	    if(csv_successfully_uploaded){	    	
	    	location.href = baseURL + "/learners/";
	    }
	     
	  })

</script>

<script src="<?php echo base_url("assets/js/learners.js"); ?>"> </script>

</body>