<?php

/** Error reporting */

error_reporting(E_ALL);

/** Include path **/
ini_set('include_path', ini_get('include_path').';assets/plugins/PHPExcel_1.8.0_doc/Classes');

/** PHPExcel */
include 'PHPExcel.php';

/** PHPExcel_Writer_Excel2007 */
include 'PHPExcel/Writer/Excel2007.php';


//Styles

$green_bg_center = array( 
				'font' => array( 'bold' => true, 'size' => 18,), 
				'alignment' => array( 'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, ), 				
				'borders' => array( 
						'outline' => array( 'style' => PHPExcel_Style_Border::BORDER_THICK, 'color' => array('argb' => '00000000'), ), 
						), 
				'fill' => array( 
					'type' => PHPExcel_Style_Fill::FILL_GRADIENT_LINEAR, 
					'rotation' => 90, 
					'startcolor' => array( 'argb' => '92D050', ), 
					'endcolor' => array( 'argb' => '92D050', ), 
				),
			);

$row_header_style = array( 
				'font' => array( 'bold' => true, ), 
				'alignment' => array( 'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, ), 				
				'borders' => array( 
						'allborders' => array( 'style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '00000000'), ), 
						), 
				'fill' => array( 
					'type' => PHPExcel_Style_Fill::FILL_GRADIENT_LINEAR, 
					'rotation' => 90, 
					'startcolor' => array( 'argb' => '92D050', ), 
					'endcolor' => array( 'argb' => '92D050', ), 
				),
			);


// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

// Set properties
$objPHPExcel->getProperties()->setCreator("Allscripts Education Services");
$objPHPExcel->getProperties()->setLastModifiedBy("Allscripts Education Services");
$objPHPExcel->getProperties()->setTitle("Office 2007 XLSX Test Document");
$objPHPExcel->getProperties()->setSubject("Office 2007 XLSX Test Document");
$objPHPExcel->getProperties()->setDescription("An Assignment Request document from the Education Services Enrollment Portal.");
$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri'); 
$objPHPExcel->getDefaultStyle()->getFont()->setSize(12);
$objPHPExcel->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getDefaultStyle()->getAlignment()->setWrapText(true);



//*******************************************************************************************************************************
// SHEET 1 CLIENT DETAILS
//*******************************************************************************************************************************
$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->mergeCells('A1:H1');
$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray($green_bg_center);
$objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Allscripts Education Services: Program Request Summary');

$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(30);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(30);

$objPHPExcel->getActiveSheet()->mergeCells('A4:B4');
$objPHPExcel->getActiveSheet()->getStyle('A4:B4')->applyFromArray($row_header_style);
$objPHPExcel->getActiveSheet()->getStyle('A4:B4')->getFont()->setSize(16);
$objPHPExcel->getActiveSheet()->SetCellValue('A4', 'Client Details');


$objPHPExcel->getActiveSheet()->SetCellValue('A5', 'Client Organization Name');
$objPHPExcel->getActiveSheet()->SetCellValue('B5', $client_details["orgName"]);
$objPHPExcel->getActiveSheet()->SetCellValue('A6', 'Client Organization Number');
$objPHPExcel->getActiveSheet()->SetCellValue('B6', $client_details["accountNumber"]);


if($contact_details != "Not Submitted"){
	$objPHPExcel->getActiveSheet()->SetCellValue('A7', 'Submitter Name');
	$objPHPExcel->getActiveSheet()->SetCellValue('B7', $contact_details["first_name"]." ".$contact_details["last_name"]);
	$objPHPExcel->getActiveSheet()->SetCellValue('A8', 'Submitter Phone');
	$objPHPExcel->getActiveSheet()->SetCellValue('B8', $contact_details["phone"]);
	$objPHPExcel->getActiveSheet()->SetCellValue('A9', 'Submitter Email');
	$objPHPExcel->getActiveSheet()->SetCellValue('B9', $contact_details["email"]);
}



$objPHPExcel->getActiveSheet()->mergeCells('A12:B12');
$objPHPExcel->getActiveSheet()->getStyle('A12:B12')->applyFromArray($row_header_style);
$objPHPExcel->getActiveSheet()->getStyle('A12:B12')->getFont()->setSize(16);
$objPHPExcel->getActiveSheet()->SetCellValue('A12', 'Request Details');

$objPHPExcel->getActiveSheet()->SetCellValue('A13', 'Request Type');
$objPHPExcel->getActiveSheet()->SetCellValue('B13', 'Assign Programs');
$objPHPExcel->getActiveSheet()->SetCellValue('A14', 'Request Number');
$objPHPExcel->getActiveSheet()->SetCellValue('B14', 'E0'.$request_details["requestId"]);
$objPHPExcel->getActiveSheet()->SetCellValue('A15', 'Submitted On');
if($contact_details != "Not Submitted"){
	$objPHPExcel->getActiveSheet()->SetCellValue('B15', $request_details["submitted_date"]);
}else{
	$objPHPExcel->getActiveSheet()->SetCellValue('B15', "Not Submitted");
}


// Rename sheet
$objPHPExcel->getActiveSheet()->setTitle('Client Details');




//*******************************************************************************************************************************
// SHEET 3 Enrollment Records
//*******************************************************************************************************************************
$objPHPExcel->createSheet(1);
$objPHPExcel->setActiveSheetIndex(1);
$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(25);
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(45);



$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray($row_header_style);
$objPHPExcel->getActiveSheet()->SetCellValue('A1', 'First Name');
$objPHPExcel->getActiveSheet()->SetCellValue('B1', 'Last Name');
$objPHPExcel->getActiveSheet()->SetCellValue('C1', 'User Name');
$objPHPExcel->getActiveSheet()->SetCellValue('D1', 'Email');
$objPHPExcel->getActiveSheet()->SetCellValue('E1', 'Phone');
$objPHPExcel->getActiveSheet()->SetCellValue('F1', 'Role');
$objPHPExcel->getActiveSheet()->SetCellValue('G1', 'Department');
$objPHPExcel->getActiveSheet()->SetCellValue('H1', 'Program Name');

$Line = 2;
foreach($all_enrollments as $enrollment){
	$objPHPExcel->getActiveSheet()->SetCellValue('A'.$Line, $enrollment["learner_details"]["first_name"]);
	$objPHPExcel->getActiveSheet()->SetCellValue('B'.$Line, $enrollment["learner_details"]["last_name"]);
	$objPHPExcel->getActiveSheet()->SetCellValue('C'.$Line, $enrollment["learner_details"]["user_name"]);
	$objPHPExcel->getActiveSheet()->SetCellValue('D'.$Line, $enrollment["learner_details"]["email"]);
	$objPHPExcel->getActiveSheet()->SetCellValue('E'.$Line, $enrollment["learner_details"]["phone"]);
	$objPHPExcel->getActiveSheet()->SetCellValue('F'.$Line, $enrollment["learner_details"]["role"]);
	$objPHPExcel->getActiveSheet()->SetCellValue('G'.$Line, $enrollment["learner_details"]["department"]);
	$objPHPExcel->getActiveSheet()->SetCellValue('H'.$Line, $enrollment["program_details"]);

	$Line++;

}

$objPHPExcel->getActiveSheet()->setTitle('Assign Programs');


//Set The Active Sheet to 0 - The Client Details Page
$objPHPExcel->setActiveSheetIndex(0);



$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
//$objWriter->save(str_replace('.php', '.xlsx', "My_Excel"));
// We'll be outputting an excel file
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
// Provide the filename
$file_name = "Allscripts_Program_Enrollment_E0".$request_details["requestId"]."_Client-".$client_details["accountNumber"];
header('Content-Disposition: attachment; filename="'.$file_name.'.xlsx"');

$objWriter->save('php://output');

exit();