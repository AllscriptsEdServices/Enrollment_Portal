<style type="text/css">

.panel-body{	

	padding: 0px 0px 0px 0px;
	
}

.panel{
	padding-bottom:0px!important;
	margin-top:0px!important;
}
.accordion_panel-heading {
	padding: 10px 10px;
	border-bottom: 1px solid transparent;
	background-color:#E5F1D9!important;
	border-bottom:3px solid #89af41;
	/*border-top:1px solid #89af41;*/
}
.panel-title_design {
	color: #3f4450!important;
    font-size: 20px;
    font-weight: 600;
    margin-top:0px!important;
    margin-bottom: 0;
    padding-bottom: 0px;
    text-align: left;
    text-decoration: none;

}	
.program_title {
	color: #3f4450;
	text-decoration: none!important;
	outline: none!important;
}
.program_title:hover {
	color: #4f4f4f;	
}
.program_title:focus {
	color: #4f4f4f;
	
}


.learner_swatch {
  cursor: pointer;
  display: inline-block;
  margin-bottom: 0;
  font-weight: normal;
  text-align: center;
  vertical-align: middle;
  -ms-touch-action: manipulation;
    touch-action: manipulation;

  background-image: none;
  border: 1px solid transparent;
  white-space: nowrap;
  font-size: 14px;
  line-height: 1.42857143;
  border-radius: 4px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;

 	color: #fff;
	background-color: #7ab800;
	margin-top: -5px;
    padding: 5px 30px;
   /* margin-left:20px;*/
}



.glyphicon-plus{	
	cursor: pointer;
    background-color:#FFFFFF;
    color:#5b8f22;
    padding:6px;
    border-radius: 5px;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    margin-left:10px;
    margin-top:-6px;
	
}

.glyphicon-minus{	
	cursor: pointer;
    background-color:#FFFFFF;
    color:#5b8f22;
    padding:6px;
    border-radius: 5px;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    margin-left:10px;
    margin-top:-6px;
	
}

.text-lead{
	font-size:18px;
}

</style>

<div class="container">

	<!-- <div class="row">
		<div class="column col-sm-6 col-md-4 header_bg" >
			<h3>Assign Programs Summary </h3>						
		</div>
		<div class="column col-sm-6 col-md-8 text-right" >
			<button id="re_edit_btn" class="btn btn-enrollment" onclick="export_request_summary()">Export Summary</button>
			<button id="re_edit_btn" class="btn btn-enrollment" onclick="view_request()">Re-edit Request</button>
			<button id="submit_btn" class="btn btn-enrollment" onclick="submit_request()">Submit Request</button>
		</div>
	</div> -->

	<div id="summary_div" class="row top-buffer">
		<div class="column col-sm-12">	
			<!-- <div class="row" style="padding-bottom:10px">
				<p class="text-lead">These are the programs you have assigned to various learners in this request. You can review and submit the request.	</p>
			</div> -->
			<div class="row bg-header-green" style="padding-bottom:10px">
				<div class="col-xs-5" >	
					<h3>Assign Programs Summary</h3>
				</div>
				<div class="col-xs-7 text-right" style="padding-top:8px">
					<button id="re_edit_btn" class="btn btn-enrollment" onclick="export_request_summary()" data-toggle="tooltip" data-placement="bottom" title="Download a copy of the summary">Export Summary</button>
					<button id="re_edit_btn" class="btn btn-enrollment" onclick="view_request()" data-toggle="tooltip" data-placement="bottom" title="Make changes to learners or programs">Re-edit Request</button>
					<button id="submit_btn" class="btn btn-enrollment" onclick="submit_request()" data-toggle="tooltip" data-placement="bottom" title="Send request to Education Services">Submit Request</button>
				</div>
			</div>

			<div class="row">
					<div class="panel-group" id="accordion"  role="tablist" aria-multiselectable="true">
						<?php		

							foreach ($summary_details as $program) {

								echo '<div class="panel  custom-panel" >';

								echo '<div class="accordion_panel-heading " role="tab" id="heading_'.$program["programId"].'">';
								echo '<h4 class="panel-title panel-title_design">';

								echo '<table style="width:100%"><tr>';

								echo '<td >';
								echo '<a role="button" class="program_title" onclick="fnChangeSpanBtn('.$program["programId"].')" data-toggle="collapse"  href="#collapse_'.$program["programId"].'" aria-expanded="true" aria-controls="collapse_'.$program["programId"].'"> '.$program["programName"].'    </a> ';
								echo '</td>';
									
								echo '<td align="right" style="width:150px" class="hidden-sm hidden-xs">';							
								echo '<span onclick="fnChangeSpanBtn('.$program["programId"].')" id="learner_swatch_'.$program["programId"].'" class=" learner_swatch" aria-hidden="true" data-toggle="collapse" data-parent="#collapse_" href="#collapse_'.$program["programId"].'" aria-expanded="true" aria-controls="collapse_'.$program["programId"].'">'.count($program["learner_list"]).' Learners</span>';
								echo '</td>';

								echo '<td align="right" style="width:40px" class="hidden-xs">';
									echo '<span onclick="fnChangeSpanBtn('.$program["programId"].')" id="span_btn_'.$program["programId"].'" class="plusminus_btn glyphicon glyphicon-plus" aria-hidden="true" data-toggle="collapse" data-parent="#collapse_" href="#collapse_'.$program["programId"].'" aria-expanded="true" aria-controls="collapse_'.$program["programId"].'"></span> ';
								echo '</td>';

								echo '</table></tr>';

								
								echo '</h4>';
								echo '</div>'; // End of panel-heading

								echo '<div id="collapse_'.$program["programId"].'" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_'.$program["programId"].'">';
								echo '<div class="panel-body">';
							
								
								echo '<table class="table table-bordered summary-table">';
								foreach ($program["learner_list"] as $learner) {
									
									echo '<tr>';
									echo '<td>'.$learner["first_name"]." ".$learner["last_name"].'</td>';
									echo '<td>'.$learner["department"].'</td>';
									echo '<td>'.$learner["role"].'</td>';
									echo '</tr>';							
														
								}
								echo '</table>';

								echo '</div>'; // End of panel-body

								echo '</div>'; //End of collapse

								echo '</div>'; //End of panel-default						
							}
						?>

					</div> <!-- End of accordion panel-group -->

			</div> <!-- New -->


		</div> <!-- End of Accordion holding column -->

	</div> <!-- End of ROW -->


	<div id="submission_msg_div" class="row  top-buffer hidden">
		<div class="column col-sm-8 col-sm-offset-2 well text-center">
			<p>Your request has been successfully submitted. You will be receiving further communication from the Allscripts Team within 48 hours.</p>
			<button class="btn btn-enrollment center-block top-buffer" onclick="go_to_requests_home()">Back to Requests</button>

		</div>
	</div>


</div> <!-- End of Container  -->


<!-- <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingOne">
      <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Collapsible Group Item #1
        </a>
      </h4>
    </div>

    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
      <div class="panel-body">
        Content
      </div>
    </div>

  </div>
  

</div> --> <!-- End of Main group -->


<script type="text/javascript">

	var baseURL = <?php echo json_encode($baseURL) ?>;
	var requestId = <?php echo ($requestId) ?>;

	$(function () {
	    $('[data-toggle="tooltip"]').tooltip();
	})

	function view_request(){
		window.location.href = baseURL + "/assign_program/display_assign_request";
	}
	
	function fnChangeSpanBtn(id){
	    $("#span_btn_"+id).toggleClass("glyphicon-plus");
	    $("#span_btn_"+id).toggleClass("glyphicon-minus");
	}

	function go_to_requests_home(){
		window.location.href = baseURL + "/requests";		
	}


	function export_request_summary(){				
		//window.location.href = baseURL + "/request_export/excel/excel_client_summary/"+requestId;
		window.open(baseURL + "/export_module/excel_client_summary/"+requestId);
	}



	function submit_request(){
		var confirm_delete = confirm("Upon submission, your request will be sent to the Allscripts Education team for processing. Continue?");

		if(confirm_delete){

			var form_data = {
				'requestId': requestId
		    };

		    $.ajax({
		      	type: "POST",
		      	url: baseURL + "/assign_program/submit_request",
		      	data: form_data,
		      	success: function(response)
		      	{		      			      		
		      		if(response){
		      			$("#summary_div" ).addClass("hidden");
		      			$("#re_edit_btn" ).hide();
		      			$("#submit_btn" ).hide();
		      			$("#submission_msg_div").removeClass("hidden");
		      			
		      		}		      		
		      	}
		    });

		}
	}


</script>