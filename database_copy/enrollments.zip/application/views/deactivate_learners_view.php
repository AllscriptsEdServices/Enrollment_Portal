<div class="container-fluid">

	<div class="row">
		<div class="column col-sm-8 "  >
			<h2 style="color:#3f4450; margin-top:0px; font-weight:bold">Deactivate Learners - E0<?php echo $requestId?></h2>	
			<ol>			
				<li>In the <strong>Learners</strong> table, select all learners whose accounts should be deactivated.</li>
				<li>When you are done selecting the required learners, click <strong>Submit Request</strong>.</li>
			</ol>
		</div>
	</div>


	<div class="row">
		
		<div class="column col-sm-8 " >	

			<div class="margin-holder" style="margin:15px">	 
				<div class="row bg-header-green">
					<h3 style="margin-top:10px" class="text-center ">Learners</h3>
				</div>

				<div class="row bg-light-green" style="padding:5px">				
					<div class="col-xs-6">	
						<label>Search By Column</label>
						<select class="form-control" id="search_by_drop" name="search_by_drop">
							<option value="2">First Name</option>
							<option value="3">Last Name</option>
							<option value="4">Department</option>
							<option value="5">Role</option>				
						</select>				
					</div>

					<div class="col-xs-6">	
						<label>Search Text</label>	
				        <input type="text" class="form-control" id="search_org_all" placeholder="Your search term"></input>		     
			        </div>
		        </div>

		        <div class="row" style="">
					<table id="users_table" class="table table-bordered green-table">
						<thead>
							<tr>
								<th><input type="checkbox" id="select_all_users_checkbox" name="users" value="all"></input></th>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Email</th>
								<th>Department</th>
								<th>Role</th>
								<!-- <th>Programs Requested</th> -->
							</tr>
						</thead>

						<tbody>					
							<?php $counter=0; foreach($learners_list as $learner): ?>
								<tr>
									<td><input type="checkbox" class="users_checkbox" name="users_checkbox" value="<?php echo $learner['learnerId'] ?>"></input></td>
									<td><?php echo $learner['first_name'] ?></td>
									<td><?php echo $learner['last_name'] ?></td>
									<td><?php echo $learner['email'] ?></td>
									<td><?php echo $learner['department'] ?></td>
									<td ><?php echo $learner['role'] ?></td>
									<!--<?php
										echo '<td id="programs_requested_div_'.$learner['learnerId'].'">';

										if(count($learner['current_assignments'])>0){
											foreach($learner['current_assignments'] as $single_assignment){
												echo '<table id="temp_assign_table_'.$single_assignment["enrollmentId"].'"class="learner_assigned_table"><tr><td class="assigned_program_name">'.$single_assignment["programName"].'</td> <td class="text-right"> <a href="javascript:delete_assignment('.$single_assignment["enrollmentId"].')"> <span class="glyphicon glyphicon-remove-circle" style="font-weight:bold" aria-hidden="true" data-toggle="tooltip" data-placement="bottom" title="Delete this assignment" ></span> </a>  </td> </tr> </table>';
											}
										}
											

										echo '</td>';
									?>		-->					

									<!-- <td id="programs_requested_div_<?php echo $learner['learnerId'] ?>"></td> -->
								</tr>

							<?php endforeach; ?>


							
						</tbody>

					</table>

				</div>

			</div>

		</div>

		<div class="column col-sm-4" >	
			<div class="margin-holder text-right" style="margin:5px 15px">		
				<button class="btn btn-enrollment btn-lg " onclick="chek_show_confirm_modal()" >Submit Request</button>

			</div>

			<div id="selection_warning_div" class="margin-holder" style="margin:15px; display:none">
				<div class="alert alert-danger text-right" role="alert">Select at least one learner before proceeding.</div>
			</div>
		</div>


		<!-- <div class="column col-sm-4" >		
			<div class="margin-holder" style="margin:15px">
				<div class="row bg-header-green"	>
					<h3 style="margin-top:10px" class="text-center ">Learners to Deactivate</h3>
				</div>
			</div>
		</div>
 -->

	</div>  <!-- End of Left learner row -->



<div class="modal fade" id="confirm_request_modal" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title">Confirm Deactivation Request</h4>
      </div>
      <div class="modal-body">
      		<div id="initial_confirm_content">
		      	<p>The selected learners will be deactivated.<p>
		      	<p>This step cannot be undone.</p>
		      	<br>
		      	<p>Click <strong>Confirm</strong> to submit the request to Education Services.</p>
		      	<div id="warning_content_div" class="text-center top-buffer">
		      		<button id="confirm_request" type="button" class="btn btn-enrollment btn-lg " onclick="submit_deactivate_request()">CONFIRM</button>
		      	</div>
		    </div>

		    <div id="successful_request_content" class="text-center" style="display:none">
		    	<p>Your request has been successfully submitted.</p>
		    	<button class="btn btn-enrollment center-block top-buffer" onclick="go_to_requests_home()">Back to Requests</button>
		    </div>

      </div>
      <!-- <div class="modal-footer text-center">       
        <button id="confirm_request" type="button" class="btn btn-enrollment" onclick="">Cancel</button>
      </div> -->
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script type="text/javascript">
	var baseURL = <?php echo json_encode($baseURL) ?>;
	var selected_learners = "";
	var selected_learners_array = [];
	var request_submitted = false;


	$(document).ready(function() {
		//Live search function for the All Users List
		$("#search_org_all").on("keyup", function() {
			//alert($("#search_by_drop").val())
		    var value = $(this).val().toLowerCase();
		    $("#users_table tr").each(function(index) {
		        if (index !== 0) {
		            $row = $(this);	
		            //Checks the value of the field drop down. Values are actually column number
		            var filter_row = $("#search_by_drop").val();
		            var id = $row.find("td:nth-child(" + filter_row + ")").text().toLowerCase();
		            if (id.indexOf(value) < 0) {
		                $row.hide();
		            }
		            else {
		                $row.show();
		            }
		        }
		    });
		});

		$(document).on('click','#select_all_users_checkbox',function() {
	        if(this.checked) { // check select status
	            $('.users_checkbox').each(function() { //loop through each checkbox	
	            	if($(this).parent().parent().css('display') !="none"){
	            		this.checked = true;  //select all checkboxes with class "users_checkbox"   	
	            	}	                           
	            });
	        }else{
	            $('.users_checkbox').each(function() { //loop through each checkbox
	                this.checked = false; //deselect all checkboxes with class "users_checkbox"                      
	            });        
	        }
	    });


	    $(document).on('click','.users_checkbox',function() {	
	    	$('#selection_warning_div').fadeOut();    	
	    	if(!this.checked && document.getElementById('select_all_users_checkbox').checked ){	    		
	    		document.getElementById('select_all_users_checkbox').checked = false;
	    	}
	    });

	    $('#confirm_request_modal').on('hidden.bs.modal', function () {
		    // # CODE TO EXECUTE UPON MODAL CLOSE
		  	if(request_submitted)     {
		  		go_to_requests_home();
		  	}
		})

	}); // End of document ready

	function chek_show_confirm_modal(){
		selected_learners_array = [];
		
		$.each($("input[name='users_checkbox']:checked"), function(){
		    selected_learners_array.push($(this).val());
		});
		
		if(selected_learners_array.length>0){
			selected_learners = selected_learners_array.join("$");
		}else{			
			$('#selection_warning_div').fadeIn();
			return;
		}

		$('#confirm_request_modal').modal('show');
		
	}


	function submit_deactivate_request(){
		var form_data = {
			'selected_learners': selected_learners	      	      	
	    };

	    $.ajax({
	      	type: "POST",
	      	url: baseURL + "/deactivate_learners/submit_request",
	      	data: form_data,
	      	success: function(response)
	      	{		      		
	      		if(response){
	      			request_submitted = true;
	      			$('#initial_confirm_content').hide();
	      			$('#successful_request_content').fadeIn();
	      		}
	      	}
	    });
	}

	function go_to_requests_home(){
		window.location.href = baseURL + "/requests";
	}


</script>