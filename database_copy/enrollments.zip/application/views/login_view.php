<style type="text/css">
	.form-control{
		height: 50px;
	}
</style>
	

<div class="container">
    <div class="row vertical-offset-100">
    	<div class="col-md-6 col-md-offset-3">
    		<div class="panel panel-default">
			  	<div class="panel-heading">
			    	<h2 class="panel-title">Program Enrollment Portal</h2>
			 	</div>
			  	<div class="panel-body">
			    	<form accept-charset="UTF-8" role="form" action="javascript:fnLogin()">
	                    <fieldset>
					    	  	<div style="margin-bottom: 25px" class="input-group">
				                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
				                    <input id="email" type="text" class="form-control" name="email" value="" placeholder="john.doe@example.com">                                        
				                </div>
					    		<div style="margin-bottom: 25px" class="input-group">
		                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
		                            <input id="password" type="password" class="form-control" name="password" value="" placeholder="enter password">                                        
		                        </div>
					    		<div>
					    	    	<label>
					    	    		 <a href="" data-toggle="modal" data-target="#myModal">Forgot Password?</a>
					    	    	</label>
		                            
		                            <!-- <label class="pull-right">
					    	    		<a href=""> Create your account</a>
					    	    	</label> -->
					    	    </div>
					    		<input class="btn btn-lg btn-success center-block"  type="submit" value="Login">
				    	</fieldset>
			      	</form>
			    </div>
			</div>
		</div>	

	</div>

	<div class="row text-center">
			<div id="loadingDiv" class="loadingDiv col-xs-6 col-xs-offset-3" style="display:none; padding:5px;">
			    <img src="<?php echo base_url("assets/img/loader.gif"); ?>" /> Processing..
			</div>  

			<div id="msgBox" class="messageBox bg-success col-xs-6 col-xs-offset-3" style="display:none; padding:5px;">
			    Your changes have been saved. You may close this dialog now.		      
			</div>

			<div id="errorBox" class="messageBox bg-danger col-xs-6 col-xs-offset-3" style="display:none; padding:5px;">
			    Enter a valid email address.
			</div>
		</div>



</div>




<!-- Preload the hover images -->
<div class="hidden">
  <img src="<?php echo base_url("assets/img/Login Button_Over.png"); ?>" />
</div>


<div class="modal fade" id="myModal" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title">Password Recovery</h4>
      </div>
      <div class="modal-body">
	      	<p>Enter your registered email address and we'll mail you a temporary password.</p>
	      	<label class="control-label" for="forgotMail">Email Address</label>
	        <input type="email" class="form-control" id="forgotMail" name="forgotMail" placeholder="Enter email">

	        <div id="msg-error" class="bg-danger hidden" style="margin-top:20px; padding:5px;">
	        	<p>This email is not registered in the system. Please check the email address and retry.</p> 
	        	<p>For further assisstance/queries you can reach out to <a href="mailTo:education@allscripts.com">education@allscripts.com</a>.</p>
	    	</div>

	    	<div id="msg-success" class="bg-success hidden" style="margin-top:20px; padding:5px;">
	        	<p>Your password has been reset! You will be receiving an mail with the temporary password shortly to the above mail address. If you cannot find it in your Inbox, please check the Junk/Spam folders as well.</p> 
	        	<p>If you are still facing problems logging in, you can write to <a href="mailTo:education@allscripts.com">education@allscripts.com</a>.</p>
	        </div>

      </div>
      <div class="modal-footer">	        
        <button id="forgot_submit_btn" type="button" class="btn btn-primary" onclick="fnForgotPassword()">Submit</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



<script type="text/javascript">
	window.history.forward();
	function noBack() { window.history.forward();}
	
	var baseURL = <?php echo json_encode($baseURL) ?>;

	function fnForgotPassword(){		
		if(validateEmail($("#forgotMail").val()))
		{
			var action = baseURL + "/login/forgotPassword";
		    var form_data = {
		      'forgotMail': $("#forgotMail").val()
		    };

		    $.ajax({
		      	type: "POST",
		      	url: action,
		      	data: form_data,
		      	success: function(response)
		      	{		      	

		      		if(response == "Success"){
		      			$("#msg-success").removeClass("hidden");
		      			$("#msg-error").addClass("hidden");
		      			$("#forgot_submit_btn").hide();
		      			//$('#defaultForm').get(0).reset()	
		      		}else{
		      			$("#msg-success").addClass("hidden");
		      			$("#msg-error").removeClass("hidden");
		      		}		      		
		      	}
		    });
		}
		else
		{
			alert("Enter a valid email address.");
		}
		
	}

	function fnLogin(){
		if(validateEmail($("#email").val()))
		{			
			$('#errorBox').hide();
			$('#loadingDiv').show();
			var action = baseURL + "/login/doLogin";
		    var form_data = {
		      'email': $("#email").val(),
		      'password': $("#password").val()
		    };

		    $.ajax({
		      	type: "POST",
		      	url: action,
		      	data: form_data,
		      	success: function(response)
		      	{		
		      		$('#loadingDiv').hide();

		      		var responseObj = $.parseJSON(response);	     		      		
		      		 
		      		if(responseObj.status=="Fail"){
		      			$('#errorBox').html("Either the email or password is incorrect. Please verify and try again.");
		      			$('#errorBox').fadeIn();
		      		}else if(responseObj.status=="Success"){
		      			$('#errorBox').hide();
		      			//if(responseObj.formFilled){
		      				window.location.href = <?php echo json_encode(base_url("index.php/introduction/")) ?>;
		      			/*}else{
		      				window.location.href = <?php echo json_encode(base_url("index.php/createnew/")) ?>;
		      			}*/
		      			
		      		}
		      		/*if(response=="Fail"){
		      			$('#errorBox').html("Either the email or password is incorrect. Please verify and try again.");
		      			$('#errorBox').fadeIn();
		      		}else{
		      			//var url = <?php echo json_encode(base_url("index.php/entry/client")) ?> + "/" + response;
		      			var url = <?php echo json_encode(base_url("index.php/clientlist/getClients")) ?>;
		      			window.location.href = url;
		      		}*/  		
		      		    		
		      	}
		    });
		}
		else
		{
			$('#errorBox').html("Enter a valid email address.");
			$('#errorBox').fadeIn();
		}
		
	}

	$('#myModal').on('hidden.bs.modal', function () {
	    // # CODE TO EXECUTE UPON MODAL CLOSE
	    $("#msg-success").hide();
	    $("#msg-error").hide();	    
	    $("#forgot_submit_btn").show();

	     
	  })


	function validateEmail(email) { 
	    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    return re.test(email);
	} 

</script>
