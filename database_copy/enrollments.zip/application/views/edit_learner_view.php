<!-- <!DOCTYPE HTML >

<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/css/stylesheet.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/css/style.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/plugins/formvalidation-master/dist/css/formValidation.css"); ?>" rel="stylesheet">

<style type="text/css">
  body{
    background: #fff;
  }
</style>
<!-- </head> -->

<body> 
	<div class="container-fluid">

		<div class="row">		
				<!-- <form id="edit_learner_form" > -->

		          <input type="hidden" class="form-control" id="learnerId" name="learnerId" value="<?php echo  $learnerId ?>">
		          	<div class="column col-xs-6 form-group">
			          <label class="control-label" for="first_name">First Name</label>
			          <input type="text" class="form-control" id="first_name" name="first_name" placeholder="First Name" value="<?php echo $learner_data["first_name"]; ?>">
			        </div>

		          	<div class="column col-xs-6 form-group">
			          <label class="control-label" for="last_name">Last Name</label>
			          <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Last Name" value="<?php echo $learner_data["last_name"]; ?>">
			        </div>

			        <div class="column col-xs-6 form-group">
			          <label class="control-label" for="email">Email</label>
			          <input type="text" class="form-control" id="email" name="email" placeholder="Email" value="<?php echo $learner_data["email"]; ?>">
			        </div>

			        <?php if($learner_data["email"] != $learner_data["user_name"]){  $force_update_username = false; ?>
				        <div class="column col-xs-6 form-group">
				          <label class="control-label" for="user_name">User Name</label>
				          <input type="text" class="form-control" id="user_name" name="user_name" placeholder="User Name" value="<?php echo $learner_data["user_name"]; ?>">
				        </div>			        

			        <?php }else{ $force_update_username = true; ?>
			        	<input type="hidden" class="form-control" id="user_name" name="user_name" placeholder="User Name" value="<?php echo $learner_data["user_name"]; ?>">

			        <?php } ?>


			        <div class="column col-xs-6 form-group">
			          <label class="control-label" for="phone">Phone</label>
			          <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone" value="<?php echo $learner_data["phone"]; ?>">
			        </div>

			        <div class="column col-xs-6 form-group">
			          <label class="control-label" for="department">Department</label>
			          <input type="text" class="form-control" id="department" name="department" placeholder="Department" value="<?php echo $learner_data["department"]; ?>">
			        </div>

			        <div class="column col-xs-6 form-group">
			          <label class="control-label" for="role">Role</label>
			          <input type="text" class="form-control" id="role" name="role" placeholder="Role" value="<?php echo $learner_data["role"]; ?>">
			        </div>


			        <div class="col-xs-12 text-center">
			        	<button id="save_btn" type="submit" class="btn btn-enrollment" onclick="save_learner_details()" >Save Changes</button>  
			        </div>
		       <!--  </form> -->
	

		        <div class="column col-xs-12 top-buffer" >

			        <div id="processingDiv" class="processingDiv bg-info">
			          <img src="<?php echo base_url("assets/img/loader.gif"); ?>" /> Processing..
			        </div> 

			        <div id="msgBox" class="msgBox bg-success">
			          You have successfully updated the learner details. You may close this dialog now.        
			        </div>

			        <div id="errorBox" class="msgBox bg-danger">
			         	Enter all the information before updating the learner details.
			        </div>

		      </div> <!-- /End of Column -->

		</div>

	</div>



	<script src="<?php echo base_url("assets/js/jquery-1.11.0.js"); ?>"></script>
	<script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>"></script>
	<script src="<?php echo base_url("assets/plugins/formvalidation-master/dist/js/formValidation.js"); ?>"></script> 
	<script src="<?php echo base_url("assets/plugins/formvalidation-master/dist/js/framework/bootstrap.js"); ?>"></script> 

	<script type="text/javascript">
		var baseURL = <?php echo json_encode($baseURL) ?>;
		var learnerId = <?php echo ($learnerId) ?>;
		var force_update_username = <?php echo json_encode($force_update_username) ?>;
		

		/*$(document).ready(function() {
	   
	    $('#edit_learner_form')
		    .formValidation({

			        message: 'This value is not valid',
			        icon: {
			            valid: 'glyphicon glyphicon-ok',
			            invalid: 'glyphicon glyphicon-remove',
			            validating: 'glyphicon glyphicon-refresh'
			        },

			        fields: {
			            first_name: {
			                validators: {
			                    notEmpty: {
			                        message: 'The first name is required'
			                    }
			                }
			            },
			            last_name: {	                
			                validators: {
			                    notEmpty: {
			                        message: 'The last number is required'
			                    }
			                }
			            },
			            
			            role: {	                
			                validators: {
			                    notEmpty: {
			                        message: 'The role name is required'
			                    }
			                }
			            },
			            department: {	                
			                validators: {
			                    notEmpty: {
			                        message: 'The department is required'
			                    }
			                }
			            },
			           
			            email: {
			                validators: {
			                    notEmpty: {
			                        message: 'The email address is required'
			                    },
			                    emailAddress: {
			                        message: 'The input is not a valid email address'
			                    }
			                }
			            }
			        }
			    })	
				.on('success.form.fv', function(e) {
		            //console.log('success.form.fv');
		            e.preventDefault();
		            save_learner_details();

		            // If you want to prevent the default handler (formValidation._onSuccess(e))
		            // 
		        });
		});
*/

		function save_learner_details(){
			//alert(Error_Check());
			if(Error_Check() == true){
		      $("#processingDiv").fadeIn();		      

		      var action = baseURL + "/learners/save_learner_changes";
		      var form_data = {
		        'first_name': $("#first_name").val(),     
		        'last_name': $("#last_name").val(),
		        'department': $("#department").val(),
		        'role': $("#role").val(),
		        'email': $("#email").val(),
		        'user_name': $("#user_name").val(),
		        'phone': $("#phone").val(),
		        'learnerId': learnerId,
		        'force_update_username':force_update_username
		      };    

		      $.ajax({
		        type: "POST",
		        url: action,
		        data: form_data,
		        success: function(response)
		        {           
		          //window.parent.update_learner_row($("#first_name").val(), $("#last_name").val(), $("#email").val(), $("#phone").val(), $("#department").val(), $("#role").val());
		          var responseObj = $.parseJSON(response);
		          window.parent.update_learner_row(responseObj);
		          //alert(response);
		          $("#errorBox").hide();
		          $("#processingDiv").hide();          
		          $("#msgBox").fadeIn();
		        }
		      });

		    }else{  
		    	$("#msgBox").hide();
		    	$("#processingDiv").hide();  
		      	$("#errorBox").fadeIn();
		    }
		}

		function Error_Check(){
		    var proceed = true;
		    if( ($.trim($("#first_name").val())=="") || ($.trim($("#first_name").val())=="") ){
		      proceed = false;
		    }

		    if( ($.trim($("#last_name").val())=="") || ($.trim($("#last_name").val())=="") ){
		      proceed = false;
		    }

		    if( ($.trim($("#department").val())=="") || ($.trim($("#department").val())=="") ){
		      proceed = false;
		    }

		    if( ($.trim($("#role").val())=="") || ($.trim($("#role").val())=="") ){
		      proceed = false;
		    }
		    
		    if(!validateEmail( $("#email").val() )){
		    	proceed = false;	
		    }

		    return proceed;
		  }

		 function validateEmail(email) { 
			var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			
			return re.test(email);
		} 


	</script>
</body>