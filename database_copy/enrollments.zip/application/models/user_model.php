<?php
Class User_Model extends CI_Model
{
  
  public function __construct()
  {
    $this->load->database();
  }
  

  function createLogin(){

  }
  

  // Return a comprehensive array with login status and further details for navigating ahead
  function doLogin($email, $password){ 

    /*@ var return_array properties definition: ****
          status = stores whether a valid user  //--Possible Values - Success, Fail --//       
          reason = If status is Fail, what is reason. //--Possible Values - "username/password" --//
          Following applicable if successful login
            clientId =    //--Possible Values - integer --//   
            formFilled = Have the client details (name, accountnum) been filled. Else navigate them to the form first. //--Possible Values - true/false --//
            skipIntro = Status of the Skip Intro button for further navigation  //--Possible Values - true/false --//
    */
    $return_array = array("status"=> "None", "reason"=>"", "clientId"=>"", "formFilled"=>false, "skipIntro"=>false);

    $query = $this->db->get_where('client_users', array('email' => $email, 'password'=>md5($password) ));
    if($query->num_rows()>0){      
      $login_result = $query->row_array();

      $this->setSessionDetails($login_result);
        
      $return_array["status"] = "Success";      
      $return_array["clientId"] = $login_result["clientId"];
      
      if($login_result["clientId"]>0){
         $return_array["formFilled"] = true;
      }

    }else{
      $return_array["status"] = "Fail";
      $return_array["reason"] = "Username";      
    }

    return $return_array;
    //return "Fail";

  }


  /*
      Function - Sets the session data for logged in user.
      Session variable name - 'logged_in_user'
      No return value
  */
  function setSessionDetails($login_result){
    $is_multi_client = (strpos($login_result["clientId"], '$') !== false)? true:false;
    /*if (strpos($login_result["clientId"], '$') !== false) {
        echo 'true';
    }*/

    $all_clients_string = $login_result["clientId"];

    if($is_multi_client){
      $all_clients_array = explode("$", $login_result["clientId"]);
      $current_client = $all_clients_array[0];
    }else{
      $current_client = $login_result["clientId"];
    }
    
    $sess_array = array();
    $sess_array = array(
       'userId' => $login_result["userId"],
       'email' => $login_result["email"],
       'first_name' => $login_result["first_name"],
       'last_name' => $login_result["last_name"],
       'phone' => $login_result["phone"],
       'date_added' => $login_result["date_added"],
       'is_multi_client' => $is_multi_client,
       'all_clients_string' => $all_clients_string,
       'clientId' => $current_client
    );
    
    $this->session->set_userdata('logged_in_user', $sess_array); 

  }


  function change_current_clientId($new_clientId){
    
    $session_details =  $this->session->userdata('logged_in_user');
    
    $sess_array = array(
       'userId' => $session_details["userId"],
       'email' => $session_details["email"],
       'first_name' => $session_details["first_name"],
       'last_name' => $session_details["last_name"],
       'phone' => $session_details["phone"],
       'date_added' => $session_details["date_added"],
       'is_multi_client' => $session_details["is_multi_client"],
       'all_clients_string' => $session_details["all_clients_string"],
       'clientId' => $new_clientId 
    );

    $this->session->set_userdata('logged_in_user', $sess_array); 
    return true;
  }

  function getSessionDetails(){
    $session_details = array("active_status"=>false, "userDetails"=>array());
    if($this->session->userdata('logged_in_user')) {
        //$session_data = $this->session->userdata('logged_in_user');
        $session_details["active_status"] = true;
        $session_details["userDetails"] =  $this->session->userdata('logged_in_user');
    }else{
      $session_details["active_status"] = false;
    }

    return $session_details;
  }

  function destroy_sesssion(){
    $this->session->unset_userdata('logged_in_user');
    $this->session->sess_destroy();
  }


  function resetPassword($mail){
    $userId = "Not Found";
    $query = $this->db->get_where('client_users', array('email' => $mail));
    
    if($query->num_rows() > 0){
      $resultArray = $query->row_array();
      $userId = $resultArray["userId"];
      $this->db->where('userId', $resultArray["userId"]);
      $this->db->update('client_users', array('password' => md5("Welcome123") )); 

      $this->reset_password_mail($resultArray);

    }
    
    
    if($userId != "Not Found"){
      return 'Success';
    }else{
      return "Fail";
    }

  }


  function changePassword($oldPassword, $newpassword_1){
    $returnString = "";
    $session_data = $this->getSessionDetails();
    $currentUserId = $session_data['userDetails']["userId"];

    $query = $this->db->get_where('client_users', array('userId' => $currentUserId, 'password'=>md5($oldPassword) ));
    if($query->num_rows() > 0){
      $this->db->where('userId', $currentUserId);
      $this->db->update('client_users', array('password' => md5($newpassword_1) )); 
      $returnString = "Success";
    }else{
      $returnString = "Wrong Password";
    }

    return $returnString;
  }

  
  function get_user_details($userId){
      $this->db->select('first_name, last_name, email, phone');
      $this->db->from('client_users');
      $this->db->where('userId', $userId);   
      $query = $this->db->get();
      return $query->row_array();
  }


  function reset_password_mail($user_details){

    $this->load->library('email');
    $this->email->set_mailtype("html");
    $this->email->from('enroll@eduserv.myallscripts.com', 'Allscripts Education Services - Program Enrollment Portal');
    $this->email->to($user_details["email"]);
    //$this->email->cc($mailArray["mailTo"]);
    $this->email->bcc('vishwajit.menon@allscripts.com');
    
    //$report_url = base_url("index.php/export_module/excel_internal_summary/")."/".$requestId;
   
    $mailBody = "<!doctype html><meta http-equiv='X-UA-Compatible' content='IE=Edge'><html><head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8'> <style type='text/css'>.ExternalClass{display:block !important;}</style></head><body leftmargin='0' rightmargin='0' topmargin='0' bottommargin='0' bgcolor='#d9dadc' style='font-family:Verdana, Geneva, sans-serif;'>  <table width='100%' cellspacing='0' cellpadding='0' bgcolor='#d9dadc' style='padding:20px; font-family:Verdana, Geneva, sans-serif;'><tr> <td width='100%' bgcolor='#5B8F22' style='padding:0px 5px; height:52px; color:#fff'>Education Services - Program Enrollment Portal</td></tr><tr>  <td width='100%' bgcolor='#FFFFFF' style='padding:10px'><table cellpadding='0' cellspacing='0'> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'> <p>Hi ".$user_details["first_name"]." ".$user_details["last_name"].",</p> <p>Your password recovery request has been processed, and your temporary password is below.</p></br> </td> </tr> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'><table style='font-family:Verdana, Geneva, sans-serif;font-size:12px; padding:0px; border-top:1px solid #DDDDDD; border-right:1px solid #DDDDDD' cellpadding='0' cellspacing='0'><tr><td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD;text-align: center; font-size:16px' colspan='2' >Password Reset</td></tr> <tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Login Name</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$user_details["email"]."</td></tr><tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Temporary Password</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Welcome123</td></tr></table></td> </tr><tr><td style='padding:0px; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;'></br><p><b>Note: </b>It is strongly advised that you change your password upon logging in the first time.</p><p>For any issues you face using these details, you can contact <a href='mailto:vishwajit.menon@allscripts.com;'>support</a>.</p></td> </tr></table> </td></tr></table>  </body></html>";

    $this->email->subject("Program Enrollment Portal - Password Reset");
    $this->email->message($mailBody);

    $this->email->send();

  }


} // End of Class Declaration


?>