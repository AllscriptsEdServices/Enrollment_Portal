<?php
Class Request_Model extends CI_Model
{
  
  public function __construct()
  {
    $this->load->database();
  }
  

  function get_all_requests($clientId){
    $this->db->from('requests');
    $this->db->where(array('clientId' => $clientId));
    $query = $this->db->get();
    return $query->result_array();
  }

  function create_request($client_id, $request_type, $userId){
      $request_array = array(                   
        'request_type' =>$request_type,
        'request_name' => "",
        'clientId' => $client_id,           
        'created_by' => $userId,
        'created_date' => date('Y-m-d G:i:s')
      );

      $this->db->insert('requests', $request_array);
      $requestId = $this->db->insert_id();  

      $this->set_current_request($requestId, $request_type);

      return $requestId;
  }
  

  function view_draft_request($reuestId){
    
    if($this->session->userdata('current_request')) {   
      $this->session->unset_userdata('current_request');
    }

  }


  /*
      Function - Sets the session data for current request.
      Session variable name - 'current_request'
      No return value
  */
  function set_current_request($requestId, $request_type, $return_required = false){
    //Destroy existing session
    if($this->session->userdata('current_request')) {   
      $this->session->unset_userdata('current_request');
    }

    $sess_array = array();
      
    $sess_array = array(
       'requestId' => $requestId,
       'request_type' => $request_type       
    );
    
    $this->session->set_userdata('current_request', $sess_array); 

    if($return_required){
      return true;
    }

  }


  function get_current_request(){
    $session_details = array("active_status"=>false, "request_details"=>array());
    if($this->session->userdata('current_request')) {        
        $session_details["active_status"] = true;
        $session_details["request_details"] =  $this->session->userdata('current_request');
    }else{
      $session_details["active_status"] = false;
    }

    return $session_details;
  }


  
  function submit_request($requestId, $userId){
      $this->db->where('requestId', $requestId);
      $this->db->update('requests', array('submission_status' => 1, 'submitted_date'=>date('Y-m-d G:i:s'), 'submitted_by'=>$userId));
      return true;
  }


  function delete_request($requestId){
    $this->db->where(array('requestId' => $requestId));
    $this->db->delete('requests');
    return true;
  }

  
  function get_request_details($requestId){
    $query = $this->db->get_where('requests', array('requestId' => $requestId));
    if($query->num_rows()>0){
      return $query->row_array();
    }else{
      return "Invalid";
    }
    
  }



  function send_request_notify_mail($requestId, $client_details, $request_type, $is_hsg_client=false){
        
        $mailing_address = ($is_hsg_client) ? "hsgeducationsupport@allscripts.com" : "education@allscripts.com";        

        $this->load->library('email');
        $this->email->set_mailtype("html");
        $this->email->from('enroll@eduserv.myallscripts.com', 'Allscripts Education Services - Program Enrollment Portal');
        //$this->email->to("vishwajit.menon@allscripts.com, sabrina.francis@allscripts.com, Jennifer.Hruska@allscripts.com, Maceo.Harrell@allscripts.com");
        $this->email->to($mailing_address);
        //$this->email->cc($mailArray["mailTo"]);
        $this->email->bcc('vishwajit.menon@allscripts.com, vishwajitrmenon@gmail.com, jennifer.hruska@allscripts.com');
        
        if($request_type=="Assign Program"){
          $report_url = base_url("index.php/export_module/excel_internal_summary/")."/".$requestId;
        }else if($request_type=="Deactivate Learners"){
          $report_url = base_url("index.php/export_module/excel_deactivate_report/")."/".$requestId;
        }
        
       
        $mailBody = "<!doctype html><meta http-equiv='X-UA-Compatible' content='IE=Edge'><html><head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8'> <style type='text/css'>.ExternalClass{display:block !important;}</style></head><body leftmargin='0' rightmargin='0' topmargin='0' bottommargin='0' bgcolor='#d9dadc' style='font-family:Verdana, Geneva, sans-serif;'>  <table width='100%' cellspacing='0' cellpadding='0' bgcolor='#d9dadc' style='padding:20px; font-family:Verdana, Geneva, sans-serif;'><tr> <td width='100%' bgcolor='#5B8F22' style='padding:0px 5px; height:52px; color:#fff'>Education Services - Program Enrollment Portal <!-- <img src='http://assessment.eduserv.myallscripts.com/images/mail_header.png' width='339' height='52'> --> </td></tr><tr>  <td width='100%' bgcolor='#FFFFFF' style='padding:10px'><table cellpadding='0' cellspacing='0'> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'> <p>Hi Team,</p> <p>A new request has been submitted from the Allscripts Education Services Program Enrollment Portal. </p>  <p>Below are the request details:</p> </br> </td>  </tr> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'><table style='font-family:Verdana, Geneva, sans-serif;font-size:12px; padding:0px; border-top:1px solid #DDDDDD; border-right:1px solid #DDDDDD' cellpadding='0' cellspacing='0'><tr><td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD;text-align: center; font-size:16px' colspan='2' >Request Details</td></tr>  <tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Request Number</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >E0".$requestId."</td></tr><tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Client Organization Name</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$client_details["orgName"]."</td></tr> <tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Client Account Number</td>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$client_details["accountNumber"]."</td></tr><tr> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Request Type</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$request_type."</td></tr><tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Request Summary</td>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' ><a href='".$report_url."''>Download Excel</a></td></tr> </table></td> </tr><tr><td style='padding:0px; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;'></br><p>For any issues you face using these details, you can contact <a href='mailto:vishwajit.menon@allscripts.com;'>support</a>.</p></td> </tr></table> </td></tr></table>  </body></html>";

        $this->email->subject("Program Enrollment Portal - Request E0".$requestId);
        $this->email->message($mailBody);

        $this->email->send();
  }


} // End of Class Declaration


?>