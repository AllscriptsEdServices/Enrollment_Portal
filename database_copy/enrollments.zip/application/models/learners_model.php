<?php
Class Learners_Model extends CI_Model
{
  
  public function __construct()
  {
    $this->load->database();
  }
  

  function createLogin(){

  }
  

  function getClientLearners($clientId){
    $this->db->order_by("first_name", "asc");     
    $query = $this->db->get_where('learners', array('clientId' => $clientId, 'status !='=>"deactivated"));
    return $query->result_array();
  }


 

  function addLearners($learner_list, $clientId, $userId){
    $return_array = array("duplicates"=>0, "successful"=>0);
    $all_learners_array = explode("|#|", $learner_list);    
    $duplicates = 0;
    /* for($i=0;$i<sizeof($all_learners_array); $i++){
      $all_learners_array[$i] = explode("$", $all_learners_array[$i]);      
    }*/

    foreach($all_learners_array as $single_learner){
      $learner = explode("$", $single_learner);
      $query = $this->db->get_where('learners', array('email' => $learner[2]));
      if($query->num_rows() <=0){
         $learnerArray = array(                   
          'first_name' =>$learner[0],
          'last_name' => $learner[1],
          'user_name' => $learner[2],
          'email' => $learner[2],
          'phone' => $learner[3],
          'department' => $learner[4],
          'role' => $learner[5],
          'clientId' => $clientId,
          'addedBy' => $userId,
          'addedOn' => date('Y-m-d G:i:s'),
          'status' => "new"
        );

        $this->db->insert('learners', $learnerArray);
        //$clientId = $this->db->insert_id();  
        $return_array["successful"]++;
      }else{
        $return_array["duplicates"]++;
      }

    } //End of foreach

    return $return_array;

  }


  function get_learner_details($learnerId){
      $this->db->select('learnerId, first_name, last_name, user_name, email, department, role, phone');
      $this->db->from('learners');
      $this->db->where('learnerId', $learnerId);   
      $query = $this->db->get();
      $learner_array = $query->row_array(); 
      return $learner_array;
  }


  function set_learner_details($learner_details){

      $this->db->where('learnerId', $learner_details["learnerId"]);

      //Change username as the email changes
      if($learner_details["force_update_username"] === true){
        $this->db->update('learners', array('first_name' => $learner_details["first_name"], 'last_name' => $learner_details["last_name"], 'user_name'=> $learner_details["email"], 'email' => $learner_details["email"], 'phone' => $learner_details["phone"], 'department' => $learner_details["department"], 'role' => $learner_details["role"]));        
      }else{
        $this->db->update('learners', array('first_name' => $learner_details["first_name"], 'last_name' => $learner_details["last_name"], 'user_name'=> $learner_details["user_name"], 'email' => $learner_details["email"], 'phone' => $learner_details["phone"], 'department' => $learner_details["department"], 'role' => $learner_details["role"]));        
      }

      
      return true;
      //return $learner_details["force_update_username"];
      
  }

  function set_lms_new_learners($learners_string, $requestId){
    $new_learners_array = array();
    
    $learners_array = explode("$", $learners_string);
    foreach ($learners_array as $learnerId) {
       
        $this->db->select('learnerId, first_name, last_name, user_name, email, department, role, phone, status');
        $this->db->from('learners');
        $this->db->where('learnerId', $learnerId);   
        $query = $this->db->get();
        $learner_details = $query->row_array(); 

        //Check if is a new learner i.e. status=new
        if($learner_details["status"] == "new"){
          $this->db->where('learnerId', $learnerId);
          $this->db->update('learners', array('status' => "active", 'added_to_lms_request'=>$requestId));

          array_push($new_learners_array, $learner_details);
        }

    }

    return $new_learners_array;
   

  }

  function get_new_learners($requestId){

    $this->db->select('learnerId, first_name, last_name, user_name, email, department, role, phone, status');
    $this->db->from('learners');
    $this->db->where('added_to_lms_request', $requestId);   
    $query = $this->db->get();
    return $query->result_array();   

  }
  

//http://www.eknowledgetree.com/codeigniter/how-to-import-data-from-csv-to-mysql-with-php-codeigniter/
//In the below code i used fgetcsv($file_handle,1024) to get csv line count and stored in $csv_line variable. Now using for loop read the csv file data and storing in an array and passing to codeigniter default insert function as shown above.
  function upload_learner_csv($userId, $clientId) {

    $data = array();
    $csv_array = array();
 
    $file_handle = fopen($_FILES['userfile']['tmp_name'],'r') or die("can't open file");

      // Read the CSV file and build the $csv_array
     while (!feof($file_handle) ) {
          $line_of_text = fgetcsv($file_handle, 1024);  

          $proceed = true;

          // Check if it is the header line (i.e. labels "First Name", etc) or is a NULL field that was added by mistake.
          if($line_of_text[2] == NULL || $line_of_text[0] == "First Name"){
            $proceed = false;
          }

          // Check if the client has kept the default example line provided in the sample csv file.
          if (strpos($line_of_text[2],'example.com') !== false) {
              $proceed = false;
          }

          //If all initial checks have passed, and $proceed is still true, add the row entry to the $csv_array
          if($proceed){
            $temp_array = array();
            $temp_array["first_name"] = $line_of_text[0];
            $temp_array["last_name"] = $line_of_text[1];
            $temp_array["email"] = $line_of_text[2];
            $temp_array["phone"] = $line_of_text[3];
            $temp_array["department"] = ($line_of_text[4]==NULL) ? " " : $line_of_text[4];
            $temp_array["role"] = ($line_of_text[5]==NULL) ? " " : $line_of_text[5];

            array_push($csv_array, $temp_array);
          }
            
      }

      fclose($file_handle);
      // END reading the CSV file
    
      //RETURN array containing information about the upload and all the related status for the front end
      $return_array = array("successful"=>0, "duplicate"=>0, "duplicate_log"=>"", "invalid"=>0, "invalid_log"=>"");

      foreach ($csv_array as $learner_array) {

        //Clean the phone number of any non numeric characters
        $learner_array["phone"] = preg_replace('/[^0-9,]|,[0-9]*$/','',$learner_array["phone"]);

        if(strlen($learner_array["phone"]) < 10){
            $return_array["invalid"]++;
            $invalid_entry = $learner_array["first_name"]." ".$learner_array["last_name"]."$";
            $return_array["invalid_log"] .= $invalid_entry;
        }
        else if(filter_var($learner_array["email"], FILTER_VALIDATE_EMAIL) == false){

            $return_array["invalid"]++;
            $invalid_entry = $learner_array["first_name"]." ".$learner_array["last_name"]."$";
            $return_array["invalid_log"] .= $invalid_entry;

        }else{

            $query = $this->db->get_where('learners', array('email' => $learner_array["email"]));

            if($query->num_rows() <=0){

              $learnerArray = array(                   
                'first_name' =>$learner_array["first_name"],
                'last_name' => $learner_array["last_name"],
                'user_name' => $learner_array["email"],
                'email' => $learner_array["email"],
                'phone' => $learner_array["phone"],
                'department' => $learner_array["department"],
                'role' => $learner_array["role"],
                'clientId' => $clientId,
                'addedBy' => $userId,
                'addedOn' => date('Y-m-d G:i:s'),
                'status' => "new",
                'added_to_lms_request'=>0
              );
              $this->db->insert('learners', $learnerArray);
              $return_array["successful"]++;

            }else{
              $duplicate_entry = $learner_array["first_name"]." ".$learner_array["last_name"]."$".$learner_array["email"]."||";
              $return_array["duplicate_log"] .= $duplicate_entry;
              $return_array["duplicate"]++;
            }

        }

      }


      $return_array["invalid_log"] = rtrim($return_array["invalid_log"], '$');
      $return_array["duplicate_log"] = rtrim($return_array["duplicate_log"], '||');
   

       return $return_array;
       //return $debug_array;

  } // End of function upload_learner_csv


  function deactivate_learners($selected_learners, $requestId){
    $selected_learner_array = explode("$", $selected_learners);

    foreach ($selected_learner_array as $learnerId) {
      $this->db->where('learnerId', $learnerId);
      $this->db->update('learners', array('status' => "deactivated", 'removed_from_lms_request'=>$requestId));
    }

    return true;
  }


  function get_deactivated_learners($requestId){
    $this->db->select('learnerId, first_name, last_name, user_name, email, department, role, phone, status');
    $this->db->from('learners');
    $this->db->where('removed_from_lms_request', $requestId); 
    $this->db->where(array('status' => "deactivated", 'removed_from_lms_request'=>$requestId));  
    $query = $this->db->get();
    return $query->result_array();   
  }



} // End of Class Declaration