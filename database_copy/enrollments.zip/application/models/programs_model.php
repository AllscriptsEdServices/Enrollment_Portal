<?php
Class Programs_Model extends CI_Model
{
  
  public function __construct()
  {
    $this->load->database();
  }
  

  function createLogin(){

  }
  
  function get_all_products(){
    $this->db->order_by("productName", "asc"); 
    $query = $this->db->get('products');
    return $query->result_array();
  }


  function get_category_versions($productId){
    $return_array = array();
    $categories_array = array();
    $versionForArray = array();

    //Query all programs for this product
    $this->db->select('product, category, version');
    $this->db->from('programs');
    $this->db->where('product', $productId);
    $query = $this->db->get();
    if($query->num_rows() > 0){
      $programs_list = $query->result_array();
      foreach ($programs_list as $program ) {

        // If mutliple categories linked
        if (strpos($program["category"],'$') !== false) {
          $this_program_categories = explode("$", $program["category"]);

          foreach ($this_program_categories as $this_program_single_category) {

            if(!in_array($this_program_single_category, $categories_array)){
              array_push($categories_array, $this_program_single_category);
              $versionForArray[$this_program_single_category] = array();
            }

            if( !in_array($program["version"], $versionForArray[$this_program_single_category]) ){
              array_push($versionForArray[$this_program_single_category], $program["version"]);
            }

          }


        }else{ 
          // If only one category
          if(!in_array($program["category"], $categories_array)){
            array_push($categories_array, $program["category"]);
            $versionForArray[$program["category"]] = array();
          }

          if( !in_array($program["version"], $versionForArray[$program["category"]]) ){
            array_push($versionForArray[$program["category"]], $program["version"]);
          }

        }        

      }


      foreach ($categories_array as $category) {
        $query = $this->db->get_where('categories', array('categoryId' => $category));
        $return_array[$category]["category_info"] = $query->row_array();
        $this_category_versions = array();
        foreach ($versionForArray[$category] as $version) {
          $queryVersion = $this->db->get_where('versions', array('versionId' => $version));
          $this_category_versions[$version] = $queryVersion->row_array();
        }

        $return_array[$category]["versions"] = $this_category_versions;
      }
      

    } //End of IF Programs present for this product LOOP

    return $return_array;
    //return $versionForArray;

  }

  
  //#1$#12$#2$#21$ 
  function get_programs($productId, $categoryId, $versionId, $eo_program=false){

    //$this->db->select('product, category, version');
    $this->db->from('programs');
    $this->db->where('product', $productId); 
    $this->db->where('version', $versionId); 
    $this->db->like('category', $categoryId); 
    //$this->db->where(array('product' => $productId, 'category' => $categoryId, 'version' => $versionId, 'pro_eo_program !='=>1));
    $query = $this->db->get();

    return $query->result_array();
  }



  
  function get_program_name($programId){

      $this->db->select('programName');
      $this->db->from('programs');
      $this->db->where('programId', $programId);
      $query = $this->db->get();
      $program_array = $query->row_array();
      return $program_array["programName"];
      
  }
  

  function insertLearnersToDatabase(){

  }





  

  



} // End of Class Declaration


?>