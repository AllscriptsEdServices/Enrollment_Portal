<?php
Class Assign_Program_Model extends CI_Model
{
  
  public function __construct()
  {
    $this->load->database();
  }
  

  function set_assignments($selected_learners, $selected_programs, $clientId, $requestId){

    $return_array = array("successful"=>0, "duplicate"=>0, "duplicate_log"=>"", "successful_data"=>"");
    
    $learners_array = explode("$", $selected_learners);
    $programs_array = explode("$", $selected_programs);


    foreach ($learners_array as $learner) {
      
      foreach ($programs_array as $program) {

        if(!$this->check_duplicate_assignment($learner, $program)){

           $enrollment_array = array(                   
            'programId' =>$program,
            'learnerId' => $learner,
            'clientId' => $clientId,
            'requestId' => $requestId,
            'created_date' => date('Y-m-d G:i:s')        
          );

          $this->db->insert('enrollments', $enrollment_array);
          $return_array["successful"]++;
          $return_array["successful_data"] .= $this->db->insert_id()."$".$learner."$".$program."||";

        }else{

          $return_array["duplicate"]++;
          $return_array["duplicate_log"] .= $this->get_duplicate_assignment_text($learner, $program)."||";

        }

      } // End of second for loop - programs

    } // End of first for loop - learners

    $return_array["successful_data"] = rtrim($return_array["successful_data"], '||');
    $return_array["duplicate_log"] = rtrim($return_array["duplicate_log"], '||');

    return $return_array;
  }

  
  function check_view_summary_active($requestId){
      $this->db->select('enrollmentId');
      $this->db->from('enrollments');
      $this->db->where('requestId', $requestId);          
      $query = $this->db->get();     

      $is_active = ($query->num_rows() > 0) ? true : false;
      return $is_active;
  }


  function check_duplicate_assignment($learnerId, $programId){

    $this->db->from('enrollments');
    $this->db->where(array('learnerId' => $learnerId, 'programId' => $programId));
    $query = $this->db->get();
    if($query->num_rows() >0){
      return true;
    }else{
      return false;
    }

    //return $query->result_array();
  }


  function get_duplicate_assignment_text($learnerId, $programId){
      //$this->db->select('programName, password, name, rights, type, phone');
      $this->db->select('first_name, last_name');
      $this->db->from('learners');
      $this->db->where('learnerId', $learnerId);
      $query = $this->db->get();
      $learner_array = $query->row_array();

      $this->db->select('programName');
      $this->db->from('programs');
      $this->db->where('programId', $programId);   
      $query = $this->db->get();
      $program_array = $query->row_array();     

      return $learner_array["first_name"]." ".$learner_array["last_name"]."$".$program_array["programName"];

  } 



  // Get the assignments in the enrollment table for a particular learner and request combination
  function get_this_request_assignments($requestId, $learnerId){
    /*Structure of $return_array
      array(array("programId"=>1, "programName"=>"Ed Services Nurse Prog"), array("programId"=>4, "programName"=>"Ed Services Signature Manager"))
    */
    $return_array = array();

    $this->db->select('enrollmentId, programId, learnerId');
    $this->db->from('enrollments');
    $this->db->where('requestId', $requestId); 
    $this->db->where('learnerId', $learnerId);       
    $query = $this->db->get();
    $assignments_array = $query->result_array();

    

    foreach ($assignments_array as $assignment) {   

      $this->db->select('programName');
      $this->db->from('programs');
      $this->db->where('programId', $assignment["programId"]);   
      $query = $this->db->get();
      $program_array = $query->row_array(); 

      $single_program_arr = array("enrollmentId"=>  $assignment["enrollmentId"], "programId"=>$assignment["programId"], "programName"=>$program_array["programName"]);

      array_push($return_array, $single_program_arr);

    }

    return $return_array;
  }


  //Delete all data from the enrollments table, for a particular requestId
  function delete_request_data($requestId){
    $this->db->where(array('requestId' => $requestId));
    $this->db->delete('enrollments');
    return true;
  }


  function delete_assignment($enrollmentId){
    $this->db->where(array('enrollmentId' => $enrollmentId));
    $this->db->delete('enrollments');
    return true;
  }



  function get_summary_details($requestId, $order_type){ 
    $this->db->from('enrollments');
    $this->db->where(array('requestId' => $requestId));
    $this->db->order_by($order_type, "asc"); 
    $query = $this->db->get();
    return $query->result_array();
  }


  function get_unique_learners($requestId){
    $this->db->distinct();
    $this->db->select('learnerId');
    $this->db->from('enrollments');
    $this->db->where(array('requestId' => $requestId));    
    $query = $this->db->get();
    //return $query->result_array();

    $return_string = "";
    foreach ($query->result_array() as $learner) {
      $return_string .= $learner["learnerId"]."$";
     
    }

    $return_string = rtrim($return_string, '$');

    return $return_string;
  }

  
   function get_learner_assignments($learnerId){    
    $return_array = array();   

    $this->db->select('programs.programName');
    $this->db->from('enrollments');      
    $this->db->join('programs', 'programs.programId = enrollments.programId');   
    $this->db->join('requests', 'requests.requestId = enrollments.requestId');
    $this->db->where('learnerId', $learnerId); 
    $this->db->where('requests.submission_status', 1);    

    $query = $this->db->get();
    return $query->result_array();

  }
  

  function check_hsg_program($requestId){
    //Actual product id of the care management and homecare products from the products table in database
    $cm_product_id = 1;
    $homecare_product_id = 4;

    $this->db->select('programs.programName');
    $this->db->from('enrollments'); 
    $this->db->join('programs', 'programs.programId = enrollments.programId');      
    $where_clause = "(enrollments.requestId=$requestId) AND (programs.product=".$cm_product_id." OR programs.product=".$homecare_product_id.") ";
    $this->db->where($where_clause);   

    $query = $this->db->get();
    if($query->num_rows()>0){
      return true;
    }else{
      return false;
    }
    
  }



} // End of Class Declaration


?>