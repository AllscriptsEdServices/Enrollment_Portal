	$(document).ready(function() {
		//Live search function for the All Users List
		$("#search_org_all").on("keyup", function() {
			deselect_all_users();
			//alert($("#search_by_drop").val())
		    var value = $(this).val().toLowerCase();
		    $("#users_table tr").each(function(index) {
		        if (index !== 0) {
		            $row = $(this);	
		            //Checks the value of the field drop down. Values are actually column number
		            var filter_row = $("#search_by_drop").val();
		            var id = $row.find("td:nth-child(" + filter_row + ")").text().toLowerCase();
		            if (id.indexOf(value) < 0) {
		                $row.hide();
		            }
		            else {
		                $row.show();
		            }
		        }
		    });
		});

		//Live search function for the All Programs List
		$("#search_program_all").on("keyup", function() {
			//alert($("#search_by_drop").val())
		    var value = $(this).val().toLowerCase();
		    $("#programs_table tr").each(function(index) {
		        if (index !== 0) {
		            $row = $(this);
		            var id = $row.find("td:nth-child(2)").text().toLowerCase();
		            if (id.indexOf(value) < 0) {
		                $row.hide();
		            }
		            else {
		                $row.show();
		            }
		        }
		    });
		});

		
	    
	    $(document).on('click','#select_all_users_checkbox',function() {
	        if(this.checked) { // check select status
	            $('.users_checkbox').each(function() { //loop through each checkbox	
	            	if($(this).parent().parent().css('display') !="none"){
	            		this.checked = true;  //select all checkboxes with class "users_checkbox"   	
	            	}	                           
	            });
	        }else{
	            $('.users_checkbox').each(function() { //loop through each checkbox
	                this.checked = false; //deselect all checkboxes with class "users_checkbox"                      
	            });        
	        }
	    });


	    $(document).on('click','.users_checkbox',function() {	    	
	    	if( !this.checked && document.getElementById('select_all_users_checkbox').checked ){	    		
	    		document.getElementById('select_all_users_checkbox').checked = false;
	    	}
	    });


	    $(document).on('click','#select_all_programs_checkbox',function() {
	        if(this.checked) { // check select status
	            $('.programs_checkbox').each(function() { //loop through each checkbox
	               if($(this).parent().parent().css('display') !="none"){
	            		this.checked = true;  //select all checkboxes with class "programs_checkbox"   	
	            	}             
	            });
	        }else{
	            $('.programs_checkbox').each(function() { //loop through each checkbox
	                this.checked = false; //deselect all checkboxes with class "programs_checkbox"                      
	            });        
	        }
	    });

	     $(document).on('click','.programs_checkbox',function() {	    	
	    	if( !this.checked && document.getElementById('select_all_programs_checkbox').checked ){	    		
	    		document.getElementById('select_all_programs_checkbox').checked = false;
	    	}
	    });


	    
	   
	}); // Document Ready Loop Ends




	function get_category_versions(productId){
		current_product = productId;
		updateNavBar("product", productId);
		
	    var form_data = {
	      'productId': productId		    
	    };

	    $.ajax({
	      	type: "POST",
	      	url: baseURL + "/assign_program/get_category_versions",
	      	data: form_data,
	      	success: function(response)
	      	{	
	      		var responseObj = $.parseJSON(response);	
	      		display_categories_versions(responseObj);       		  			
	      		    		
	      	}
	    });

	}


	function get_programs(){		 

		if( $('input[name=category_radio]:checked' ).val() != undefined){			
			$('#version_drop_'+$('input[name=category_radio]:checked' ).val()).val();
			var selected_category_id = $('input[name=category_radio]:checked' ).val();
			//Text to update the navbar. Concatenate category name + _ + version name
			var cat_ver_string = $('input[name=category_radio]:checked' ).parent().text() + "_" + $('#version_drop_'+selected_category_id + ' option:selected').text();
			
			updateNavBar("category_version", cat_ver_string);

			
			var form_data = {
				'productId': current_product,
		      	'categoryId': $('input[name=category_radio]:checked' ).val(),
		      	'versionId': $('#version_drop_'+$('input[name=category_radio]:checked' ).val()).val()
		    };

		    $.ajax({
		      	type: "POST",
		      	url: baseURL + "/assign_program/get_programs",
		      	data: form_data,
		      	success: function(response)
		      	{	
		      		var responseObj = $.parseJSON(response);
		      		//alert(responseObj)	
		      		display_programs(responseObj);       		  			
		      		    		
		      	}
		    });

		}else{
			alert("Please select a product category.");
		}

	}


	function display_categories_versions(response_obj){
		//Sample Response Obj
		/*var raw_response = '{"2":{"category_info":{"categoryId":"2","categoryName":"Acute","categoryInfo":""},"versions":{"3":{"versionId":"3","version":"14.2","versionInfo":""}}},"3":{"category_info":{"categoryId":"3","categoryName":"Ambulatory","categoryInfo":""},"versions":{"4":{"versionId":"4","version":"14.3","versionInfo":""},"3":{"versionId":"3","version":"14.2","versionInfo":""}}}}';
		var response_obj = $.parseJSON(raw_response);*/
		//alert(responseObj["2"]);

		//var display_string = '<p class="text-center">Product Categories and Versions</p>';

		var display_string = "";
		display_string += '<table class="table table-bordered bg-white" style="width:60%" align="center">';
		var first_category_flag = true;

		for(category in response_obj){
			
			display_string += '<tr>';
			display_string += '<td>';
			if(first_category_flag){
				display_string += '<label> <input type="radio" name="category_radio" value="'+response_obj[category].category_info.categoryId+'" checked />  ' + response_obj[category].category_info.categoryName + '</label>';
				first_category_flag = false;
			}else{
				display_string += '<label> <input type="radio" name="category_radio" value="'+response_obj[category].category_info.categoryId+'" />  ' + response_obj[category].category_info.categoryName + '</label>';
			}
			
			display_string += '</td>';


			display_string +=  '<td>';

			var total_versions = response_obj[category].versions;
			var versions_drop = '<select id="version_drop_'+response_obj[category].category_info.categoryId+'" name="version_drop_'+response_obj[category].category_info.categoryId+'">';
			var first_version_flag = true;
			for(version in total_versions){
				//alert(total_versions[version].version);
				if(first_version_flag){
					versions_drop += '<option value="'+total_versions[version].versionId+'" selected>' + total_versions[version].version + '</option>';
					first_version_flag = false;
				}else{
					versions_drop += '<option value="'+total_versions[version].versionId+'">' + total_versions[version].version + '</option>';
				}
				
			}
			versions_drop += '</select>';
			display_string += versions_drop;

			display_string += '</td>';
			display_string += '</tr>';			

		}

		display_string += '</table>';

		if(response_obj.length == 0){
			display_string += '<p class="text-center">No programs are available for this product currently.</p>';
			display_string += '<button class="btn btn-success center-block" onclick="javascript:display_home()">Go back</button>';
		}else{
			display_string += '<button class="btn btn-success center-block" onclick="javascript:get_programs()">Go To Programs</button>';
		}
		

		$("#category_version_div").removeClass("hidden");
		$("#category_version_div").html(display_string);
		$('#products_list').addClass("hidden");
		$('#programs_div').addClass("hidden");
		

	}


	function display_programs(response_obj){
		current_programs_array = [];
		var display_string = '<table id="programs_table" class="table table-bordered bg-white" > <thead>	<th><input type="checkbox" id="select_all_programs_checkbox" name="programs" value="all"></th> <th></th>	<th>Program Name</th>	</thead>  ';

		var counter = 0;
		for(program in response_obj){
			//alert(response_obj[program].programName);
			
			display_string += '<tr>';	
			display_string += '<td> <input type="checkbox" name="programs_checkbox" class="programs_checkbox" value="'+ response_obj[program].programId +'"> </td>';
			//Check if not description given, if so display "No Description Available"
			if(response_obj[program].programDescription!="" && response_obj[program].programDescription != " "){
				display_string += '<td><span onclick="display_program_description('+ response_obj[program].programId +')" class="descr_icon changecolor glyphicon glyphicon-info-sign" data-toggle="tooltip" data-placement="top" title="'+response_obj[program].programDescription+'"></span></td>';
			}else{
				display_string += '<td><span class="descr_icon changecolor glyphicon glyphicon-info-sign" data-toggle="tooltip" data-placement="top" title="No Description Available"></span></td>';
			}
			display_string += '<td>'+ response_obj[program].programName +'</td>';
			display_string += '</tr>';

			var temp_program_obj = [response_obj[program].programId, response_obj[program].programName, response_obj[program].programDescription];			
			current_programs_array.push(temp_program_obj);
			//current_programs_array[counter] = 
		}

		display_string += '</table>';

		$("#programs_list").html(display_string);

		$("#category_version_div").addClass("hidden");
		$('#products_list').addClass("hidden");
		$("#programs_div").removeClass("hidden");
		
		//Re-initiate tooltip so that dynamically added tooltips function
		$('[data-toggle="tooltip"]').tooltip();
		//alert(current_programs_array);
	}


	// Function to populate and open the program_description_modal;
	// STRUCTURE = current_programs_array[programId, programName, programDescription]
	function display_program_description(programId){
		for(var i=0; i<current_programs_array.length; i++){				
			if(current_programs_array[i][0] == programId){			
									
				$('#program_description_title').html(current_programs_array[i][1]);	
				if(current_programs_array[i][2] !== "" && current_programs_array[i][2] != " "){
					$('#program_description_text').html(current_programs_array[i][2]);	
				}else{
					$('#program_description_text').html("No Description Available.");	
				}
				
				$('#program_description_modal').modal('show');

			}
		}
		
	}


	function display_home(){
		current_product = 0;
		updateNavBar("home", "");
		$("#category_version_div").addClass("hidden");
		$("#programs_div").addClass("hidden");
		$('#products_list').removeClass("hidden");		
	}


	function updateNavBar(type, resource_id){
		var display_string = '<a href="javascript:display_home()" >Home<a>';

		if(type=="product" || type=="category_version" ){
			var required_product_id = (String(resource_id).indexOf("_") > 0) ? current_product : resource_id;

			for(var i=0; i<all_products.length; i++){
				//alert(all_products[i]["productId"]);
				if(required_product_id == all_products[i]["productId"]){
					display_string += ' > <a href="javascript:get_category_versions('+all_products[i]["productId"]+')">'+ all_products[i]["productName"] +'</a> ';
					break;
				}
			}
		}

		if(type == "category_version"){
			var cat_ver_array = resource_id.split("_");
			display_string += ' > <a href="#">'+ cat_ver_array[0] +'</a>';
			display_string += ' > <a href="#">'+ cat_ver_array[1] +'</a>';
		}

		$("#breadcrumb_div").html(display_string);

	}


	function assign_programs(){		

		var selected_learners = "";
		var selected_learners_array = [];
		$.each($("input[name='users_checkbox']:checked"), function(){
		    selected_learners_array.push($(this).val());
		});
		
		if(selected_learners_array.length>0){
			selected_learners = selected_learners_array.join("$");
		}else{
			alert("Please select learners.");
			return;
		}

		var selected_programs = "";
		var selected_programs_array = [];
		$.each($("input[name='programs_checkbox']:checked"), function(){
		    selected_programs_array.push($(this).val());
		});
		
		if(selected_programs_array.length>0){
			selected_programs = selected_programs_array.join("$");
		}else{
			alert("Please select the required programs.");
			return;
		}		
		
		submit_assignments(selected_learners, selected_programs);
	}


	function submit_assignments(selected_learners, selected_programs){
		$("#loader_div").show();
		var form_data = {
			'selected_learners': selected_learners,
	      	'selected_programs': selected_programs	      	
	    };

	    $.ajax({
	      	type: "POST",
	      	url: baseURL + "/assign_program/set_assignments",
	      	data: form_data,
	      	success: function(response)
	      	{		      		
	      		var responseObj = $.parseJSON(response);
	      		
	      		if(responseObj.duplicate>0){	      			
	      			display_duplicates_warning(responseObj.duplicate_log);	      		
	      		}	      		

	      		//display_successful_assignments(selected_learners, selected_programs);	      		
	      		display_successful_assignments(responseObj.successful_data);
	      		$("#loader_div").hide();
	      	}
	    });

	    deselect_all_programs();
	}


	//Format of the duplicate assignment log received
	//"Alex Fergusson$Ed Services: Sunrise Acute 14.2 for Project Managers||Jill Drake$Ed Services: Sunrise Acute 14.2 for Project Managers"
	function display_duplicates_warning(duplicate_log){
		var duplicates_array = duplicate_log.split("||");
		var warnings_table = '<table class="table table-bordered"><tr> <th>Learner</th> <th>Program</th> </tr>'
		for(var i=0; i<duplicates_array.length; i++){
			var split_data = duplicates_array[i].split("$"); 
			warnings_table += '<tr>';
			warnings_table += '<td>' + split_data[0] + '</td>';
			warnings_table += '<td>' + split_data[1] + '</td>';
			warnings_table += '</tr>';
		}
		warnings_table += '<table>';

		$('#warning_content_div').html(warnings_table);
		$('#warning_modal').modal('show');
	}


	//Format of the successful_data received
	// <enrollmentId_1> $ <learnerId_1> $ <programId_1> || <enrollmentId_2> $ <learnerId_2> $ <programId_2>
	function display_successful_assignments(successful_data){
		var single_enrollment_data = successful_data.split("||");

		for(var i=0; i<single_enrollment_data.length; i++){
			var composite_assign_data = single_enrollment_data[i].split("$");

			//** Structure
			//composite_assign_data = [enrollment Id, learner Id, program Id]	
			
			var learner_display_string = '<table id="temp_assign_table_' + composite_assign_data[0] + '" class="learner_assigned_table"><tr><td class="assigned_program_name">' + get_program_name(composite_assign_data[2]) + '</td> <td class="text-right"> <a href="javascript:delete_assignment('+composite_assign_data[0]+')"><span class="glyphicon glyphicon-remove-circle" style="font-weight:bold" aria-hidden="true" data-toggle="tooltip" data-placement="bottom" title="Delete this assignment"></span></a> </td> </tr> </table>';
			$("#programs_requested_div_" + composite_assign_data[1]).append(learner_display_string);
		}

	}

	

	function get_program_name(programId){		
		for(var i=0; i<current_programs_array.length; i++){				
			if(current_programs_array[i][0] == programId){				
				return current_programs_array[i][1];				
			}
		}
		return false;
	}

	function delete_assignment(enrollmentId){
		var confirm_delete = confirm("This will permanently delete this assignment for this learner. Would you like to proceed?");
		if(confirm_delete){
			var form_data = {
				'enrollmentId': enrollmentId	      	
		    };

		    $.ajax({
		      	type: "POST",
		      	url: baseURL + "/assign_program/delete_assignment",
		      	data: form_data,
		      	success: function(response)
		      	{		      			      		
		      		if(response){
		      			$("#temp_assign_table_" + enrollmentId).hide();
		      			
		      		}		      		
		      	}
		    });

		}

	}


	function show_request_summary(){
		
		$.ajax({
	      	type: "POST",
	      	url: baseURL + "/assign_program/check_view_summary_active",		      	
	      	success: function(response)
	      	{		
	      		     			      		
	      		if(response){
	      			window.location.href = baseURL + "/assign_program/show_assign_summary" ;	      			
	      		}else{
	      			alert("Please assign at least one program."); 
	      		}	      		
	      	}
	    });
		
	}


	function deselect_all_programs(){
		$('.programs_checkbox').each(function() { //loop through each checkbox
           if($(this).parent().parent().css('display') !="none"){
        		this.checked = false;  //select all checkboxes with class "programs_checkbox"   	
        	}             
        });
        document.getElementById('select_all_programs_checkbox').checked = false;
	}


	function deselect_all_users(){
		$('.users_checkbox').each(function() { //loop through each checkbox
           if($(this).parent().parent().css('display') !="none"){
        		this.checked = false;  //select all checkboxes with class "programs_checkbox"   	
        	}             
        });
        document.getElementById('select_all_users_checkbox').checked = false;
	}