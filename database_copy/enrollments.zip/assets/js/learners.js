var confirmbox = document.getElementById("confirmBox");
var errorbox = document.getElementById("ErrorBox");
var successbox = document.getElementById("SuccessBox");
var closeconfirmbox = document.getElementById("closeconfirmBox");
var saved = false;
function getenteredinfo(array){
		var arraylength = array.length;
		var finalstring = "";
		 for (var index = 0; index < arraylength; index++ ){
			var i = array[index];
			finalstring += document.getElementById("row_" + i + "_first_name").value + "$";
			finalstring += document.getElementById("row_" + i + "_last_name").value + "$";
			finalstring += document.getElementById("row_" + i + "_email").value + "$";
			finalstring += document.getElementById("row_" + i + "_phone").value + "$";
			finalstring += document.getElementById("row_" + i + "_department").value + "$";
			
			if(index==(arraylength-1)){
				finalstring += document.getElementById("row_" + i + "_role").value ;
			}else{
				finalstring += document.getElementById("row_" + i + "_role").value+ "|#|";
			}
			
		}
		
		

		//alert(finalstring);
	
		fnAddUsers(finalstring);
	}
	
	var table = document.getElementById("Table");
	var tablelength = table.rows.length;
	var arrayofids = ["_first_name", "_last_name", "_email", "_phone", "_department", "_role"]
	var newrow = tablelength;
function alertClose(){
	if (checkclose("all") ==  false ){
		
		if (containsclass(confirmbox, "hidden")== false){
					addClass(confirmbox, "hidden");
				}
		if (containsclass(errorbox, "hidden")== false){
					addClass(errorbox, "hidden");
				}
		if (containsclass(successbox, "hidden")== false){
					addClass(successbox, "hidden");
				}
		if (containsclass(closeconfirmbox, "hidden") == true){
					removeClass(closeconfirmbox, "hidden");
					
				}
	} 

	else if (checkclose('all') == "true"){
		$('#myTable').modal("toggle");
	} 
	else if (checkclose("all") == "false"){
		if (saved == true && num == numbers ){
			$('#myTable').modal("toggle");
		} else {
			if (containsclass(errorbox, "hidden")== false){
						addClass(errorbox, "hidden");
					}
			if (containsclass(confirmbox, "hidden")== false){
						addClass(confirmbox, "hidden");
					}
			if (containsclass(successbox, "hidden")== false){
						addClass(successbox, "hidden");
					}
			if (containsclass(closeconfirmbox, "hidden") == true){
						removeClass(closeconfirmbox, "hidden");
						
					}
			}
	}
}
var num = 0;
var numbers = 0;

function checkclose(inputvalue){
	if (inputvalue == 'all'){
		var process = "true";
		var arrayoffilledrows = [];
		var indexofrowwithfilledcell = "";
		//check for empty rows//
		//alert(newrow)
		for (var i = 1; i < newrow; i++ ){      //eachrow//
			for (var j = 0; j < arrayofids.length; j++){
					var idname = document.getElementById("row_" + i + arrayofids[j]); //eachcell//
						if  (idname.value !== "") {     //cell is not empty//
							indexofrowwithfilledcell = i;  
							process = "false";
							break;
						} 
			}
			if (arrayoffilledrows.indexOf(indexofrowwithfilledcell) == -1 && indexofrowwithfilledcell != "") {
					arrayoffilledrows.push(indexofrowwithfilledcell);
			} 
		}
		if (process == "true") {
			ProceSS = "true"
				
		} else if (process == "false"){
				if (showerror(arrayoffilledrows) == "true") {
					numbers = arrayoffilledrows.length;
					ProceSS = "false";
				
				} else {
					ProceSS = false;
					}
				
		}
	

	}	return ProceSS;
}

function checkempty(inputvalue){

	if (inputvalue == 'all'){
		var process = "true";
		var arrayoffilledrows = [];
		var indexofrowwithfilledcell = "";
		
		//check for empty rows//
		for (var i = 1; i < newrow; i++ ){      //eachrow//
			for (var j = 0; j < arrayofids.length; j++){
					var idname = document.getElementById("row_" + i + arrayofids[j]); //eachcell//
						if  (idname.value !== "") {     //cell is not empty//
							indexofrowwithfilledcell = i;  
							process = "false";
							break;
						}  
			} if (arrayoffilledrows.indexOf(indexofrowwithfilledcell) == -1 && indexofrowwithfilledcell != "") {
				arrayoffilledrows.push(indexofrowwithfilledcell);
		} 
		}
		if (process == "true") {
				if (containsclass(errorbox, "hidden")== false){
					addClass(errorbox, "hidden");
				}
				if (containsclass(closeconfirmbox, "hidden")== false){
					addClass(closeconfirmbox, "hidden");
				}
				if (containsclass(successbox, "hidden")== false){
					addClass(successbox, "hidden");
				}
				if (containsclass(confirmbox, "hidden") == true){
					removeClass(confirmbox, "hidden");
				}
				
			} else if (process == "false"){
				if (showerror(arrayoffilledrows) == "true") {
					if (containsclass(confirmbox, "hidden") == false){
					addClass(confirmbox, "hidden");
					}
					if (containsclass(closeconfirmbox, "hidden") == false){
					addClass(closeconfirmbox, "hidden");
					}
					
					
					if (containsclass(errorbox, "hidden")== false){
					addClass(errorbox, "hidden");
					}
				if (containsclass(successbox, "hidden")== true){
					removeClass(successbox, "hidden");
					}
					saved = true;
					
					getenteredinfo(arrayoffilledrows);
				} else {
					if (containsclass(closeconfirmbox, "hidden") == false){
					addClass(closeconfirmbox, "hidden");
					}
					if (containsclass(confirmbox, "hidden")== false){
					addClass(confirmbox, "hidden");
					}
					if (containsclass(successbox, "hidden") ==false){
					addClass(successbox, "hidden");
					}
					if (containsclass(errorbox, "hidden")== true){
					removeClass(errorbox, "hidden");
				}
				}
				
			}
	

			 //whatever number is not in the arrayof filled rows are the ones empty call a function to make sure   // 
			 var arrayofemptyrows = [];
			 
			  ;
			 for (var k = 1; k < newrow ; k++ ){
				 var notequal = "true";
				 for (var m = 0; m < arrayoffilledrows.length; m++) {
					 if ( k == arrayoffilledrows[m]) {
						 notequal = "false";
						 break;
					 } 
				 } if (notequal == "true" && 	arrayofemptyrows.indexOf(k) == -1) {
					 arrayofemptyrows.push (k)
				 }  
			 } 
				removeerror(arrayofemptyrows);
	
	}
 else {
	 var ids = checkempty1(inputvalue);
	 var anId = ids[1].id;
	 var rownum = anId.substr(7, 1);
	 if (inputvalue.value != "" && containsclass(ids[0], "hidden")== true){
		removeClass(ids[1], "hidden");
	} else if (inputvalue.value == "" && containsclass(ids[1], "hidden") == true && otherrowsvalues(rownum, inputvalue) == "false") {
		removeClass(ids[0], "hidden");
		removeClass(ids[2], "hidden");
	} else if (inputvalue.value != "" && containsclass(ids[0], "hidden") == false) {
		addClass(ids[0], "hidden");
		addClass(ids[2], "hidden");
		removeClass(ids[1], "hidden");
	} else if (otherrowsvalues(rownum, inputvalue) == "false"){
		addClass(ids[1], "hidden");
		removeClass(ids[0], "hidden");
		removeClass(ids[2], "hidden");
	} else if (otherrowsvalues(rownum, inputvalue) == "true" && inputvalue.value == "" ){
		removeerror([rownum]);
		}
		
	}
 }

function phoneemail(feed){
	var arrayofspans = checkempty1(feed);
	var anId = arrayofspans[1].id;
	var rownum = anId.substr(7, 1);
	var process = "false"
	for (var t = 1; t < newrow; t++){
		if (feed.getAttribute("id") == "row_" + t + "_email"){

			process = "true";
			break
		}
	} 	if (process == "true") {
	if (feed.value == ""){
		if (containsclass(arrayofspans[1], "hidden") == false){
				addClass(arrayofspans[1], "hidden");
			}
	 if (otherrowsvalues(rownum, feed) == "true" ){
			removeerror(rownum);
		} else if (containsclass(arrayofspans[3], "hidden")== false){
			addClass(arrayofspans[3], "hidden");
			addClass(arrayofspans[4], "hidden");
			if (containsclass(arrayofspans[2], "hidden") == true){
				removeClass(arrayofspans[0], "hidden");
				removeClass(arrayofspans[2], "hidden");
			} 
		} else{
			
			removeClass(arrayofspans[0], "hidden");
			removeClass(arrayofspans[2], "hidden");
		}
	} else if (feed.value!= "" && validateEmail(feed.value) == true){
		if (containsclass(arrayofspans[1], "hidden") == true){
				removeClass(arrayofspans[1], "hidden");
	}
} 
} else {
	var phonelength = feed.value.length;
	if (feed.value == ""){
	if (containsclass(arrayofspans[1], "hidden")== false){
				addClass(arrayofspans[1], "hidden");
			}
	 if (otherrowsvalues(rownum, feed) == "true" ){
			removeerror(rownum);
		} else if (containsclass(arrayofspans[3], "hidden")== false){
			addClass(arrayofspans[3], "hidden");
			addClass(arrayofspans[4], "hidden");
			if (containsclass(arrayofspans[2], "hidden")== true){
				removeClass(arrayofspans[0], "hidden");
				removeClass(arrayofspans[2], "hidden");
			} 
		} else{
			
				removeClass(arrayofspans[0], "hidden");
				removeClass(arrayofspans[2], "hidden");
		}
	} else 
	{if ( phonelength == 10 && containsclass(arrayofspans[3], "hidden")== true){
	 if (containsclass(arrayofspans[7], "hidden")==false){
			addClass(arrayofspans[7], "hidden");
			addClass(arrayofspans[8], "hidden");
		}
		if (containsclass(arrayofspans[1], "hidden") == true){
				removeClass(arrayofspans[1], "hidden");
				
	}}

	else if (phonelength < 10){
		if (containsclass(arrayofspans[3], "hidden")== false){
			if (containsclass(arrayofspans[2], "hidden") == false){
				addClass(arrayofspans[0], "hidden");
				addClass(arrayofspans[2], "hidden");
			} if (containsclass(arrayofspans[1], "hidden") == false){
				addClass(arrayofspans[1], "hidden");
			}
		} 
		else if (containsclass(arrayofspans[7], "hidden")== true){
				if (containsclass(arrayofspans[1], "hidden")== false){
					addClass(arrayofspans[1], "hidden");
				}
				removeClass(arrayofspans[7], "hidden");
				removeClass(arrayofspans[8], "hidden");
			}
	}
	
	
	} 
}
}

function otherrowsvalues(rownum, inputvalue){
	moveonwitherror = "true";
	for (var h = 0; h <6; h++){
			var otherrows = "row_" + rownum + arrayofids[h];
			if (otherrows != inputvalue.getAttribute("id")){
				if (document.getElementById(otherrows).value != "") {
						moveonwitherror = "false";
						return moveonwitherror;
				
			}
}
} 
return moveonwitherror;
}
 

function alertinput(feed){
	if (feed.value == "no"){
		var classname = feed.parentNode.parentNode.className;
		feed.parentNode.parentNode.className = classname + " " + "hidden";
		
	} else{
		$('#myTable').modal("toggle");
	}
}

function checkempty1(inputname){
	 var idresults = [];
	 var inputparent = inputname.parentNode;
	 var inputprtid = inputparent.getAttribute("id");
	 var getspecspan = document.getElementById(inputprtid).getElementsByTagName("span");
	 var id1 = getspecspan[0];
	 idresults.push(id1);
	 var id2 = getspecspan[1];
	 idresults.push(id2);
	 var id3name = inputname.getAttribute("id") + "_error";
	 var id3 = document.getElementById(id3name);

	idresults.push(id3);
	if (getspecspan.length == 3){
		var id4 = getspecspan[2];
		idresults.push(id4);
		var id5name = inputname.getAttribute("id") + "_warning";
		var id5 = document.getElementById(id5name);
		idresults.push(id5);
	}
	if (getspecspan.length == 5){
		var id4 = getspecspan[2];
		idresults.push(id4);
		var id5name = inputname.getAttribute("id") + "_warning";
		var id5 = document.getElementById(id5name);
		idresults.push(id5);
		var id6 = getspecspan[3];
		idresults.push(id6);
		var id7name = inputname.getAttribute("id") + "_warningmore";
		var id7 = document.getElementById(id7name);
		idresults.push(id7);
		var id8 = getspecspan[4];
		idresults.push(id8);
		
		var id9name = inputname.getAttribute("id") + "_warningless";
		var id9 = document.getElementById(id9name);
		idresults.push(id9);
		 }
	 return idresults;
}	
	function showerror(array){
		//check empty cells in each filled row//
		var emptycells = "true";
		for (var i = 0; i < array.length; i++) {
			for (var j = 0; j < arrayofids.length; j++){
				var idName = "row_" + array[i] + arrayofids[j];
				var idname = document.getElementById(idName);
				var inputparent = idname.parentNode;
				var inputprtid = inputparent.getAttribute("id");
				var getspecspan = document.getElementById(inputprtid).getElementsByTagName("span");
				var showerror = document.getElementById(getspecspan[0].id);	
				var erroridname = idName + "_error"; 
				var showerrormsg = document.getElementById(erroridname);
				var showok = document.getElementById(getspecspan[1].id);	
					if ( idname.value == "" ){  //check if cell is empty//
							
						emptycells = "false";
													
						
						if 	(containsclass(showerror, "hidden")== true) {
							removeClass (showerror, "hidden");
							removeClass(showerrormsg, "hidden");
							if (containsclass(showok, "hidden") == false) {
								addClass (showok, "hidden");
							}
							
						}
							//show error//
							
					} else if(j == 2){
						 if (validateEmail(idname.value) == false){
							
							emptycells = "false";
					}}
						else if(j == 3){
						if (validatePhone == false){
							emptycells = "false";
						}
					}
				else {
						
						
						if 	(containsclass(showok, "hidden")== true) {
							removeClass (showok, "hidden");
							
							if (containsclass(showerror, "hidden") == false) {
								addClass (showerror, "hidden");
								addClass(showerrormsg,"hidden");
							}
					//show ok//
				}	
				
					}	
					}	
		
		
		}
		return emptycells;
}  



function removeerror(where){
	if (where == "[object HTMLInputElement]") {
			var anId = where.getAttribute("id");
			var rownum = anId.substr(4, 1);
			
			if (otherrowsvalues(rownum, where) == "true" && where.value == "" ){
				removeerror([rownum]);
	}

		else {
	var inputparent = where.parentNode;
	var inputprtid = inputparent.getAttribute("id");
	var getspecspan = document.getElementById(inputprtid).getElementsByTagName("span");
	var showerror = document.getElementById(getspecspan[0].id);	
	var erroridname = where.getAttribute("id")+ "_error"; 
	var showerrormsg = document.getElementById(erroridname);	
	 if (containsclass(showerror, "hidden") == false && containsclass(showerrormsg, "hidden") == false){
		addClass (showerror, "hidden");
		addClass(showerrormsg, "hidden") ;
	 }
	} }else if (where.constructor === Array) {
		for (var i = 0; i < where.length; i++) {
				for (var j = 0; j < arrayofids.length; j++){
					var idName = "row_" + where[i] + arrayofids[j];
					var idname = document.getElementById(idName);
					var inputparent = idname.parentNode;
					var inputprtid = inputparent.getAttribute("id");
					var getspecspan = document.getElementById(inputprtid).getElementsByTagName("span");
					var showerror = document.getElementById(getspecspan[0].id);	
					var erroridname = idName + "_error"; 
					var showerrormsg = document.getElementById(erroridname);	
					var showok = document.getElementById(getspecspan[1].id);		
					var warningidname = idName + "_warning";
					var showwarnmsg = document.getElementById(warningidname);
					
					if 	(containsclass(showerror, "hidden")== false) {
							addClass (showerror, "hidden");
							addClass(showerrormsg, "hidden");
								
					} if (containsclass(showok, "hidden") == false) {
							addClass (showok, "hidden");
								
					} 
				}
		}
	}else {
	
				var idName = "row_" + where + "_email";		
				var idname = document.getElementById(idName);
				var inputparent = idname.parentNode;
				var inputprtid = inputparent.getAttribute("id");
				var getspespan = document.getElementById(inputprtid).getElementsByTagName("span");
				var showerror = document.getElementById(getspespan[0].id);	
				var erroridname = idName + "_error"; 
				var showerrormsg = document.getElementById(erroridname);	
				var showok = document.getElementById(getspespan[1].id);	
							
				var showwarn = document.getElementById(getspespan[2].id);
				var warningidname = idName + "_warning";
				var showwarnmsg = document.getElementById(warningidname);
				
				if 	(containsclass(showerror, "hidden")== false) {
							addClass (showerror, "hidden");
						addClass(showerrormsg, "hidden");
							
						} if (containsclass(showok, "hidden")== false) {
							addClass (showok, "hidden");
							
			} if (containsclass(showwarn, "hidden") ==false) {
							addClass(showwarn, "hidden");
							addClass(showwarnmsg, "hidden");
			} removeerror([where]);
	}
}



function emailvalidate(email){
	var arrayofspans = checkempty1(email);
	var anId = arrayofspans[1].id;
	var rownum = anId.substr(7, 1);
	if (email.value == ""){
	 if (otherrowsvalues(rownum, email) == "true" ){
			removeerror(rownum);
		}
		
	}
		else if(validateEmail(email.value) != true ){
			
			
			if (containsclass(arrayofspans[3],"hidden")== true){
				removeClass(arrayofspans[3], "hidden");
				removeClass(arrayofspans[4], "hidden");
				//continue from here
			} if (containsclass(arrayofspans[1] , "hidden") == false){
				addClass(arrayofspans[1], "hidden");
			} if (containsclass(arrayofspans[0], "hidden")== false){
				addClass(arrayofspans[0], "hidden");
				addClass(arrayofspans[2], "hidden");
		
		}} else if (containsclass(arrayofspans[3], "hidden")== false){
			addClass(arrayofspans[3], "hidden");
			addClass(arrayofspans[4], "hidden");
			
		}

}
function addhidden(){
num = 0;
newrow = 6;
//alert(table.rows.length);
if (table.rows.length > 6){
	table.deleteRow(-1);
	
	return addhidden();
	
	
	
}
		
		


var getallelems = document.getElementById("Container").getElementsByClassName("erase");	
var getallinputs = document.getElementById("Container").getElementsByTagName("input");	

for ( var i = 0; i < getallelems.length; i++){
	if (containsclass(getallelems[i], "hidden") == false){
		addClass(getallelems[i], "hidden");
	}
}
for ( var i = 0; i < getallinputs.length; i++){
	if (getallinputs[i].value != ""){
		getallinputs[i].value = "";
	}
}
}
function removeError(where){
				var idName = "row_" + where + "_phone";		
				var idname = document.getElementById(idName);
				var inputparent = idname.parentNode;
				var inputprtid = inputparent.getAttribute("id");
				var getspespan = document.getElementById(inputprtid).getElementsByTagName("span");
				var showerror = document.getElementById(getspespan[0].id);	
				var erroridname = idName + "_error"; 
				var showerrormsg = document.getElementById(erroridname);	
				var showok = document.getElementById(getspespan[1].id);	
							
				
				var showwarn = document.getElementById(getspespan[2].id);
				var warningidname = idName + "_warning";
				var showwarnmsg = document.getElementById(warningidname);
				
				var showwarnmore = document.getElementById(getspespan[3].id);
				var warningmoreidname = idName + "_warningmore";
				var showwarnmoremsg = document.getElementById(warningmoreidname);
				
				var showwarnless = document.getElementById(getspespan[4].id);
				var warninglessidname = idName + "_warningless";
				var showwarnlessmsg = document.getElementById(warninglessidname);
				
				if 	(containsclass(showerror, "hidden")== false) {
							addClass (showerror, "hidden");
							addClass(showerrormsg, "hidden");
							
				} if (containsclass(showok, "hidden")== false) {
							addClass (showok, "hidden");
							
				} if (containsclass(showwarn, "hidden")== false) {
							addClass (showwarn, "hidden");
							addClass(showwarnmsg, "hidden");
				} if (containsclass(showwarnmore, "hidden") == false) {
							addClass (showwarnmore, "hidden");
							addClass(showwarnmsgmore, "hidden");
				} if (containsclass(showwarnless, "hidden")== false) {
							addClass (showwarnless, "hidden");
							addClass(showwarnlessmsg, "hidden");
				} removeerror([where]);
	
}
function phonevalidate(phone){
	var val = phone.value;
	var res = isNaN(val);
	var arrayofspans = checkempty1(phone);
	var anId = arrayofspans[1].id;
	var rownum = anId.substr(7, 1);
	if (phone.value == ""){
	 if (otherrowsvalues(rownum, phone) == "true" ){
			removeError(rownum);
		}
		
	}
	if (res == true) {
			if (containsclass(arrayofspans[6], "hidden")== false){
				addClass(arrayofspans[5], "hidden");
				addClass(arrayofspans[6], "hidden");
			} if (containsclass(arrayofspans[7], "hidden")== false){
					addClass(arrayofspans[7], "hidden");
					addClass(arrayofspans[8], "hidden");
			}  if (containsclass(arrayofspans[0],"hidden")== false){
					addClass(arrayofspans[0], "hidden");
					addClass(arrayofspans[2], "hidden");
			} if (containsclass(arrayofspans[1], "hidden")){
					addClass(arrayofspans[1], "hidden");
					
			} 
			if (containsclass(arrayofspans[3], "hidden")== true){
				removeClass(arrayofspans[3], "hidden");
				removeClass(arrayofspans[4], "hidden");
			} 
	} else {
			if (containsclass(arrayofspans[3], "hidden")== false){
				addClass(arrayofspans[3], "hidden");
				addClass(arrayofspans[4], "hidden");
		} 		if (containsclass(arrayofspans[6], "hidden")== false){
				addClass(arrayofspans[5], "hidden");
				addClass(arrayofspans[6], "hidden");
				
		}  if (containsclass(arrayofspans[0], "hidden")== false){
				addClass(arrayofspans[0], "hidden");
				addClass(arrayofspans[2], "hidden");
				
		} 
		
	} 	if (res == false) {
		if (val.length > 10){
			if (containsclass(arrayofspans[1], "hidden")== false){
				addClass(arrayofspans[1], "hidden");
				
		}  if (containsclass(arrayofspans[7], "hidden")== false){
				addClass(arrayofspans[7], "hidden");
				addClass(arrayofspans[8], "hidden");
				
			}
			if (containsclass(arrayofspans[6], "hidden")== true){
				removeClass(arrayofspans[5], "hidden");
				removeClass(arrayofspans[6], "hidden");
		
	}	
	} else if(val.length == 10 || val.length == 0){
		 if (containsclass(arrayofspans[7], "hidden") == false){
				addClass(arrayofspans[7], "hidden");
				addClass(arrayofspans[8], "hidden");
			}
	}
	}
}

function validatePhone(phone){
	if (isNaN(phone.value) == false && phone.value.length == 10){
		return true;
	}
	else {
		return false;
	}
}
 function addnewrows() {
	 var appendString = "<tr>";
  
	 var colNum;
		//totalColumns is the total number of <td>
		for(colNum = 0; colNum <6; colNum++){  	
			if (colNum != 2 && colNum != 3) {
				
		  appendString += '<td> <div id = "row_' + newrow + arrayofids[colNum] + '_div" class = "has-feedback form-group"> <input type = "text" class = "form-control" id = "row_' + newrow + arrayofids[colNum] + '" onkeyup = "removeerror(this)" onblur = "checkempty(this)"/> <span id = "spanerror_' + newrow + arrayofids[colNum] + '"  class = "glyphicon glyphicon-exclamation-sign form-control-feedback hidden"></span> <span id = "spanok_' + newrow + arrayofids[colNum] + '"class="glyphicon glyphicon-ok form-control-feedback hidden"></span></div> <div  id = "row_' + newrow + arrayofids[colNum] + '_error" class="alert alert-danger hidden"> <strong>Error:</strong> Please fill this box.	</div>  </td>'
		}
		else if (colNum == 2){
	 
	 appendString += '<td> <div id = "row_' + newrow + arrayofids[colNum] + '_div" class = "has-feedback form-group"> <input type = "text" class = "form-control" id = "row_' + newrow + arrayofids[colNum] + '" onblur = "phoneemail(this)" onkeyup = "emailvalidate(this)"/> <span id = "spanerror_' + newrow + arrayofids[colNum] + '"' + '  class = "glyphicon glyphicon-exclamation-sign form-control-feedback hidden"></span> <span id = "spanok_' + newrow + arrayofids[colNum] + '" ' + 'class="glyphicon glyphicon-ok form-control-feedback hidden"></span> <span id = "spanwarn_' + newrow + arrayofids[colNum] + '" class = "glyphicon glyphicon-warning-sign form-control-feedback hidden"></span> </div> <div  id = "row_' + newrow + arrayofids[colNum] + '_error" class="alert alert-danger hidden"> <strong>Error:</strong> Please fill this box.	</div>  <div  id = "row_' + newrow + arrayofids[colNum] + '_warning" class="alert alert-warning hidden"> Invalid Email </div>  </td>'
		}
	 else if (colNum == 3){
	 
	 appendString += '<td> <div id = "row_' + newrow + arrayofids[colNum] + '_div" class = "has-feedback form-group"> <input type = "text" class = "form-control" id = "row_' + newrow + arrayofids[colNum] + '" onblur = "phoneemail(this)" onkeyup = "phonevalidate(this)"/> <span id = "spanerror_' + newrow + arrayofids[colNum] + '" ' + ' class = "glyphicon glyphicon-exclamation-sign form-control-feedback hidden"></span> <span id = "spanok_' + newrow + arrayofids[colNum] + '"' + 'class="glyphicon glyphicon-ok form-control-feedback hidden"></span> <span id = "spanwarn_' + newrow + 
	 arrayofids[colNum] + '" class = "glyphicon glyphicon-warning-sign form-control-feedback hidden"></span> <span id = "spanwarnmore_' + newrow + arrayofids[colNum] + '"' + ' class = "glyphicon glyphicon-warning-sign form-control-feedback hidden"></span> <span id = "spanwarnless_' + newrow + arrayofids[colNum] + '" ' + 'class = "glyphicon glyphicon-warning-sign form-control-feedback hidden"></span></div> <div  id = "row_' + newrow + arrayofids[colNum] + '_error" ' + 'class="alert alert-danger hidden"> <strong>Error:</strong> Please fill this box.	</div> <div id = "row_' + newrow + arrayofids[colNum] + '_warning" class = "alert alert-warning hidden"> <strong>Error:</strong> Only numbers, please. </div> <div id = "row_' + newrow +  arrayofids[colNum] + '_warningmore" class = "alert alert-warning hidden"> Phone number exceeds normal. </div> <div id = "row_' + newrow +  arrayofids[colNum] + '_warningless" class = "alert alert-warning hidden"> Invalid phone format. Length is less than normal. </div> </td>'
	
       
		}
		
								
			
 }     
 		appendString += "</tr>";
		
		var tableId = "Table";
		$("#"+ tableId + " > tbody:last").append(appendString); 
		newrow += 1;
 }	

	function fnAddUsers(finalstring){
		var action = baseURL + "/learners/addLearners";
	    var form_data = {
	      'learner_list': finalstring	   
	    };

	    $.ajax({
	      	type: "POST",
	      	url: action,
	      	data: form_data,
	      	success: function(response)
	      	{		
	      		

	      		var responseObj = $.parseJSON(response);
	      		//alert("From database - Successful Entries = "+responseObj.successful);
	      		num = num + responseObj.successful;

	      		var display_string = "Your changes have been saved.</br>"
				display_string += responseObj.successful + " - Learners added successfully.</br>";
				display_string += responseObj.duplicates + " - Duplicate Entries. Not added to system.";
				$('#SuccessBox > .panel-body').html(display_string);	
				//alert (num)
	      		
	      			
	      	}
	    });
	}
function containsclass(htmlelement, classname ) {
     if ((" " + htmlelement.className + " " ).indexOf( " "+classname+ " " ) > -1){
		 return true;
	 } else{
		 return false;
	 }
}

function addClass(htmlelement, classname){
	var nameofclass = htmlelement.className;
	htmlelement.className = nameofclass + " " + classname;
	
}

function removeClass(htmlelement, classname){
	var nameofclass = htmlelement.className;
	htmlelement.className = nameofclass.replace(classname, "");

}

function validateEmail(email) { 
	var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	
	return re.test(email);
} 

function refreshPage(){
	window.location.reload(true);
}

function search(feed){
		$('input, textarea').placeholder();
		var usertable = document.getElementById("users_table");
		var usertablelength =  usertable.rows.length;
		var columnnum = document.getElementById("search_by_drop").value;
		
		
		//alert($("#search_by_drop").val())
	    var searchValue = feed.value.toLowerCase();
		for (var i = 1; i < usertablelength; i++){
			var rowinfo = ""
			rowinfo = usertable.rows.item(i).cells.item(columnnum).innerText.toLowerCase();
			//alert (rowinfo)
		 if (rowinfo.search(searchValue) == -1){
            usertable.rows.item(i).style.display = 'none';
		 }
        else{
            usertable.rows.item(i).style.display = 'table-row';
		}
		
		}
		
}
	    

//Live search function for the All Users List
$("#search").on("keyup", function() {
	//alert($("#search_by_drop").val())
    var value = $(this).val().toLowerCase();
    $("#users_table tr").each(function(index) {
        if (index !== 0) {
            $row = $(this);	
            //Checks the value of the field drop down. Values are actually column number
            var filter_row = $("#search_by_drop").val();
            var id = $row.find("td:nth-child(" + filter_row + ")").text().toLowerCase();
            if (id.indexOf(value) < 0) {
                $row.hide();
            }
            else {
                $row.show();
            }
        }
    });
});

