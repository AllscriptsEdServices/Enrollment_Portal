<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscription_Model extends CI_Model {    

	public function __construct()
    {
        parent::__construct();            
    }

    /*
        subscription -> status = active, terminated, completed

    */

    public function get_learner_subscriptions($learner_id){
        $this->db->from("tb_subscriptions");
        $where_clause = "learner_id='".$learner_id."' AND (status='active' OR status='completed') ";
        $this->db->where($where_clause);
        $query = $this->db->get();
        
        return $query->result_array();       
    }


    //$course_string = "[course_id]$[sub/unsub]$[daily/all]#[course_id]$[sub/unsub]$[daily/all]#[course_id]$[sub/unsub]$[daily/all]"
    public function process_subscriptions($learner_id, $courses_string){
        $return_array = array("status"=>NULL, "message"=>"", "user_id"=>0);
        $status_array = array();

        $courses_array = explode("#", $courses_string);

        foreach ($courses_array as $course) {
            $course_attributes = explode("$", $course);
            /* Structure of the just created $course_attributes array  
            $course_attributes[0] = course_id
            $course_attributes[1] = action i.e. subscribe/unsubscribe
            $course_attributes[2] = schedule i.e. daily/all     */

            //array_push($status_array, $course_attributes);
            if($course_attributes[1] == "subscribe"){
                array_push($status_array, $this->add_subscription($learner_id, $course_attributes));
            }else{
                array_push($status_array, $this->terminate_subscription($learner_id, $course_attributes));                
            }
            
        }             
        
        return $status_array;
    }


    public function add_subscription($learner_id, $sub_attributes){

        $subscription_details = $this->check_subscription_status($learner_id, $sub_attributes[0]);
        
        if($subscription_details == 0 || $subscription_details["status"] == "terminated"){
            
            $insert_array = array(
                            "learner_id" => $learner_id,
                            "course_id" => $sub_attributes[0],
                            "schedule" => $sub_attributes[2],
                            "start_date" => date("Y-m-d"),
                            "status" => "active",
                            "last_sent_topic_id" => 0
                        );
            $this->db->insert("tb_subscriptions", $insert_array);

            return array("course_id"=> $sub_attributes[0],  "action_taken"=>"subscribe");

        }else if( ($subscription_details["status"] == "active") && ($subscription_details["schedule"]!= $sub_attributes[2]) ){

            $this->db->where('sub_id', $subscription_details["sub_id"]);
            $this->db->update('tb_subscriptions', array('schedule' => $sub_attributes[2]) );

            return array("course_id"=> $sub_attributes[0],  "action_taken"=>"schedule");

        }else{

            return array("course_id"=> $sub_attributes[0],  "action_taken"=>"no_action");

        }

    }


    public function terminate_subscription($learner_id, $sub_attributes){

        $subscription_details = $this->check_subscription_status($learner_id, $sub_attributes[0]);
        
        if($subscription_details["status"] == "active"){

            $this->db->where('sub_id', $subscription_details["sub_id"]);
            $this->db->update('tb_subscriptions', array('status' => "terminated", "end_date"=>date("Y-m-d")) );          

            return array("course_id"=> $sub_attributes[0],  "action_taken"=>"unsubscribe");

        }else{

            return array("course_id"=> $sub_attributes[0],  "action_taken"=>"no_action");

        }

    }




    public function check_subscription_status($learner_id, $course_id){
        //Making sure only the last entered subscription record is selected. This is to offset the scenario of multiple times subscribed, then terminated kind of records
        $this->db->order_by("sub_id", "desc");
        $this->db->limit(1);
        $query = $this->db->get_where("tb_subscriptions", array("learner_id"=>$learner_id, "course_id"=>$course_id ));
        if($query->num_rows() > 0){
            return $query->row_array();
        }else{
            return 0;
        }

    }


    public function update_last_sent_topic($sub_id, $last_sent_topic_id){
        $this->db->where('sub_id', $sub_id);
        $this->db->update('tb_subscriptions', array('last_sent_topic_id' => $last_sent_topic_id) );
    }


    public function mark_subscription_complete($sub_id){
        $this->db->where('sub_id', $sub_id);
        $this->db->update('tb_subscriptions', array('status' => "completed", "end_date"=>date("Y-m-d")) );
    }


    public function get_active_learners($timezone){
        $this->db->select("tb_subscriptions.sub_id, tb_subscriptions.learner_id, tb_subscriptions.course_id, tb_subscriptions.schedule, tb_subscriptions.last_sent_topic_id");
        $this->db->from('tb_subscriptions'); 
        $this->db->join('tb_learners', 'tb_learners.learner_id = tb_subscriptions.learner_id'); 
        $this->db->where(array("tb_learners.timezone" =>$timezone, "tb_subscriptions.status"=>"active")); 
        $this->db->order_by("learner_id", "asc"); 
        //$this->db->group_by("learner_id"); 
        $query = $this->db->get();

        return $query->result_array();
    }

    
    
}

/* End of file subscription_model.php */
/* Location: ./application/models/subscription_model.php */