<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Analytics_Model extends CI_Model {    

	public function __construct()
    {
        parent::__construct();            
    }


    public function get_courses_for_home($learner_id=false){
        $this->db->select("course_id, course_title, course_description, COUNT(tb_topics.parent_id) as total_days");
        $this->db->from('tb_courses'); 
        $this->db->join('tb_topics', 'tb_topics.parent_id = tb_courses.course_id'); 
        $this->db->where(array("tb_topics.status"=>1, "tb_courses.status"=>1));        
        $this->db->group_by("course_id");
        $this->db->order_by("course_title", "asc");
        $query = $this->db->get();
        
        $all_courses = $query->result_array();

        if($learner_id != false){
            foreach ($all_courses as $key => $value) {
                $all_courses[$key]["sub_status"] = $this->subscription_model->check_subscription_status($learner_id, $all_courses[$key]["course_id"]);
            }
        }
        

        
        return $all_courses;

        

        /*$this->db->select("category_title");
        $this->db->select('programs.programName');
        $this->db->from('enrollments'); 
        $this->db->join('programs', 'programs.programId = enrollments.programId');      
        $where_clause = "(enrollments.requestId=$requestId) AND (programs.product=".$cm_product_id." OR programs.product=".$homecare_product_id.") ";
        $this->db->where($where_clause);   

        $this->db->select('programs.programName');
        $this->db->from('enrollments');      
        $this->db->join('programs', 'programs.programId = enrollments.programId');   
        $this->db->join('requests', 'requests.requestId = enrollments.requestId');
        $this->db->where('learnerId', $learnerId); 
        $this->db->where('requests.submission_status', 1); */

    }



    public function get_course_details($course_id){
        $this->db->select("course_id, course_title, course_description, COUNT(tb_topics.parent_id) as total_days");
        $this->db->from('tb_courses'); 
        $this->db->join('tb_topics', 'tb_topics.parent_id = tb_courses.course_id');
        $this->db->where(array("tb_topics.status"=>1, "tb_courses.status"=>1, "tb_courses.course_id"=>$course_id));        
        $this->db->group_by("course_id");        
        $query = $this->db->get();
        
        return $query->row_array();
    }

    


    public function get_next_topic($course_id, $last_sent_topic_id){
        $return_array = array("topic_details"=>NULL, "is_last_topic" => FALSE );
        
        if($last_sent_topic_id != 0){
            $this->db->select("topic_id, parent_id, sequence");
            $query = $this->db->get_where("tb_topics", array("topic_id"=>$last_sent_topic_id) );        
            $result_array = $query->row_array();

            
            $this->db->where(array("parent_id"=>$course_id, "sequence >"=>$result_array["sequence"], "status"=>1 ) );   
        }else{
            $this->db->where(array("parent_id"=>$course_id, "status"=>1 ) );   
        }
        
        
        $this->db->from("tb_topics");
        $this->db->order_by("sequence", "asc");
        $query_2 = $this->db->get();

        $return_array["is_last_topic"] = ($query_2->num_rows() == 1) ? TRUE:FALSE;

        $return_array["topic_details"] = $query_2->row_array();

        return $return_array;
    }



    	
}

/* End of file course_model.php */
/* Location: ./application/models/course_model.php */