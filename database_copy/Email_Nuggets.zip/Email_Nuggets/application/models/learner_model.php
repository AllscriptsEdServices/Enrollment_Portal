<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Learner_Model extends CI_Model {

	public function __construct()
    	{
            parent::__construct();
    	}


    	public function sign_up_learner($input_details)
    	{
    		$return_array = array("status"=>NULL, "message"=>"", "learner_id"=>0);
    		$query = $this->db->get_where("tb_learners", array("email" => $input_details["email"]));
    		if($query->num_rows() > 0)
    		{
    			$return_array["status"] = "FAIL";
    			$return_array["message"] = "This email is already registered in the system.";
    		}
    		else
    		{
    			$insert_array = array(
                                    "first_name" => $input_details["first_name"],
                                    "last_name" => $input_details["last_name"],
    								"email" => $input_details["email"],
    								"password" => md5($input_details["password"]),
                                    "timezone" => $input_details["timezone"],
    								"joined_date" => date("Y-m-d"),
                                    "last_login" => date("Y-m-d")
    									);
    			$this->db->insert("tb_learners", $insert_array);

    			$return_array["status"] = "SUCCESS";
    			$return_array["learner_id"] = $this->db->insert_id();

                $insert_array["learner_id"] = $this->db->insert_id();                
                $this->set_user_session($insert_array);

    		}

    		return $return_array;

    	}



    	public function do_login($email, $password)
    	{
    		$return_array = array("status" => NULL, "learner_id" => 0, "message" => "" );

    		$query = $this->db->get_where("tb_learners", array("email" => $email));
    		if($query->num_rows() > 0)
    		{
    			$user_details = $query->row_array();

    			if( md5($password) == $user_details["password"] ) 
    			{
    				$return_array["status"] = "SUCCESS";    				
    				$return_array["learner_id"] = $user_details["learner_id"];
    				$this->set_user_session($user_details);
    			}
    			else
    			{
    				$return_array["status"] = "FAIL";
    				$return_array["message"] = "The password entered is incorrect.";
    			}

    		}
    		else{
    			$return_array["status"] = "FAIL";
    			$return_array["message"] = "This email is not registered.";
    		}

    		return $return_array;
    	}


    	public function set_user_session($user_details)
    	{
    		$user_data = array(
                   'learner_id'  => $user_details["learner_id"],
                   'first_name'  => $user_details["first_name"],
                   'last_name'  => $user_details["last_name"],
                   'email'  => $user_details["email"],
                   'timezone'  => $user_details["timezone"],
                   'joined_date'  => $user_details["joined_date"],
                   'last_login'  => $user_details["last_login"]                   
            );

			$this->session->set_userdata("logged_in_user", $user_data);
    	}



    	public function get_current_user()
    	{
    		$return_array = array("active" => 1, "user_data" => array());

    		if ($this->session->userdata('logged_in_user') !== FALSE) 
    		{

    			$return_array["user_data"] = $this->session->userdata('logged_in_user');
    		}
    		else
    		{
    			$return_array["active"] = 0;
    		}
    		
    		return $return_array;

    	}


    	public function change_password($learner_id, $old_password, $new_password)
    	{
    		$return_array = array("status" => NULL, "message" => "");
    		$this->db->from("tb_learners");
    		$this->db->select("password, learner_id");
    		$this->db->where("learner_id", $learner_id);
    		$query = $this->db->get();
    		
    		$user_details = $query->row_array();

    		if( md5($old_password) == $user_details["password"])
    		{
    			$this->db->where('learner_id', $learner_id);
				$this->db->update('tb_learners', array("password" => md5($new_password) ) );
				$return_array["status"] = "SUCCESS";
    		}
    		else{
    			$return_array["status"] = "FAIL";
    			$return_array["message"] = "Old Password does not match our records.";
    		}

    		return $return_array;
    	}



        public function reset_password($email){
            $return_array = array("status" => NULL,  "message" => "" );
            $default_password = "Welcome123";
            
            $this->db->from("tb_learners");
            //$this->db->select("learner_id");
            $this->db->where("email", $email);
            $query = $this->db->get();

            if($query->num_rows() > 0)
            {
                $user_details = $query->row_array();
                $this->db->where('learner_id', $user_details["learner_id"]);
                $this->db->update('tb_learners', array("password" => md5($default_password) ) );
                $return_array["status"] = "SUCCESS";
                $return_array["message"] = "The password has been emailed to you.";
                $this->send_reset_mail($user_details, $default_password);
            }
            else{
                $return_array["status"] = "FAIL";
                $return_array["message"] = "This email is not registered.";
            }

            

            return $return_array;
        }


        public function send_reset_mail($user_details, $password){

            $message_body = '<html><body style="background: #d9dadc; margin:0px; font-family:Arial; font-size:16px;"><table style="background: #d9dadc; width:100%; padding:20px; "><tr><td style="background-color:#0098cc; width:100%; padding:5px 15px; height:52px; color:#fff; font-size:24px; font-family:Arial;"><strong>Video Library</strong></td></tr><tr><td style="background: #FFFFFF; width:100%; padding:10px"><table><tr><td style="padding:0px;color:#000000; font-family:Arial; font-size:16px;"><p>Hi,</p><p>Your password reset request has been processed, and your temporary password is as below.</p></td></tr><tr><td style="font-size:16px; padding:0px;color:#000000;"><table style="padding:0px; border-top:1px solid #DDDDDD; border-right:1px solid #DDDDDD" cellpadding="0" cellspacing="0"><tr><td style="padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD;text-align: center; font-size:18px; font-family:Arial;" colspan="2">Password Reset</td></tr><tr><td style="padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD; font-family:Arial; font-size:16px;">Login Name</td><td style="padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD; font-family:Arial; font-size:16px;">'.$user_details["email"].'</td></tr><tr><td style="padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD; font-family:Arial; font-size:16px;">Temporary Password</td><td style="padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD; font-family:Arial; font-size:16px;">'.$password.'</td></tr></table></td></tr><tr><td style="padding:0px; color:#000; font-family:Arial; font-size:16px;"> <br> <p><b>Note: </b>It is strongly advised that you change your password upon logging in the first time.</p><p>For any issues you face using these details, you can contact <a href="mailto:university@capgemini.com">support</a>.</p></td></tr></table></td></tr></table></body></html>';

            $subject = 'Video Library - Password Reset';
            
            $headers = "From: university@capgemini.com\r\n";
            $headers .= "Reply-To: university@capgemini.com\r\n";
            $headers .= "Bcc: vishwajit.menon@capgemini.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

            $to = $user_details["email"];
            //$to = 'vishwajit.menon@capgemini.com';    //To test the email and format

            mail($to, $subject, $message_body, $headers);

            
        }


    	public function destroy_current_session()
    	{
			$this->session->unset_userdata("logged_in_user");
			$this->session->sess_destroy();
    	}


        public function get_learner_details($learner_id){            
            $query = $this->db->get_where("tb_learners", array("learner_id" => $learner_id));
            if($query->num_rows()>0){
                return $query->row_array();
            }else{
                return 0;
            }
        }
    	
}

/* End of file learner_model.php */
/* Location: ./application/models/learner_model.php */