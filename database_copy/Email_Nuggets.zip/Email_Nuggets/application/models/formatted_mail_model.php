<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Formatted_Mail_Model extends CI_Model {

    public $email_body = '<table style="width:100%">';  
    public $email_to = '';
    public $email_subject = 'Uni One Mail';
    public $email_salutation_name = '';
    public $learner_id = 0;

	public function __construct()
    	{
            parent::__construct();
    	}


    public function process_scheduled_mail($learner_array){
        $return_array = array();
        $this->email_body = '<table style="width:100%">'; 

        $learner_details = $this->learner_model->get_learner_details($learner_array[0]["learner_id"]);

        $this->learner_id = $learner_details["learner_id"];
        $this->email_salutation_name = $learner_details["first_name"]." ".$learner_details["last_name"];
        $this->email_to = $learner_details["email"];
        //array_push($return_array, $learner_details);

        foreach ($learner_array as $single_sub) {
            $course_array = $this->course_model->get_course_details($single_sub["course_id"]);
            $topic_array = $this->course_model->get_next_topic($single_sub["course_id"], $single_sub["last_sent_topic_id"]);
            
            $this->build_course_block($course_array, $topic_array["topic_details"], $single_sub["schedule"], $topic_array["is_last_topic"]);

            if($topic_array["is_last_topic"] || $single_sub["schedule"]=="all"){
                $this->subscription_model->mark_subscription_complete($single_sub["sub_id"]);
            }else{
                $this->subscription_model->update_last_sent_topic($single_sub["sub_id"], $topic_array["topic_details"]["topic_id"]);
            }
        }

        $this->email_body .= '</table>';

        $this->send_scheduled_mail();
        //return $return_array;
        
        return $this->email_body;
    }


    public function build_course_block($course_details, $topic_details, $schedule, $add_feedback=false){
        if($schedule == "daily"){
            $link_identifier = "topic00aa00" . $topic_details["topic_id"]."00aa00" . $this->learner_id . "aa00aa". $topic_details["topic_source"];
            $tracking_url = base_url("index.php"). "/link/". $link_identifier;

            $this->email_body .= '<tr><td></td></tr>';
            $this->email_body .= '<tr><td><h2>'.$course_details["course_title"].'</h2></td></tr>';        
            $this->email_body .= '<tr><td><a href="'.$tracking_url.'">'.$topic_details["topic_title"].'</a></td></tr>';
            $this->email_body .= '<tr><td>'.$topic_details["topic_description"].'</td></tr>';
        }else if($schedule == "all"){
            $all_topics_pdf_url = base_url("index.php"). "/export/all_topics_pdf/". $course_details["course_id"];
            $this->email_body .= '<tr><td></td></tr>';
            $this->email_body .= '<tr><td><h2>'.$course_details["course_title"].'</h2></td></tr>';
            $this->email_body .= '<tr><td>'.$topic_details["topic_description"].'</td></tr>';
            $this->email_body .= '<tr><td><a href="'.$all_topics_pdf_url.'">View All Topics</a></td></tr>';
        }
        

        if($add_feedback || $schedule=="all"){
            $identifier = "course00aa0". $course_details["course_id"] . "00aa0" . $this->learner_id;
            $like_url = base_url("index.php")."/feedback/1/" . $identifier; 
            $dislike_url = base_url("index")."/feedback/0/" . $identifier;
            $this->email_body .= '<tr><td>Let us know how you found this course</td> <td><a href="'.$like_url.'">Like</a>  <a href="'.$dislike_url.'">Dislike</a></td>';            
        }

    }

    

    public function send_scheduled_mail(){
        
        $headers = "From: university@capgemini.com\r\n";
        $headers .= "Reply-To: university@capgemini.com\r\n";
        $headers .= "Bcc: vishwajit.menon@capgemini.com\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

        $salutation = "<p>Hello ".$this->email_salutation_name."!</p>";
        $this->email_body = $salutation.$this->email_body;
        
        //$to = 'vishwajit.menon@capgemini.com';    //To test the email and format

        mail($this->email_to, $this->email_subject, $this->email_body, $headers); 

    }


	



    	
}

/* End of file formatted_mail_model.php */
/* Location: ./application/models/formatted_mail_model.php */