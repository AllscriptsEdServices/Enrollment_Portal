<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo APPLICATION_NAME ?>- Login</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/main.css') ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/plugins/formvalidation-master/dist/css/formValidation.css'); ?>" rel="stylesheet">
</head>
<body>
	<nav class="navbar navbar-default">
	  	<div class="container-fluid">
		    <!-- Brand and toggle get grouped for better mobile display -->
		    <div class="navbar-header">	     
		    	<table >		    		
		    			<tr>
		    				<td><a class="navbar-brand" href="#"><img src="<?php echo base_url('assets/img/cg_logo.png') ?>" alt=""></a></td>
		    				<td class="hidden-xs"><a class="navbar-brand" href="#"><img src="<?php echo base_url('assets/img/ou_logo.png') ?>" alt=""></a></td>
		    			</tr>
		    		
		    	</table>		      
		    </div>	    
	    	
			<div class="text-right">
				<h2>Uni One Mail</h2>
			</div>
	  	</div><!-- /.container-fluid -->
	</nav>

	<div class="container-fluid">
		
		<div class="row">

			<div id="" class="col-md-8">
				

			</div>

			<div id="login_div" class="login-box column col-md-4">
					
					<div class="login-header">
						<h3>Hello!</h3>	
					</div>

				<form id="login_form" action="javascript:do_login()" >

					<div class="input-group">
					  <span class="input-group-addon input-lg" id="basic-addon1"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span></span>
					  <input id="email" type="email" class="form-control input-lg" placeholder="email" aria-describedby="basic-addon1">
					</div>

					<div class="input-group top-buffer-20">
					  <span class="input-group-addon input-lg" id="basic-addon2"><span class="glyphicon glyphicon-lock" aria-hidden="true"></span></span>
					  <input id="password" type="password" class="form-control input-lg" placeholder="password" aria-describedby="basic-addon2">
					</div>
					
					<div class=" text-center top-buffer-20">						
						<button type="submit" class="btn btn-primary btn-lg" style="width:100%">Sign In</button>
					</div>
					<div class="top-buffer-20">
						<label>
		    	    		 <a href="" data-toggle="modal" data-target="#myModal">Forgot Password?</a>
		    	    	</label>
					</div>
				</form>

				<div id="message_box" class="message_box error_msg" >
					The password is incorrect.
				</div>
				<div id="processing_div" class="processing_div" >
					<img src="<?php echo base_url('assets/img/ajax-loader.gif') ?>" alt="">
				</div>


				<div style="margin-top:100px" class="text-center">
					<button type="button" class="btn btn-danger btn-lg" style="width:100%" onclick="toggle_div_display()"> SIGN UP</button>
				</div>

			</div>

			<div id="signup_div" class="login-box column col-md-4" style="display:none">
					
					<div class="login-header">
						<h3>New User</h3>	
					</div>

				<form id="signup_form" action="javascript:do_sign_up()" >
					<div class="input-group">
					  <span class="input-group-addon input-lg" id="basic-addon1"><span class="glyphicon glyphicon-user" aria-hidden="true"></span></span>
					  <input id="first_name" name="first_name" type="text" class="form-control input-lg" placeholder="first name" aria-describedby="basic-addon1">
					</div>

					<div class="input-group top-buffer-20">
					  <span class="input-group-addon input-lg" id="basic-addon1"><span class="glyphicon glyphicon-user" aria-hidden="true"></span></span>
					  <input id="last_name" name="last_name" type="text" class="form-control input-lg" placeholder="last name" aria-describedby="basic-addon1">
					</div>

					<div class="input-group top-buffer-20">
					  <span class="input-group-addon input-lg" id="basic-addon1"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span></span>
					  <input id="signup_email" name="signup_email" type="email" class="form-control input-lg" placeholder="email" aria-describedby="basic-addon1">
					</div>

					<div class="input-group top-buffer-20">
					  <span class="input-group-addon input-lg" id="basic-addon2"><span class="glyphicon glyphicon-lock" aria-hidden="true"></span></span>
					  <input id="signup_password" name="signup_password" type="password" class="form-control input-lg" placeholder="password" aria-describedby="basic-addon2">
					</div>

					<div class="input-group top-buffer-20">
					  <span class="input-group-addon input-lg" id="basic-addon2"><span class="glyphicon glyphicon-lock" aria-hidden="true"></span></span>
					  <input id="signup_password_1" name="signup_password_1" type="password" class="form-control input-lg" placeholder="re-enter password" aria-describedby="basic-addon2">
					</div>

					<div class="input-group top-buffer-20">
					  <span class="input-group-addon input-lg" id="basic-addon2"><span class="glyphicon glyphicon-time" aria-hidden="true"></span></span>
					  <!-- <input id="password_1" name="password_1" type="password" class="form-control input-lg" placeholder="reenter password" aria-describedby="basic-addon2"> -->
					  <select id="timezone" name="timezone" class="form-control input-lg" aria-describedby="basic-addon2"  >		
					  	<option value="" selected disabled>Select Timezone</option>			  	
					  	<option value="us">US</option>
					  	<option value="europe">Europe</option>
					  	<option value="asia">Asia/Pacific</option>
					  	
					  </select>
					</div>

					
					<div class=" text-center top-buffer-20">						
						<button type="submit" class="btn btn-primary btn-lg" style="width:100%">SIGN UP</button>
					</div>
					
				</form>

				<div id="message_box" class="message_box error_msg" >
					The password is incorrect.
				</div>
				<div id="processing_div" class="processing_div" >
					<img src="<?php echo base_url('assets/img/ajax-loader.gif') ?>" alt="">
				</div>


				<!-- <div style="margin-top:100px" class="text-center">
					<button type="button" class="btn btn-danger btn-lg" style="width:100%" onclick="toggle_div_display()"> SIGN IN</button>
				</div> -->

			</div>

			
		</div>

	</div>

	<div class="modal fade" id="myModal" data-keyboard="false" data-backdrop="static">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		        <h4 class="modal-title">Password Recovery</h4>
	      </div>
	      <div class="modal-body">
		      	<p>Enter your registered email address and we'll mail you a temporary password.</p>
		      	<label class="control-label" for="forgotMail">Email Address</label>
		        <input type="email" class="form-control" id="forgotMail" name="forgotMail" placeholder="Enter email">

		        <div id="msg-error" class="bg-danger hidden" style="margin-top:20px; padding:5px;">
		        	<p>This email is not registered in the system. Please check the email address and retry.</p> 
		        	<p>For further assisstance/queries you can reach out to <a href="mailTo:university@capgemini.com?subject=Video Library Admin - Login Password Issue">university@capgemini.com</a>.</p>
		    	</div>

		    	<div id="msg-success" class="bg-success hidden" style="margin-top:20px; padding:5px;">
		        	<p>Your password has been reset! You will be receiving an mail with the temporary password shortly to the above mail address. If you cannot find it in your Inbox, please check the Junk/Spam folders as well.</p> 
		        	<p>If you are still facing problems logging in, you can write to <a href="mailTo:university@capgemini.com?subject=Uni One Mail - Login Password Issue">university@capgemini.com</a>.</p>
		        </div>

	      </div>
	      <div class="modal-footer">	        
	        <button id="forgot_submit_btn" type="button" class="btn btn-primary" onclick="fnForgotPassword()">Submit</button>
	      </div>
	    </div><!-- /.modal-content -->
	  </div><!-- /.modal-dialog -->
	</div><!-- /.modal -->


	<script src="<?php echo base_url('assets/js/jquery-2.2.3.min.js') ?>" type="text/javascript" charset="utf-8"></script>
	<script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>" type="text/javascript" charset="utf-8"></script>
	<script src="<?php echo base_url('assets/plugins/formvalidation-master/dist/js/formValidation.js'); ?>"></script> 
	<script src="<?php echo base_url('assets/plugins/formvalidation-master/dist/js/framework/bootstrap.js'); ?>"></script>
	
	<script type="text/javascript">
		var base_url = <?php echo json_encode($base_url) ?>;
		$(document).ready(function() {

		$(".form-control").focus(function(event) {
			$("#message_box").fadeOut();
		});

	   
	    $('#signup_form')
		    .formValidation({

		        message: 'This value is not valid',
		        icon: {
		            valid: 'glyphicon glyphicon-ok',
		            invalid: 'glyphicon glyphicon-remove',
		            validating: 'glyphicon glyphicon-refresh'
		        },

		        fields: {	         
		            first_name: {	                
		                validators: {
		                    notEmpty: {
		                        message: 'The first name cannot be empty.'
		                    }
		                }
		            },
		            last_name: {	                
		                validators: {
		                    notEmpty: {
		                        message: 'The last name cannot be empty.'
		                    }
		                }
		            },
		           	signup_email: {
		                validators: {
		                	notEmpty: {
		                        message: 'The first name cannot be empty.'
		                    },
		                    emailAddress: {
		                        message: 'Not a valid email address'
		                    }
		                }
		            },
		            signup_password: {
		                validators: {
		                    notEmpty: {
		                    	message: 'The password cannot be empty.'
		                    },
		                    stringLength: {
		                        min: 2,
		                        max: 20,
		                        message: 'The password must be more than 6 and less than 20 characters long.'
		                    }
		                }
		            },
		            signup_password_1: {
		                validators: {
		                    notEmpty: {
		                    	message: 'The password cannot be empty.'
		                    },
		                    identical: {
		                        field: 'signup_password',
		                        message: 'The password and its confirm are not the same.'
		                    }
		                }
		            },
		            timezone: {	                
		                validators: {
		                    notEmpty: {
		                        message: 'The timezone cannot be empty.'
		                    }
		                }
		            },
		            
		        }
		    })	
			.on('success.form.fv', function(e) {
	            //console.log('success.form.fv');
	             e.preventDefault();
	             do_sign_up();

	        });
		});

		$(".form-control").focus(function(event) {
			$("#message_box").fadeOut();
			$("#signup_div>#message_box").fadeOut();
		});


		function toggle_div_display() {
			/*$('#login_div').toggle();
			$('#signup_div').toggle();*/
			$('#login_div').fadeOut();
			$('#signup_div').fadeIn();
		}


		function do_login(){
			$("#processing_div").show();
			$.ajax({
				url: base_url + "/login/do_login",
				type: 'POST',
				dataType: 'json',
				data: {
					"email": $("#email").val(),
					"password": $("#password").val()
				},
				success: function(response)
		      	{			      		
					console.log(response.status);	
					$("#processing_div").hide();
					switch (response.status) {
						case "SUCCESS":
							window.location.href = base_url + "/home";
							break;
						case "FAIL":
							$("#message_box").html(response.message);
							$("#message_box").fadeIn();
							break;
						default:
							// statements_def
							break;
					}
		      			
		      	}


			})
			/*.success(function(response) {
				var responseObj = $.parseJSON(response);
				//var response_obj = $.parseJSON(response);
				console.log(responseObj.status);				
			})*/
		}


		function do_sign_up(){
			console.log('In SIgn up')
			$("#processing_div").show();
			$.ajax({
				url: base_url + "/login/do_signup",
				type: 'POST',
				dataType: 'json',
				data: {
					"first_name": $("#first_name").val(),
					"last_name": $("#last_name").val(),
					"email": $("#signup_email").val(),
					"password": $("#signup_password").val(),
					"timezone": $("#timezone").val()
				},
				success: function(response)
		      	{			      		
					console.log(response.status);	
					$("#signup_div>#processing_div").hide();
					switch (response.status) {
						case "SUCCESS":
							window.location.href = base_url + "/home";
							break;
						case "FAIL":
							$("#signup_div>#message_box").html(response.message);
							$("#signup_div>#message_box").fadeIn();
							break;
						default:
							// statements_def
							break;
					}
		      			
		      	}

			})
		}



		function fnForgotPassword(){		
			if(validateEmail($("#forgotMail").val()))
			{
				var action = base_url + "/login/forgot_password";
			    var form_data = {
			      'forgotMail': $("#forgotMail").val()
			    };

			    $.ajax({
			      	type: "POST",
			      	url: action,
			      	dataType: 'json',
			      	data: form_data,
			      	success: function(response)
			      	{		      	
			      		console.log(response);
			      		console.log(typeof(response))
			      		if(response.status == "SUCCESS"){
			      			$("#msg-success").removeClass("hidden");
			      			$("#msg-error").addClass("hidden");
			      			$("#forgot_submit_btn").hide();
			      			//$('#defaultForm').get(0).reset()	
			      		}else{
			      			$("#msg-success").addClass("hidden");
			      			$("#msg-error").removeClass("hidden");
			      		}		      		
			      	}
			    });
			}
			else
			{
				alert("Enter a valid email address.");
			}
			
		}


	function validateEmail(email) { 
	    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    return re.test(email);
	} 

	</script>
	
</body>

</html>