<div id="loader_div" class="row loader_div" >
	<div class="col-xs-12 text-center" >
		 <div>
		 	<img width="150px"src="<?php echo base_url("assets/img/loader_circle.gif"); ?>" /> Processing..
		 </div>			 
	</div>
</div>


<div class="container main_container">

<form id="myform">
	<?php foreach ($all_courses as $course): 

		if($course["sub_status"] ==0 || $course["sub_status"]["status"] == "terminated"){
	?>

		<div class="col-md-4 col-sm-6">
			<div class="course_div" data-course-id="<?php echo $course['course_id'] ?>">
			
				<div class="subscribe_band">
					<!-- <input id="subscribe_btn_" type="button" class="subscribe_btn"></input> -->
					<input type="checkbox" class="subscribe_check" data-course-id="<?php echo $course['course_id'] ?>" id="subscribe_btn_<?php echo $course['course_id'] ?>" name="subscribe_btn_<?php echo $course['course_id'] ?>"  ></input>
				</div>
				<div class="course_title_div">
					<span class="course_title"> <?php echo $course["course_title"] ?> </span>
					<div class="separator"></div>
					<span class="duration_text"><?php echo $course["total_days"] ?> Days</span>
				</div>

				<div id="options_band_<?php echo $course['course_id'] ?>" class="course-options-band hidden">
					<table class="table-condensed" style="width:100%" class="">
						<tr>
							<td> <input type="radio" name="schedule_radio_<?php echo $course['course_id'] ?>"  class="input_escape" value="all" > All At Once </input> </td>
							<td align="right"> <input type="radio" name="schedule_radio_<?php echo $course['course_id'] ?>" class="input_escape"  value="daily" checked> Daily </input> </td>
						</tr>					
					</table>
				</div>

			</div>
		</div>

		<?php
			}else if($course["sub_status"]["status"] == "active"){
		?>
			<div class="col-md-4 col-sm-6">
				<div class="course_div course_div_subscribed" data-course-id="<?php echo $course['course_id'] ?>">
				
					<div class="subscribe_band">
						<!-- <input id="subscribe_btn_<?php echo $course['course_id'] ?>" type="button" class="subscribe_btn"></input> -->
						<input type="checkbox" class="subscribe_check" data-course-id="<?php echo $course['course_id'] ?>" id="subscribe_btn_<?php echo $course['course_id'] ?>" name="subscribe_btn_<?php echo $course['course_id'] ?>" checked></input>
					</div>
					<div class="course_title_div">
						<span class="course_title"> <?php echo $course["course_title"] ?> </span>
						<div class="separator"></div>
						<span class="duration_text"><?php echo $course["total_days"] ?> Days</span>
					</div>

					<div id="options_band_<?php echo $course['course_id'] ?>" class="course-options-band">
						<table class="table-condensed" style="width:100%" class="">
							<tr>
								<?php 
									$all_checked = ($course["sub_status"]["schedule"] == "all") ? "checked":""; 
									$daily_checked = ($course["sub_status"]["schedule"] == "daily") ? "checked":""; 									
								?>
								<td> <input type="radio" name="schedule_radio_<?php echo $course['course_id'] ?>"  class="input_escape"  value="all" <?php echo $all_checked ?> > All At Once </input> </td>
								<td align="right"> <input type="radio" name="schedule_radio_<?php echo $course['course_id'] ?>" class="input_escape" value="daily" <?php echo $daily_checked ?> > Daily </input> </td>
							</tr>					
						</table>
					</div>

				</div>
			</div>

		<?php
			}else if($course["sub_status"]["status"] == "completed"){
		?>

			<div class="col-md-4 col-sm-6">
				<div class="course_div_completed" data-course-id="<?php echo $course['course_id'] ?>">
				
					<div class="subscribe_band">
						<!-- <input id="subscribe_btn_<?php echo $course['course_id'] ?>" type="button" class="subscribe_btn"></input> -->
						<input type="checkbox" class="subscribe_check" data-course-id="<?php echo $course['course_id'] ?>" id="subscribe_btn_<?php echo $course['course_id'] ?>" name="subscribe_btn_<?php echo $course['course_id'] ?>" checked disabled></input>
					</div>
					<div class="course_title_div">
						<span class="course_title"> <?php echo $course["course_title"] ?> </span>
						<div class="separator"></div>
						<span class="duration_text"><?php echo $course["total_days"] ?> Days</span>
					</div>

					<div id="options_band_<?php echo $course['course_id'] ?>" class="course-options-band">
						<table class="table-condensed" style="width:100%" class="">										
							<tr>
								<td></td>
								<td align="right"> <button class="pdf_btn input_escape"></button> </td>
							</tr>						
						</table>
					</div>

				</div>
			</div>

	<?php } endforeach ?>

</form>
	<!-- <div class="col-md-4 col-sm-6">
		<div class="course_div">

			<div class="subscribe_band">
				<button class="subscribe_btn"></button>
			</div>

			<div class="course_title_div">
				<span class="course_title">Deep Learning</span>
				<div class="separator"></div>
				<span class="duration_text">10 Days</span>
			</div>

			<div class="course-options-band">
				<table class="table-condensed" style="width:100%">										
					<tr>
						<td><input type="radio" name="schedule_radio" > All At Once </input></td>
						<td align="right"><input type="radio" name="schedule_radio" > Daily </input></td>
					</tr>					
				</table>
			</div>

		</div>
	</div> 

	<div class="col-md-4 col-sm-6">
		<div class="course_div course_div_subscribed">

			<div class="subscribe_band">
				<button class="subscribe_btn"></button>
			</div>

			<div class="course_title_div">
				<span class="course_title">Subscribed Course</span>
				<div class="separator"></div>
				<span class="duration_text">10 Days</span>
			</div>

			<div class="course-options-band">
				<table class="table-condensed" style="width:100%">										
					<tr>
						<td><input type="radio" name="schedule_radio" class="input_escape"> All At Once </input></td>
						<td align="right"><input type="radio" name="schedule_radio" class="input_escape" checked> Daily </input></td>
					</tr>					
				</table>
			</div>

		</div>
	</div>

	<div class="col-md-4 col-sm-6">
		<div class="course_div_completed">

			<div class="subscribe_band">
				<button class="subscribe_btn"></button>
			</div>

			<div class="course_title_div">
				<span class="course_title">Complete Course</span>
				<div class="separator"></div>
				<span class="duration_text">10 Days</span>
			</div>

			<div class="course-options-band">
				<table class="table-condensed" style="width:100%">										
					<tr>
						<td></td>
						<td align="right"> <button class="pdf_btn input_escape"></button> </td>
					</tr>					
				</table>
			</div>

		</div>
	</div>-->


	
	<!-- <?php echo json_encode($all_courses); ?>  -->
	<!-- <?php echo json_encode($subscribed_courses); ?> -->
	
	


</div> <!-- /.main_container -->


<div id="bottom-band" class="bottom-band text-center">
	<span>Save your changes. </span><button type="" id="save_changes_btn" class="btn btn-lg btn-success" onclick="process_subscriptions()" disabled>GO</button>
</div>


<div id="em_modal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog  modal-lg">
    <div class="modal-content">

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="em_modal_title">Modal title</h4>
      </div>

      <div id="em_modal_body" class="modal-body">	        
        <!-- <iframe id="video_actions_iframe" src="" width="100%" height="550px" frameborder="0"></iframe> -->

      </div>
      
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script src="<?php echo base_url('assets/js/home.js') ?>"></script>

<script type="text/javascript">
	var base_url = <?php echo json_encode($base_url) ?>;
	var all_courses = <?php echo json_encode($all_courses) ?>;	 

	
	


	
</script>