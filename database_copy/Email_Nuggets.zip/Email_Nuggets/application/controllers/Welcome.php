<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function show_custom($my_var_5=false){
		$this->load->model('custom_model');

		

		$content["my_var"] = "Vijay";
		$content["my_var_2"] = $this->get_name();
		$content["my_var_5"] = $this->custom_model->get_users("all");;

		$this->load->view('custom_view', $content);
	}


	private function get_name(){
		return "Baxter";
	}

}
