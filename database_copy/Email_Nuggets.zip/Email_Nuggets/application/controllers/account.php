<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model("learner_model");
    }


	public function index()
	{		
		
	}

	public function change_password(){
		$this->load_page("change_password_view", "");
	}


	public function logout(){		
		$this->learner_model->destroy_current_session();
		redirect('login','refresh');
	}


	public function load_page($page_name, $page_data){
		$current_user = $this->learner_model->get_current_user();

		if($current_user["active"]==1){
			$header_data["current_user"] = $current_user["user_data"];
			$page_data["base_url"] = base_url("index.php");
			$footer_data["active_nav"] = "";

			$this->load->view('global/header', $header_data);
			$this->load->view($page_name, $page_data);
			$this->load->view('global/footer', $footer_data);
		}
		else{
			redirect('login','refresh');
		}
	}



	
	public function make_password_change(){
		$current_user = $this->learner_model->get_current_user();

		$old_password = $this->input->post("old_password");
		$new_password = $this->input->post("new_password");
		$process_status = $this->learner_model->change_password($current_user["user_data"]["learner_id"], $old_password, $new_password);
		//header('Content-Type: application/json');
		echo json_encode($process_status);

		
	}

	
	

}
