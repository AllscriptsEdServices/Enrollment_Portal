<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mail_Sender extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model("course_model");
        $this->load->model("subscription_model");
        $this->load->model("formatted_mail_model");
        
    }


	public function index()
	{
		
	}

	public function send($timezone=false){
		$active_learners = $this->subscription_model->get_active_learners($timezone);
		echo json_encode($active_learners);

		$group_learner_array = array();
		$previous_learner_id = 0;
		foreach ($active_learners as $key => $value) {
			

			if( ($active_learners[$key]["learner_id"] != $previous_learner_id) && ($previous_learner_id != 0) ){				
				$process_status = $this->formatted_mail_model->process_scheduled_mail($group_learner_array);
				echo "<br><br>";
				echo json_encode($process_status);
				$group_learner_array = array();					
									
			}else{

			}

			array_push($group_learner_array, $active_learners[$key]);			
			$previous_learner_id = $active_learners[$key]["learner_id"];
		}

		$process_status = $this->formatted_mail_model->process_scheduled_mail($group_learner_array);
		echo "<br><br>";
		echo json_encode($process_status);
		
	}


	


	
	

}
