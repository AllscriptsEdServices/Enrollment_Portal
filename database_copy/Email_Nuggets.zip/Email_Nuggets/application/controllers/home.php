<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model("course_model");
        $this->load->model("subscription_model");
        
    }


	public function index()
	{

		/*$this->load->library('encryption', array(
                'cipher' => 'aes-256',
                'mode' => 'ctr',
                'key' => '<a 32-character random string>'
        ));
		$plain_text = "32#DISlike#25";
		$ciphertext = $this->encryption->encrypt($plain_text);

		echo $ciphertext;

		$decr_text = $this->encryption->decrypt($ciphertext);
		echo "<br><br>";
		echo $decr_text;*/

		$current_user = $this->learner_model->get_current_user();

		if($current_user["active"]==1){
			$content["all_courses"] = $this->course_model->get_courses_for_home($current_user["user_data"]["learner_id"]);
			//$content["subscribed_courses"] = $this->subscription_model->get_learner_subscriptions(1);
			
			$this->load_page("home_view", $content);
		}else{
			redirect('login','refresh');
		}
		
	}


	public function load_page($page_name, $page_data){
		$current_user = $this->learner_model->get_current_user();

		if($current_user["active"]==1){
			$header_data["current_user"] = $current_user["user_data"];
			$page_data["base_url"] = base_url("index.php");
			$footer_data["active_nav"] = "home";

			$this->load->view('global/header', $header_data);
			$this->load->view($page_name, $page_data);
			$this->load->view('global/footer', $footer_data);
		}
		else{
			redirect('login','refresh');
		}
		
	}


	public function process_subscriptions(){
		//$learner_id = $this->input->post("learner_id");
		$current_user = $this->learner_model->get_current_user();
		$courses_string = $this->input->post("courses_string");
		$process_status = $this->subscription_model->process_subscriptions($current_user["user_data"]["learner_id"], $courses_string);
		echo json_encode($process_status);

	}


	
	

}
