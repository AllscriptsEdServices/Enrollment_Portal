<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model("learner_model");
    }


	public function index()
	{		
		$page_data = "";
		$this->load_page("login_view", $page_data);
	}


	public function load_page($page_name, $page_data){
		$header_data = "";
		$page_data["base_url"] = base_url("index.php");
		//$footer_data["active_nav"] = "login";

		//$this->load->view('global/header', $header_data);
		$this->load->view($page_name, $page_data);
		//$this->load->view('global/footer', $footer_data);
	}



	public function do_login(){
		$email = $this->input->post("email");
		$password = $this->input->post("password");
		$process_status = $this->learner_model->do_login($email, $password);
		echo json_encode($process_status);
	}


	public function do_signup(){
		$input_data["first_name"] = $this->input->post("first_name");
		$input_data["last_name"] = $this->input->post("last_name");
		$input_data["email"] = $this->input->post("email");
		$input_data["password"] = $this->input->post("password");
		$input_data["timezone"] = $this->input->post("timezone");
		
		$process_status = $this->learner_model->sign_up_learner($input_data);
		echo json_encode($process_status);
	}



	public function forgot_password(){
		$email = $this->input->post("forgotMail");
		$process_status = $this->learner_model->reset_password($email);
		echo json_encode($process_status);
	}

	
	

}
