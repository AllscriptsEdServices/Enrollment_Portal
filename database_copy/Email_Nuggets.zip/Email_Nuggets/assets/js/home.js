
	$('#myform').data('serialize',$('#myform').serialize());
	console.log($('#myform').data('serialize',$('#myform').serialize()))

	$(function(){
  		$('[data-toggle="tooltip"]').tooltip(); 		 
	});

	$(document).on('click','.course_div',function() {
		console.log($(this).attr('data-course-id'));
		var array_key = get_array_key($(this).attr('data-course-id'));
		console.log(array_key);
		show_description(array_key);
	});

	$(document).on('click','input',function(e) {
		check_enable_submit_btn();
	});

	$(document).on('click','.subscribe_check',function(e) {
		console.log('subscribe button clicked = ' + $(this).prop("checked"));
		e.stopPropagation();
		handle_scheduling_band($(this).prop("checked"), $(this).attr('data-course-id'));
	});

	$(document).on('click','.input_escape',function(e) {
		console.log('other input clicked');
		e.stopPropagation();
	});

	function show_description(course_array_key){

		$("#em_modal_title").html(all_courses[course_array_key]["course_title"]);
		$("#em_modal_body").html(all_courses[course_array_key]["course_description"]);
		$('#em_modal').modal('show'); 
	}


	function get_array_key(course_id){
		for(var i=0; i<all_courses.length; i++){
			if(course_id == all_courses[i]["course_id"]){
				return i;
				break;
			}
		}
	}

	function handle_scheduling_band(show_flag, course_id){
		if(show_flag){
			$("#options_band_" + course_id).removeClass("hidden");
		}else{
			$("#options_band_" + course_id).addClass("hidden");
		}		
	}

	
	$('#video_action_modal').on('hidden.bs.modal', function () {
		var frame = document.getElementById("video_actions_iframe");
      	frame.src = "about:blank";    	
	});


	function check_enable_submit_btn(){		
		if($('#myform').serialize()!=$('#myform').data('serialize')){
   			console.log("data changed");
   			$("#save_changes_btn").attr("disabled", false);
		}else{
			$("#save_changes_btn").attr("disabled", true);
		}
	}



	function process_subscriptions(){	
		$("#loader_div").show();
		var courses_string = "";
		for(var i=0; i<all_courses.length; i++){
			var course_ob = all_courses[i];
			if(course_ob["sub_status"]["status"] != "completed"){
				if($("#subscribe_btn_" + course_ob["course_id"]).prop("checked")){
					courses_string += course_ob["course_id"] + "$" + "subscribe" + "$" +  $('input[name=schedule_radio_'+ course_ob["course_id"] +']:checked').val();
				}else{					
					courses_string += course_ob["course_id"] + "$" + "unsubscribe" + "$" + $('input[name=schedule_radio_'+ course_ob["course_id"] +']:checked').val();
				}
				courses_string += "#";
			}			
		}

		courses_string = courses_string.slice(0, -1);
		console.log('courses_string = ' + courses_string);
		//var courses_string = "1$subscribe$daily#3$subscribe$daily";
		$.ajax({
			url: base_url + "/home/process_subscriptions",
			type: 'POST',
			dataType: 'json',
			data: {
				"courses_string": courses_string			
			},

		})
		.success(function(response) {
			$("#loader_div").hide();
			
		});		
		
	}

	

	