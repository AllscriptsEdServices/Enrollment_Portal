<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Password extends CI_Controller {

	public function __construct()
	{
		parent::__construct();		
		$this->load->helper('form');
		$this->load->helper('url');	
	}

	public function index()
	{			
   		$content = "";
   		$this->fnLoadPage($content);
	}


	public function change(){		
		$page_data = "";
		$this->fnLoadPage($page_data);
		
	}

	function fnLoadPage($page_data){

		if($this->session->userdata('logged_in')) {
		     $session_data = $this->session->userdata('logged_in');		    
		     $header_data['mail'] = $session_data['mail'];
		     $header_data['name'] = $session_data['name'];
		     $header_data['rights'] = $session_data['rights'];
		     $header_data['userType'] = $session_data['userType'];
		     $page_data['name'] = $session_data['name'];
		     $page_data['userType'] = $session_data['userType'];		    
						     
		}else{
		     //If no session, redirect to login page
		     redirect('login', 'refresh');
		}


		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'
		);	


		$header_data['headerfiles'] = $headerfiles;
		
		
		$footer_data["activeTab"] = "password";

		$this->load->view('global/header', $header_data);
   		$this->load->view('password_view', $page_data);
   		$this->load->view('global/footer', $footer_data);

	}

	public function changePassword_Internal(){
		if($this->session->userdata('logged_in')) {
		    $session_data = $this->session->userdata('logged_in');		    
		}else{		    
		    redirect('login', 'refresh');
		}

		$this->load->model('user');	
		$oldPassword = $this->input->post('oldPassword');
		$newpassword_1 = $this->input->post('newpassword_1');
				
		$changeStatus = $this->user->changePassword($oldPassword, $newpassword_1, $session_data["id"]);
		echo $changeStatus;
	}

	public function changePassword_External(){
		if($this->session->userdata('logged_in')) {
		    $session_data = $this->session->userdata('logged_in');		    
		}else{		    
		    redirect('login', 'refresh');
		}

		$this->load->model('clientuser_model');	
		
		$oldPassword = $this->input->post('oldPassword');
		$newpassword_1 = $this->input->post('newpassword_1');
				
		$changeStatus = $this->clientuser_model->changePassword($oldPassword, $newpassword_1, $session_data["id"]);
		echo $changeStatus;
	}


}