<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class AddProject extends CI_Controller {

 function __construct()
 {
   parent::__construct();
   $this->load->model('newprojects_model','',TRUE);
 }

 function index()
 {
   //This method will have the credentials validation
   $this->load->library('form_validation');
   $mail = $this->input->post('organizationName');
   echo $mail;
  /* $this->form_validation->set_rules('mail', 'mail', 'trim|required|xss_clean');
   $this->form_validation->set_rules('password', 'password', 'trim|required|xss_clean|callback_check_database');

  
   
   if($this->form_validation->run() == FALSE)
   {     
     $this->load->view('login/index');
   }
   else
   {     
     redirect('home', 'refresh');
   }*/
  
 }

 function check_database($password)
 {
   //Field validation succeeded.  Validate against database


   $mail = $this->input->post('mail');
   //$password = $this->input->post('password');
  
    //query the database
     $result = $this->user->login($mail, $password);   
     if($result)
     {
       $sess_array = array();
       foreach($result as $row)
       {      
         $sess_array = array(
           'id' => $row->id,
           'mail' => $row->mail
         );
         $this->session->set_userdata('logged_in', $sess_array);
       }
       //echo "true";
       return TRUE;
     }
     else
     {
       //echo "false";
       $this->form_validation->set_message('check_database', 'Invalid email or password');
       return false;
     }  
   }
}
?>