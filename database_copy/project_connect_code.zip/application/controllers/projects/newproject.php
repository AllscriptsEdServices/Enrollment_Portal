<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class NewProject extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
	}

	public function index()
	{		
		$this->load->model('newprojects_model');
		
		$conversions_Array_1 = array();
		$conversions_Array_2 = array();
		$conversions_Array_3= array();
		$interfaces_Array_1 = array();
		$interfaces_Array_2 = array();
		$interfaces_Array_3= array();
		$addOns_Array_1 = array();
		$addOns_Array_2 = array();
		$addOns_Array_3= array();

		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'					
		);
		$footerData["activeTab"] = "projects";

		$conversionsResult = $this->newprojects_model->getConversions();		
		foreach ($conversionsResult as $conversion) {		    		    
		    if (strpos($conversion["productId"],'1') !== false) {			  
			    array_push($conversions_Array_1, $conversion);
			}
			if (strpos($conversion["productId"],'2') !== false) {
				array_push($conversions_Array_2, $conversion);
			}
			if (strpos($conversion["productId"],'3') !== false) {
				array_push($conversions_Array_3, $conversion);
			}
		}

		$interfacesResult = $this->newprojects_model->getInterfaces();		
		foreach ($interfacesResult as $interface) {		    		    
		    if (strpos($interface["productId"],'1') !== false) {			  
			    array_push($interfaces_Array_1, $interface);
			}
			if (strpos($interface["productId"],'2') !== false) {
				array_push($interfaces_Array_2, $interface);
			}
			if (strpos($interface["productId"],'3') !== false) {
				array_push($interfaces_Array_3, $interface);
			}
		}

		$addOnsResult = $this->newprojects_model->getAddOns();		
		foreach ($addOnsResult as $addOn) {		    		    
		    if (strpos($addOn["productId"],'1') !== false) {			  
			    array_push($addOns_Array_1, $addOn);
			}
			if (strpos($addOn["productId"],'2') !== false) {
				array_push($addOns_Array_2, $addOn);
			}
			if (strpos($addOn["productId"],'3') !== false) {
				array_push($addOns_Array_3, $addOn);
			}
		}

		$formData["conversions_Array_1"] = $conversions_Array_1;
		$formData["conversions_Array_2"] = $conversions_Array_2;
		$formData["conversions_Array_3"] = $conversions_Array_3;
		$formData["interfaces_Array_1"] = $interfaces_Array_1;
		$formData["interfaces_Array_2"] = $interfaces_Array_2;
		$formData["interfaces_Array_3"] = $interfaces_Array_3;
		$formData["addOns_Array_1"] = $addOns_Array_1;
		$formData["addOns_Array_2"] = $addOns_Array_2;
		$formData["addOns_Array_3"] = $addOns_Array_3;

		$formData["productTypes"] = $this->newprojects_model->getProductTypes();

		$data['headerfiles'] = $headerfiles;
		if($this->session->userdata('logged_in')) {
		     $session_data = $this->session->userdata('logged_in');
		     $data['mail'] = $session_data['mail'];
		     $data['name'] = $session_data['name'];
		     $data['rights'] = $session_data['rights'];	
		     $data['userType'] = $session_data['userType'];		     
		}else{
		     //If no session, redirect to login page
		     redirect('login', 'refresh');
		}				

		$this->load->view('global/header',$data);
   		$this->load->view('projects/new_project_view', $formData);
   		$this->load->view('global/footer', $footerData);
   		
	}

	function addNewProject(){
		$this->load->model('newprojects_model');
		$clientAdmin["name"] = $this->input->post('userName');
		$clientAdmin["mail"] = $this->input->post('userMail');
		$clientAdmin["phone"] = $this->input->post('phone');
		
		//echo "Client Id = ".$clientId."<br>";

		$projectData["organizationName"] = $this->input->post('organizationName');
		$projectData["cdhNum"] = $this->input->post('cdhNum');
		$projectData["address"] = $this->input->post('address');
		$projectData["projectType"] = $this->input->post('projectType');
		$projectData["productId"] = $this->input->post('productName');
		$projectData["hostingType"] = $this->input->post('hostingType');
		$projectData["conversions"] = $this->input->post('conversions');
		$projectData["interfaces"] = $this->input->post('interfaces');
		$projectData["addOns"] = $this->input->post('addOns');
		
		//echo $this->input->post('interfaces');

		$processStatus = $this->newprojects_model->addProject($clientAdmin,$projectData);		
		echo json_encode($processStatus);	
		
	}	
	
}