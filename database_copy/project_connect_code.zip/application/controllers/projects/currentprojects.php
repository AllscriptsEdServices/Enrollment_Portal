<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CurrentProjects extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('currentprojects_model');
		$this->load->model('first_run_model');
	}

	public function index()
	{				
		if($this->session->userdata('logged_in')) {
		     $session_data = $this->session->userdata('logged_in');
		     $data['id'] = $session_data['id'];
		     $data['mail'] = $session_data['mail'];
		     $data['name'] = $session_data['name'];
		     $data['rights'] = $session_data['rights'];	
		     $data['userType'] = $session_data['userType'];
		     $projectsData['rights'] =  $session_data['rights'];  
		}else{
		     //If no session, redirect to login page
		     redirect('login', 'refresh');
		}

		$this->first_run_model->check_design_call_mails();

		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'	
		);	

		$data['headerfiles'] = $headerfiles;
		$projectsData["myProjects"] = $this->currentprojects_model->getMyProjects($session_data['id']);
		$projectsData["allProjects"] =$this->currentprojects_model->getAllProjects();
		$footerData["activeTab"] = "projects";
		
		//echo sizeof($projectsData["myProjects"]);

		$this->load->view('global/header',$data);		
		$this->load->view('projects/my_projects_view', $projectsData);   		
   		$this->load->view('global/footer', $footerData);
	}

	public function allprojects()
	{				
		if($this->session->userdata('logged_in')) {
		     $session_data = $this->session->userdata('logged_in');
		     $data['id'] = $session_data['id'];
		     $data['mail'] = $session_data['mail'];
		     $data['name'] = $session_data['name'];
		     $data['rights'] = $session_data['rights'];	
		     $data['userType'] = $session_data['userType'];
		     $projectsData['rights'] =  $session_data['rights'];  
		}else{
		     //If no session, redirect to login page
		     redirect('login', 'refresh');
		}


		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'	
		);	

		$data['headerfiles'] = $headerfiles;
		$projectsData["myProjects"] = $this->currentprojects_model->getMyProjects($session_data['id']);
		$projectsData["allProjects"] =$this->currentprojects_model->getAllProjects();
		$footerData["activeTab"] = "projects";
		
		//echo sizeof($projectsData["myProjects"]);

		$this->load->view('global/header',$data);		
		$this->load->view('projects/all_projects_view', $projectsData);   		
   		$this->load->view('global/footer', $footerData);
	}

	
}