<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ProjectStatus extends CI_Controller {	

	public function __construct()
	{
		parent::__construct();
		$this->load->model('projectstatus_model');
		
	}

	public function index()
	{		
		$this->load->helper('form');

		$projectsData["cdhSearchString"] = "";
		$projectsData["orgNameSearchString"] = "";
		$projectsData["projectsList"] = array();
		

		$this->fnLoadPage($projectsData);
	}
	
	public function getStatus($projectId){	
		$projectArray = $this->projectstatus_model->getProjectDetails($projectId);
		$suiteDetailsArray = $this->projectstatus_model->getSuiteDetails($projectId, $projectArray["productId"], $projectArray["projectType"]);

		$projectsData["projectInfo"] = $projectArray;
		$projectsData["stagesDetails"] = $suiteDetailsArray;
		$this->fnLoadPage($projectsData);
	}
	
	public function fnLoadPage($pageData){
		if($this->session->userdata('logged_in')) {
		     $session_data = $this->session->userdata('logged_in');
		     $headerData['mail'] = $session_data['mail'];
		     $headerData['name'] = $session_data['name'];
		     $headerData['rights'] = $session_data['rights'];
		     $headerData['userType'] = $session_data['userType'];
		     $pageData["userType"] = $session_data['userType'];		     
		}else{
		     //If no session, redirect to login page
		     redirect('login', 'refresh');
		}


		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">',
			'2' => '<link rel="stylesheet" href="'.base_url("assets/css/app_dashboard.css").'">',
			'3' => '<link rel="stylesheet" href="'.base_url("assets/plugins/bootstrap-datepicker-1.5.0-dist/css/bootstrap-datepicker.min.css").'">'
		);
		$headerData['headerfiles'] = $headerfiles;

		$footerData["activeTab"] = "dashboard";

		$this->load->view('global/header',$headerData);
   		$this->load->view('dashboard/projectstatus_view', $pageData);
   		$this->load->view('global/footer', $footerData);	

	}


	function getTemplateDetails(){		
		$resourceId = $this->input->post('resourceId');
		$projectId = $this->input->post('projectId');
		$productId = $this->input->post('productId');

		$resourceArray = $this->projectstatus_model->getTemplateDetails($resourceId, $projectId, $productId);

		echo json_encode($resourceArray);

	}


	function set_date(){		

        $resourceId = $this->input->post('resourceId');
		$projectId = $this->input->post('projectId');
		$call_date = $this->input->post('call_date');
		$dateType = $this->input->post('dateType');

		$process_status = $this->projectstatus_model->set_date($resourceId, $projectId, $call_date, $dateType);

		echo $process_status;
	}
	
}