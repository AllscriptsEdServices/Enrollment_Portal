<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {	

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		
		
	}

	public function index()
	{		
		
		$this->load->model('home_model');

		$projectsData["cdhSearchString"] = "";
		$projectsData["orgNameSearchString"] = "";
		$projectsData["projectsList"] = array();

		$this->fnLoadPage($projectsData);
	}

	public function searchCDH(){	
	$this->load->model('home_model');	
		$this->load->library('form_validation');
  
		$projectsData["projectsList"] = $this->home_model->getProjectsByCDH($this->input->post('cdhNum'));			
		$projectsData["cdhSearchString"] = $this->input->post('cdhNum');
		$projectsData["orgNameSearchString"] = "";

		$this->fnLoadPage($projectsData);
	}
	
	public function searchOrgName(){
		$this->load->model('home_model');
		$this->load->library('form_validation');
   		
		$projectsData["projectsList"] = $this->home_model->getProjectsByOrgName($this->input->post('organizationName'));
		$projectsData["cdhSearchString"] = "";
		$projectsData["orgNameSearchString"] = $this->input->post('organizationName');
		$this->fnLoadPage($projectsData);
	
	}

	public function fnLoadPage($pageData){
		if($this->session->userdata('logged_in')) {
		    $session_data = $this->session->userdata('logged_in');
		    $headerData['mail'] = $session_data['mail'];
		    $headerData['name'] = $session_data['name'];
		    $headerData['rights'] = $session_data['rights'];
		    $headerData['userType'] = $session_data['userType'];
		}else{
		    //If no session, redirect to login page
		    redirect('login', 'refresh');
		}


		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'
		);	
		$headerData['headerfiles'] = $headerfiles;
		$footerData["activeTab"] = "dashboard";

		

		if($headerData['userType'] == "external"){
			redirect('dashboard/projectstatus/getStatus/'.$session_data['projectId'], 'refresh');
			//$this->load->view('dashboard/projectstatus/getStatus/1', $pageData);
		}else{
			$this->load->view('global/header',$headerData);
			$this->load->view('dashboard/home_view', $pageData);
			$this->load->view('global/footer', $footerData);
		}
   		
   			

	}
	
}