<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Fileupload extends CI_Controller {



	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->model('form_model');
	}



	public function index()

	{			

   		//$this->load->view('questionnaire/file_upload_dummy');

	}



	public function displayPage($questionId,$projectId){

		 //$content["firstPageData"] = $this->form_model->getFirstPage($quest_id, $projectId);

		 $content["questionId"] = $questionId;

		 $content["projectId"] = $projectId;	 

		 $this->fnLoadPage($content);

	}



	public function fnLoadPage($pageData){

		/*if($this->session->userdata('logged_in')) {

		     $session_data = $this->session->userdata('logged_in');

		     $headerData['mail'] = $session_data['mail'];

		     $headerData['name'] = $session_data['name'];

		     $headerData['rights'] = $session_data['rights'];

		}else{

		     //If no session, redirect to login page

		     redirect('login', 'refresh');

		}*/
		$pageData["message"] = "";
   		$this->load->view('questionnaire/file_upload_dummy',$pageData);   		

	}



	function do_upload()
	{
		/*if(!is_dir('./uploads/proj1')){			
			mkdir('./uploads/proj1', 0700);			
		}*/
		//echo $this->input->post("projectId");

		$targetDir = "./uploads/".$this->input->post("projectId");

		if(!is_dir($targetDir)){			
			mkdir($targetDir, 0700);			
		}

		//$config['upload_path'] = './uploads/';
		$config['upload_path'] = $targetDir;
		$config['allowed_types'] = 'gif|jpg|png|xls|xlsx|pdf|doc|docx';
		$config['max_size']	= '2000';
		$config['max_width']  = '0';
		$config['max_height']  = '0';
		
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload())
		{
			$error = array('message' => $this->upload->display_errors());	
			$error["projectId"] = $this->input->post("projectId");
			$error["questionId"] = $this->input->post("questionId");	
				
			$this->load->view('questionnaire/file_upload_dummy', $error);
		}
		else
		{
			//$data["success"] = array('upload_data' => $this->upload->data());
			$upload_data =  $this->upload->data();	
			$data["message"] = "File Uploaded Successfully.";
			$data["projectId"] = $this->input->post("projectId");
			$data["questionId"] = $this->input->post("questionId");


			/*echo($upload_data["file_name"])."<br>";
			echo($upload_data["full_path"])."<br>";
			echo($upload_data["file_path"])."<br>";
			echo($upload_data["file_type"]);*/

			$fileUrl =  base_url().'uploads/'.$this->input->post("projectId").'/'.$upload_data["file_name"];
	
			$this->form_model->submitFileUploads($upload_data["file_name"], $fileUrl, $this->input->post("projectId"), $this->input->post("questionId"));

			$this->load->view('questionnaire/file_upload_dummy', $data);
		}
	}


	




}