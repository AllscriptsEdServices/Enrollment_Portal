<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Form extends CI_Controller {


	public function __construct()
	{
		parent::__construct();
		$this->load->model('form_model');
	}

	public function index()
	{
		$this->load->helper('form');
	}
	
	public function getQuest($quest_id,$projectId){
		 $content["firstPageData"] = $this->form_model->getFirstPage($quest_id, $projectId);
		 $content['checkInDetails'] = $this->form_model->fnHandleActiveUser($quest_id, $projectId); 

		 $content["quest_id"] = $quest_id;
		 $content["projectId"] = $projectId;

		 $this->fnLoadIntroPage($content);
	}

	public function getSummary($quest_id,$projectId){
		 $content["firstPageData"] = $this->form_model->getFirstPage($quest_id, $projectId);
		 $content["quest_id"] = $quest_id;
		 $content["projectId"] = $projectId;	
		 $content['surveyStatus'] = $this->form_model->getSurveyStatus($quest_id, $projectId); 	
		 $content['checkInDetails'] = $this->form_model->fnHandleActiveUser($quest_id, $projectId); 	 

		 $this->fnLoadSummaryPage($content);
	}
	

	public function getTopic($quest_id, $topicId, $projectId){
		$content["firstPageData"] = $this->form_model->getFirstPage($quest_id, $projectId);
		$content["topicData"] = $this->form_model->getTopic($topicId, $projectId);
		$content["currentTopicId"] = $topicId;
		$content["quest_id"] = $quest_id;
		$content["projectId"] = $projectId;
		$content['surveyStatus'] = $this->form_model->getSurveyStatus($quest_id, $projectId); 

		$content['checkInDetails'] = $this->form_model->fnHandleActiveUser($quest_id, $projectId); 

		if(sizeof($content['surveyStatus']["ic"])>0){
			$content["lockQuestions"] = true;
		}else{
			$content["lockQuestions"] = false;
		}		 		
		 
		$this->fnLoadQuestionPage($content);
	}
	
	
	public function fnLoadIntroPage($pageData){
		if($this->session->userdata('logged_in')) {
		     $session_data = $this->session->userdata('logged_in');
		     $headerData['mail'] = $session_data['mail'];
		     $headerData['name'] = $session_data['name'];
		     $headerData['rights'] = $session_data['rights'];
		     $pageData["userType"] = $session_data['userType'];

		}/*else{
		     //If no session, redirect to login page
		     redirect('login', 'refresh');
		}*/

		/*if($this->session->userdata('logged_in')) {
			$session_data = $this->session->userdata('logged_in');
			$pageData["userType"] = $session_data['userType'];
		}
		$pageData["userType"] = "external";*/
		//$pageData["userType"] = "external";

		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">',
			'2' => '<link rel="stylesheet" href="'.base_url("assets/css/app_form.css").'">'	
		);

		$headerData['headerfiles'] = $headerfiles;

		$footerData["activeTab"] = "dashboard";

		$this->load->view('global/header_form',$headerData);
   		$this->load->view('questionnaire/form_intro_view', $pageData);
   		$this->load->view('global/footer_form', $footerData);
	}

	public function fnLoadSummaryPage($pageData){
		if($this->session->userdata('logged_in')) {
			$session_data = $this->session->userdata('logged_in');
			$pageData["userType"] = $session_data['userType'];
		}
		//$pageData["userType"] = "external";

		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">',
			'2' => '<link rel="stylesheet" href="'.base_url("assets/css/app_form.css").'">'	
		);

		$headerData['headerfiles'] = $headerfiles;

		$footerData["activeTab"] = "dashboard";

		$this->load->view('global/header_form',$headerData);
   		$this->load->view('questionnaire/form_summary_view', $pageData);
   		$this->load->view('global/footer_form', $footerData);
	}


	public function fnLoadQuestionPage($pageData){
		if($this->session->userdata('logged_in')) {
			$session_data = $this->session->userdata('logged_in');
			$pageData["userType"] = $session_data['userType'];
		}
		//$pageData["userType"] = "external";

		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">',	
			'2' => '<link rel="stylesheet" href="'.base_url("assets/css/app_form.css").'">'
		);	
		$headerData['headerfiles'] = $headerfiles;

		$footerData["activeTab"] = "dashboard";

		$this->load->view('global/header_form',$headerData);
   		$this->load->view('questionnaire/form_questions_view', $pageData);
   		$this->load->view('global/footer_form', $footerData);	
	}




	//*****************************************************
	// UTILITY FUNCTIONS
	//*****************************************************

	public function submitAnswers(){
		$responseString = $this->input->post('responseString');
		$questionIdString = $this->input->post('questionIdString');
		$projectId = $this->input->post('projectId');
		$surveyId = $this->input->post('surveyId');
		$notesString = $this->input->post('notesString');
		
		$submissionSuccess = $this->form_model->submitAnswers($questionIdString, $responseString, $notesString, $projectId, $surveyId);
		echo $submissionSuccess;
		//echo "Success";
		/*if($submissionSuccess =="false"){
			echo "Fail";
		}else{
			echo $submissionSuccess;
		}*/
		
	}

	public function submitAssessment(){
		$projectId = $this->input->post('projectId');
		$surveyId = $this->input->post('surveyId');
		$submitLabel = $this->input->post('submitLabel');

		$submissionSuccess = $this->form_model->submitAssessment($projectId, $surveyId, $submitLabel);
	}

	public function approveAssessment(){
		$projectId = $this->input->post('projectId');
		$surveyId = $this->input->post('surveyId');
		$submitLabel = $this->input->post('submitLabel');

		$submissionSuccess = $this->form_model->approveAssessment($projectId, $surveyId, $submitLabel);
		//echo $submissionSuccess;
	}

	function checkSurveyProgress(){
		$projectId = $this->input->post('projectId');
		$surveyId = $this->input->post('surveyId');

		$progress = $this->form_model->checkProgress($projectId, $surveyId);

		echo $progress;
	}

	function exitQuestionnaire(){
		$processStatus = $this->form_model->checkOutUser();
		echo $processStatus;
	}


}