<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ExportPdf extends CI_Controller {


	public function __construct()
	{
		parent::__construct();
		$this->load->model('export_model');
	}

	public function index()
	{
		$this->load->helper('form');		
	}
	
	public function getpdf($quest_id, $projectId){
		 /*$content["firstPageData"] = $this->export_model->getFirstPage($quest_id, $projectId);
		 $content["quest_id"] = $quest_id;
		 $content["projectId"] = $projectId;*/
		 $content["firstPageData"] = $this->export_model->getFirstPage($quest_id, $projectId);
		 $content['surveyStatus'] = $this->export_model->getSurveyStatus($quest_id, $projectId); 
		 $questionsArray = array();
		 for($i=0; $i<count($content["firstPageData"]["topicDefArray"]); $i++){
		 	$topicId = $content["firstPageData"]["topicDefArray"][$i]["topicId"];
		 	$questionsInfoBlock =  $this->export_model->getTopic($topicId, $projectId);
		 	array_push($questionsArray, $questionsInfoBlock);
		 }

		 $content["questionBlock"] = $questionsArray;
		 $content["quest_id"] = $quest_id;

		 $this->load->view('questionnaire/pdf_view', $content);

		 //$this->fnLoadIntroPage($content);
	}

	public function fnLoadSummaryPage($pageData){
		if($this->session->userdata('logged_in')) {
			$session_data = $this->session->userdata('logged_in');
			$pageData["userType"] = $session_data['userType'];
		}
	

		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">',
			'2' => '<link rel="stylesheet" href="'.base_url("assets/css/app_form.css").'">'	
		);

		$headerData['headerfiles'] = $headerfiles;

		$footerData["activeTab"] = "dashboard";

		$this->load->view('global/header_form',$headerData);
   		$this->load->view('questionnaire/form_summary_view', $pageData);
   		$this->load->view('global/footer_form', $footerData);
	}


	
}