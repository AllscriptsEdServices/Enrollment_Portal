<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class TeamAdmin extends CI_Controller {	

	public function __construct()
	{
		parent::__construct();
		$this->load->model('teamadmin_model');
		
	}

	public function index()
	{		
		$this->load->helper('form');

		if($this->session->userdata('logged_in')) {
			$session_data = $this->session->userdata('logged_in');
			$content["members"] = $this->teamadmin_model->getMyTeam($session_data['projectId']);
			$this->fnLoadPage($content);
		}else{
			//If no session, redirect to login page
		     redirect('login', 'refresh');
		}
		//		
	}
	
	
	public function fnLoadPage($pageData){
		if($this->session->userdata('logged_in')) {
		     $session_data = $this->session->userdata('logged_in');
		     $headerData['mail'] = $session_data['mail'];
		     $headerData['name'] = $session_data['name'];
		     $headerData['rights'] = $session_data['rights'];
		     $headerData['userType'] = $session_data['userType'];
		     $pageData["userType"] = $session_data['userType'];
		}else{
		     //If no session, redirect to login page
		     redirect('login', 'refresh');
		}


		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">',
			'2' => '<link rel="stylesheet" href="'.base_url("assets/css/app_dashboard.css").'">'
		);
		$headerData['headerfiles'] = $headerfiles;

		$footerData["activeTab"] = "myTeam";

		$this->load->view('global/header',$headerData);
   		$this->load->view('myteam/teamadmin_view', $pageData);
   		$this->load->view('global/footer', $footerData);	

	}
	

	public function addMember(){
		$name = $this->input->post('name');
		$mail = $this->input->post('mail');
		$phone = $this->input->post('phone');

		$processStatus = $this->teamadmin_model->addMember($name, $mail, $phone);

		echo $processStatus;

	}

	
}