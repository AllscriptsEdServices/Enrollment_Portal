<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Internal_Mails extends CI_Controller {	



	public function __construct()

	{
		parent::__construct();
		//$this->load->model('teamstructure_model');	

	}



	public function index()
	{		
		//$this->load->helper('form');
		
	}
	

	public function send_login_mail(){
		$to_name = 'Terri Ferguson';
		$to_email = 'terri.ferguson@allscripts.com';
		$to_role = "Implementation Consultant";
		
	
	$this->load->library('email');
	
      $this->email->set_mailtype("html");
      $this->email->from('projectconnect@eduserv.myallscripts.com', 'Allcripts Project Connect');
      $this->email->to($to_email);      
      $this->email->bcc('vishwajit.menon@allscripts.com');
      
      $site_url = base_url("index.php/");
     

      $mailBody = "<!doctype html><meta http-equiv='X-UA-Compatible' content='IE=Edge'><html><head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8'> <style type='text/css'>.ExternalClass{display:block !important;}</style></head><body leftmargin='0' rightmargin='0' topmargin='0' bottommargin='0' bgcolor='#d9dadc' style='font-family:Verdana, Geneva, sans-serif;'>  <table width='100%' cellspacing='0' cellpadding='0' bgcolor='#d9dadc' style='padding:20px; font-family:Verdana, Geneva, sans-serif;'><tr> <td width='100%' bgcolor='#5B8F22' style='padding:0px 5px; height:52px; color:#fff'>Allscripts Project Connect </td></tr><tr>  <td width='100%' bgcolor='#FFFFFF' style='padding:10px'><table cellpadding='0' cellspacing='0'> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'> <p>Hi ".$to_name.",</p> <p>Welcome to the <b>Project Connect</b> Tool. The tool assists clients with viewing information about their implementation and also enables them to complete their Design Questionnaire.</p> <p>Your login credentials are given below.</p></br> </td> </tr> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'><table style='font-family:Verdana, Geneva, sans-serif;font-size:12px; padding:0px; border-top:1px solid #DDDDDD; border-right:1px solid #DDDDDD' cellpadding='0' cellspacing='0'><tr><td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD;text-align: center; font-size:16px' colspan='2' >Login Info</td></tr> <tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Portal URL</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$site_url."</td></tr> <tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Login Name</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$to_email."</td></tr><tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Temporary Password</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Welcome123</td></tr></table></td> </tr><tr><td style='padding:0px; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;'></br><p>For any issues you face using these details, you can contact <a href='mailto:vishwajit.menon@allscripts.com;'>support</a>.</p></td> </tr></table> </td></tr></table>  </body></html>";

      $this->email->subject("Welcome to Project Connect!");
      $this->email->message($mailBody);

      if($this->email->send()){
      	echo "Mail Sent to ".$to_email;
      }

    }



  }