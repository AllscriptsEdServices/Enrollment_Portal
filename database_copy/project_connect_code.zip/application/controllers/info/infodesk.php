<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class InfoDesk extends CI_Controller {	

	public function __construct()
	{
		parent::__construct();
		//$this->load->model('projectstatus_model');
		
	}

	public function index()
	{		
		$this->load->helper('form');

		$projectsData["cdhSearchString"] = "";
		$projectsData["orgNameSearchString"] = "";
		$projectsData["projectsList"] = array();

		$this->fnLoadPage($projectsData);
	}
	
	public function getStatus($projectId){	
		$projectArray = $this->projectstatus_model->getProjectDetails($projectId);
		$suiteDetailsArray = $this->projectstatus_model->getSuiteDetails($projectId, $projectArray["productId"]);

		$projectsData["projectInfo"] = $projectArray;
		$projectsData["stagesDetails"] = $suiteDetailsArray;
		$this->fnLoadPage($projectsData);
	}
	
	public function fnLoadPage($pageData){
		if($this->session->userdata('logged_in')) {
		     $session_data = $this->session->userdata('logged_in');
		     $headerData['mail'] = $session_data['mail'];
		     $headerData['name'] = $session_data['name'];
		     $headerData['rights'] = $session_data['rights'];
		     $headerData['userType'] = $session_data['userType'];
		     $pageData["userType"] = $session_data['userType'];
		}else{
		     //If no session, redirect to login page
		     redirect('login', 'refresh');
		}


		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">',
			'2' => '<link rel="stylesheet" href="'.base_url("assets/css/app_dashboard.css").'">'
		);
		$headerData['headerfiles'] = $headerfiles;

		$footerData["activeTab"] = "infoDesk";

		$this->load->view('global/header',$headerData);
   		$this->load->view('info/infodesk_view', $pageData);
   		$this->load->view('global/footer', $footerData);	

	}


	function getTemplateDetails(){		
		$resourceId = $this->input->post('resourceId');
		$projectId = $this->input->post('projectId');
		

		$resourceArray = $this->projectstatus_model->getTemplateDetails($resourceId, $projectId);

		echo json_encode($resourceArray);

	}

	
}