<?php //if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//header("Access-Control-Allow-Origin: *");
//header('Access-Control-Expose-Headers: Access-Control-Allow-Origin"');
class Getter_Setter extends CI_Controller {

	function __construct() {
	   parent::__construct();
	   $this->load->model('external_api_model','',TRUE);
	   //$this->output->set_header("Access-Control-Allow-Origin: *");
	}


	public function index()
	{		
		$this->load->helper('form');
   		/*$this->load->view('login/index');*/
	}	

	public function get_project_details($projectId){
		$this->output->set_header("Access-Control-Allow-Origin: *");
		$this->load->model('projectstatus_model','',TRUE);
		$project_details = $this->projectstatus_model->getProjectDetails($projectId);
		echo json_encode($project_details);
	}

	public function get_resource_details($resourceId){
		$this->output->set_header("Access-Control-Allow-Origin: *");
		$current_user_details = $this->external_api_model->getResourceArray($resourceId);
		echo json_encode($current_user_details);
	}


}