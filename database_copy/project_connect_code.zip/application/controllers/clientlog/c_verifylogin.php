<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_VerifyLogin extends CI_Controller {
  
   public $projectId = "";

   function __construct()
   {
     parent::__construct();
     $this->load->model('clientuser_model','',TRUE);
   }

   function index()
   {
     //This method will have the credentials validation
     $this->load->library('form_validation');

     $this->form_validation->set_rules('mail', 'mail', 'trim|required|xss_clean');
     $this->form_validation->set_rules('password', 'password', 'trim|required|xss_clean|callback_check_database');
     
     if($this->form_validation->run() == FALSE)
     {
       //Field validation failed.  User redirected to login page
       $this->load->view('login/c_login_view');
     }
     else
     {
       //Go to private area
      $url = '/dashboard/projectstatus/getStatus/'.$this->projectId;
       redirect($url , 'refresh');
     }
    
   }

   function check_database($password)
   {
     //Field validation succeeded.  Validate against database
     
     $mail = $this->input->post('mail');
     //$password = $this->input->post('password');
    
      //query the database
       $result = $this->clientuser_model->login($mail, $password);   
       if($result)
       {
         $sess_array = array();
         foreach($result as $row)
         {      
           $this->projectId = $row->projectId;  
           $sess_array = array(
             'id' => $row->userId,
             'mail' => $row->mail,
             'name' => $row->name,
             'userType' => "external",
             'projectId' => $row->projectId,
             'phone' => $row->phone,
             'rights' => $row->rights
           );
           $this->session->set_userdata('logged_in', $sess_array);

         }
         //echo "true";
         return TRUE;
       }
       else
       {
         //echo "false";
         $this->form_validation->set_message('check_database', 'Invalid email or password');
         return false;
       }  
     }
}

?>