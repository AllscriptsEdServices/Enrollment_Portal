<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class TeamStructure extends CI_Controller {	



	public function __construct()

	{

		parent::__construct();

		$this->load->model('teamstructure_model');

		$this->projectId = '';

	}



	public function index()
	{		
		$this->load->helper('form');

		$projectsData["cdhSearchString"] = "";
		$projectsData["orgNameSearchString"] = "";
		$projectsData["projectsList"] = array();

		$this->fnLoadPage($projectsData);
	}
	

	public function showCurrentTeam($projectId){

		$this->projectId = $projectId;	
		$projectsData["projectInfo"] = $this->teamstructure_model->getProjectDetails($projectId);	
		$projectsData["internalResources"] = $this->teamstructure_model->getInternalResources($projectId);
		$this->fnLoadPage($projectsData);
	}

	



	public function saveResource($toInsertResources, $projectId, $resourceType){
		$updateStatus = $this->teamstructure_model->setResource($toInsertResources, $projectId, $resourceType);
		if($updateStatus){
			$this->showCurrentTeam($projectId);
		}
	} 


	function updateConsultants(){		
		$ehr_consultants_string = $this->input->post('ehr_consultants_string');
		$pm_consultants_string = $this->input->post('pm_consultants_string');
		$projectId = $this->input->post('projectId');
		$productId = $this->input->post('productId');

		$processStatus = $this->teamstructure_model->updateConsultants($ehr_consultants_string, $pm_consultants_string, $projectId, $productId);
		echo $processStatus;
	}

	public function fnLoadPage($pageData){

		if($this->session->userdata('logged_in')) {
		     $session_data = $this->session->userdata('logged_in');
		     $headerData['mail'] = $session_data['mail'];
		     $headerData['name'] = $session_data['name'];
		     $headerData['rights'] = $session_data['rights'];
		     $headerData['userType'] = $session_data['userType'];
		}else{
		     //If no session, redirect to login page
		     redirect('login', 'refresh');
		}





		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'
		);	

		$headerData['headerfiles'] = $headerfiles;
		$footerData["activeTab"] = "team";


		$this->load->view('global/header',$headerData);
   		$this->load->view('team/team_structure_view', $pageData);
   		$this->load->view('global/footer', $footerData);	

	}

	function sendMail()
	{
	    $config = Array(
	  'protocol' => 'smtp',
	  'smtp_host' => 'ssl://smtp.googlemail.com',
	  'smtp_port' => 465,
	  'smtp_user' => 'xxx@gmail.com', // change it to yours
	  'smtp_pass' => 'xxx', // change it to yours
	  'mailtype' => 'html',
	  'charset' => 'iso-8859-1',
	  'wordwrap' => TRUE
	);

	        $message = '';
	        $this->load->library('email', $config);
	      $this->email->set_newline("\r\n");
	      $this->email->from('xxx@gmail.com'); // change it to yours
	      $this->email->to('xxx@gmail.com');// change it to yours
	      $this->email->subject('Resume from JobsBuddy for your Job posting');
	      $this->email->message($message);
	      if($this->email->send())
	     {
	      echo 'Email sent.';
	     }
	     else
	    {
	     show_error($this->email->print_debugger());
	    }

	}

	function fnSendActivationMail(){
		$projectId = $this->input->post('projectId');
		$mailArray = $this->teamstructure_model->getActivationMailDetails($projectId);

		$this->load->library('email');
		$this->email->set_mailtype("html");
		$this->email->from('projectconnect@eduserv.myallscripts.com', 'Allcripts Project Connect');
		$this->email->to($mailArray["mailTo"]);
		
		$this->email->cc($mailArray["cc_String"]);
		$this->email->bcc('vishwajit.menon@allscripts.com');

		
		$this->email->subject($mailArray["subject"]);
		$this->email->message($mailArray["mailBody"]);

		//$this->email->send();
		
		if($this->email->send()){
			echo date('Y-m-d G:i:s');
		}else{
			echo "Fail";
		}

		//echo $this->email->print_debugger();
	}

	

	

}