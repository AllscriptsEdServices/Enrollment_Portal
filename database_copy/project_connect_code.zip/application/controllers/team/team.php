<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Team extends CI_Controller {	

	public function __construct()
	{
		parent::__construct();
		$this->load->model('team_model');
		
	}

	public function index()
	{		
		$this->load->helper('form');

		$projectsData["cdhSearchString"] = "";
		$projectsData["orgNameSearchString"] = "";
		$projectsData["projectsList"] = array();

		$this->fnLoadPage($projectsData);
	}

	public function searchCDH(){		
		$this->load->library('form_validation');

   		/*$this->form_validation->set_rules('cdhNum', 'cdhNum', 'trim|required|xss_clean');
   		if ($this->form_validation->run() == FALSE) {
   			echo "Empty Form";
			//redirect(current_url());		
		}else{*/
			//redirect(current_url());	
			$projectsData["projectsList"] = $this->team_model->getProjectsByCDH($this->input->post('cdhNum'));			
			$projectsData["cdhSearchString"] = $this->input->post('cdhNum');
			$projectsData["orgNameSearchString"] = "";

			$this->fnLoadPage($projectsData);
		//}
	}
	
	public function searchOrgName(){		
		$this->load->library('form_validation');
   		
		$projectsData["projectsList"] = $this->team_model->getProjectsByOrgName($this->input->post('organizationName'));
		$projectsData["cdhSearchString"] = "";
		$projectsData["orgNameSearchString"] = $this->input->post('organizationName');
		$this->fnLoadPage($projectsData);
	
	}

	public function fnLoadPage($pageData){
		if($this->session->userdata('logged_in')) {
		     $session_data = $this->session->userdata('logged_in');
		     $headerData['mail'] = $session_data['mail'];
		     $headerData['name'] = $session_data['name'];		    
		     $headerData['rights'] = $session_data['rights'];
		     $headerData['userType'] = $session_data['userType'];		     
		}else{
		     //If no session, redirect to login page
		     redirect('login', 'refresh');
		}


		$headerfiles = array(
			'1' => '<link rel="stylesheet" href="'.base_url("assets/css/app_main.css").'">'
		);	
		$headerData['headerfiles'] = $headerfiles;
		$footerData["activeTab"] = "team";

		$this->load->view('global/header',$headerData);
   		$this->load->view('team/team_view', $pageData);
   		$this->load->view('global/footer', $footerData);	

	}
	
}