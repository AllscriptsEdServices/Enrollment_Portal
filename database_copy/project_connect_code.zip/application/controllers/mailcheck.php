<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Mailcheck extends CI_Controller {	



	public function __construct()

	{

		parent::__construct();

		$this->load->model('teamstructure_model');

		$this->projectId = '';

	}



	public function index()
	{		
		$this->load->helper('form');
		
	}
	

	

	function sendMail()
	{
	    $config = Array(
		  'protocol' => 'smtp',
		  'smtp_host' => 'ssl://smtp.googlemail.com',
		  'smtp_port' => 465,
		  'smtp_user' => 'xxx@gmail.com', // change it to yours
		  'smtp_pass' => 'xxx', // change it to yours
		  'mailtype' => 'html',
		  'charset' => 'iso-8859-1',
		  'wordwrap' => TRUE
		);

	      $message = '';
	      //$this->load->library('email', $config);
	      $this->load->library('email');
	      $this->email->set_newline("\r\n");
	      $this->email->from('projectconnect@eduserv.myallscripts.com', 'Project Connect'); // change it to yours
	      $this->email->to('vishwajitrmenon@gmail.com, vishwajit.menon@allscripts.com, zahrah.s1@gmail.com');// change it to yours
	      $this->email->subject('Checking Mail from Hostgator');
	      $this->email->message("Test Message");
	      if($this->email->send())
	      {
	      	echo 'Email sent.';
	      }
	      else
	      {
	      	show_error($this->email->print_debugger());
	      }

	}

	/*function fnSendActivationMail(){
		$projectId = $this->input->post('projectId');
		$mailArray = $this->teamstructure_model->getActivationMailDetails($projectId);

		$this->load->library('email');
		$this->email->set_mailtype("html");
		$this->email->from('vishwajit.menon@allscripts.com', 'Allcripts Project Connect');
		$this->email->to($mailArray["mailTo"]);
		//$this->email->cc($mailArray["mailTo"]);
		$this->email->bcc('vishwajit.menon@allscripts.com');

		//$mailBody = $this->fnGetMailBody();
		$this->email->subject($mailArray["subject"]);
		$this->email->message($mailArray["mailBody"]);

		//$this->email->send();
		
		if($this->email->send()){
			echo date('Y-m-d G:i:s');
		}else{
			echo "Fail";
		}

		//echo $this->email->print_debugger();
	}*/

	
	

}