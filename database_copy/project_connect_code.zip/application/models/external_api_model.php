<?php
header("Access-Control-Allow-Origin: *");

Class External_API_Model extends CI_Model
{
  public function __construct()
  {
    $this->load->database();
    $this->output->set_header("Access-Control-Allow-Origin: *");
  }


  //**********************************************************************************************************
  // UTILITY FUNCTIONS
  //**********************************************************************************************************
  function getResourceName($resourceId){
    //echo "Resource is = ".empty($resourceId)."<br>";
    if(empty($resourceId)){
      return "";
    }else{
      $query = $this->db->get_where('allscripts_users', array('id' => $resourceId));    
      $resultArray = $query->row_array(); 
      return $resultArray;
    }  

  }

  function getResourceArray($resourceId){
    if(empty($resourceId)){
      return "";
    }else{
      $query = $this->db->get_where('allscripts_users', array('id' => $resourceId));
      $resultArrayProject = $query->row_array(); 
      return $resultArrayProject;
    }  
  }

  function getCurrentUser(){
      $session_data = $this->session->userdata('logged_in');
      $userData["id"] = $session_data['id'];
      $userData["mail"] = $session_data['mail'];
      $userData["userType"] = $session_data['userType'];
      $userData["projectId"] = $session_data['projectId'];
      $userData["phone"] = $session_data['phone'];
      return ($userData);
  }

  //Used function from here https://thebarton.org/php-format-phone-number-function/
  function format_phone_us($phone) {    

    //****************** Solution 2 ***************************
    // Allow only Digits, remove all other characters.
    $phone = preg_replace("/[^\d]/","",$phone);
    // get number length.
    $length = strlen($phone);
    // if number = 10
    if($length == 10) {
      $phone = preg_replace("/^1?(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $phone);
    }
    
    return $phone;

  }



} //  END OF CLASS DECLARATION


?>