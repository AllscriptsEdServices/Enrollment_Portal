<?php
Class ProjectStatus_Model extends CI_Model
{
  var $productId = 0;

  public function __construct()
  {
    $this->load->database();
  }


  function getProjectDetails($projectId){
    $query = $this->db->get_where('projects', array('projectId' => $projectId));
    //return $query->row_array(); 
    $resultArrayProject = $query->row_array();
    $resultArrayProject["allscriptsPMName"] = $this->getResourceName($resultArrayProject["allscriptsPM"]);
    $resultArrayProject["allscriptsAPMName"] =  $this->getResourceName($resultArrayProject["allscriptsAPM"]);
    
    $this->productId = $resultArrayProject["productId"];

    $consolidatedConsultants = $this->getAllConsultantsArray($resultArrayProject["ehrConsultants"], $resultArrayProject["pmConsultants"], $resultArrayProject["productId"]);
    $resultArrayProject["consolidatedConsultants"] = $consolidatedConsultants;
    

    //Get Client Details
    $query2 = $this->db->get_where('client_users', array('userId' => $resultArrayProject["primaryContact"]));
    $resultArrayClient = $query2->row_array(); 

    $resultArrayProject["primaryContactName"] = $resultArrayClient["name"];
    $resultArrayProject["primaryContactPhone"] = $resultArrayClient["phone"];
    $resultArrayProject["primaryContactEmail"] = $resultArrayClient["mail"];

    return $resultArrayProject;
  }

  function getAllConsultantsArray($ehr_consultants_string, $pm_consultants_string, $productId){
    $allConsultantsArray = array();

    if(trim($ehr_consultants_string) != ""){
      $ehr_consultants_id = explode("_", $ehr_consultants_string);
      foreach ($ehr_consultants_id as $consultantId) {
        $consultantInfo = $this->getResourceArray($consultantId);
        $consultantInfo["projectRole"] = 1;
        $consultantInfo["phone"] = $this->format_phone_us($consultantInfo["phone"]);
        array_push($allConsultantsArray, $consultantInfo);
      }
    }
    
    if(trim($pm_consultants_string) != ""){
      $pm_consultants_id = explode("_", $pm_consultants_string);
      foreach ($pm_consultants_id as $consultantId) {
        $consultantInfo = $this->getResourceArray($consultantId);
        $consultantInfo["projectRole"] = 2;
        $consultantInfo["phone"] = $this->format_phone_us($consultantInfo["phone"]);
        array_push($allConsultantsArray, $consultantInfo);      
      }   
    }

    return $allConsultantsArray;
  }

  function getSuiteDetails($projectId, $productId, $projectType){
    
    $currentUser = $this->getCurrentUser();    
    if($currentUser["userType"] == "external"){
      $query_param_array = array('productId'=>0, 'visibility_project_type'=>$projectType, 'visibility_for_client'=>1);
    }else{
      $query_param_array = array('productId'=>0, 'visibility_project_type'=>$projectType);
    }
    

    $suiteArray = array();

    if($productId == 3){ 

      $suiteArray[0]["stageName"] = "Professional EHR";

      $query = $this->db->get('stages');       
      $this->db->order_by("stageSequenceNum", "asc");  
      $query_param_array["productId"] = 1;
      $query = $this->db->get_where('stages', $query_param_array);
      
      $suiteArray[0]["stages_definition"] = $query->result_array();
      for($i=0; $i<sizeof($suiteArray[0]["stages_definition"]); $i++){
        $suiteArray[0]["templates_definition"][$i] = $this->getTemplates($suiteArray[0]["stages_definition"][$i]["stageId"], $productId);
      }

      $suiteArray[1]["stageName"] ="Allscripts PM";

      $query = $this->db->get('stages');       
      $this->db->order_by("stageSequenceNum", "asc");
      $query_param_array["productId"] = 2;
      $query = $this->db->get_where('stages', $query_param_array);
     
      $suiteArray[1]["stages_definition"] = $query->result_array();
      for($i=0; $i<sizeof($suiteArray[1]["stages_definition"]); $i++){
        $suiteArray[1]["templates_definition"][$i] = $this->getTemplates($suiteArray[1]["stages_definition"][$i]["stageId"], $productId);
      }

    }else if($productId == 1){  
      $suiteArray[0]["stageName"] = "Professional EHR";

      $this->db->order_by("stageSequenceNum", "asc");  
      $query_param_array["productId"] = 1;
      $query = $this->db->get_where('stages', $query_param_array);
      
      $suiteArray[0]["stages_definition"] = $query->result_array();
      for($i=0; $i<sizeof($suiteArray[0]["stages_definition"]); $i++){
        $suiteArray[0]["templates_definition"][$i] = $this->getTemplates($suiteArray[0]["stages_definition"][$i]["stageId"], $productId);
      }

    }else{   
      $suiteArray[1]["stageName"] ="Allscripts PM";

      $this->db->order_by("stageSequenceNum", "asc");  
      $query_param_array["productId"] = 2;
      $query = $this->db->get_where('stages', $query_param_array);
      
      $suiteArray[1]["stages_definition"] = $query->result_array();
      for($i=0; $i<sizeof($suiteArray[1]["stages_definition"]); $i++){
        $suiteArray[1]["templates_definition"][$i] = $this->getTemplates($suiteArray[1]["stages_definition"][$i]["stageId"], $productId);
      }
     // $suiteArray[0]["template_definition"]
    }

    return $suiteArray;
  }


  function getTemplates($stageId, $productId){
    $currentUser = $this->getCurrentUser();    

    $show_dependent_criteria = ($productId == 3) ? "suite" : "single";

    $this->db->order_by("stageSequenceNum", "asc"); 

    if($currentUser["userType"] == "external"){
      $query = $this->db->get_where('template_items_tb', array('stageId' => $stageId, 'menu_position' => 'parent', "visibility"=>'client'));
    }else{
      $query = $this->db->get_where('template_items_tb', array('stageId' => $stageId, 'menu_position' => 'parent'));
    }
    
    $templates_array = $query->result_array(); 

    for($i=0; $i<count($templates_array); $i++){
      // Check if it depends on whether the client has Pro Suite or individual
      if($templates_array[$i]["isProductDependant"] == 1){
        //
        if($templates_array[$i]["forProduct"] != $show_dependent_criteria){
          unset($templates_array[$i]);
        }
      }
    }
   
    return $templates_array;
  }


  //**********************************************************************************************************
  // TEMPLATE LEVEL FUNCTIONS
  //**********************************************************************************************************
  function getTemplateDetails($resourceId, $projectId, $productId){      
      $currentUser = $this->getCurrentUser();   
      $root_item = array();
      $child_items = array();
      //$show_dependent_criteria = ($this->productId == 3) ? "suite" : "single";
      $show_dependent_criteria = ($productId == 3) ? "suite" : "single";
           
      $root_item = $this->get_single_template($resourceId, $projectId);

      if($currentUser["userType"] == "external"){
        $query = $this->db->get_where('template_items_tb', array('parent_node_id' => $resourceId, 'menu_position'=>"child", "visibility"=>'client'));
      }else{
        $query = $this->db->get_where('template_items_tb', array('parent_node_id' => $resourceId, 'menu_position'=>"child"));
      }      
      $child_results = $query->result_array();   

      foreach ($child_results as $single_item) {        
        // Check if it depends on whether the client has Pro Suite or individual
        if($single_item["isProductDependant"] == 1){
            if($single_item["forProduct"] == $show_dependent_criteria){
                $item_detail = $this->get_single_template($single_item["resourceId"], $projectId);
                array_push($child_items, $item_detail);
            }
        }else{
            $item_detail = $this->get_single_template($single_item["resourceId"], $projectId);
            array_push($child_items, $item_detail);
        }

      }         
      

      $return_array = array($root_item, $child_items);

      return $return_array;
  }


  function get_single_template($resourceId, $projectId){
      $query = $this->db->get_where('template_items_tb', array('resourceId' => $resourceId));
      $resultArray = $query->row_array();    

      switch ($resultArray["resourceType"] ) {
        case 'survey':
          $surveyURL = base_url("index.php/questionnaire/form/getQuest/")."/".$resultArray["resourceURL/ID"]."/".$projectId;
          $resultArray["gotoURL"] = '<a href="'.$surveyURL.'" target="_blank" style="font-size:18px">Go to Questionnaire</a>';
          break;

        case 'info_date':
          $surveyURL = base_url("index.php/questionnaire/form/getQuest/")."/".$resultArray["resourceURL/ID"]."/".$projectId;
          $resultArray["preset_date"] = $this->get_date($resourceId, $projectId);
          break;

        case 'external_survey':
          $surveyURL = base_url("index.php/questionnaire/form/getQuest/")."/".$resultArray["resourceURL/ID"]."/".$projectId;
          if($this->check_create_assessment_link($projectId, $resourceId, $resultArray["resourceURL/ID"] )){
            $resultArray["assessment_details"] = $this->get_external_assessment_status($projectId, $resourceId);
          }
          
          break;        
        
        default:
          $resultArray["gotoURL"] = "";
          break;
      }


      return $resultArray;
  }

  //FUNCTION to check if an assignId exists for this project/template combination. Else create one.
  function check_create_assessment_link($projectId, $resourceId, $surveyId){
    $goAhead = true;
    
    //Check if a mapping entry exists for this project and resourceId
    $query = $this->db->get_where('external_quest_mapping', array('projectId' => $projectId, 'resourceId'=>$resourceId));    
    // if no such entry exists, create a mapping
    if($query->num_rows()<=0){  
        $data_mapping = array(
            'projectId' =>$projectId,
            'resourceId' => $resourceId,            
            'status' => 0            
        );

        $this->db->insert('external_quest_mapping', $data_mapping);
        $new_map_id =  $this->db->insert_id();      

        
        //Request the assessment toolwith the newly created mapping id, project id, surveyid. To create an assignment for this mapping.
        $url = CONSTANT_Assessment_Portal_URL.'/external_api/set_assessment_assign.php?surveyId='.$surveyId.'&projectId='.$projectId.'&mapId='.$new_map_id;
        $ch = curl_init();    
        // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);    
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);    
        curl_setopt($ch, CURLOPT_URL, $url);    
        $assign_response = curl_exec($ch);    
        curl_close($ch);   
        $assign_response = json_decode($assign_response);

        // If the assignment has been successfully added i.e. assignId is greater than 0, UPDATE the recently created mapId entry with assess_assign_id
        if($assign_response->assignId != 0){
          $this->db->where('mapId', $new_map_id);
          $this->db->update('external_quest_mapping', array('assess_assign_id' => $assign_response->assignId) );
        }else{
          $goAhead = false;
        }

    }

    
   return $goAhead;

  }

  // FUNCTION to get the template details of External Assessment for this project and resourceId. Completion Status/URL/ etc
  function get_external_assessment_status($projectId, $resourceId){
    $return_array = array(
      "assignId"=>0, 
      "completion_status"=>0, 
      "completed_date"=>0, 
      "entry_exists"=>"false", 
      "survey_url"=>"", 
      "survey_report"=>""
      );

    $query = $this->db->get_where('external_quest_mapping', array('projectId' => $projectId, 'resourceId'=>$resourceId));    
    if($query->num_rows()>0){
      $mapped_array = $query->row_array();
      
      $url = CONSTANT_Assessment_Portal_URL.'/external_api/get_assessment_status.php?assignId='.$mapped_array["assess_assign_id"];
      $ch = curl_init();    
      // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);    
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);    
      curl_setopt($ch, CURLOPT_URL, $url);    
      $assessment_response = curl_exec($ch);    
      curl_close($ch);   
      $assessment_response = json_decode($assessment_response);

      $currentUser = $this->getCurrentUser();

      if($assessment_response){
        $return_array["entry_exists"] = $assessment_response->entry_exists;
        $return_array["completion_status"] = $assessment_response->completion_status;
        $return_array["completed_date"] = $assessment_response->completed_date;
        $return_array["surveyId"] = $assessment_response->surveyId;
        $return_array["assignId"] = $mapped_array["assess_assign_id"];
        $return_array["survey_url"] = CONSTANT_Assessment_Portal_URL.'Form/defaultForm_intro.php?asi='.$assessment_response->assignId.'&sur='.$assessment_response->surveyId.'&u='.$currentUser["id"];
        $return_array["survey_report"] = CONSTANT_Assessment_Portal_URL.'Report_Center/defaultForm_pdf_report.php?asi='.$assessment_response->assignId.'&sur='.$assessment_response->surveyId;
      }      

    }    

    return $return_array;

  } 




  function set_date($resourceId, $projectId, $call_date, $dateType){
    $currentUser = $this->getCurrentUser();

    $query = $this->db->get_where('dates_tb', array('resourceId' => $resourceId, 'projectId'=>$projectId, 'dateType'=>$dateType));    
    if($query->num_rows()>0){

      $existing_date = $query->row_array();
      $this->db->where('dateId', $existing_date["dateId"]);
      $this->db->update('dates_tb', array('date' => $call_date, 'lastModifiedBy'=>$currentUser["id"], 'lastModifiedOn'=>date('Y-m-d G:i:s')));
      $returnString = $existing_date["dateId"];
    }else{

        $data_user = array(
            'projectId' =>$projectId,
            'dateType' => $dateType,            
            'resourceId' => $resourceId,
            'date' => $call_date,
            'createdBy' => $currentUser["id"],
            'createdOn' => date('Y-m-d G:i:s')
        );

        $this->db->insert('dates_tb', $data_user);
        $returnString =  $this->db->insert_id(); 

    }
    
    return $call_date;
    //return $returnString;
  }

  function get_date($resourceId, $projectId){
    $query = $this->db->get_where('dates_tb', array('resourceId' => $resourceId, 'projectId'=>$projectId));    
    if($query->num_rows()>0){
      $existing_date = $query->row_array();
      return $existing_date["date"];
    }else{
      return false;
    }
  }



  //**********************************************************************************************************
  // UTILITY FUNCTIONS
  //**********************************************************************************************************
  function getResourceName($resourceId){
    //echo "Resource is = ".empty($resourceId)."<br>";
    if(empty($resourceId)){
      return "";
    }else{
      $query = $this->db->get_where('allscripts_users', array('id' => $resourceId));    
      $resultArray = $query->row_array(); 
      return $resultArray;
    }  

  }

  function getResourceArray($resourceId){
    if(empty($resourceId)){
      return "";
    }else{
      $query = $this->db->get_where('allscripts_users', array('id' => $resourceId));
      $resultArrayProject = $query->row_array(); 
      return $resultArrayProject;
    }  
  }

  function getCurrentUser(){
      $session_data = $this->session->userdata('logged_in');
      $userData["id"] = $session_data['id'];
      $userData["mail"] = $session_data['mail'];
      $userData["userType"] = $session_data['userType'];
      $userData["projectId"] = $session_data['projectId'];
      $userData["phone"] = $session_data['phone'];
      return ($userData);
    }

  //Used function from here https://thebarton.org/php-format-phone-number-function/
  function format_phone_us($phone) {    

    //****************** Solution 2 ***************************
    // Allow only Digits, remove all other characters.
    $phone = preg_replace("/[^\d]/","",$phone);
    // get number length.
    $length = strlen($phone);
    // if number = 10
    if($length == 10) {
      $phone = preg_replace("/^1?(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $phone);
    }
    
    return $phone;

  }



} //  END OF CLASS DECLARATION


?>