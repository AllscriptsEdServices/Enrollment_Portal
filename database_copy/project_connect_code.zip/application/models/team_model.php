<?php
Class Team_Model extends CI_Model
{
  public function __construct()
  {
    $this->load->database();    
  }

  function getProductTypes(){  
    $query = $this->db->get('product_suites');
    return $query->result_array();
  }

  function getProjectsByCDH($searchString){ 
      $this->db->like('cdhNum', $searchString, 'both'); 
      $this->db->from('projects');
      $query = $this->db->get();
      //return $query->result_array(); 
      
      $resultArray = $query->result_array(); 

      for($i=0;$i<sizeof($resultArray);$i++){
          $productSuiteArray = $this->getProductName($resultArray[$i]["productId"]);     
          $resultArray[$i]["productName"] = $productSuiteArray["productName"];
      }

      return $resultArray;
  }

   function getProjectsByOrgName($searchString){
      $this->db->like('organizationName', $searchString, 'both'); 
      $this->db->from('projects');
      $query = $this->db->get();
      //return $query->result_array();
      $resultArray = $query->result_array(); 

      for($i=0;$i<sizeof($resultArray);$i++){
          $productSuiteArray = $this->getProductName($resultArray[$i]["productId"]);     
          $resultArray[$i]["productName"] = $productSuiteArray["productName"];
      }

      return $resultArray;
  }

  function getProductName($productId){   
    $query = $this->db->get_where('product_suites', array('id' => $productId));
    return $query->row_array(); 
  }

  

  
}


?>

