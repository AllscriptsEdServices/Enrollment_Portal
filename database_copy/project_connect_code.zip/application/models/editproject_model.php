<?php
Class EditProject_Model extends CI_Model
{

  var $hosting_types = array("3rd Party Hosted", "Cloud Hosted", "ASP Hosted", "On Premise");
  var $project_types = array("New", "Existing");

  public function __construct()
  {
    $this->load->database();    
  }

    function getProductTypes(){  
      $query = $this->db->get('product_suites');
      return $query->result_array();
    }

    function getConversions(){
      /*$this->db->select('conversionId, conversionName, productId, extra');
      $this->db->from('allscripts_users');
      $query = $this->db->get();*/
      $query = $this->db->get('conversions');
      return $query->result_array();
    }


    function getInterfaces(){  
      $query = $this->db->get('interfaces');
      return $query->result_array();
    }

    function getAddOns(){  
      $query = $this->db->get('addons');
      return $query->result_array();
    }


    function getProjectDetails($projectId){
      $queryProject = $this->db->get_where('projects', array('projectId' =>$projectId));
      //$resultProject = $queryProject->row_array();
      return $queryProject->row_array();
    }

    function getPrimaryContact($projectId){
      $queryUser = $this->db->get_where('client_users', array('projectId' =>$projectId, 'rights'=>'primary'));
      //$resultUser = $queryUser->row_array();
      return $queryUser->row_array();
    }



    
    function updateProject($clientAdminData, $projectData){

      $data_userUpdate = array(
          'name' =>$clientAdminData["name"],
          'mail' => $clientAdminData["mail"],
          'phone' => $clientAdminData["phone"]         
      );   
      $this->db->where('userId', $clientAdminData["userId"]);
      $this->db->update('client_users', $data_userUpdate);
   

      $data_projectUpdate = array(
          'organizationName' =>$projectData["organizationName"],
          'cdhNum' => $projectData["cdhNum"],      
          'address' => $projectData["address"],
          'productId' => $projectData["productId"],
          'hostingType' => $projectData["hostingType"],         
          'conversions' => $projectData["conversions"],
          'interfaces' => $projectData["interfaces"],
          'addOns' => $projectData["addOns"],           
          'phone' => $clientAdminData["phone"]
      );

      $this->db->where('projectId', $projectData["projectId"]);
      $this->db->update('projects', $data_projectUpdate);
      
      return "Success";

    }


    function getCurrentUser(){
      $session_data = $this->session->userdata('logged_in');
      $userData["id"] = $session_data['id'];
      $userData["mail"] = $session_data['mail'];
      $userData["userType"] = $session_data['userType'];
      $userData["projectId"] = $session_data['projectId'];
      $userData["phone"] = $session_data['phone'];
      return ($userData);
    }



}

?>