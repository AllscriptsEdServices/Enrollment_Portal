<?php
Class TeamAdmin_Model extends CI_Model
{
    public function __construct()
    {
      $this->load->database();      
    }



   function getMyTeam($projectId){
      $currentUser = $this->getCurrentUser();
      $query = $this->db->get_where('client_users', array('userId != ' => $currentUser["id"], 'projectId'=>$projectId));
      $team_array = $query->result_array();
      for($i=0; $i<count($team_array); $i++){
        $team_array[$i]["phone"] = $this->format_phone_us($team_array[$i]["phone"]);
      }

    
      return  $team_array;
   }


  function getCurrentUser(){

    $session_data = $this->session->userdata('logged_in');
    $userData["id"] = $session_data['id'];
    $userData["name"] = $session_data['name'];
    $userData["mail"] = $session_data['mail'];
    $userData["userType"] = $session_data['userType'];
    $userData["projectId"] = $session_data['projectId'];
    $userData["phone"] = $session_data['phone'];
    return ($userData);

  }

  function addMember($name, $mail, $phone){
      $query = $this->db->get_where('client_users', array('mail'=>$mail));
      $returnString = "";
      if($query->num_rows()>0){
        $returnString = "User Exists";
      }else{
        $currentUser = $this->getCurrentUser();

        //Add the client primary contact in the client_users table and note userId
        $data_user = array(
            'name' =>$name,
            'mail' => $mail,
            'phone' => $phone,            
            'projectId' => $currentUser["projectId"],     
            'password' => md5("Welcome123"),
            'rights' => "secondary",
            'addedBy' => $currentUser["id"],
            'addedDate' => date("Y-m-d")
        );

        $this->db->insert('client_users', $data_user);
        $returnString =  $this->db->insert_id(); 


        
        $site_url = base_url("index.php/clientlog/c_login");
        $mailBody = "<!doctype html><meta http-equiv='X-UA-Compatible' content='IE=Edge'><html><head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8'> <style type='text/css'>.ExternalClass{display:block !important;}</style></head><body leftmargin='0' rightmargin='0' topmargin='0' bottommargin='0' bgcolor='#d9dadc' style='font-family:Verdana, Geneva, sans-serif;'>  <table width='100%' cellspacing='0' cellpadding='0' bgcolor='#d9dadc' style='padding:20px; font-family:Verdana, Geneva, sans-serif;'><tr> <td width='100%' bgcolor='#5B8F22' style='padding:0px 5px; height:52px; color:#fff'>Allscripts Project Connect</td></tr><tr>  <td width='100%' bgcolor='#FFFFFF' style='padding:10px'><table cellpadding='0' cellspacing='0'> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'> <p>Hello ".$name.",</p> <p>This is an automatic message to notify you that <b>".$currentUser["name"]."</b>, has enrolled you in <b>Project Connect</b>.  This tool can be used to view the phases of the implementation, and to assist with any tasks as needed. Please contact <a href='mailTo:".$currentUser["mail"]."'>".$currentUser["name"]."</a> with any questions about using this tool.</p><br> </td> </tr> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'><table style='font-family:Verdana, Geneva, sans-serif;font-size:12px; padding:0px; border-top:1px solid #DDDDDD; border-right:1px solid #DDDDDD' cellpadding='0' cellspacing='0'><tr><td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD;text-align: center; font-size:16px' colspan='2' >Login Info</td></tr><tr> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Portal URL</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' ><a href='".$site_url."'>".$site_url."</a></td></tr><tr> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Username</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$mail."</td></tr><tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Password</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Welcome123</td></tr></table></td> </tr><tr><td style='padding:0px; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;'></br><p>For any issues you face using these details, you can contact <a href='mailto:vishwajit.menon@allscripts.com;'>support</a>.</p></br></td>  </tr>  <tr><td style='padding:3px; color:#000000; font-size:11px; font-family:Verdana, Geneva, sans-serif;' align='center' bgcolor='#CCCCCC'><p> PLEASE DO NOT REPLY TO THIS MESSAGE. This is an unmonitored system mailbox.</p></td></tr> </table> </td></tr></table>  </body></html>";

        $this->load->library('email');
        $this->email->set_mailtype("html");
        $this->email->from('projectconnect@eduserv.myallscripts.com', 'Allcripts Project Connect');
        $this->email->to($mail);
        //$this->email->cc($mailArray["mailTo"]);
        $this->email->bcc('vishwajit.menon@allscripts.com');

        //$mailBody = $this->fnGetMailBody();
        $this->email->subject('Welcome to Allscripts Project Connect!');
        $this->email->message($mailBody);
        $this->email->send();

      }

      return $returnString;
  }


//Used function from here https://thebarton.org/php-format-phone-number-function/
  function format_phone_us($phone) {
    //****************** Solution 1 ***************************
    // note: making sure we have something
    /*if(!isset($phone{3})) { return ''; }
    // note: strip out everything but numbers 
    $phone = preg_replace("/[^0-9]/", "", $phone);
    $length = strlen($phone);
    switch($length) {
    case 7:
      return preg_replace("/([0-9]{3})([0-9]{4})/", "$1-$2", $phone);
    break;
    case 10:
     return preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})/", "($1) $2-$3", $phone);
    break;
    case 11:
    return preg_replace("/([0-9]{1})([0-9]{3})([0-9]{3})([0-9]{4})/", "$1($2) $3-$4", $phone);
    break;
    default:
      return $phone;  
    break;
    }*/

    //****************** Solution 2 ***************************
    // Allow only Digits, remove all other characters.
    $phone = preg_replace("/[^\d]/","",$phone);
    // get number length.
    $length = strlen($phone);
    // if number = 10
    if($length == 10) {
      $phone = preg_replace("/^1?(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $phone);
    }
    
    return $phone;

  }



} // End of class definition


?>