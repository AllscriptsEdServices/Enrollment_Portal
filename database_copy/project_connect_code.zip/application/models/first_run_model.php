<?php
Class First_Run_Model extends CI_Model
{
  public function __construct()
  {
    $this->load->database();    
  }


  function check_design_call_mails(){ 
    $return_string =  "";
    $today = date("Y-m-d");
    $backcheck_days = 4;

    //Check if the Daily Processes routine has been run today. If not, run it.
    $query = $this->db->get_where('check_first_run', array('runDate' => $today));
    if($query->num_rows() <= 0){
      //$return_string .= $this->process_design_call_dates($today);
      $this->process_design_call_dates();
    }  

    return $return_string;
  }


  function process_design_call_dates(){
    $today = date("Y-m-d");
    $return_string = "";

    // Select only those Design Call Entries whose Reminder mails have NOT been sent
    $query = $this->db->get_where('dates_tb', array('dateType' => "design_call", 'reminder_mail_sent' => 0));
    $design_calls_list = $query->result_array();
    foreach ($design_calls_list as $design_call_entry) {

      $design_date = $design_call_entry["date"];
      $reminder_earliest_date = date("Y-m-d", strtotime("$design_date - 14 Days")); // Design Date - 14 days (2 weeks)
      $reminder_latest_date = date("Y-m-d", strtotime("$design_date - 7 Days"));    // Design Date - 7 days (1 week)

      //$return_string .= $design_date."**".$reminder_earliest_date."**".$reminder_earliest_date."  ||  ";
      //***********************************************************************************************************
      // If  (Design Date - 14 days) <= TODAY <= (Design Date - 7 days) || Check whether valid period to send mail
      //***********************************************************************************************************
      if( ( strtotime($today) >=  strtotime($reminder_earliest_date) ) && ( strtotime($today) <= strtotime($reminder_latest_date) ) ){
        $this->send_design_call_reminder($design_call_entry);
      }
      
    }

    // Update check_first_run table for today
    $data_first_run = array(
        'runDate' => $today,
        'status' => 1,
        'runtimestamp' => date('Y-m-d G:i:s')
    );

    $this->db->insert('check_first_run', $data_first_run);
    //$this->db->insert_id(); 
    //return $return_string;
  }


  function send_design_call_reminder($design_call_entry){

    //Find primary contact details for the project
    $this->db->select('projects.projectId, client_users.userId, client_users.name, client_users.mail');
    $this->db->from('projects');      
    $this->db->join('client_users', 'projects.primaryContact = client_users.userId');
    $this->db->where('projects.projectId', $design_call_entry["projectId"]);
    $query = $this->db->get();
    $contact_details = $query->row_array();

    //Get the Questionnaire Name
    $this->db->select('resourceName');    
    $query = $this->db->get_where( 'template_items_tb', array('resourceId' => $design_call_entry["resourceId"]) );    
    $result_array = $query->row_array();
    $template_name = $result_array["resourceName"];

    //Send the Reminder email
    $this->load->library('email');
    $this->email->set_mailtype("html");
    $this->email->from('projectconnect@eduserv.myallscripts.com', 'Allcripts Project Connect');
    $this->email->to($contact_details["mail"]);  
    $this->email->bcc('vishwajit.menon@allscripts.com');    
    
    $site_url = base_url("index.php/clientlog/c_login");
   
    $mailBody = '<!doctype html><meta http-equiv="X-UA-Compatible" content="IE=Edge"><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">.ExternalClass{display:block !important;}</style></head><body leftmargin="0" rightmargin="0" topmargin="0" bottommargin="0" bgcolor="#d9dadc" style="font-family:Verdana, Geneva, sans-serif;"><table width="100%" cellspacing="0" cellpadding="0" bgcolor="#d9dadc" style="padding:20px; font-family:Verdana, Geneva, sans-serif;"> <tr><td width="100%" bgcolor="#5B8F22" style="padding:0px 5px; height:52px; color:#fff">  Allscripts Project Connect  </td> </tr> <tr><td width="100%" bgcolor="#FFFFFF" style="padding:10px">  <table cellpadding="0" cellspacing="0"><tr> <td style="font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;">This is a gentle reminder that your <b>'.$template_name.'</b> is scheduled for <b>'.$design_call_entry["date"].'</b>. The corresponding questionnaire needs to be completed 1 Week prior to your Design Call. You can log into Project Connect to complete this.</br></br>  <a href="'.$site_url.'">Project Connect</a> </td></tr><tr>  <td style="padding:0px; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;"></br><p>If you face any issues accessing the link, you can contact <a href="mailto:vishwajit.menon@allscripts.com;">support</a>.</p></td></tr>  </table></td> </tr> </table></body></html>';

    $this->email->subject("Project Connect - ".$template_name." Reminder");
    $this->email->message($mailBody);
    $this->email->send();
    

    //Update the design_call_entry to reminder_sent true in dates table
    $data_update = array(
      'reminder_mail_sent' =>1
    );
    $this->db->where('dateId', $design_call_entry["dateId"]);
    $this->db->update('dates_tb', $data_update);

    //Add the design reminder mail sent entry to client_mails table
    $data_client_mail = array(
      'mailType' =>"design_call",
      'toUserId' => $contact_details["userId"],
      'sentBy' => 0,
      'projectId' => $design_call_entry["projectId"],
      'toEmailAddress' => $contact_details["mail"],
      'date' => date('Y-m-d G:i:s')
    );

    $this->db->insert('client_mails', $data_client_mail);

  }


  




}


?>