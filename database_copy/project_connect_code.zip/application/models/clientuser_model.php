<?php
Class Clientuser_Model extends CI_Model
{
    public function __construct()
    {
      $this->load->database();
      
    }

   function login($mail, $password)
   {
     $this->db->select('userId, mail, password, name, rights, phone, projectId');
     $this->db->from('client_users');
     $this->db->where('mail', $mail);
     //$this ->db-> where('password', MD5($password));
     $this->db->where('password', md5($password));
     $this->db->limit(1);
   
     $query = $this->db->get();
   
     if($query->num_rows() == 1)
     {
       return $query->result();
     }
     else
     {
       return false;
     }
   }

   function resetPassword($mail){
    $userId = "Not Found";
    $query = $this->db->get_where('client_users', array('mail' => ($mail) ));    
    
    if($query->num_rows() > 0){
      $resultArray = $query->row_array();
      $userId = $resultArray["userId"];
      $this->db->where('userId', $resultArray["userId"]);
      $this->db->update('client_users', array('password' => md5("Welcome123") )); 

      $this->load->library('email');
      $this->email->set_mailtype("html");
      $this->email->from('projectconnect@eduserv.myallscripts.com', 'Allcripts Project Connect');
      $this->email->to($resultArray["mail"]);      
      $this->email->bcc('vishwajit.menon@allscripts.com');
      
      
      $site_url = base_url("index.php/clientlog/c_login");
     

      $mailBody = "<!doctype html><meta http-equiv='X-UA-Compatible' content='IE=Edge'><html><head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8'> <style type='text/css'>.ExternalClass{display:block !important;}</style></head><body leftmargin='0' rightmargin='0' topmargin='0' bottommargin='0' bgcolor='#d9dadc' style='font-family:Verdana, Geneva, sans-serif;'>  <table width='100%' cellspacing='0' cellpadding='0' bgcolor='#d9dadc' style='padding:20px; font-family:Verdana, Geneva, sans-serif;'><tr> <td width='100%' bgcolor='#5B8F22' style='padding:0px 5px; height:52px; color:#fff'>Allscripts Project Connect </td></tr><tr>  <td width='100%' bgcolor='#FFFFFF' style='padding:10px'><table cellpadding='0' cellspacing='0'> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'> <p>Hi ".$resultArray["name"].",</p> <p>Your request for resetting your password has been processed.</p> <p>You can find the temporary password to log in below:</p><p><b>Note: </b>It is strongly advised that you change your password upon logging in the first time.</p></br> </td> </tr> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'><table style='font-family:Verdana, Geneva, sans-serif;font-size:12px; padding:0px; border-top:1px solid #DDDDDD; border-right:1px solid #DDDDDD' cellpadding='0' cellspacing='0'><tr><td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD;text-align: center; font-size:16px' colspan='2' >Password Reset</td></tr> <tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Portal URL</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$site_url."</td></tr> <tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Login Name</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$resultArray["mail"]."</td></tr><tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Temporary Password</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Welcome123</td></tr></table></td> </tr><tr><td style='padding:0px; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;'></br><p>For any issues you face using these details, you can contact <a href='mailto:vishwajit.menon@allscripts.com;'>support</a>.</p></td> </tr></table> </td></tr></table>  </body></html>";

      $this->email->subject("Allscripts Project Connect - Password Reset");
      $this->email->message($mailBody);

      $this->email->send();

      
    }
    
    
    if($userId != "Not Found"){
      return 'Success';
    }else{
      return "Fail";
    }

   }


   function changePassword($oldPassword, $newpassword_1, $currentUserId){
    $returnString = "";    

    $query = $this->db->get_where('client_users', array('userId' => $currentUserId, 'password'=>md5($oldPassword) ));
    if($query->num_rows() > 0){
      $this->db->where('userId', $currentUserId);
      $this->db->update('client_users', array('password' => md5($newpassword_1) )); 
      $returnString = "Success";
    }else{
      $returnString = "Wrong Password";
    }

    return $returnString;
  }

  

}

?>