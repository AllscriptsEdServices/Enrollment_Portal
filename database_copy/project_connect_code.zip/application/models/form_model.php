<?php
Class Form_Model extends CI_Model
{
  public function __construct()
  {
    $this->load->database();
  }


  function getFirstPage($quest_id, $projectId){
    $query = $this->db->get_where('quest_survey', array('surveyId' => $quest_id));
    $surveyArray = $query->row_array();

    $query = $this->db->get_where('projects', array('projectId' => $projectId));
    $projectDetailsArray = $query->row_array();
         

    $firstPageArray = array();
    $firstPageArray["surveyId"] = $surveyArray["surveyId"];
    $firstPageArray["surveyTitle"] = $surveyArray["surveyTitle"];
    $firstPageArray["surveyIntro"] = $surveyArray["surveyIntro"];
    $firstPageArray["surveySummary"] = $surveyArray["surveySummary"];
    $firstPageArray["projectId"] = $projectDetailsArray["projectId"];
    $firstPageArray["organizationName"] = $projectDetailsArray["organizationName"];
    $firstPageArray["cdhNum"] = $projectDetailsArray["cdhNum"];
    $firstPageArray["primaryContact"] = $projectDetailsArray["primaryContact"];

    $firstPageArray["consolidatedConsultants"] = $this->getAllConsultantsArray($projectDetailsArray["ehrConsultants"], $projectDetailsArray["pmConsultants"], $projectDetailsArray["productId"]);
    $firstPageArray["allscriptsPMName"] = $this->getResource_Data($projectDetailsArray["allscriptsPM"], "name");
    $firstPageArray["allscriptsAPMName"] = $this->getResource_Data($projectDetailsArray["allscriptsAPM"], "name");
    $firstPageArray["allscriptsPMName_Mail"] = $this->getResource_Data($projectDetailsArray["allscriptsPM"], "mail");
    $firstPageArray["allscriptsAPMName_Mail"] = $this->getResource_Data($projectDetailsArray["allscriptsAPM"], "mail");
    

    $query = $this->db->get_where('quest_topics_tb', array('topicSurveyId ' => $quest_id));
    //$firstPageArray["totalTopics"] = $projectDetailsArray = $query->num_rows();
    $firstPageArray["topicDefArray"] =  $query->result_array();

    return $firstPageArray;

  }


  function getResourceArray($resourceId){
    if(empty($resourceId)){
      return "";
    }else{
      $query = $this->db->get_where('allscripts_users', array('id' => $resourceId));  
      $resultArrayProject = $query->row_array(); 
      return $resultArrayProject;
    }  
  }
  

  function getAllConsultantsArray($ehr_consultants_string, $pm_consultants_string, $productId){
    $allConsultantsArray = array();

    if(trim($ehr_consultants_string) != ""){
      $ehr_consultants_id = explode("_", $ehr_consultants_string);
      foreach ($ehr_consultants_id as $consultantId) {
        $consultantInfo = $this->getResourceArray($consultantId);
        $consultantInfo["phone"] = $this->format_phone_us($consultantInfo["phone"]);
        $consultantInfo["projectRole"] = 1;
        array_push($allConsultantsArray, $consultantInfo);
      }
    }
    
    if(trim($pm_consultants_string) != ""){
      $pm_consultants_id = explode("_", $pm_consultants_string);
      foreach ($pm_consultants_id as $consultantId) {
        $consultantInfo = $this->getResourceArray($consultantId);
        $consultantInfo["phone"] = $this->format_phone_us($consultantInfo["phone"]);
        $consultantInfo["projectRole"] = 2;
        array_push($allConsultantsArray, $consultantInfo);      
      }   
    }

    return $allConsultantsArray;
  }



  function getTopic($topicId, $projectId){
    $this->db->order_by("qSequenceNum", "asc");  
    $query = $this->db->get_where('quest_questions', array('qTopicId' => $topicId)); 
    $resultQuestionArray = $query->result_array();
    for($i=0;$i<sizeof($resultQuestionArray); $i++){
      //$resultQuestionArray[$i]["qId"];
      if($this->getUserResponse($resultQuestionArray[$i]["qId"], $projectId) != null){
         $resultQuestionArray[$i]["isAnswered"] = "true";
         $resultQuestionArray[$i]["response"] = $this->getUserResponse($resultQuestionArray[$i]["qId"], $projectId);
      }else{
         $resultQuestionArray[$i]["isAnswered"] = "false";
         $resultQuestionArray[$i]["response"] = "";
      }
      
      $resultQuestionArray[$i]["noteText"] = $this->getNoteText($resultQuestionArray[$i]["qId"], $projectId);

      $resultQuestionArray[$i]["filesArray"] = $this->getUploadedFiles($resultQuestionArray[$i]["qId"], $projectId);
    }
    return $resultQuestionArray;
  }
  

  function getSurveyStatus($quest_id, $projectId){
    $statusDetailsArray = array();

   // $query = $this->db->get_where('quest_status', array('projectId' => $projectId, 'surveyId' => $quest_id, 'status' => "Submitted" ));
    $query = $this->db->get_where('quest_status', array('projectId' => $projectId, 'surveyId' => $quest_id, 'userType' => "external" ));
    $statusDetailsArray["client"] = $query->result_array();
    for($i=0;$i<sizeof($statusDetailsArray["client"]); $i++){
      $statusDetailsArray["client"][$i]["client_userName"] = $this->getUserDetailsById($statusDetailsArray["client"][$i]["userId"] , $statusDetailsArray["client"][$i]["userType"] );
    }      
    
     
    $query = $this->db->get_where('quest_status', array('projectId' => $projectId, 'surveyId' => $quest_id, 'status' => "Approved"));
    if($query->num_rows()>0){
        
        $statusDetailsArray["ic"] = $query->result_array();
        $statusDetailsArray["ic"][0]["ic_userName"] = $this->getUserDetailsById($statusDetailsArray["ic"][0]["userId"], $statusDetailsArray["ic"][0]["userType"]);
        /*$clientSubmitArray = $query->results_array();
        $statusDetailsArray[1]["approved"]  = "true";
        $statusDetailsArray["ic"] = 
        $statusDetailsArray[1]["ic_statusId"] = $clientSubmitArray["statusId"];
        $statusDetailsArray[1]["ic_userId"] = $clientSubmitArray["userId"];
        $statusDetailsArray[1]["ic_userType"] = $clientSubmitArray["userType"];
        $statusDetailsArray[1]["ic_userName"] = $this->getUserDetailsById($clientSubmitArray["userId"], $clientSubmitArray["userType"]);
        //$statusDetailsArray[1]["ic_status"] = $clientSubmitArray["status"];
        $statusDetailsArray[1]["ic_status"] = 'Complete';
        $statusDetailsArray[1]["ic_date"] = $clientSubmitArray["date"];*/
    }else{
        /*$statusDetailsArray[1]["approved"]  = "false";
        $statusDetailsArray[1]["ic_status"] = 'Pending';
        $statusDetailsArray[1]["ic_userName"] = "NA";
        $statusDetailsArray[1]["ic_date"] = "NA";*/
        $statusDetailsArray["ic"]= array();
    }
 

    return $statusDetailsArray;
  }


  function getUserResponse($qId, $projectId){
     $query = $this->db->get_where('quest_responses', array('qId' => $qId, 'projectId' => $projectId));
     if($query->num_rows()>0){
        $resultArray = $query->row_array();
        return $resultArray["response"];
     }else{
        return null;
     }
  }

  function getNoteText($qId, $projectId){
     $query = $this->db->get_where('quest_notes_tb', array('noteElementId' => $qId, 'noteForProject' => $projectId, 'noteLevel' => 'question'));
     if($query->num_rows()>0){
        $resultArray = $query->row_array();
        $noteToDisplay["author"] = $this->getResource_Data($resultArray["noteBy"], "name");
        $noteToDisplay["text"] = $resultArray["noteText"];
        return $noteToDisplay;
     }else{
        return null;
     }
  }

  function getUploadedFiles($qId, $projectId){
    $query = $this->db->get_where('quest_files', array('fileElementId' => $qId, 'fileProjectId' => $projectId, 'fileForElement' => 'question'));
    if($query->num_rows()>0){
      $resultArray = $query->result_array();
      return $resultArray;
    }else{
      return null;
    }

  }

  function getResource_Data($resourceId, $column){
   // echo "Resource is = ".empty($resourceId)."<br>";
    if(empty($resourceId)){
      return "";
    }else{
      $query = $this->db->get_where('allscripts_users', array('id' => $resourceId));    
      $resultArrayProject = $query->row_array(); 
      return $resultArrayProject[$column];
    }
  }

 

  function submitAnswers($questionIdString, $responseString, $notesString, $projectId, $surveyId){
    $insertedResponses = "BEGIN -->";
    $questionsArray = explode("|$|", $questionIdString);
    $responsesArray = explode("|$|", $responseString);
    $notesArray = explode("|$|", $notesString);

    $currentUser = $this->getCurrentUser();

    for($i=0; $i<(sizeof($questionsArray)-1); $i++){
      if($responsesArray[$i] != "null"){
          $data = array(
            'qId' =>$questionsArray[$i],
            'surveyId' => $surveyId,
            'projectId' => $projectId,
            'userId' => $currentUser["id"],
            'userType' => $currentUser["userType"],
            /*'userId' => 3,
            'userType' => 'external',*/
            'response' =>$responsesArray[$i],
            'date' => date("Y-m-d")            
       
          );

          //Check whether the question had been answered earlier
          $query = $this->db->get_where('quest_responses', array('qId' => $questionsArray[$i], 'projectId' => $projectId));
          // If yes, update the existing response
          if($query->num_rows()>0)
          {
            $existingResponse = $query->row_array();
            $this->db->where('responseId', $existingResponse["responseId"]);
            $this->db->update('quest_responses', array('response' => $responsesArray[$i], 'userId' => $currentUser["id"], 'userType' => $currentUser["userType"], 'date' => date("Y-m-d")));
          }
          //Else Add a new entry for the question
          else
          {
            $this->db->insert('quest_responses', $data);
          }
         
          //$clientId =  $this->db->insert_id(); 

      } // END OF QUESTION NULL FOR LOOP
      // DELETE QUESTIONS THAT MAY HAVE BEEN RESET
      else{
        $this->db->where(array('qId' => $questionsArray[$i], 'projectId' => $projectId));
        $this->db->delete('quest_responses');
      }

      // *************** NOTES *****************************
      $query_note = $this->db->get_where('quest_notes_tb', array('noteElementId' => $questionsArray[$i], 'noteForProject' => $projectId, 'noteLevel' => 'question'));
      if($query_note->num_rows()>0)
      {
        $insertedResponses .= "* EXISTING COMMENCE *";
        $existingNote = $query_note->row_array();
        if($existingNote["noteText"] != $notesArray[$i]){

            if($notesArray[$i] == "null"){
                $this->db->where('noteId', $existingNote["noteId"]);
                $this->db->delete('quest_notes_tb');
                $insertedResponses .= "Deleted = ".$existingNote["noteId"];
               
            }else{
                $this->db->where('noteId', $existingNote["noteId"]);
                $this->db->update('quest_notes_tb', array('noteText' => $notesArray[$i], 'noteDate' => date("Y-m-d")));
                $insertedResponses .= "Updated = ".$existingNote["noteId"];                   
            }             
        }
      }
      //INSERT the new note
      else
      {
          if($notesArray[$i] != "null"){
              $insertedResponses .= "* Commence Insert *";
              $dataNote = array(
                'noteElementId' =>$questionsArray[$i],
                'noteLevel' => 'question',
                'noteForProject' => $projectId,
                'noteBy' => "1",
                'noteText' =>$notesArray[$i],
                'noteDate' => date("Y-m-d")
              );

              $this->db->insert('quest_notes_tb', $dataNote);
              $insertedResponses .= "Inserted = ".$this->db->insert_id();
          }
      }

     // }

     
    } // END OF FOR LOOP

    return $insertedResponses;
    /*if(strlen($insertedResponses)>1){
      return $insertedResponses;
    }else{
      return "false";
    }*/

  }



  function checkProgress($projectId, $surveyId){
    $allQuestionsArray = array();

    $query = $this->db->get_where('quest_topics_tb', array('topicSurveyId' => $surveyId));
    $topicListArray =  $query->result_array();
    for($i=0; $i<sizeof($topicListArray); $i++){
      $this->db->order_by("qSequenceNum", "asc"); 
      $query_2 = $this->db->get_where('quest_questions', array('qTopicId' => $topicListArray[$i]["topicId"]));
      $topicQuestionsArray =  $query_2->result_array();
      
      for($j=0; $j<sizeof($topicQuestionsArray); $j++){
        $query_3 = $this->db->get_where('quest_responses', array('qId' => $topicQuestionsArray[$j]["qId"], 'projectId' => $projectId));        
        $responseArray =  $query_3->result_array();
        if($query_3->num_rows()>0){
          $topicQuestionsArray[$j]["isAnswered"] = "true";
        }else{
          $topicQuestionsArray[$j]["isAnswered"] = "false";
        }       

        array_push($allQuestionsArray, $topicQuestionsArray[$j]);

      }
    }

    $requiredQuestions = 0;
    $requiredQAnswered = 0;
    for($k=0;$k<sizeof($allQuestionsArray); $k++){
      if($allQuestionsArray[$k]["qRequired"] == 1){
         $requiredQuestions++;
        if($allQuestionsArray[$k]["isAnswered"] == "true"){
            $requiredQAnswered++;
        }
      }
      
    }

    $progress = round(($requiredQAnswered/$requiredQuestions)*100);

    return $progress;

  }


  function approveAssessment($projectId, $surveyId, $submitLabel){
      $currentUser = $this->getCurrentUser();
      $dataStatus = array(
      'surveyId' =>$surveyId,
      'projectId' => $projectId,
      'userId' => $currentUser["id"],
      'userType' => $currentUser["userType"],     
      'status' =>$submitLabel,
      'date' => date('Y-m-d G:i:s')
    );


    $this->db->insert('quest_status', $dataStatus);
    $insertedResponses = $this->db->insert_id();

    $firstPage = $this->getFirstPage($surveyId, $projectId); 

    $ic_emails = "";
    foreach ($firstPage["consolidatedConsultants"] as $consultant) {
      if($consultant["projectRole"] == $surveyId){        
        $ic_emails .= $consultant["mail"].",";
      }       
    }
    
    
    $query = $this->db->get_where('client_users', array('userId' => $firstPage["primaryContact"]));    
    $resultArray = $query->row_array(); 
    $primary_contact_mail = $resultArray["mail"];

    if(!empty($primary_contact_mail)){ $ic_emails .= $primary_contact_mail.","; }
    if(!empty($firstPage["allscriptsPMName_Mail"])){ $ic_emails .= $firstPage["allscriptsPMName_Mail"].","; }
    if(!empty($firstPage["allscriptsAPMName_Mail"])){ $ic_emails .= $firstPage["allscriptsAPMName_Mail"].","; }
    

    $ic_emails = rtrim($ic_emails, ',');

    $this->load->library('email');
    $this->email->set_mailtype("html");
    $this->email->from('projectconnect@eduserv.myallscripts.com', 'Allcripts Project Connect');
    $this->email->to($ic_emails);
    //$this->email->to('vishwajit.menon@allscripts.com');
    //$this->email->cc($mailArray["mailTo"]);
    $this->email->bcc('vishwajit.menon@allscripts.com');
    
    
    $quest_pdf_url = base_url("index.php/questionnaire/exportpdf/getpdf/")."/".$surveyId."/".$projectId;
   
    $mailBody = '<!doctype html><meta http-equiv="X-UA-Compatible" content="IE=Edge"><html><head> <meta http-equiv="Content-Type" content="text/html; charset=utf-8"> <style type="text/css">.ExternalClass{display:block !important;}</style></head><body leftmargin="0" rightmargin="0" topmargin="0" bottommargin="0" bgcolor="#d9dadc" style="font-family:Verdana, Geneva, sans-serif;">  <table width="100%" cellspacing="0" cellpadding="0" bgcolor="#d9dadc" style="padding:20px; font-family:Verdana, Geneva, sans-serif;"><tr> <td width="100%" bgcolor="#5B8F22" style="padding:0px 5px; height:52px; color:#fff">Allscripts Project Connect</td></tr><tr>  <td width="100%" bgcolor="#FFFFFF" style="padding:10px"><table cellpadding="0" cellspacing="0"> <tr><td style="font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;"> This is an automatic message to notify you that <b>'.$firstPage["surveyTitle"].'</b> for <b>'.$firstPage["organizationName"].' ('.$firstPage["cdhNum"].')</b> has been completed and marked as approved by <b>'.$currentUser["name"].'</b>. Please use the below link to access the responses or download for review.<br><br><a href="'.$quest_pdf_url.'">Questionnaire Document</a></td> </tr> <tr><td style="padding:0px; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;"></br><p>If you face any issues accessing the link, you can contact <a href="mailto:vishwajit.menon@allscripts.com;">support</a>.</p></br></td>  </tr> <tr><td style="padding:3px; color:#000000; font-size:11px; font-family:Verdana, Geneva, sans-serif;" align="center" bgcolor="#CCCCCC"><p> PLEASE DO NOT REPLY TO THIS MESSAGE. This is an unmonitored system mailbox.</p></td></tr></table> </td></tr></table> </td></tr></table> </td></tr></table>  </body></html>';

    $this->email->subject("Project Connect Questionnaire Approved - ".$firstPage["organizationName"]." (".$firstPage["cdhNum"].")");
    $this->email->message($mailBody);

    $this->email->send();

    return $insertedResponses;

  }


  function submitAssessment($projectId, $surveyId, $submitLabel){
    /*$reviewUserId = 1;
      if($projectId == 2){
        $reviewUserId = 3;
      }else if($projectId == 3){
        $reviewUserId = 8;
      }else if($projectId == 4){
        $reviewUserId = 10;
      }else if($projectId == 5){
        $reviewUserId = 11;
    }*/

    /*$this->db->where(array('projectId'=>$projectId, 'surveyId'=>$surveyId));
    $this->db->delete('quest_status');*/  

       
    $currentUser = $this->getCurrentUser();
    $dataStatus = array(
      'surveyId' =>$surveyId,
      'projectId' => $projectId,
      'userId' => $currentUser["id"],
      'userType' => $currentUser["userType"], 
      /*'userId' => $reviewUserId,
      'userType' => 'external',*/     
      'status' =>$submitLabel,
      'date' => date('Y-m-d G:i:s')
    );


    $this->db->insert('quest_status', $dataStatus);
    $insertedResponses = $this->db->insert_id();

    $firstPage = $this->getFirstPage($surveyId, $projectId);

    $ic_emails = "";
    foreach ($firstPage["consolidatedConsultants"] as $consultant) {
      if($consultant["projectRole"] == $surveyId){        
        $ic_emails .= $consultant["mail"].",";
      }       
    }

    if($submitLabel == "Submitted"){
      if(!empty($firstPage["allscriptsPMName_Mail"])){ $ic_emails .= $firstPage["allscriptsPMName_Mail"].","; }
      if(!empty($firstPage["allscriptsAPMName_Mail"])){ $ic_emails .= $firstPage["allscriptsAPMName_Mail"].","; }
    }

    $ic_emails = rtrim($ic_emails, ',');

    $this->load->library('email');
    $this->email->set_mailtype("html");
    $this->email->from('projectconnect@eduserv.myallscripts.com', 'Allcripts Project Connect');
    $this->email->to($ic_emails);
    //$this->email->to('vishwajit.menon@allscripts.com');
    //$this->email->cc($mailArray["mailTo"]);
    $this->email->bcc('vishwajit.menon@allscripts.com');
    
    
    $quest_pdf_url = base_url("index.php/questionnaire/exportpdf/getpdf/")."/".$surveyId."/".$projectId;
   
    $mailBody = '<!doctype html><meta http-equiv="X-UA-Compatible" content="IE=Edge"><html><head> <meta http-equiv="Content-Type" content="text/html; charset=utf-8"> <style type="text/css">.ExternalClass{display:block !important;}</style></head><body leftmargin="0" rightmargin="0" topmargin="0" bottommargin="0" bgcolor="#d9dadc" style="font-family:Verdana, Geneva, sans-serif;">  <table width="100%" cellspacing="0" cellpadding="0" bgcolor="#d9dadc" style="padding:20px; font-family:Verdana, Geneva, sans-serif;"><tr> <td width="100%" bgcolor="#5B8F22" style="padding:0px 5px; height:52px; color:#fff">Allscripts Project Connect</td></tr><tr>  <td width="100%" bgcolor="#FFFFFF" style="padding:10px"><table cellpadding="0" cellspacing="0"> <tr><td style="font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;"> This is an automatic message to notify you that <b>'.$currentUser["name"].'</b> at <b>'.$firstPage["organizationName"].' ('.$firstPage["cdhNum"].')</b> has '.strtolower($submitLabel).' the <b>'.$firstPage["surveyTitle"].'</b>. Please use the below link to access the responses or download for review.<br><br><a href="'.$quest_pdf_url.'">Questionnaire Document</a></td> </tr> <tr><td style="padding:0px; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;"></br><p>If you face any issues accessing the link, you can contact <a href="mailto:vishwajit.menon@allscripts.com;">support</a>.</p></br></td>  </tr> <tr><td style="padding:3px; color:#000000; font-size:11px; font-family:Verdana, Geneva, sans-serif;" align="center" bgcolor="#CCCCCC"><p> PLEASE DO NOT REPLY TO THIS MESSAGE. This is an unmonitored system mailbox.</p></td></tr></table> </td></tr></table> </td></tr></table>  </body></html>';

    $this->email->subject("Project Connect Questionnaire ".$submitLabel." - ".$firstPage["organizationName"]." (".$firstPage["cdhNum"].")");
    $this->email->message($mailBody);

    $this->email->send();


    return $insertedResponses;
  }


  function getCurrentUser(){
    $session_data = $this->session->userdata('logged_in');
    $userData["id"] = $session_data['id'];
    $userData["name"] = $session_data['name'];
    $userData["mail"] = $session_data['mail'];
    $userData["userType"] = $session_data['userType'];
    $userData["projectId"] = $session_data['projectId'];
    $userData["phone"] = $session_data['phone'];
    return ($userData);
  }

  function getUserDetailsById($userId, $userType){
    if($userType=="internal"){
        $query = $this->db->get_where('allscripts_users', array('id' => $userId));
        $resultArray = $query->row_array(); 
        return $resultArray["name"];
    }else if($userType=="external"){
        $query = $this->db->get_where('client_users', array('userId' => $userId));    
        $resultArray = $query->row_array(); 
        return $resultArray["name"];
    }
   
  }


  function submitFileUploads($fileName, $fileUrl, $projectId, $questionId){
    $currentUser = $this->getCurrentUser();

    $dataFile = array(
      'filePath' => $fileUrl,
      'fileName' => $fileName,
      'fileForElement' => 'question',
      'fileElementId' => $questionId,
      'fileUserId' => $currentUser["id"],
      //'fileUserId' => 1,
      'fileProjectId' => $projectId,      
      'fileDate' => date("Y-m-d")
    );

    $this->db->insert('quest_files', $dataFile);
    return $this->db->insert_id();

  }



  function fnHandleActiveUser($quest_id, $projectId){
    //Array to be returned to view
    $userAccessArray = array("lock"=>false, "checkInUserName"=>"");
    //User logged in to the tool
    $currentUser = $this->getCurrentUser();
    //A Hash to be saved with the session variable and sent to database to prevent 2 or more people using same login to access at the same time.
    $security_hash = str_shuffle("asdfghjk12345678");

    //Applicable only to external users
    if($currentUser["userType"] == "external") {    

        $query = $this->db->get_where('quest_active_users', array('projectId' => $projectId, 'surveyId'=>$quest_id, 'status'=>"active"));             

        //As per the database, is there a person from this project, editing this questionnaire at the moment?
        if($query->num_rows()>0){
          $checkedInUser = $query->row_array(); 

          //Does the currently logged in user have a Questionnaire session attached to their name
          if($this->session->userdata('form_active')) {  
            $requestingUser = $this->session->userdata('form_active');
            
            //Is this user the same as the one who is editing as per the database based on the hash
            if($requestingUser["security_hash"] == $checkedInUser["security_hash"]){
              $userAccessArray["lock"] = false;
              $userAccessArray["checkInUserName"] = "Self";
            }else{
              //May be a redundant else clause, as chances of this are almost not possible.
              $userAccessArray["lock"] = true;
              $userAccessArray["checkInUserName"] = $this->getClientUserName($checkedInUser["userId"]);
            }

          // Current user does NOT have a Questionnaire session attached to their name
          }else{
              $userAccessArray["lock"] = true;
              $userAccessArray["checkInUserName"] = $this->getClientUserName($checkedInUser["userId"]);
          }

        } 
        // If no user is checked in the database, activate the Questionnaire session and insert into database
        else{
            //Insert the current logged in user as the active editor in the database
            $checkInUserArray = array(
              'userId' => $currentUser["id"],
              'projectId' => $projectId,
              'surveyId' => $quest_id,
              'status' => "active",
              'security_hash' => $security_hash,         
              'start_time' => date('Y-m-d G:i:s')            
            );
            $this->db->insert('quest_active_users', $checkInUserArray);

            //Create the Questionnaire session for this user with the generated hash
            $sess_array = array(      
             'userId' => $currentUser["id"],
             'surveyId' => $quest_id,
             'security_hash' => $security_hash,
             'userType' => "external",
             'projectId' => $projectId,
             'status' => "active"
            );
            $this->session->set_userdata('form_active', $sess_array);

            $userAccessArray["lock"] = false;
            $userAccessArray["checkInUserName"] = "Self";

        }    

    } // End of IF loop to check if EXTERNAL user
   
    return $userAccessArray;
    
  }


  function getClientUserName($userId){
    $query = $this->db->get_where('client_users', array('userId' => $userId)); 
    $userDetails = $query->row_array(); 
    return $userDetails["name"];
  }


  function checkOutUser(){
    if($this->session->userdata('form_active')) { 
      $exitingUser = $this->session->userdata('form_active');
      /*$this->db->where(array('projectId'=>$exitingUser["projectId"], 'surveyId'=> $exitingUser["surveyId"], 'security_hash'=> $exitingUser["security_hash"]));
      $this->db->delete('quest_active_users');*/

      $this->db->where(array('projectId'=>$exitingUser["projectId"], 'surveyId'=>$exitingUser["surveyId"], 'security_hash'=>$exitingUser["security_hash"]));
      $this->db->update('quest_active_users', array('status' => "inactive", 'end_time' => date('Y-m-d G:i:s') ));

    }

    $this->session->unset_userdata('form_active');
    return 'Success';
  }



  //Used function from here https://thebarton.org/php-format-phone-number-function/
  function format_phone_us($phone) {
    //****************** Solution 1 ***************************
    // note: making sure we have something
    /*if(!isset($phone{3})) { return ''; }
    // note: strip out everything but numbers 
    $phone = preg_replace("/[^0-9]/", "", $phone);
    $length = strlen($phone);
    switch($length) {
    case 7:
      return preg_replace("/([0-9]{3})([0-9]{4})/", "$1-$2", $phone);
    break;
    case 10:
     return preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})/", "($1) $2-$3", $phone);
    break;
    case 11:
    return preg_replace("/([0-9]{1})([0-9]{3})([0-9]{3})([0-9]{4})/", "$1($2) $3-$4", $phone);
    break;
    default:
      return $phone;  
    break;
    }*/

    //****************** Solution 2 ***************************
    // Allow only Digits, remove all other characters.
    $phone = preg_replace("/[^\d]/","",$phone);
    // get number length.
    $length = strlen($phone);
    // if number = 10
    if($length == 10) {
      $phone = preg_replace("/^1?(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $phone);
    }
    
    return $phone;

  }

  

} //END OF CLASS DEFINITION



?>