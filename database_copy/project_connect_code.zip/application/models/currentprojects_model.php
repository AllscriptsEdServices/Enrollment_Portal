<?php
Class CurrentProjects_Model extends CI_Model
{
  public function __construct()
  {
    $this->load->database();    
  }

  function getProductTypes(){  
    $query = $this->db->get('product_suites');
    return $query->result_array();
  }

  function getAllProjects(){
   
    $query = $this->db->get('projects');    
    $resultArray = $query->result_array();

    for($i=0;$i<sizeof($resultArray);$i++){
        $productSuiteArray = $this->getProductName($resultArray[$i]["productId"]);
        $resultArray[$i]["productName"] = $productSuiteArray["productName"];
    }
    return $resultArray;
  }


  function getMyProjects($myId){
    $finalCoursesArray = array();
    $session_data = $this->session->userdata('logged_in');
    $userDesignation = $session_data['rights'];
    
    $query = $this->db->get('projects');
    $resultArray = $query->result_array();

    foreach($resultArray as $project){
        $ehr_consultants_array = array();
        $pm_consultants_array = array();

        $pm_array = array();
        $apm_array = array();
        
        if(trim($project["ehrConsultants"]) != ""){
            $ehr_consultants_array = explode("_", $project["ehrConsultants"]);
        }

        if(trim($project["pmConsultants"]) != ""){
            $pm_consultants_array = explode("_", $project["pmConsultants"]);
        }

        if(trim($project["allscriptsPM"]) != ""){
          $pm_array = explode("_", $project["allscriptsPM"]);
        }

        if(trim($project["allscriptsAPM"]) != ""){
          $apm_array = explode("_", $project["allscriptsAPM"]);
        }
        
        if(in_array($myId, $ehr_consultants_array) || in_array($myId, $pm_consultants_array) || in_array($myId, $pm_array) || in_array($myId, $apm_array) ){
          $productSuiteArray = $this->getProductName($project["productId"]);
          $project["productName"] = $productSuiteArray["productName"];
          array_push($finalCoursesArray, $project);
        }
    }

    return $finalCoursesArray;

  }


  function getProductName($productId){
    $query = $this->db->get_where('product_suites', array('id' => $productId));
    return $query->row_array(); 
  }




}


?>