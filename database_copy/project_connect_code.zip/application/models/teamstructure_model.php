<?php

Class TeamStructure_Model extends CI_Model

{

  public function __construct()
  {
    $this->load->database();   
  }



  function getProjectDetails($projectId){

    $query = $this->db->get_where('projects', array('projectId' => $projectId));
    $resultArrayProject = $query->row_array(); 

    $productDetails = $this->getProductName($resultArrayProject["productId"]);
    $resultArrayProject["productName"] = $productDetails["productName"];
    $resultArrayProject["allscriptsPMName"] = $this->getResourceName($resultArrayProject["allscriptsPM"]);
    $resultArrayProject["allscriptsAPMName"] =  $this->getResourceName($resultArrayProject["allscriptsAPM"]);    

    ($resultArrayProject["allscriptsPM"]!="") ? $pm_IdArray = explode("_", $resultArrayProject["allscriptsPM"]): $pm_IdArray = array();    
    $pm_InfoArray = array();
    for($i=0;$i<sizeof($pm_IdArray);$i++){
      $pm_NamesArray[$i] = $this->getResourceName($pm_IdArray[$i]);
      $pm_InfoArray[$i] = $this->getResourceArray($pm_IdArray[$i]);
    }
    $resultArrayProject["pm_IdArray"] = $pm_IdArray;
    $resultArrayProject["pm_InfoArray"] = $pm_InfoArray;

    
    ($resultArrayProject["allscriptsAPM"]!="") ? $apm_IdArray = explode("_", $resultArrayProject["allscriptsAPM"]): $apm_IdArray = array();
    $apm_InfoArray = array();
    for($i=0;$i<sizeof($apm_IdArray);$i++){
      $apm_NamesArray[$i] = $this->getResourceName($apm_IdArray[$i]);
      $apm_InfoArray[$i] = $this->getResourceArray($apm_IdArray[$i]);
    }
    $resultArrayProject["apm_IdArray"] = $apm_IdArray;
    $resultArrayProject["apm_InfoArray"] = $apm_InfoArray;
     
  

    //Based on product check if the criteria has been matched for the right number consultants.
    // If product is Pro EHR, at least 1 IC/EC should be assigned to ehrConsultants
    // if product is Pro Suite, then at least 1 IC/EC should be assigned to both ehrConsultants and pmConsultants
    $consultantCriteria_satisfied = false;

    if($resultArrayProject["productId"] == 1){
      if(trim($resultArrayProject["ehrConsultants"]) != ""){
        $consultantCriteria_satisfied = true;
      }
    }else if($resultArrayProject["productId"] == 2){
      if(trim($resultArrayProject["pmConsultants"]) != ""){
        $consultantCriteria_satisfied = true;
      }
    }else if($resultArrayProject["productId"] == 3){
      if(trim($resultArrayProject["ehrConsultants"]) != "" && trim($resultArrayProject["pmConsultants"]) != ""){
        $consultantCriteria_satisfied = true;
      }
    }

    if( $consultantCriteria_satisfied &&( count($pm_InfoArray)>0 || count($apm_InfoArray)>0 ) ){
      $resultArrayProject["submitEnabled"] = true;
    }else{
      $resultArrayProject["submitEnabled"] = false;
    }

    $mailDetails = array();
    if($this->getMailStatus($projectId) == "Empty"){
      $mailDetails["status"] = "Not Sent";
      $mailDetails["date"] = "NA";
    }else{
      $mailQuery = $this->getMailStatus($projectId);
      $mailDetails["status"] = "Sent" ;
      $mailDetails["date"] = $mailQuery["date"];
    }
    $resultArrayProject["mailDetails"] = $mailDetails; 
    
    //Get Client Details
    $query2 = $this->db->get_where('client_users', array('userId' => $resultArrayProject["primaryContact"]));
    $resultArrayClient = $query2->row_array(); 

    $resultArrayProject["primaryContactName"] = $resultArrayClient["name"];
    $resultArrayProject["primaryContactPhone"] = $this->format_phone_us($resultArrayClient["phone"]);  
    $resultArrayProject["primaryContactEmail"] = $resultArrayClient["mail"];

    $resultArrayProject["consolidatedConsultants"] = $this->getAllConsultantsArray($resultArrayProject["ehrConsultants"], $resultArrayProject["pmConsultants"], $resultArrayProject["productId"]);

    return $resultArrayProject;
  }


  
  function getInternalResources($projectId){  

    $query = $this->db->get_where('projects', array('projectId' => $projectId));
    $resultArrayProject = $query->row_array();

    $allscriptsPMArray = explode("_", $resultArrayProject["allscriptsPM"]) ;
    $allscriptsAPMArray = explode("_", $resultArrayProject["allscriptsAPM"]) ;
    

    $ehr_ConsultantsArray = explode("_", $resultArrayProject["ehrConsultants"]);
    $pm_ConsultantsArray = explode("_", $resultArrayProject["pmConsultants"]);

    $this->db->from("allscripts_users");
    $this->db->order_by("name", "asc");
    $query = $this->db->get();
    $resultArrayResources = $query->result_array();

    
    for($i=0;$i<sizeof($resultArrayResources);$i++){
      switch ($resultArrayResources[$i]["rights"]){
        case 'PM':            
          $resultArrayResources[$i]["isAssigned"] = (in_array($resultArrayResources[$i]["id"], $allscriptsPMArray)) ? "true":"false";               
          break;

        case 'APM':
          $resultArrayResources[$i]["isAssigned"] = (in_array($resultArrayResources[$i]["id"], $allscriptsAPMArray)) ? "true":"false";         
          break;

        case 'EduConsultant':
        case 'Consultant':
            if(in_array($resultArrayResources[$i]["id"], $ehr_ConsultantsArray)){
              $resultArrayResources[$i]["isAssigned"] = "true";
              $resultArrayResources[$i]["projectRole"] = "EHR";
            }else if(in_array($resultArrayResources[$i]["id"], $pm_ConsultantsArray)){
              $resultArrayResources[$i]["isAssigned"] = "true";
              $resultArrayResources[$i]["projectRole"] = "PM";
            }else{
              $resultArrayResources[$i]["isAssigned"] = "false";
            }               
            break;

        /*case 'Consultant':    
            if(in_array($resultArrayResources[$i]["id"], $ehr_ConsultantsArray)){
              $resultArrayResources[$i]["isAssigned"] = "true";
            }else if(in_array($resultArrayResources[$i]["id"], $pm_ConsultantsArray)){
              $resultArrayResources[$i]["isAssigned"] = "true";
            }else{
              $resultArrayResources[$i]["isAssigned"] = "false";
            }    
                  
            break;*/

        default:         
          $resultArrayResources[$i]["isAssigned"] = "false";           
          break;

      }      

    }

    return $resultArrayResources;   

  }


  function getProductName($productId){   
    $query = $this->db->get_where('product_suites', array('id' => $productId));
    return $query->row_array(); 
  }

  function getResourceArray($resourceId){
    if(empty($resourceId)){
      return "";
    }else{
      $query = $this->db->get_where('allscripts_users', array('id' => $resourceId));  
      $resultArrayProject = $query->row_array(); 
      return $resultArrayProject;
    }  
  }

  function getResourceName($resourceId){
   // echo "Resource is = ".empty($resourceId)."<br>";
    if(empty($resourceId)){
      return "";
    }else{
      $query = $this->db->get_where('allscripts_users', array('id' => $resourceId));  
      $resultArrayProject = $query->row_array(); 
      return $resultArrayProject["name"];
    }    

  }

  function getAllConsultantsArray($ehr_consultants_string, $pm_consultants_string, $productId){
    $allConsultantsArray = array();

    if(trim($ehr_consultants_string) != ""){
      $ehr_consultants_id = explode("_", $ehr_consultants_string);
      foreach ($ehr_consultants_id as $consultantId) {
        $consultantInfo = $this->getResourceArray($consultantId);
        $consultantInfo["projectRole"] = 1;
        array_push($allConsultantsArray, $consultantInfo);
      }
    }
    
    if(trim($pm_consultants_string) != ""){
      $pm_consultants_id = explode("_", $pm_consultants_string);
      foreach ($pm_consultants_id as $consultantId) {
        $consultantInfo = $this->getResourceArray($consultantId);
        $consultantInfo["projectRole"] = 2;
        array_push($allConsultantsArray, $consultantInfo);      
      }   
    }

    return $allConsultantsArray;
  }


   function setResource($resourceId, $projectId, $resourceType){
    if($resourceId!='Empty'){
      $data3 = array(
         $resourceType => $resourceId
      );

      $this->db->where('projectId', $projectId);
      $this->db->update('projects', $data3); 
      
    }else{
      $data3 = array(
         $resourceType =>NULL
      );

      $this->db->where('projectId', $projectId);
      $this->db->update('projects', $data3); 
    }

    return true;
  }


  function updateConsultants($ehr_consultants_string, $pm_consultants_string, $projectId, $productId){
     $data3 = array(
         "ehrConsultants" => $ehr_consultants_string,
         "pmConsultants" => $pm_consultants_string
      );

      $this->db->where('projectId', $projectId);
      $this->db->update('projects', $data3); 
      echo "Success";
  }


  function getMailStatus($projectId){
    //$query = $this->db->get_where('client_mails', array('projectId' => $projectId,'mailType'=>"client_activation"));  
    $query = $this->db->get_where('client_mails', array('projectId' => $projectId));     

    if($query->num_rows()>0){
       return $query->row_array();
    }else{
       return "Empty";
    }  

  }


  function getActivationMailDetails($projectId){
    $query = $this->db->get_where('projects', array('projectId' => $projectId));
    $resultArrayProject = $query->row_array();

    //Get Client Details
    $query2 = $this->db->get_where('client_users', array('userId' => $resultArrayProject["primaryContact"]));
    $resultArrayClient = $query2->row_array();

    $resultArrayProject["primaryContactName"] = $resultArrayClient["name"];
    $resultArrayProject["primaryContactPhone"] = $resultArrayClient["phone"];
    $resultArrayProject["primaryContactEmail"] = $resultArrayClient["mail"];
    $resultArrayProject["primaryContactPassword"] = $resultArrayClient["password"];

    //******** Get PM/APM Name and Email *****************   

    $pm_contact_print = '';
    $cc_String = "";
    if(!empty($resultArrayProject["allscriptsPM"])){
      $query = $this->db->get_where('allscripts_users', array('id' => $resultArrayProject["allscriptsPM"]));  
      $result_array_pm = $query->row_array(); 
      $pm_contact_print = "<a href='mailTo:".$result_array_pm['mail']."' >".$result_array_pm['name']."</a> ";
      $cc_String = $result_array_pm['mail'];
    }else if(!empty($resultArrayProject["allscriptsAPM"])){
      $query = $this->db->get_where('allscripts_users', array('id' => $resultArrayProject["allscriptsAPM"]));  
      $result_array_apm = $query->row_array(); 
      $pm_contact_print = "<a href='mailTo:".$result_array_apm['mail']."' >".$result_array_apm['name']."</a> ";
      $cc_String = $result_array_apm['mail'];
    }else{
      $pm_contact_print = "Not Set";
    }
    
    
  
    $site_url = base_url("index.php/clientlog/c_login");
    
    $consolidatedConsultants = $this->getAllConsultantsArray($resultArrayProject["ehrConsultants"], $resultArrayProject["pmConsultants"], $resultArrayProject["productId"]);

    
    $consultantsList = '<ol>';
    foreach ($consolidatedConsultants as $consultant) {     
      //$cc_String .= $consultant["mail"].",";
      if($consultant["projectRole"]=="1"){ 
        $consultantsList .= "<li>Profession EHR - ".$consultant["name"]." | ".$consultant["mail"]."</li>";
      }else if($consultant["projectRole"]=="2"){                
        $consultantsList .= "<li>Allscripts PM - ".$consultant["name"]." | ".$consultant["mail"]."</li>";
      }


      $this->load->library('email');
      $this->email->set_mailtype("html");
      $this->email->from('projectconnect@eduserv.myallscripts.com', 'Allcripts Project Connect');
      $this->email->to($consultant["mail"]);      
      $this->email->bcc('vishwajit.menon@allscripts.com');

      $ic_mail_body = "<!doctype html><meta http-equiv='X-UA-Compatible' content='IE=Edge'><html><head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8'> <style type='text/css'>.ExternalClass{display:block !important;}</style></head><body leftmargin='0' rightmargin='0' topmargin='0' bottommargin='0' bgcolor='#d9dadc' style='font-family:Verdana, Geneva, sans-serif;'>  <table width='100%' cellspacing='0' cellpadding='0' bgcolor='#d9dadc' style='padding:20px; font-family:Verdana, Geneva, sans-serif;'><tr> <td width='100%' bgcolor='#5B8F22' style='padding:0px 5px; height:52px; color:#fff'>Allscripts Project Connect</td></tr><tr>  <td width='100%' bgcolor='#FFFFFF' style='padding:10px'><table cellpadding='0' cellspacing='0'> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'> Hello ".$consultant["name"].",<br><br> You have been added to the Project Connect Team for <b>".$resultArrayProject["organizationName"].", ".$resultArrayProject["cdhNum"]."</b>.<br>  </td> </tr> <tr><td style='padding:0px; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;'></br><p>If you face any issues accessing the link, you can contact <a href='mailto:vishwajit.menon@allscripts.com;'>support</a>.</p></br></td> </tr> <tr><td style='padding:3px; color:#000000; font-size:11px; font-family:Verdana, Geneva, sans-serif;' align='center' bgcolor='#CCCCCC'>  <p> PLEASE DO NOT REPLY TO THIS MESSAGE. This is an unmonitored system mailbox.</p></td>  </tr></table> </td></tr></table>  </body></html>";
      
      $this->email->subject("New Project Attached in Allscripts Project Connect");
      $this->email->message($ic_mail_body);

      $this->email->send();

    }

    $consultantsList .= "</ol>";


    //$mailBody = "<!doctype html>  <meta http-equiv='X-UA-Compatible' content='IE=Edge'> <html>  <head><meta http-equiv='Content-Type' content='text/html; charset=utf-8'><style type='text/css'>.ExternalClass{display:block !important;}</style> </head> <body leftmargin='0' rightmargin='0' topmargin='0' bottommargin='0' bgcolor='#d9dadc' style='font-family:Verdana, Geneva, sans-serif;'><table width='100%' cellspacing='0' cellpadding='0' bgcolor='#d9dadc' style='padding:20px; font-family:Verdana, Geneva, sans-serif;'>  <tr><td width='100%' bgcolor='#5B8F22' style='padding:0px 5px; height:52px; color:#fff'>  Allscripts Project Connect </td> </tr> <tr><td width='100%' bgcolor='#FFFFFF' style='padding:20px'>  <table cellpadding='0' cellspacing='0'><tr> <td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:20px;color:#000000;'><p>Hello ".$resultArrayProject["primaryContactName"].",</p><p>Welcome to <strong>Project Connect</strong> – your Allscripts Implementation guide.</p><p>This tool provides you all the important information and action steps that will help you to complete the implementation in an easy manner.</p> </td></tr><tr>  <td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:20px;color:#000000;'><p>Here are your login details:</p><table style='font-family:Verdana, Geneva, sans-serif;font-size:12px; padding:0px; border-top:1px solid #DDDDDD; border-right:1px solid #DDDDDD' cellpadding='0' cellspacing='0'>  <tr><td style='padding:20px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD;text-align: center; font-size:16px' colspan='2' >Login Details</td></tr><tr><td style='padding:20px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Site</td><td style='padding:20px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$site_url."</td>  </tr><tr><td style='padding:20px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Username</td><td style='padding:20px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$resultArrayProject["primaryContactEmail"]."</td>  </tr> <tr><td style='padding:20px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Password</td><td style='padding:20px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$resultArrayProject["primaryContactPassword"]."</td> </tr></table></td></tr><tr> <td style='padding:20px;color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;'><p>The following Allscripts Team member/s will be working closely with you during the implementation. You can reach out to them for any queries.</p>".$consultantsList." </td></tr><tr>  <td style='padding:20px;color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;'>If you face any issues logging in or viewing the tool, feel free to <a href='mailto:vishwajit.menon@allscripts.com;amanda.turner@allscripts.com'>contact us</a>.</td></tr> </table></td> </tr></table></body>  </html>";

   $mailBody = "<!doctype html><meta http-equiv='X-UA-Compatible' content='IE=Edge'><html><head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8'> <style type='text/css'>.ExternalClass{display:block !important;}</style></head><body leftmargin='0' rightmargin='0' topmargin='0' bottommargin='0' bgcolor='#d9dadc' style='font-family:Verdana, Geneva, sans-serif;'>  <table width='100%' cellspacing='0' cellpadding='0' bgcolor='#d9dadc' style='padding:20px; font-family:Verdana, Geneva, sans-serif;'><tr> <td width='100%' bgcolor='#5B8F22' style='padding:0px 5px; height:52px; color:#fff'>Allscripts Project Connect</td></tr><tr>  <td width='100%' bgcolor='#FFFFFF' style='padding:10px'><table cellpadding='0' cellspacing='0'> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'> <p>Hello ".$resultArrayProject['primaryContactName'].",</p> <p>You have been added to the <b>Project Connect Tool</b> to assist you with viewing information about your Allscripts Implementation, including contact information for your assigned consultants. This Tool will be used to complete your Design Call Questionnaire. Please contact your primary Allscripts contact, ".$pm_contact_print.", with any questions about how to use this tool.</p><br> </td> </tr> <tr><td style='font-size:12px; font-family:Verdana, Geneva, sans-serif;padding:0px;color:#000000;'><table style='font-family:Verdana, Geneva, sans-serif;font-size:12px; padding:0px; border-top:1px solid #DDDDDD; border-right:1px solid #DDDDDD' cellpadding='0' cellspacing='0'><tr><td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD;text-align: center; font-size:16px' colspan='2' >Login Info</td></tr><tr> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Portal URL</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' ><a href='".$site_url."'>".$site_url."</a></td></tr><tr> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Username</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$resultArrayProject['primaryContactEmail']."</td></tr><tr>  <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >Password</td> <td style='padding:10px;border-bottom:1px solid #DDDDDD;border-left:1px solid #DDDDDD' >".$resultArrayProject['primaryContactPassword']."</td></tr></table></td> </tr><tr><td style='padding:0px; color:#000; font-size:12px; font-family:Verdana, Geneva, sans-serif;'></br><p>For any issues you face using these details, you can contact <a href='mailto:vishwajit.menon@allscripts.com;'>support</a>.</p></br></td>  </tr><tr><td style='padding:3px; color:#000000; font-size:11px; font-family:Verdana, Geneva, sans-serif;' align='center' bgcolor='#CCCCCC'><p> PLEASE DO NOT REPLY TO THIS MESSAGE. This is an unmonitored system mailbox.</p></td></tr></table> </td></tr></table>  </body></html>";

    $mailSendArray = array();
    $mailSendArray["mailTo"] = $resultArrayProject["primaryContactEmail"];
    $mailSendArray["cc_String"] = $cc_String;
    $mailSendArray["mailBody"] = $mailBody;
    $mailSendArray["subject"] = "Welcome to Allscripts Project Connect!";

    $session_data = $this->session->userdata('logged_in');
    //$headerData['mail'] = $session_data['mail'];

    $dataMail = array(
      'mailType' =>"client_activation",
      'toUserId' => $resultArrayClient["userId"],
      'sentBy' => $session_data['id'],
      'projectId' => $projectId,
      'date' =>date('Y-m-d G:i:s'),
      'toEmailAddress' => $resultArrayProject["primaryContactEmail"]
    );

     $this->db->insert('client_mails', $dataMail);  



     //******************************************************************************************************
     //     IC MAIL COMPOSE
     /*$mailSendArray["ic_array"] = $consolidatedConsultants;
     $mailSendArray["ic_array"] =*/

     return  $mailSendArray;  

  }


 
  //Used function from here https://thebarton.org/php-format-phone-number-function/
  function format_phone_us($phone) {
    //****************** Solution 1 ***************************
    // note: making sure we have something
    /*if(!isset($phone{3})) { return ''; }
    // note: strip out everything but numbers 
    $phone = preg_replace("/[^0-9]/", "", $phone);
    $length = strlen($phone);
    switch($length) {
    case 7:
      return preg_replace("/([0-9]{3})([0-9]{4})/", "$1-$2", $phone);
    break;
    case 10:
     return preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})/", "($1) $2-$3", $phone);
    break;
    case 11:
    return preg_replace("/([0-9]{1})([0-9]{3})([0-9]{3})([0-9]{4})/", "$1($2) $3-$4", $phone);
    break;
    default:
      return $phone;  
    break;
    }*/

    //****************** Solution 2 ***************************
    // Allow only Digits, remove all other characters.
    $phone = preg_replace("/[^\d]/","",$phone);
    // get number length.
    $length = strlen($phone);
    // if number = 10
    if($length == 10) {
      $phone = preg_replace("/^1?(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $phone);
    }
    
    return $phone;

  }






}


?>