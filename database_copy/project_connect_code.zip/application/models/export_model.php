<?php
Class Export_Model extends CI_Model
{
  public function __construct()
  {
    $this->load->database();
  }


  function getFirstPage($quest_id, $projectId){
    $query = $this->db->get_where('quest_survey', array('surveyId' => $quest_id));
    $surveyArray = $query->row_array();

    $query = $this->db->get_where('projects', array('projectId' => $projectId));
    $projectDetailsArray = $query->row_array();
         

    $firstPageArray = array();
    $firstPageArray["surveyId"] = $surveyArray["surveyId"];
    $firstPageArray["surveyTitle"] = $surveyArray["surveyTitle"];
    $firstPageArray["surveyIntro"] = $surveyArray["surveyIntro"];
    $firstPageArray["surveySummary"] = $surveyArray["surveySummary"];
    $firstPageArray["projectId"] = $projectDetailsArray["projectId"];
    $firstPageArray["organizationName"] = $projectDetailsArray["organizationName"];
    $firstPageArray["cdhNum"] = $projectDetailsArray["cdhNum"];
    $firstPageArray["address"] = $projectDetailsArray["address"];
    $firstPageArray["hostingType"] = $projectDetailsArray["hostingType"];

    $firstPageArray["consolidatedConsultants"] = $this->getAllConsultantsArray($projectDetailsArray["ehrConsultants"], $projectDetailsArray["pmConsultants"], $projectDetailsArray["productId"]);
    $firstPageArray["allscriptsPMName"] =  $this->getResourceName($projectDetailsArray["allscriptsPM"]);
    $firstPageArray["allscriptsAPMName"] =  $this->getResourceName($projectDetailsArray["allscriptsAPM"]);
    

    $query = $this->db->get_where('quest_topics_tb', array('topicSurveyId ' => $quest_id));
    //$firstPageArray["totalTopics"] = $projectDetailsArray = $query->num_rows();
    $firstPageArray["topicDefArray"] =  $query->result_array();

    return $firstPageArray;

  }

  function getResourceArray($resourceId){
    if(empty($resourceId)){
      return "";
    }else{
      $query = $this->db->get_where('allscripts_users', array('id' => $resourceId));  
      $resultArrayProject = $query->row_array(); 
      return $resultArrayProject;
    }  
  }
  

  function getAllConsultantsArray($ehr_consultants_string, $pm_consultants_string, $productId){
    $allConsultantsArray = array();

    if(trim($ehr_consultants_string) != ""){
      $ehr_consultants_id = explode("_", $ehr_consultants_string);
      foreach ($ehr_consultants_id as $consultantId) {
        $consultantInfo = $this->getResourceArray($consultantId);
        $consultantInfo["phone"] = $this->format_phone_us($consultantInfo["phone"]);
        $consultantInfo["projectRole"] = 1;
        array_push($allConsultantsArray, $consultantInfo);
      }
    }
    
    if(trim($pm_consultants_string) != ""){
      $pm_consultants_id = explode("_", $pm_consultants_string);
      foreach ($pm_consultants_id as $consultantId) {
        $consultantInfo = $this->getResourceArray($consultantId);
        $consultantInfo["phone"] = $this->format_phone_us($consultantInfo["phone"]);
        $consultantInfo["projectRole"] = 2;
        array_push($allConsultantsArray, $consultantInfo);      
      }   
    }

    return $allConsultantsArray;
  }
  function getTopic($topicId, $projectId){
    $this->db->order_by("qSequenceNum", "asc");  
    $query = $this->db->get_where('quest_questions', array('qTopicId' => $topicId)); 
    $resultQuestionArray = $query->result_array();
    for($i=0;$i<sizeof($resultQuestionArray); $i++){
      //$resultQuestionArray[$i]["qId"];
      if($this->getUserResponse($resultQuestionArray[$i]["qId"], $projectId) != null){
         $resultQuestionArray[$i]["isAnswered"] = "true";
         $resultQuestionArray[$i]["response"] = $this->getUserResponse($resultQuestionArray[$i]["qId"], $projectId);
      }else{
         $resultQuestionArray[$i]["isAnswered"] = "false";
         $resultQuestionArray[$i]["response"] = "";
      }
      
      $resultQuestionArray[$i]["noteText"] = $this->getNoteText($resultQuestionArray[$i]["qId"], $projectId);

      $resultQuestionArray[$i]["filesArray"] = $this->getUploadedFiles($resultQuestionArray[$i]["qId"], $projectId);
    }
    return $resultQuestionArray;
  }
  

  function getSurveyStatus($quest_id, $projectId){
    $statusDetailsArray = array();

   // $query = $this->db->get_where('quest_status', array('projectId' => $projectId, 'surveyId' => $quest_id, 'status' => "Submitted" ));
    $query = $this->db->get_where('quest_status', array('projectId' => $projectId, 'surveyId' => $quest_id, 'userType' => "external" ));
    $statusDetailsArray["client"] = $query->result_array();
    for($i=0;$i<sizeof($statusDetailsArray["client"]); $i++){
      $statusDetailsArray["client"][$i]["client_userName"] = $this->getUserDetailsById($statusDetailsArray["client"][$i]["userId"] , $statusDetailsArray["client"][$i]["userType"] );
    }      
    
     
    $query = $this->db->get_where('quest_status', array('projectId' => $projectId, 'surveyId' => $quest_id, 'status' => "Approved"));
    if($query->num_rows()>0){
        
        $statusDetailsArray["ic"] = $query->result_array();
        $statusDetailsArray["ic"][0]["ic_userName"] = $this->getUserDetailsById($statusDetailsArray["ic"][0]["userId"], $statusDetailsArray["ic"][0]["userType"]);
        /*$clientSubmitArray = $query->results_array();
        $statusDetailsArray[1]["approved"]  = "true";
        $statusDetailsArray["ic"] = 
        $statusDetailsArray[1]["ic_statusId"] = $clientSubmitArray["statusId"];
        $statusDetailsArray[1]["ic_userId"] = $clientSubmitArray["userId"];
        $statusDetailsArray[1]["ic_userType"] = $clientSubmitArray["userType"];
        $statusDetailsArray[1]["ic_userName"] = $this->getUserDetailsById($clientSubmitArray["userId"], $clientSubmitArray["userType"]);
        //$statusDetailsArray[1]["ic_status"] = $clientSubmitArray["status"];
        $statusDetailsArray[1]["ic_status"] = 'Complete';
        $statusDetailsArray[1]["ic_date"] = $clientSubmitArray["date"];*/
    }else{
        /*$statusDetailsArray[1]["approved"]  = "false";
        $statusDetailsArray[1]["ic_status"] = 'Pending';
        $statusDetailsArray[1]["ic_userName"] = "NA";
        $statusDetailsArray[1]["ic_date"] = "NA";*/
        $statusDetailsArray["ic"]= array();
    }
 

    return $statusDetailsArray;
  }


  function getUserResponse($qId, $projectId){
     $query = $this->db->get_where('quest_responses', array('qId' => $qId, 'projectId' => $projectId));
     if($query->num_rows()>0){
        $resultArray = $query->row_array();
        return $resultArray["response"];
     }else{
        return null;
     }
  }

  function getNoteText($qId, $projectId){
     $query = $this->db->get_where('quest_notes_tb', array('noteElementId' => $qId, 'noteForProject' => $projectId, 'noteLevel' => 'question'));
     if($query->num_rows()>0){
        $resultArray = $query->row_array();
        $noteToDisplay["author"] = $this->getResourceName($resultArray["noteBy"]);
        $noteToDisplay["text"] = $resultArray["noteText"];
        return $noteToDisplay;
     }else{
        return null;
     }
  }

  function getUploadedFiles($qId, $projectId){
    $query = $this->db->get_where('quest_files', array('fileElementId' => $qId, 'fileProjectId' => $projectId, 'fileForElement' => 'question'));
    if($query->num_rows()>0){
      $resultArray = $query->result_array();
      return $resultArray;
    }else{
      return null;
    }

  }

  function getResourceName($resourceId){
   // echo "Resource is = ".empty($resourceId)."<br>";
    if(empty($resourceId)){
      return "";
    }else{
      $query = $this->db->get_where('allscripts_users', array('id' => $resourceId));    
      $resultArrayProject = $query->row_array(); 
      return $resultArrayProject["name"];
    }
  }

 


  function submitAnswers($questionIdString, $responseString, $notesString, $projectId, $surveyId){
    $insertedResponses = "BEGIN -->";
    $questionsArray = explode("|$|", $questionIdString);
    $responsesArray = explode("|$|", $responseString);
    $notesArray = explode("|$|", $notesString);

    $currentUser = $this->getCurrentUser();

    for($i=0; $i<(sizeof($questionsArray)-1); $i++){
      if($responsesArray[$i] != "null"){
          $data = array(
            'qId' =>$questionsArray[$i],
            'surveyId' => $surveyId,
            'projectId' => $projectId,
            'userId' => $currentUser["id"],
            'userType' => $currentUser["userType"],
            /*'userId' => 3,
            'userType' => 'external',*/
            'response' =>$responsesArray[$i],
            'date' => date("Y-m-d")            
       
          );

          //Check whether the question had been answered earlier
          $query = $this->db->get_where('quest_responses', array('qId' => $questionsArray[$i], 'projectId' => $projectId));
          // If yes, update the existing response
          if($query->num_rows()>0)
          {
            $existingResponse = $query->row_array();
            $this->db->where('responseId', $existingResponse["responseId"]);
            $this->db->update('quest_responses', array('response' => $responsesArray[$i], 'userId' => $currentUser["id"], 'userType' => $currentUser["userType"], 'date' => date("Y-m-d")));
          }
          //Else Add a new entry for the question
          else
          {
            $this->db->insert('quest_responses', $data);
          }
         
          //$clientId =  $this->db->insert_id(); 

      } // END OF QUESTION NULL FOR LOOP
      // DELETE QUESTIONS THAT MAY HAVE BEEN RESET
      else{
        $this->db->where(array('qId' => $questionsArray[$i], 'projectId' => $projectId));
        $this->db->delete('quest_responses');
      }

      // *************** NOTES *****************************
      $query_note = $this->db->get_where('quest_notes_tb', array('noteElementId' => $questionsArray[$i], 'noteForProject' => $projectId, 'noteLevel' => 'question'));
      if($query_note->num_rows()>0)
      {
        $insertedResponses .= "* EXISTING COMMENCE *";
        $existingNote = $query_note->row_array();
        if($existingNote["noteText"] != $notesArray[$i]){

            if($notesArray[$i] == "null"){
                $this->db->where('noteId', $existingNote["noteId"]);
                $this->db->delete('quest_notes_tb');
                $insertedResponses .= "Deleted = ".$existingNote["noteId"];
               
            }else{
                $this->db->where('noteId', $existingNote["noteId"]);
                $this->db->update('quest_notes_tb', array('noteText' => $notesArray[$i], 'noteDate' => date("Y-m-d")));
                $insertedResponses .= "Updated = ".$existingNote["noteId"];                   
            }             
        }
      }
      //INSERT the new note
      else
      {
          if($notesArray[$i] != "null"){
              $insertedResponses .= "* Commence Insert *";
              $dataNote = array(
                'noteElementId' =>$questionsArray[$i],
                'noteLevel' => 'question',
                'noteForProject' => $projectId,
                'noteBy' => "1",
                'noteText' =>$notesArray[$i],
                'noteDate' => date("Y-m-d")
              );

              $this->db->insert('quest_notes_tb', $dataNote);
              $insertedResponses .= "Inserted = ".$this->db->insert_id();
          }
      }

     // }

     
    } // END OF FOR LOOP

    return $insertedResponses;
    /*if(strlen($insertedResponses)>1){
      return $insertedResponses;
    }else{
      return "false";
    }*/

  }



  function checkProgress($projectId, $surveyId){
    $allQuestionsArray = array();

    $query = $this->db->get_where('quest_topics_tb', array('topicSurveyId' => $surveyId));
    $topicListArray =  $query->result_array();
    for($i=0; $i<sizeof($topicListArray); $i++){
      $this->db->order_by("qSequenceNum", "asc"); 
      $query_2 = $this->db->get_where('quest_questions', array('qTopicId' => $topicListArray[$i]["topicId"]));
      $topicQuestionsArray =  $query_2->result_array();
      
      for($j=0; $j<sizeof($topicQuestionsArray); $j++){
        $query_3 = $this->db->get_where('quest_responses', array('qId' => $topicQuestionsArray[$j]["qId"], 'projectId' => $projectId));        
        $responseArray =  $query_3->result_array();
        if($query_3->num_rows()>0){
          $topicQuestionsArray[$j]["isAnswered"] = "true";
        }else{
          $topicQuestionsArray[$j]["isAnswered"] = "false";
        }       

        array_push($allQuestionsArray, $topicQuestionsArray[$j]);

      }
    }

    $requiredQuestions = 0;
    $requiredQAnswered = 0;
    for($k=0;$k<sizeof($allQuestionsArray); $k++){
      if($allQuestionsArray[$k]["qRequired"] == 1){
         $requiredQuestions++;
        if($allQuestionsArray[$k]["isAnswered"] == "true"){
            $requiredQAnswered++;
        }
      }
      
    }

    $progress = round(($requiredQAnswered/$requiredQuestions)*100);

    return $progress;

  }


  function approveAssessment($projectId, $surveyId, $submitLabel){
      $currentUser = $this->getCurrentUser();
      $dataStatus = array(
      'surveyId' =>$surveyId,
      'projectId' => $projectId,
      'userId' => $currentUser["id"],
      'userType' => $currentUser["userType"],     
      'status' =>$submitLabel,
      'date' => date('Y-m-d G:i:s')
    );


    $this->db->insert('quest_status', $dataStatus);
    $insertedResponses = $this->db->insert_id();

    return $insertedResponses;

  }


  function submitAssessment($projectId, $surveyId, $submitLabel){
    $reviewUserId = 1;
    if($projectId == 2){
      $reviewUserId = 3;
    }else if($projectId == 3){
      $reviewUserId = 8;
    }else if($projectId == 4){
      $reviewUserId = 10;
    }else if($projectId == 5){
      $reviewUserId = 11;
    }

    /*$this->db->where(array('projectId'=>$projectId, 'surveyId'=>$surveyId));
    $this->db->delete('quest_status');*/  

       
    $currentUser = $this->getCurrentUser();
    $dataStatus = array(
      'surveyId' =>$surveyId,
      'projectId' => $projectId,
      /*'userId' => $currentUser["id"],
      'userType' => $currentUser["userType"], */
      'userId' => $reviewUserId,
      'userType' => 'external',     
      'status' =>$submitLabel,
      'date' => date('Y-m-d G:i:s')
    );


    $this->db->insert('quest_status', $dataStatus);
    $insertedResponses = $this->db->insert_id();

     return $insertedResponses;
  }


  function getCurrentUser(){
    $session_data = $this->session->userdata('logged_in');
    $userData["id"] = $session_data['id'];
    $userData["mail"] = $session_data['mail'];
    $userData["userType"] = $session_data['userType'];
    $userData["projectId"] = $session_data['projectId'];
    $userData["phone"] = $session_data['phone'];
    return ($userData);
  }

  function getUserDetailsById($userId, $userType){
    if($userType=="internal"){
        $query = $this->db->get_where('allscripts_users', array('id' => $userId));
        $resultArray = $query->row_array(); 
        return $resultArray["name"];
    }else if($userType=="external"){
        $query = $this->db->get_where('client_users', array('userId' => $userId));    
        $resultArray = $query->row_array(); 
        return $resultArray["name"];
    }
   
  }


  function submitFileUploads($fileName, $fileUrl, $projectId, $questionId){
    $currentUser = $this->getCurrentUser();

    $dataFile = array(
      'filePath' => $fileUrl,
      'fileName' => $fileName,
      'fileForElement' => 'question',
      'fileElementId' => $questionId,
      'fileUserId' => $currentUser["id"],
      //'fileUserId' => 1,
      'fileProjectId' => $projectId,      
      'fileDate' => date("Y-m-d")
    );

    $this->db->insert('quest_files', $dataFile);
    return $this->db->insert_id();

  }

  //Used function from here https://thebarton.org/php-format-phone-number-function/
  function format_phone_us($phone) {
    //****************** Solution 1 ***************************
    // note: making sure we have something
    /*if(!isset($phone{3})) { return ''; }
    // note: strip out everything but numbers 
    $phone = preg_replace("/[^0-9]/", "", $phone);
    $length = strlen($phone);
    switch($length) {
    case 7:
      return preg_replace("/([0-9]{3})([0-9]{4})/", "$1-$2", $phone);
    break;
    case 10:
     return preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})/", "($1) $2-$3", $phone);
    break;
    case 11:
    return preg_replace("/([0-9]{1})([0-9]{3})([0-9]{3})([0-9]{4})/", "$1($2) $3-$4", $phone);
    break;
    default:
      return $phone;  
    break;
    }*/

    //****************** Solution 2 ***************************
    // Allow only Digits, remove all other characters.
    $phone = preg_replace("/[^\d]/","",$phone);
    // get number length.
    $length = strlen($phone);
    // if number = 10
    if($length == 10) {
      $phone = preg_replace("/^1?(\d{3})(\d{3})(\d{4})$/", "$1-$2-$3", $phone);
    }
    
    return $phone;

  }
} //END OF CLASS DEFINITION



?>