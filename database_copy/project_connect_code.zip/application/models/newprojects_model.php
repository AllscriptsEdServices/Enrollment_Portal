<?php
Class NewProjects_Model extends CI_Model
{
  public function __construct()
  {
    $this->load->database();    
  }

    function getProductTypes(){  
      $query = $this->db->get('product_suites');
      return $query->result_array();
    }

    function getConversions(){
      /*$this->db->select('conversionId, conversionName, productId, extra');
      $this->db->from('allscripts_users');
      $query = $this->db->get();*/
      $query = $this->db->get('conversions');
      return $query->result_array();
    }


    function getInterfaces(){  
      $query = $this->db->get('interfaces');
      return $query->result_array();
    }

    function getAddOns(){  
      $query = $this->db->get('addons');
      return $query->result_array();
    }


    function addProject($clientAdminData, $projectData){ 
        
        $noErrors = true;  
        //This is a return array that  will hold the status and the projectId if generated  
        $statusArray = array();

        $queryUser = $this->db->get_where('client_users', array('mail' => $clientAdminData["mail"]));       

        $queryCDH = $this->db->get_where('projects', array('cdhNum' =>$projectData["cdhNum"]));  
        
        if($queryUser->num_rows()>0){
          $statusArray["status"] = "usermail";
          $noErrors = false;
        }

        if($queryCDH->num_rows()>0){
          $statusArray["status"] = "cdh";
          $noErrors = false;
        }

        
        //Proc.edd to insert user and project only if the the usermail and cdh number are unique
        if($noErrors){
            $currentUser = $this->getCurrentUser();

            //Add the client primary contact in the client_users table and note userId
            $data_user = array(
                'name' =>$clientAdminData["name"],
                'mail' => $clientAdminData["mail"],
                'phone' => $clientAdminData["phone"],                
                'password' => md5("Welcome123"),
                'rights' => "primary",
                'addedBy' => $currentUser["id"],
                'addedDate' => date("Y-m-d")
            );

            $this->db->insert('client_users', $data_user);
            $primaryUserId =  $this->db->insert_id();          


            //Add the project in the projects table along with the primaryUserId just generated for the linking between project and primary user
            $data_project = array(
                'organizationName' =>$projectData["organizationName"],
                'cdhNum' => $projectData["cdhNum"],      
                'address' => $projectData["address"],
                'projectType' => $projectData["projectType"],
                'productId' => $projectData["productId"],
                'hostingType' => $projectData["hostingType"],      
                'primaryContact' => $primaryUserId,
                'conversions' => $projectData["conversions"],
                'interfaces' => $projectData["interfaces"],
                'addOns' => $projectData["addOns"],
                'projectStatus' => "0",
                'projectStartedDate' => date("Y-m-d"),
                'phone' => $clientAdminData["phone"]
            );

            $this->db->insert('projects', $data_project);
            $projectId =  $this->db->insert_id();
            $statusArray["status"] = "success";
            $statusArray["projectId"] = $projectId;


            //Update the client_users table for the primary contact to reverse link the projectId with the primary contact ($primaryUserId)
            $data_userUpdate = array(
                   'projectId' => $projectId               
                );

            $this->db->where('userId', $primaryUserId);
            $this->db->update('client_users', $data_userUpdate);

        } //End of Error Free IF Loop


        return $statusArray;

    }


    function getCurrentUser(){
      $session_data = $this->session->userdata('logged_in');
      $userData["id"] = $session_data['id'];
      $userData["mail"] = $session_data['mail'];
      $userData["userType"] = $session_data['userType'];
      $userData["projectId"] = $session_data['projectId'];
      $userData["phone"] = $session_data['phone'];
      return ($userData);
    }



}

?>
