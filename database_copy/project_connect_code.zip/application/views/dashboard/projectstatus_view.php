<div class="container-fluid">  

  <?php
    if($userType=="internal"){
      echo '<div style="margin-bottom:10px"><button onclick="GoBack()" class="btn btn-default"><span class="glyphicon glyphicon-search" aria-hidden="true"></span> Back</button></div>';
    }
  ?>  

  <div class="row ">
    <div class="col-xs-12 well"  id="orgDetails">      
      <?php 
        if($userType=="internal"){
          echo '<div class="col-xs-6">';
          echo '<span class="lead" style="color:#444;">'.$projectInfo["organizationName"].'</span><br>';
          echo '<span style="color:#777;">'.$projectInfo["address"].'</span><br>  ';
          echo '</div>';
        }else{
          echo '<div class="col-xs-6">';
          echo '<span class="lead" style="color:#444;">'.$projectInfo["organizationName"].'</span><br>';          
          echo '</div>';
        }
        //Consultants Drop Info
        echo '<div class="col-xs-6">';        
        echo '<button id="view_consultants_btn" class="btn btn-primary pull-right">Allscripts Consultants <span id="view_consultants_glyph" class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></button>';
        
        
        echo '<table id="consultants_table" style="display:none;"  class="table table-bordered bg-white">';
        //echo '<tr><th class="text-center" colspan="4">Allscripts Consultants</th></tr>';
        echo '<tr> <th>Product</th> <th>Name</th> <th>Phone Number</th> <th>Email Address</th> </tr>';
       
        foreach ($projectInfo["consolidatedConsultants"] as $consultant) {
          echo '<tr>';   
          $project_role = ($consultant["projectRole"]==1) ? "Professional EHR" : "Allscripts PM";
          echo '<td>'.$project_role.'</td>'     ;
          echo '<td>'.$consultant["name"].'</td>';
          //echo '<td>'.$consultant["phone"].' &nbsp;<span class="glyphicon glyphicon-earphone  " aria-hidden="true" style="color:#23D5E6"></span></td>';
          echo '<td>'.$consultant["phone"].'</td>';
          echo '<td>'.$consultant["mail"].'</td>';
          echo '</tr>';
        }
            
         
          echo '</table>';
          echo '</div>';
        

      ?>
    </div>
  </div>



  <div class="row">
      <div class="col-md-3 col-sm-5 col-xs-12" id="leftNav">
        <!-- <ul class="nav nav-stacked " data-spy="affix" id="" data-offset-top="195"> -->     

          <!-- Nav tabs -->
          <ul class="nav nav-tabs" role="tablist">

          <?php $i=1; foreach ($stagesDetails as $stage): ?>
              <!-- <li role="presentation" class="active"><a href="#product_tab_1" aria-controls="product_tab_1" onclick="fnShowTab(1)" role="tab" data-toggle="tab">Professional EHR</a></li>
              <li role="presentation"><a href="#product_tab_2" aria-controls="product_tab_2" onclick="fnShowTab(2)" role="tab" data-toggle="tab">Allscripts PM</a></li> -->
              <?php if($i==1){ ?>
                <li role="presentation" class="active"><a href="#product_tab_<?php echo $i ?>" aria-controls="product_tab_<?php echo $i ?>" onclick="fnShowTab(<?php echo $i ?>)" role="tab" data-toggle="tab"><?php echo $stage["stageName"] ?></a></li>
              <?php }else{ ?>
                <li role="presentation"><a href="#product_tab_<?php echo $i ?>" aria-controls="product_tab_<?php echo $i ?>" onclick="fnShowTab(<?php echo $i ?>)" role="tab" data-toggle="tab"><?php echo $stage["stageName"] ?></a></li>
              <?php } $i++?>
            <?php endforeach ?>
          </ul>

          <?php $i=1; foreach ($stagesDetails as $stage): ?>
              <?php if($i==1){ ?>
                <div class="panel-group top-buffer tabContent" id="product_tab_<?php echo $i ?>" role="tablist" aria-multiselectable="true">
              <?php }else{ ?>
                <div class="panel-group top-buffer tabContent" id="product_tab_<?php echo $i ?>" role="tablist" aria-multiselectable="true" style="display:none">
               <?php } ?>

              <?php $j=0; foreach ($stage["stages_definition"] as $individualStage): ?>
                <?php $accordionName = $i."_".$individualStage["stageSequenceNum"]; ?>

                  <div class="panel panel-default">

                    <div class="panel-heading" role="tab" id="heading_<?php echo $accordionName ?>">
                      <h4 class="panel-title">                        
                          <a style="display:block" data-toggle="collapse" data-parent="#collapse_<?php echo $accordionName ?>" onclick="fn_RefreshTabs()" href="#collapse_<?php echo $accordionName ?>" aria-expanded="true" aria-controls="collapse_<?php echo $accordionName ?>">
                           <?php echo $individualStage["stageName"] ?>
                          <span class="glyphicon glyphicon-flag pull-right bg-not-attempted" aria-hidden="true" ></span>
                        </a>
                      </h4>
                    </div>

                    <div id="collapse_<?php echo $accordionName ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_<?php echo $accordionName ?>">
                      <div class="panel-body">
                         
                          <?php 
                            //echo sizeof($stage["templates_definition"][$j])."<br>";
                            $all_templates = $stage["templates_definition"][$j];
                            foreach ($all_templates as $template_item) {
                              echo '<a id="resourceLink_'.$template_item["resourceId"].'" href="javascript:fnShowTemplate('.$template_item["resourceId"].')" class="resource-normal" ><span class="glyphicon glyphicon-stop" aria-hidden="true"></span> '.$template_item["resourceName"].'</a></br>';
                            }
                            /*for($m=0;$m<sizeof($stage["templates_definition"][$j]); $m++){
                              //echo $stage["templates_definition"][$j][$m]["resourceName"];
                              echo '<a id="resourceLink_'.$stage["templates_definition"][$j][$m]["resourceId"].'" href="javascript:fnShowTemplate('.$stage["templates_definition"][$j][$m]["resourceId"].')" class="resource-normal" ><span class="glyphicon glyphicon-stop" aria-hidden="true"></span> '.$stage["templates_definition"][$j][$m]["resourceName"].'</a></br>';
                            }   */                         

                          ?>
                          
                      </div>
                    </div>
                  </div>
                 <?php $j++;?>
              <?php endforeach ?>

              </div> <!-- END OF ACCORDIION  -->
              <?php $i++?>
          <?php endforeach ?>

        

      </div><!-- END OF LEFT SIDE NAV COLUMN -->


      <div class="col-md-9 col-sm-7 col-xs-12" id="stageContent" >
        <div id="loader_div" class="row" style="">
          <div class="col-xs-12 text-center" style="position:fixed; top:0px; left:0px; width:100%; height:100%; display:block; background-color:#666; z-index:1000; opacity: 0.8">
             <div style="position:absolute; height:180px; margin-top:-90px; top:50%; width:190px; margin-left:-95px; left:50%; font-size:20px; color:#fff">
              <img width="150px"src="<?php echo base_url('assets/img/loader_circle.gif'); ?>" /> Processing..
             </div>           
          </div>
        </div>
      

        <div class="row">         

          <div class="col-md-12" >
            <h2 id="templateTitle"></h2>
          </div>
          <div class="col-md-12" id="templateContent">
              <p class="text-justify"><i>Click on any of the stages in the left to view details.</i></p>  


              <!-- <h3><a href="../../../questionnaire/form/getQuest/1/2" target="_blank"><span class="glyphicon glyphicon-globe" aria-hidden="true"></span> Go To The Questionnaire</a></h3> -->       
          </div>

        </div>

        </div><!-- END OF RIGHT SIDE PARENT ROW  -->


      </div><!-- END OF FULL PAGE SECOND COLUMN -->



  </div> <!-- END OF PAGE DIVISION ROW -- >



</div><!-- End of Container -->



<!--<a href="javascript:fnOpenNew()">Open Window</a>-->
<script type="text/javascript" src="<?php echo base_url("assets/plugins/bootstrap-datepicker-1.5.0-dist/js/bootstrap-datepicker.min.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/dashboard.js"); ?>"></script>

<script type="text/javascript">
  var projectId = <?php echo json_encode($projectInfo["projectId"]) ?>;
  var baseURL = <?php echo json_encode(base_url("index.php/dashboard/projectstatus")) ?>;
  var productId = <?php echo json_encode($projectInfo["productId"]) ?>;
  var currentSelectedTab = 1;
  var userType = <?php echo json_encode($userType) ?>;

  $(document).ready(function(){
      $("#myNav").affix({
          offset: {
              top: 195
          }
      });  

  });

  $(window).load(function(){
    $("#loader_div").hide();
  });
  
  $(function () {
      $('[data-toggle="tooltip"]').tooltip();
  })

  $("#view_consultants_btn").click(function(){
    $("#consultants_table").fadeToggle();
    $("#view_consultants_glyph").toggleClass("glyphicon-chevron-down");
    $("#view_consultants_glyph").toggleClass("glyphicon-chevron-up");
  })

  
  

</script>