<div class="container-fluid">
	<!-- <form id="defaultForm"  method="post"> -->
	<div class="row">	
		<div class="col-lg-12">
			
		  	<!-- Nav tabs -->
			  <div class="span12 centered-pills">
				  <ul class="nav nav-pills" role="tablist">				    
				     <li role="presentation"><a href="javascript:showTab('my')" >My Projects</a></li>
				    <li role="presentation" class="active"><a href="javascript:showTab('all')" >All Projects</a></li>
				  </ul>
			  </div>
			  <!-- Tab panes -->
			
			    

			  
	    	<div class="row">
	    		<div class="column col-sm-6 col-lg-3 col-md-5">
			    	<form class="form-inline">
			            <div class="form-group">
							<label class="control-label-horizontal" for="search_org_all">Search By: </label>
			            	<input type="text" class="form-control" id="search_org_all" placeholder="Organization Name"></input>
			            </div>
			        </form>
			    </div>

			    <div class="column col-sm-6 col-lg-3 col-md-5">
			    	<form class="form-inline">
			            <div class="form-group">
							<label class="control-label-horizontal" for="search_cdh_all">Search By: </label>
			            	<input type="text" class="form-control" id="search_cdh_all" placeholder="CDH Number"></input>
			            </div>
			        </form>
			    </div>
	        </div>

	        <div class="row top-buffer">
	    		<div class="column col-sm-12">
			    	<table id="allTable" class="table table-striped table-bordered tablesorter">
						<thead>
							 <tr>
							 	<th>Organization</th>							 	
							 	<th>CDH Number</th>
							 	<th>Project Type</th>
							 	<th>Product</th>
							 	<th class="hidden-xs">Client Type</th>
							 	<!-- <th class="hidden-xs">Allscripts APM</th> -->
							 	<!-- <th class="hidden-xs">Start Date</th> -->
							 	<th></th>
							 </tr>
						</thead>
						<tbody>
							<?php foreach ($allProjects as $project): ?>
								<tr>
									<td><?php echo $project["organizationName"] ?></td>									
									<td><?php echo $project["cdhNum"] ?></td>
									<td><?php echo $project["projectType"] ?> Client</td>
									<td><?php echo $project["productName"] ?></td>
									<td class="hidden-xs"><?php echo $project["hostingType"] ?></td>
									<!-- <td class="hidden-xs"><?php echo $project["allscriptsPM"] ?></td> -->
									<!-- <td class="hidden-xs"><?php echo $project["projectStartedDate"] ?></td> -->
									<td width="210px">
										<button type="button" class="btn btn-default btn-sm" aria-label="Left Align" onclick="fnEditProject(<?php echo $project["projectId"] ?>)"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true" ></span>
										  View
										</button>
										<button type="button" class="btn btn-default btn-sm" onclick="fnGoToDashboard(<?php echo $project["projectId"] ?>)" aria-label="Left Align"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span>
										  Dashboard
										</button>
									</td>
								</tr>
							<?php endforeach ?>						
						</tbody>
					</table>
				</div>
	        </div>

			<div class="row top-buffer">
				<button onclick="fnAddProject()" class="btn btn-default center-block">New Project</button>
			</div>

					   
			
		</div><!-- END OF COLUMN -->
	</div><!-- END OF ROW -->

	

	


</div><!-- END OF CONTAINER  -->

<link rel="stylesheet" href="<?php echo base_url("assets/plugins/tablesorter-master/dist/css/theme.dropbox.min.css") ?>">
<script type="text/javascript" src="<?php echo base_url("assets/plugins/tablesorter-master/dist/js/jquery.tablesorter.min.js") ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/plugins/tablesorter-master/dist/js/jquery.tablesorter.widgets.min.js") ?>"></script>
<script type="text/javascript">	
	var baseURL = <?php echo json_encode(base_url("index.php/")) ?>

	$('input, textarea').placeholder();

	$(document).ready(function(){
		$(function(){
			$("#allTable").tablesorter(
			{
				theme : 'dropbox',
			 
				//sortList : [[1,0],[2,0],[3,0]],
				sortList : [[0,0]],
			 
			    // header layout template; {icon} needed for some themes
			    headerTemplate : '{content}{icon}',
			 
				// initialize column styling of the table
			    widgets : ["columns"],
				widgetOptions : {
			      // change the default column class names
			      // primary is the first column sorted, secondary is the second, etc
			      columns : [ "primary", "secondary", "tertiary" ]
				}
			});
		});

		//Live search function for the All Projects List Org Name
		$("#search_org_all").on("keyup", function() {
		    var value = $(this).val().toLowerCase();
		    $("#allTable tr").each(function(index) {
		        if (index !== 0) {
		            $row = $(this);		            
		            var id = $row.find("td:first").text().toLowerCase();		            
		            if (id.indexOf(value) < 0) {
		                $row.hide();
		            }
		            else {
		                $row.show();
		            }
		        }
		    });
		});

		//Live search function for the All Projects List CDH Number
		$("#search_cdh_all").on("keyup", function() {
		    var value = $(this).val().toLowerCase();
		    $("#allTable tr").each(function(index) {
		        if (index !== 0) {
		            $row = $(this);		            
		            var id = $row.find("td:nth-child(2)").text().toLowerCase();		            
		            if (id.indexOf(value) < 0) {
		                $row.hide();
		            }
		            else {
		                $row.show();
		            }
		        }
		    });
		});

		


	});
	
	function showTab(tabName){
		if(tabName == "my"){
			location.href = baseURL + "/projects/currentprojects/" ;
		}else{
			location.href = baseURL + "/projects/currentprojects/allprojects";
		}
		
	}

	function fnGoToDashboard(projectId){		
		location.href = baseURL + "/dashboard/projectstatus/getStatus/" + projectId;
	}

	function fnAddProject(){
		location.href = baseURL + "/projects/newproject/" ;
	}

	function fnEditProject(projectId){		
		location.href = baseURL + "/projects/editproject/showdetails/" + projectId;	
	}

</script>

<!-- glyphicon glyphicon-zoom-in
glyphicon glyphicon-plus-sign
glyphicon glyphicon-pencil
glyphicon-folder-open -->