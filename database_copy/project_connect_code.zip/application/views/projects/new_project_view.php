
<div class="container my_container">

<!--<?php echo validation_errors(); ?>
<?php echo form_open('projects/newproject/fnAddNewProject'); ?>-->
<form id="defaultForm"  method="" class="" action="">
	<div class="row ">		
		<div class="col-lg-12 ">
			<h2 class="center-block">New Project</h2>
		</div>
	</div>

	<div class="row lightborder">
		 <div class="col-lg-6 rightBorder">
		 	
		 	<h3>Organization Details</h3>
		 	<div class="form-group">
				<label class="control-label" for="organizationName">Organization Name</label>
				<input type="text" class="form-control" id="organizationName" name="organizationName" placeholder="Enter Organization Name">
			</div>
			<div class="form-group">
				<label class="control-label" for="cdhNum">CDH Number</label>
				<input type="text" class="form-control" id="cdhNum" name="cdhNum" placeholder="Enter CDH Number">
			</div>
			<div class="form-group">
				<label class="control-label" for="address">Address</label>
				<textarea class="form-control" id="address" name="address" rows="3"></textarea>
			</div>
			
		 </div><!-- END of COLUMN -->

		<div class="col-lg-6">
		 	<h3>Primary Contact</h3>
		 	<div class="form-group">
				<label class="control-label" for="userName">Name</label>
				<input type="text" class="form-control" id="userName" name="userName" placeholder="John Doe">
			</div>
			<div class="form-group">
				<label class="control-label" for="userMail">Contact's Email</label>
				<input type="email" class="form-control" id="userMail" name="userMail" placeholder="john.doe@example.com">
			</div>
			<div class="form-group">
				<label class="control-label" for="phone">Phone</label>
				<input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Phone Number">
			</div>
	
		</div><!-- END of COLUMN -->
	</div> <!-- END OF ROW -->

	<div class="row ">

	</div>
	 <div class="row top-buffer lightborder">
	 	<div class="col-lg-4 "> 
	 		<h3>Project Type</h3>
			<div class="radio">
			  <label>
			    <input type="radio" name="projectType" id="projectType_1" checked value="New">
			    Net New Client (new to product)
			  </label>
			</div>
			<div class="radio">
			  <label>
			    <input type="radio" name="projectType" id="projectType_2" value="Existing">
			    Existing Client (already live on product)
			  </label>
			</div>			
		</div> <!-- END of COLUMN -->

		<div class="col-lg-4 products">
			<h3>Product</h3>
			<?php foreach ($productTypes as $product): ?>
				<div class="radio">
				  <label>
				    <input type="radio" name="productName" id="productRadio_<?php echo $product['id'] ?>" value="<?php echo $product['id'] ?>">
				    <?php echo $product['productName'] ?>
				  </label>
				</div>
			<?php endforeach ?>
		</div><!-- END of COLUMN -->
		
		<div class="col-lg-4 "> 
	 		<h3>Installation Type</h3>
			<div class="radio">
			  <label>
			    <input type="radio" name="hostingType" id="hostingRadio_1" value="3rd Party Hosted">
			    3rd Party Hosted
			  </label>
			</div>
			<div class="radio">
			  <label>
			    <input type="radio" name="hostingType" id="hostingRadio_2" value="Cloud Hosted">
			    Cloud Hosted
			  </label>
			</div>
			<div class="radio">
			  <label>
			    <input type="radio" name="hostingType" id="hostingRadio_3" value="ASP Hosted">
			    ASP Hosted
			  </label>
			</div>
			<div class="radio">
			  <label>
			    <input type="radio" name="hostingType" id="hostingRadio_4" value="On Premise">
			    On Premise
				</label>
			</div>
		</div> <!-- END of COLUMN -->

	</div><!-- END OF ROW -->

	<div class="row lightborder" id="project_options">  

		<!-- CONVERSIONS DIV -->
		<div class="col-lg-4 bg-blue_1 height-full">
		 	<h4>Conversions</h4>	
		 	<div name="conversions" id="conversions_1" class="hide">
			 	<?php foreach ($conversions_Array_1 as $conversion): ?>
			 		<div class="checkbox">
						<label>
						    <input type="checkbox" name="conversions" value="<?php echo $conversion['conversionId'] ?>">
						   	<?php echo $conversion['conversionName'] ?>
						</label>
					</div>
			 	<?php endforeach ?>
			</div><!-- END OF CHECKBOX GROUP -->

			<div name="conversions" id="conversions_2" class="hide">
			 	<?php foreach ($conversions_Array_2 as $conversion): ?>
			 		<div class="checkbox">
						<label>
						    <input type="checkbox" name="conversions" value="<?php echo $conversion['conversionId'] ?>">
						   	<?php echo $conversion['conversionName'] ?>
						</label>
					</div>
			 	<?php endforeach ?>				
			</div><!-- END OF CHECKBOX GROUP -->

			<div name="conversions" id="conversions_3" class="hide">
			 	<?php foreach ($conversions_Array_3 as $conversion): ?>
			 		<div class="checkbox">
						<label>
						    <input type="checkbox" name="conversions" value="<?php echo $conversion['conversionId'] ?>">
						   	<?php echo $conversion['conversionName'] ?>
						</label>
					</div>
			 	<?php endforeach ?>
			</div><!-- END OF CHECKBOX GROUP -->
			

		</div>

		<!-- INTERFACES DIV -->
		<div class="col-lg-4 bg-blue_2 height-full">
		 	<h4>Interfaces</h4>		
		 	<div name="interfaces" id="interfaces_1" class="hide">
		 		<?php foreach ($interfaces_Array_1 as $interface): ?>
			 		<div class="checkbox">
						<label>
						    <input type="checkbox" name="interfaces" value="<?php echo $interface['interfaceId'] ?>">
						   	<?php echo $interface['interfaceName'] ?>
						</label>
					</div>
			 	<?php endforeach ?>			 	
			</div><!-- END OF CHECKBOX GROUP -->

			<div name="interfaces" id="interfaces_2" class="hide">
			 	<?php foreach ($interfaces_Array_2 as $interface): ?>
			 		<div class="checkbox">
						<label>
						    <input type="checkbox" name="interfaces" value="<?php echo $interface['interfaceId'] ?>">
						   	<?php echo $interface['interfaceName'] ?>
						</label>
					</div>
			 	<?php endforeach ?>	
			</div><!-- END OF CHECKBOX GROUP -->
			<div name="interfaces" id="interfaces_3" class="hide">
			 	<?php foreach ($interfaces_Array_3 as $interface): ?>
			 		<div class="checkbox">
						<label>
						    <input type="checkbox" name="interfaces" value="<?php echo $interface['interfaceId'] ?>">
						   	<?php echo $interface['interfaceName'] ?>
						</label>
					</div>
			 	<?php endforeach ?>	
			</div><!-- END OF CHECKBOX GROUP -->

		</div>

		<!-- ADD ONS DIV -->
		<div class="col-lg-4 bg-blue_1 height-full">
		 	<h4>Add Ons</h4>

		 	<div name="addOns" id="addOns_1" class="hide">	
			 	<?php foreach ($addOns_Array_1 as $addOn): ?>
			 		<div class="checkbox">
						<label>
						    <input type="checkbox" name="addOns" value="<?php echo $addOn['addOnId'] ?>">
						   	<?php echo $addOn['addOnName'] ?>
						</label>
					</div>
			 	<?php endforeach ?>	
			</div><!-- END OF CHECKBOX GROUP -->

			<div name="addOns" id="addOns_2" class="hide">	
			 	<?php foreach ($addOns_Array_2 as $addOn): ?>
			 		<div class="checkbox">
						<label>
						    <input type="checkbox" name="addOns" value="<?php echo $addOn['addOnId'] ?>">
						   	<?php echo $addOn['addOnName'] ?>
						</label>
					</div>
			 	<?php endforeach ?>				
			</div><!-- END OF CHECKBOX GROUP -->

			<div name="addOns" id="addOns_3" class="hide">	
			 	<?php foreach ($addOns_Array_3 as $addOn): ?>
			 		<div class="checkbox">
						<label>
						    <input type="checkbox" name="addOns" value="<?php echo $addOn['addOnId'] ?>">
						   	<?php echo $addOn['addOnName'] ?>
						</label>
					</div>
			 	<?php endforeach ?>	
			</div><!-- END OF CHECKBOX GROUP -->

		</div>	<!-- END of COLUMN -->

	</div><!-- END OF ROW -->
	
	<div class="row top-buffer" style="margin-bottom:20px;!important">  
		<div class="col-lg-12"> 
			<button type="submit" class="btn btn-default btn-lg center-block">Add Project</button>
		</div>
	</div><!-- END OF ROW -->
		
</form>

	<div class="row">
		<div id="processingDiv" class="processingDiv bg-info">
		    <img src="<?php echo base_url("assets/img/loader.gif"); ?>" /> Processing..
		 </div> 

		<div id="msgBox" class="msgBox bg-danger text-center">
          This primary contact email is already present in the system. Please check and try again.
        </div>
        
	</div> <!-- END of ROW -->


</div> <!-- End of Container -->

<!-- <a href="javascript:fnCheckValues()">Check Values</a> -->

<script type="text/javascript">
	var baseURL = <?php echo json_encode(base_url("index.php/projects/newproject/")) ?>;
	var msg_array = ["This primary contact email is already present in the system. Please check and try again.", "An organization with this CDH Number is already present in the system. Please check and try again."];

	$('input, textarea').placeholder();

	//Handle the conversion, interface and addon options group based on the product selected
	$('[name=productName]').change(function(){
	    //alert("The text has been changed.");
	    for(var i=1;i<=3;i++){
	    	$("#conversions_"+i).removeClass("show");
	    	$("#conversions_"+i).addClass("hide");	    		    	

	    	$("#interfaces_"+i).removeClass("show");
	    	$("#interfaces_"+i).addClass("hide");

	    	$("#addOns_"+i).removeClass("show");
	    	$("#addOns_"+i).addClass("hide");

	    	//Clear all checkbox selections:
	    	$('input[type=checkbox]').removeAttr('checked');
	    }

	    var selectedProduct = $("input[name=productName]:checked").val();
	    $("#conversions_"+selectedProduct).addClass("show");
	    $("#interfaces_"+selectedProduct).addClass("show");
	    $("#addOns_"+selectedProduct).addClass("show");
	    //alert($("input[name=productName]:checked").val());
	});

	

	function fnGetCheckBoxValue(checkBoxName){
		var selectedArray = [];
		$.each($("input[name='"+checkBoxName+"']:checked"), function(){
            selectedArray.push($(this).val());
        });
       // alert("My favourite sports are: " + favorite.join("$"));
        return selectedArray.join("$");
	}

	 $(document).ready(function() {
	   
	    $('#defaultForm')
		    .formValidation({

		        message: 'This value is not valid',
		        icon: {
		            valid: 'glyphicon glyphicon-ok',
		            invalid: 'glyphicon glyphicon-remove',
		            validating: 'glyphicon glyphicon-refresh'
		        },

		        fields: {
		            organizationName: {
		                validators: {
		                    notEmpty: {
		                        message: 'The organization name is required'
		                    }
		                }
		            },
		            cdhNum: {	                
		                validators: {
		                    notEmpty: {
		                        message: 'The CDH Number is required'
		                    },
		                    greaterThan: {
		                        value: 8
		                    }
		                }
		            },
		            address: {
		                validators: {
		                    notEmpty: {
		                        message: 'The address field is required'
		                    }
		                }
		            },
		            userName: {
		                validators: {
		                    notEmpty: {
		                        message: 'The primary contact\'\s name is required'
		                    }
		                }
		            },
		            userMail: {
		                validators: {
		                    notEmpty: {
		                        message: 'The email address is required'
		                    },
		                    emailAddress: {
		                        message: 'The input is not a valid email address'
		                    }
		                }
		            },
		            phone: {
		                validators: {
		                    notEmpty: {},
		                    digits: {},
		                    phone: {
		                        country: 'US'
		                    }
		                }
		            },
		            projectType: {
		                validators: {
		                    notEmpty: {}
		                }
		            },
		            productName: {
		                validators: {
		                    notEmpty: {}
		                }
		            },
		            hostingType: {
		                validators: {
		                    notEmpty: {}
		                }
		            }/*,
		            'conversions[]': {
		                validators: {
		                    notEmpty: {}
		                }
		            },
		            'interfaces[]': {
		                validators: {
		                    notEmpty: {}
		                }
		            },
		            'addOns[]': {
		                validators: {
		                    notEmpty: {}
		                }
		            }*/
		       
		        }
		    })	
			.on('success.form.fv', function(e) {
				// If you want to prevent the default handler (formValidation._onSuccess(e))
	            //console.log('success.form.fv');
	            e.preventDefault();
	            // 

	            fnSendProjectDetails();          
	            
	        });
	});

	
	function fnSendProjectDetails(){
		$("#processingDiv").show();

		var action = baseURL + "/addNewProject/";
	    var form_data = {	      
	      'organizationName': $("#organizationName").val(),
	      'cdhNum': $("#cdhNum").val(),
	      'address': $("#address").val(),
	      'userName': $("#userName").val(),
	      'userMail': $("#userMail").val(),
	      'phone': $("#phone").val(),
	      'projectType': $('input[name=projectType]:checked' ).val(),
	      'productName': $('input[name=productName]:checked' ).val(),
	      'hostingType': $('input[name=hostingType]:checked' ).val(),
	      'conversions': fnGetCheckBoxValue('conversions'),
	      'interfaces': fnGetCheckBoxValue('interfaces'),
	      'addOns': fnGetCheckBoxValue('addOns')
	    };

	    $.ajax({
	      	type: "POST",
	      	url: action,
	      	data: form_data,
	      	success: function(response)
	      	{	
	      		//alert(response);
	      		var responseObj = $.parseJSON(response);
	      		$("#processingDiv").hide();
	      		
	      		if(responseObj.status=="usermail"){
	      			$('#msgBox').html(msg_array[0]);
	      			$('#msgBox').fadeIn();
	      		}else if(responseObj.status=="cdh"){
	      			$('#msgBox').html(msg_array[1]);
	      			$('#msgBox').fadeIn();
	      		}else if(responseObj.status=="success"){
	      			window.location.href = <?php echo json_encode(base_url("index.php/team/teamstructure/showCurrentTeam/")) ?> + "/" + responseObj.projectId;	
	      		}

	      		
	      		
	      	}
	    });
	}


	
</script>