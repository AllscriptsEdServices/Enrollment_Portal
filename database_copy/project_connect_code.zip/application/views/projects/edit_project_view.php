
<div class="container my_container">

<!--<?php echo validation_errors(); ?>
<?php echo form_open('projects/newproject/fnAddNewProject'); ?>-->
<form id="defaultForm"  method="" class="" action="">
	<div class="row ">		
		<div class="col-lg-12 ">
			<h2 class="center-block">Project - <?php echo $projectData["organizationName"] ?></h2>
		</div>
	</div>

	<div class="row lightborder">
		 <div class="col-lg-6 rightBorder">
		 	
		 	<h3>Organization Details</h3>
		 	<div class="form-group">
				<label class="control-label" for="organizationName">Organization Name</label>
				<input type="text" class="form-control" id="organizationName" name="organizationName" value="<?php echo $projectData["organizationName"] ?>" placeholder="Enter Organization Name">
			</div>
			<div class="form-group">
				<label class="control-label" for="cdhNum">CDH Number</label>
				<input type="text" class="form-control" id="cdhNum" name="cdhNum" value="<?php echo $projectData["cdhNum"] ?>"  placeholder="Enter CDH Number">
			</div>
			<div class="form-group">
				<label class="control-label" for="address">Address</label>
				<textarea class="form-control" id="address" name="address" rows="3"><?php echo $projectData["address"] ?></textarea>
			</div>
			
		 </div><!-- END of COLUMN -->

		<div class="col-lg-6">
		 	<h3>Primary Contact</h3>
		 	<div class="form-group">
				<label class="control-label" for="userName">Name</label>
				<input type="text" class="form-control" id="userName" name="userName" value="<?php echo $primaryUser["name"] ?>" placeholder="John Doe">
			</div>
			<div class="form-group">
				<label class="control-label" for="userMail">Contact's Email</label>
				<input type="email" class="form-control" id="userMail" name="userMail" value="<?php echo $primaryUser["mail"] ?>" placeholder="john.doe@example.com">
			</div>
			<div class="form-group">
				<label class="control-label" for="phone">Phone</label>
				<input type="text" class="form-control" id="phone" name="phone" value="<?php echo $primaryUser["phone"] ?>" placeholder="Enter Phone Number">
			</div>
			
			<input type="hidden" class="form-control" id="projectId" name="projectId" value="<?php echo $projectId ?>" placeholder="">
			<input type="hidden" class="form-control" id="primaryContactId" name="primaryContactId" value="<?php echo $primaryUser["userId"] ?>" placeholder="">

		</div><!-- END of COLUMN -->
	</div> <!-- END OF ROW -->

	<div class="row ">

	</div>
	 <div class="row top-buffer lightborder">
	 	<div class="col-sm-4 "> 
	 		<h3>Project Type</h3>
	 		<?php

	 			$is_new_client = ($projectData["projectType"] == "New")? "checked" : "";
	 			$is_existing_client = ($projectData["projectType"] == "Existing")? "checked" : "";

	 			echo '<div class="radio">';
	 				echo '<label>';
	 				echo '<input type="radio" name="projectType" id="projectType_1" '.$is_new_client.' disabled value="New">';
	 				echo 'Net New Client (new to product)';
	 				echo '</label>';
	 			echo '</div>';

	 			echo '<div class="radio">';
	 				echo '<label>';
	 				echo '<input type="radio" name="projectType" id="projectType_2" '.$is_existing_client.' disabled value="Existing">';
	 				echo 'Existing Client (already live on product)';
	 				echo '</label>';
	 			echo '</div>';
	 			
	 		?>
			
		</div> <!-- END of COLUMN -->

		<div class="col-sm-4 products">
			<h3>Product</h3>
			<?php 
				foreach ($productTypes as $product){					
					echo '<div class="radio">';
					echo '<label>';
					if($product['id'] == $projectData["productId"]){
						
						echo '<input type="radio" name="productName" id="productRadio_'.$product['id'].'" checked value="'.$product['id'].'">'.$product['productName'];
					}else{					
						echo '<input type="radio" name="productName" id="productRadio_'.$product['id'].'" value="'.$product['id'].'">'.$product['productName'];
					}
					echo '</label>';
					echo '</div>';
				}
			?>
				
		</div><!-- END of COLUMN -->
		

		<div class="col-sm-4 "> 
	 		<h3>Installation Type</h3>
	 		<?php

	 			$idCounter = 1;
	 			foreach ($hosting_types as $single_type) {	 			
	 				echo '<div class="radio">';
	 				echo '<label>';
	 				if($single_type == $projectData["hostingType"]){
	 					echo '<input type="radio" name="hostingType" id="hostingRadio_'.$idCounter.'" checked value="'.$single_type.'">';
	 				}else{
	 					echo '<input type="radio" name="hostingType" id="hostingRadio_'.$idCounter.'" value="'.$single_type.'">';
	 				}
	 				echo $single_type;
	 				echo '</label>';
	 				echo '</div>';
	 				$idCounter++;
	 			}

	 		?>
			
		</div> <!-- END of COLUMN -->

	</div><!-- END OF ROW -->

	<div class="row lightborder" id="project_options">  

		<!-- CONVERSIONS DIV -->		
		<div class="col-sm-4 bg-blue_1 height-full">
		 	<h4>Conversions</h4>	

		 	<?php 
		 		$project_conversions_array = explode("$", $projectData["conversions"]);

		 		for($i = 1; $i<=3; $i++){
		 			if($i == $projectData["productId"]){ 
		 				echo '<div name="conversions" id="conversions_'.$i.'" class=""> ';
		 			}else{
		 				echo '<div name="conversions" id="conversions_'.$i.'" class="hide"> ';
		 			}

		 			$standard_conversions = ${"conversions_Array_{$i}"};
		 			foreach ($standard_conversions as $conversion){
		 				echo '<div class="checkbox">';
							echo '<label>';
								if(in_array($conversion['conversionId'], $project_conversions_array)){
									echo '<input type="checkbox" name="conversions" checked value="'.$conversion["conversionId"].'">';
								}else{
									echo '<input type="checkbox" name="conversions" value="'.$conversion["conversionId"].'">';
								}						
							    echo $conversion['conversionName'];
							echo '</label>';
						echo '</div>';
		 			}

		 			echo '</div>';
		 		}

		 	?>		 
		 		

		</div>


		<!-- INTERFACES DIV -->
		<div class="col-sm-4 bg-blue_2 height-full">
		 	<h4>Interfaces</h4>		

		 	<?php 
		 		$project_interfaces_array = explode("$", $projectData["interfaces"]);

		 		for($i = 1; $i<=3; $i++){
		 			if($i == $projectData["productId"]){ 
		 				echo '<div name="interfaces" id="interfaces_'.$i.'" class=""> ';
		 			}else{
		 				echo '<div name="interfaces" id="interfaces_'.$i.'" class="hide"> ';
		 			}

		 			$standard_interfaces = ${"interfaces_Array_{$i}"};
		 			foreach ($standard_interfaces as $interface){
		 				echo '<div class="checkbox">';
							echo '<label>';
								if(in_array($interface['interfaceId'], $project_interfaces_array)){
									echo '<input type="checkbox" name="interfaces" checked value="'.$interface["interfaceId"].'">';
								}else{
									echo '<input type="checkbox" name="interfaces" value="'.$interface["interfaceId"].'">';
								}						
							    echo $interface['interfaceName'];
							echo '</label>';
						echo '</div>';
		 			}

		 			echo '</div>';
		 		}

		 	?>		 	

		</div>

		<!-- ADD ONS DIV -->
		<div class="col-sm-4 bg-blue_1 height-full">
		 	<h4>Add Ons</h4>

		 	<?php 
		 		$project_addons_array = explode("$", $projectData["addOns"]);

		 		for($i = 1; $i<=3; $i++){
		 			if($i == $projectData["productId"]){ 
		 				echo '<div name="addOns" id="addOns_'.$i.'" class=""> ';
		 			}else{
		 				echo '<div name="addOns" id="addOns_'.$i.'" class="hide"> ';
		 			}

		 			$standard_addons = ${"addOns_Array_{$i}"};
		 			foreach ($standard_addons as $addOn){
		 				echo '<div class="checkbox">';
							echo '<label>';
								if(in_array($addOn['addOnId'], $project_addons_array)){
									echo '<input type="checkbox" name="addOns" checked value="'.$addOn["addOnId"].'">';
								}else{
									echo '<input type="checkbox" name="addOns" value="'.$addOn["addOnId"].'">';
								}						
							    echo $addOn['addOnName'];
							echo '</label>';
						echo '</div>';
		 			}

		 			echo '</div>';
		 		}

		 	?>

		

		</div>	<!-- END of COLUMN -->

	</div><!-- END OF ROW -->
	
	<div class="row top-buffer" style="margin-bottom:20px;!important">  
		<div class="col-lg-12"> 
			<button type="submit" class="btn btn-default btn-lg center-block">Update Project</button>
		</div>
	</div><!-- END OF ROW -->
		
</form>

	<div class="row">
		<div id="processingDiv" class="processingDiv bg-info">
		    <img src="<?php echo base_url("assets/img/loader.gif"); ?>" /> Processing..
		 </div> 

		<div id="errorBox" class="msgBox bg-danger text-center">
          This primary contact email is already present in the system. Please check and try again.
        </div>

        <div id="msgBox" class="msgBox bg-success text-center">
          The project details have been updated successfully.
        </div>

        
	</div> <!-- END of ROW -->


</div> <!-- End of Container -->



<script type="text/javascript">
	var baseURL = <?php echo json_encode(base_url("index.php/projects/editproject/")) ?>;
	var msg_array = ["This primary contact email is already present in the system. Please check and try again.", "An organization with this CDH Number is already present in the system. Please check and try again."];

	$('input, textarea').placeholder();

	//Handle the conversion, interface and addon options group based on the product selected
	$('[name=productName]').change(function(){
	    //alert("The text has been changed.");
	    for(var i=1;i<=3;i++){
	    	$("#conversions_"+i).removeClass("show");
	    	$("#conversions_"+i).addClass("hide");	    		    	

	    	$("#interfaces_"+i).removeClass("show");
	    	$("#interfaces_"+i).addClass("hide");

	    	$("#addOns_"+i).removeClass("show");
	    	$("#addOns_"+i).addClass("hide");

	    	//Clear all checkbox selections:
	    	$('input[type=checkbox]').removeAttr('checked');
	    }

	    var selectedProduct = $("input[name=productName]:checked").val();

	    $("#conversions_"+selectedProduct).addClass("show");
	    $('.conversions').each(function(){
			this.checked = false;
		});

	    $("#interfaces_"+selectedProduct).addClass("show");
	    $('.interfaces').each(function(){
			this.checked = false;
		});

	    $("#addOns_"+selectedProduct).addClass("show");
	    $('.addOns').each(function(){
			this.checked = false;
		});
	});

	$('[name=conversions]').change(function(){
		$("#defaultForm").formValidation('disableSubmitButtons', true);
	});
	

	function fnGetCheckBoxValue(checkBoxName){
		var selectedArray = [];
		$.each($("input[name='"+checkBoxName+"']:checked"), function(){
            selectedArray.push($(this).val());
        });       
        return selectedArray.join("$");
	}

	 $(document).ready(function() {
	   
	    $('#defaultForm')
		    .formValidation({

		        message: 'This value is not valid',
		        icon: {
		            valid: 'glyphicon glyphicon-ok',
		            invalid: 'glyphicon glyphicon-remove',
		            validating: 'glyphicon glyphicon-refresh'
		        },

		        fields: {
		            organizationName: {
		                validators: {
		                    notEmpty: {
		                        message: 'The organization name is required'
		                    }
		                }
		            },
		            cdhNum: {	                
		                validators: {
		                    notEmpty: {
		                        message: 'The CDH Number is required'
		                    },
		                    greaterThan: {
		                        value: 8
		                    }
		                }
		            },
		            address: {
		                validators: {
		                    notEmpty: {
		                        message: 'The address field is required'
		                    }
		                }
		            },
		            userName: {
		                validators: {
		                    notEmpty: {
		                        message: 'The primary contact\'\s name is required'
		                    }
		                }
		            },
		            userMail: {
		                validators: {
		                    notEmpty: {
		                        message: 'The email address is required'
		                    },
		                    emailAddress: {
		                        message: 'The input is not a valid email address'
		                    }
		                }
		            },
		            phone: {
		                validators: {
		                    notEmpty: {},
		                    digits: {},
		                    phone: {
		                        country: 'US'
		                    }
		                }
		            },
		            productName: {
		                validators: {
		                    notEmpty: {}
		                }
		            },
		            hostingType: {
		                validators: {
		                    notEmpty: {}
		                }
		            }/*,
		            'conversions[]': {
		                validators: {
		                    notEmpty: {}
		                }
		            },
		            'interfaces[]': {
		                validators: {
		                    notEmpty: {}
		                }
		            },
		            'addOns[]': {
		                validators: {
		                    notEmpty: {}
		                }
		            }*/
		       
		        }
		    })	
			.on('success.form.fv', function(e) {
				// If you want to prevent the default handler (formValidation._onSuccess(e))
	            //console.log('success.form.fv');
	            e.preventDefault();
	            // 	

	            fnUpdateProjectDetails();
	            
	        });
	});

	
	function fnUpdateProjectDetails(){		
		$("#processingDiv").show();
		//alert(fnGetCheckBoxValue('conversions'));
		var action = baseURL + "/updateProject/";
	    var form_data = {	      
	      'primaryContactId': $("#primaryContactId").val(),
	      'projectId': $("#projectId").val(),
	      'organizationName': $("#organizationName").val(),
	      'cdhNum': $("#cdhNum").val(),
	      'address': $("#address").val(),
	      'userName': $("#userName").val(),
	      'userMail': $("#userMail").val(),
	      'phone': $("#phone").val(),
	      'productName': $('input[name=productName]:checked' ).val(),
	      'hostingType': $('input[name=hostingType]:checked' ).val(),
	      'conversions': fnGetCheckBoxValue('conversions'),
	      'interfaces': fnGetCheckBoxValue('interfaces'),
	      'addOns': fnGetCheckBoxValue('addOns')
	    };

	    $.ajax({
	      	type: "POST",
	      	url: action,
	      	data: form_data,
	      	success: function(response)
	      	{		      		
	      		$("#processingDiv").hide();

	      		if(response=="Success"){
	      			$('#msgBox').fadeIn();
	      		}	      			      		
	      		
	      	}
	    });
	}


	
</script>