<script>
	/*$("#mainNav li").removeClass("active");		
	$("#"+<?php echo json_encode($activeTab) ?>).addClass('active');*/	
	
</script>

</body>

</html>