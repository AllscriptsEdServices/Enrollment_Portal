<?php
//echo md5('1234');

?>

<!DOCTYPE HTML>
<html lang="en" >
<head>
	<meta charset="utf-8" />
	<meta name="author" content="Vishwajit Menon" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Project Connect</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>">
	<!-- <link rel="stylesheet" href="<?php echo base_url("assets/css/main.css"); ?>"> -->


	<style type="text/css">
		.navbar-brand,
	.navbar-nav li a {
	    line-height: 70px;
	    height: 70px;
	    padding-top: 0;
	}
	.navbar-brand{
		padding:10px;
	}
	.height-full{
		height:300px;
	}
	.btn {
	    text-transform: uppercase;
	    /*font-family: Montserrat,"Helvetica Neue",Helvetica,Arial,sans-serif;*/
	    font-weight: 400;
	    -webkit-transition: all .3s ease-in-out;
	    -moz-transition: all .3s ease-in-out;
	    transition: all .3s ease-in-out;
	}

	.btn-default {
	    border: 1px solid #93C508;
	    color: #93C508;
	    background-color: transparent;
	}

	.btn-default:hover,
	.btn-default:focus {
	    border: 1px solid #93C508;
	    outline: 0;
	    color: #000;
	    background-color: #93C508;
	}

	.login-header{
		background-color:#52841f; 
		border-radius:10px 10px 0px 0px;
	}

	.login-body{
		/*7ab800*/
		border:1px solid #52841f;
		border-top-width: 0px;
		padding-top:10px;
		padding-bottom: 15px;
		border-radius: 0px 0px 10px 10px;
	}
	</style>

	<script src="<?php echo base_url("assets/js/modernizr.custom.26324.js"); ?>"></script>
	<script src="<?php echo base_url("assets/js/css3-mediaqueries.js"); ?>"></script>

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	  <!--[if lt IE 9]>
	      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	  <![endif]-->

	<script src="<?php echo base_url("assets/js/jquery-1.11.0.js"); ?>"></script> 
	<script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>"></script> 
	<script src="<?php echo base_url("assets/plugins/jquery-placeholder-master/jquery.placeholder.min.js"); ?>"></script> 

</head>

<nav class="navbar navbar-inverse" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
	      <!-- <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-main"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
	      <a class="navbar-brand" id="brandName" href="#"><img src="<?php echo base_url("assets/img/proj_conn_v1.png"); ?>"/></a> 
  	</div> 
  </div>
</nav>
<!-- /navbar --> 


<div class="container-fluid">
	<div class="row" style="margin-top:20px"> 
		<div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-8 col-xs-offset-2 text-center login-header" style="">
			<h3 style="color:#ffffff">Internal Login</h3>
		</div>
	</div>

	<div class="row">   		

	    <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-8 col-xs-offset-2 login-body" style="">
	    	<span style="color:red"><?php echo validation_errors(); ?></span>
	    	<?php echo form_open('verifylogin'); ?>
	   		<!-- <form> -->
				<div class="form-group">
					<label class="control-label" for="exampleInputEmail1">Email address</label>
					<input type="email" class="form-control" id="mail" name="mail" placeholder="Enter email">				
				</div>
				<div class="form-group">
					    <label for="exampleInputPassword1">Password</label>
					    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
				</div>		
		
				<button type="submit" class="btn btn-default  center-block">Submit</button>
		
			</form>
			<a href="#" class="pull-right" data-toggle="modal" data-target="#myModal">Forgot Password</a>
			
		</div> 		

	</div> <!-- END OF ROW -->


	<div class="modal fade" id="myModal" data-keyboard="false" data-backdrop="static">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		        <h4 class="modal-title">Password Recovery</h4>
	      </div>
	      <div class="modal-body">
		      	<p>Enter your registered email address and we'll mail you a temporary password.</p>
		      	<label class="control-label" for="forgotMail">Email Address</label>
		        <input type="email" class="form-control" id="forgotMail" name="forgotMail" placeholder="Enter email">

		        <div id="msg-error" class="bg-danger hidden" style="margin-top:20px; padding:5px;">
		        	<p>This email is not registered in the system. Please check the email address and retry.</p> 
		        	<p>For further assisstance/queries you can reach out to <a href="mailTo:info-projectconnect@allscripts.com">info-projectconnect@allscripts.com</a>.</p>
		    	</div>

		    	<div id="msg-success" class="bg-success hidden" style="margin-top:20px; padding:5px;">
		        	<p>Your password has been reset! You will be receiving a mail with the temporary password shortly to the above mail address. If you cannot find it in your Inbox, please check the Junk/Spam folders as well.</p> 
		        	<p>If you are still facing problems logging in, you can write to <a href="mailTo:info-projectconnect@allscripts.com">info-projectconnect@allscripts.com</a>.</p>
		        </div>

	      </div>
	      <div class="modal-footer">	        
	        <button id="forgot_submit_btn" type="button" class="btn btn-primary" onclick="fnForgotPassword()">Submit</button>
	      </div>
	    </div><!-- /.modal-content -->
	  </div><!-- /.modal-dialog -->
	</div><!-- /.modal -->



</div>   <!-- END OF CONTAINER -->


<!-- footer -->
<!-- <footer>
  <hr/>
  <div class="container">
    <p class="text-right"></p>
  </div>
</footer> -->
<!-- /footer --> 

<!-- js --> 


<script type="text/javascript">
	var baseURL = <?php echo json_encode(base_url("index.php/login/")) ?>;
	$('input, textarea').placeholder();

	function fnForgotPassword(){
		if(validateEmail($("#forgotMail").val()))
		{
			var action = baseURL + "/forgotPassword";
		    var form_data = {
		      'forgotMail': $("#forgotMail").val()
		    };

		    $.ajax({
		      	type: "POST",
		      	url: action,
		      	data: form_data,
		      	success: function(response)
		      	{		      				      
		      		if(response == "Success"){
		      			$("#msg-success").removeClass("hidden");
		      			$("#msg-error").addClass("hidden");
		      			$("#forgot_submit_btn").hide();
		      		}else{
		      			$("#msg-success").addClass("hidden");
		      			$("#msg-error").removeClass("hidden");
		      		}		      		
		      	}
		    });
		}
		else
		{
			alert("Enter a valid email.");
		}
		
	}

	function validateEmail(email) { 
	    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    return re.test(email);
	} 

	
</script>
</body>
</html>