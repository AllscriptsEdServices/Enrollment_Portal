
<div class="container-fluid">  

	<div class="row">

		<div class="column col-sm-10">
			<h3>My Support Team</h3>
			<p>You can invite team members from your organization, who will be assissting you with this implementation. Once you add them, they will receive a mail with access details to the tool.</p>
		</div>

	</div> <!-- / End of ROW -->


	<div class="row form_row">
		<div class="column col-xs-12" style="padding-right:0px">
	  		<button id="add_member_btn" class="btn btn-primary pull-right">Add Member <span id="add_member_glyph" class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></button>
	  	</div>

	  	<form id="defaultForm" method="" class="" action="">
		  	<div id="addMember_div" class="addMember_div">				

				<div class="column col-xs-4">
					<div class="form-group">
						<label class="control-label" for="name">Name</label>
						<input type="text" class="form-control" id="name" name="name" placeholder="John Doe" value="">
					</div>
				</div>

				<div class="column col-xs-4">
					<div class="form-group">
						<label class="control-label" for="mail">Email</label>
						<input type="text" class="form-control" id="mail" name="mail" placeholder="john.doe@example.com" value="">			 
					</div>	
				</div>

				<div class="column col-xs-4">
					<div class="form-group">
						<label class="control-label" for="phone">Phone</label>
						<input type="text" class="form-control" id="phone" name="phone" placeholder="1000200300" value=""> 
					</div>
				</div>
				
				<div class="column col-xs-12">
					<button type="submit" class="btn btn-primary center-block">Submit</button>
				</div>
		  		
		  		<div class="column col-xs-12" style="margin:5px 0px">
			  		<div id="msgBox" class="msgBox bg-success">
			          This member has been added. A mail with login details to the tool has been sent.
			        </div>
			        <div id="errorBox" class="msgBox bg-danger">
			          A member by this email already exists in the system.
			        </div>
			    </div>

			</div> <!-- End of addMember_div  -->

		</form>

	</div> <!-- End of ROW -->

	<div class="row">
  	<div class="column col-xs-12">
  		<table id="memberlist_table" class="table table-bordered table-striped">
  			<tr>
  				<th>Member Name</th>
  				<th class="hidden-sm hidden-xs">Email</th>
  				<th>Phone</th>
  				<!-- <th class="hidden-sm hidden-xs">Contact Name</th>
  				<th class="hidden-sm hidden-xs">Contact Email</th>
  				<th>Order Status</th>
  				<th>Order Accepted On</th>
  				<th>Actions</th> -->
  			</tr>
  			<?php
  				foreach ($members as $single_member) { 
  			
	  				echo '<tr>';
	  				echo '<td>'.$single_member["name"].'</td>';
	  				echo '<td>'.$single_member["mail"].'</td>';
	  				echo '<td>'.$single_member["phone"].'</td>';
	  				echo '</tr>';
	  			}

  			?>
  			<!--<?php 
	  			foreach ($clients as $client) { 
	  				echo '<tr>';

	  				echo '<td>'.$client['orgName'].'</td>';
	  				echo '<td class="hidden-sm hidden-xs">'.$client['accountNumber'].'</td>';
	  				echo '<td>'.$client['curriculumName'].'</td>';
	  				echo '<td class="hidden-sm hidden-xs">'.$client['contactName'].'</td>';
	  				echo '<td class="hidden-sm hidden-xs">'.$client['contactEmail'].'</td>';
	  				if($client['order_final']==1){
	  					echo '<td>Order Submiited</td>';
	  					echo '<td>'.$client['order_accepted_date'].'</td>';
	  					$order_url = base_url("index.php/clientlist/showOrder/")."/".$client["clientId"]."/".$client["curriculumId"];
	  					echo '<td><a href="'.$order_url.'">Order Details</td>';
	  				}else{
	  					echo '<td>NA</td>';
	  					echo '<td>NA</td>';
	  					echo '<td>NA</td>';
	  				}

	  				echo '</tr>';

	  			}
  			?> -->

  		</table>
  	</div>
  </div>


</div> <!-- End of Container -->


<script type="text/javascript">
	var baseURL = <?php echo json_encode(base_url("index.php/myteam/teamadmin")) ?>;
	$('input, textarea').placeholder();

	$("#add_member_btn").click(function(){
		$("#addMember_div").fadeToggle();
		$("#add_member_glyph").toggleClass("glyphicon-chevron-down");
		$("#add_member_glyph").toggleClass("glyphicon-chevron-up");
	})

	$(document).ready(function() {
	   
	    $('#defaultForm')
		    .formValidation({

		        message: 'This value is not valid',
		        icon: {
		            valid: 'glyphicon glyphicon-ok',
		            invalid: 'glyphicon glyphicon-remove',
		            validating: 'glyphicon glyphicon-refresh'
		        },

		        fields: {
		            name: {
		                validators: {
		                    notEmpty: {
		                        message: 'The member\'\s name is required'
		                    }
		                }
		            },		            
		            phone: {	                
		                 validators: {
		                    notEmpty: {},
		                    digits: {},
		                    phone: {
		                        country: 'US'
		                    }
		                }
		            },		            
		           
		            mail: {
		                validators: {
		                    notEmpty: {
		                        message: 'The email address is required'
		                    },
		                    emailAddress: {
		                        message: 'The input is not a valid email address'
		                    }
		                }
		            }
		        }
		    })	
			.on('success.form.fv', function(e) {
	            //console.log('success.form.fv');
	            e.preventDefault();
	            fnAddMember();

	            // If you want to prevent the default handler (formValidation._onSuccess(e))
	            // 
	        });
	});
	

	function fnAddMember(){
		$("#errorBox").hide();    
		var action = baseURL + "/addMember";
	    var form_data = {		      
	      'name': $("#name").val(),		      
	      'mail': $("#mail").val(),		      
	      'phone': $("#phone").val()		      
	    };

	    $.ajax({
	      	type: "POST",
	      	url: action,
	      	data: form_data,
	      	success: function(response)
	      	{	
	      		if(response!="User Exists"){
	      			$("#msgBox").fadeIn();	      

	      			var newRow = '<tr><td>'+ $("#name").val()+ '</td>  <td>' + $("#mail").val() + '</td> <td>' + get_us_phone_format($("#phone").val()) + '</td> </tr>';
	      			$('#memberlist_table > tbody').append(newRow);
	      			
	      		}else{
	      			$("#errorBox").fadeIn();
	      		}

	      	}
	    });

      	
	      	
		
	}

	function get_us_phone_format(phone_number){
		return phone_number.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
	}

</script>