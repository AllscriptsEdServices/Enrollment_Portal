<div class="container-fluid">   
<button onclick="GoBack()" class="btn btn-default"><span class="glyphicon glyphicon-search" aria-hidden="true"></span> Back to Search</button>
  <div class="row top-buffer">
    <div class="col-xs-10 well col-xs-offset-1"  id="orgDetails">
      <span class="lead" style="color:#444;"><?php echo $projectInfo["organizationName"] ?></span><br>
      <span style="color:#777;"><?php echo $projectInfo["address"] ?></span><br>
      <span style="color:#777;">Date Added: 2015-02-22</span>
      <span class="pull-right">Cl;et</span>
    </div>
  </div>


<!--  <?php foreach ($stagesDetails as $stage): ?>             
    <?php echo $stage["stageName"] ?> <br>
  <?php endforeach ?>  -->

  <div class="row">
      <div class="col-sm-3" id="leftNav">
        <!-- <ul class="nav nav-stacked " data-spy="affix" id="" data-offset-top="195"> -->     

          <!-- Nav tabs -->
          <ul class="nav nav-tabs" role="tablist">
            <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Professional EHR</a></li>
            <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Allscripts PM</a></li>            
          </ul>

          <div class="panel-group top-buffer" id="accordion" role="tablist" aria-multiselectable="true">
              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="heading_1">
                  <h4 class="panel-title">
                    <!-- <a data-toggle="collapse" data-parent="#accordion" href="#collapse_1" aria-expanded="true" aria-controls="collapse_1"> -->
                      <a data-toggle="collapse" data-parent="#collapse_1" href="#collapse_1" aria-expanded="true" aria-controls="collapse_1">
                      Design/Build 
                      <span class="glyphicon glyphicon-flag pull-right bg-complete" aria-hidden="true" ></span>
                    </a>
                  </h4>
                </div>
                <div id="collapse_1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading_1">
                  <div class="panel-body">               
                      <a href="">How to access/set up E-Learning</a></br>
                      <a href="">Pre-Req E-learning prior to build</a></br>             
                    
                  </div>
                </div>
              </div>

              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="heading_2">
                  <h4 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" data-parent="#collapse_2" href="#collapse_2" aria-expanded="false" aria-controls="collapse_2">
                      Train
                      <span class="glyphicon glyphicon-flag pull-right bg-in-progress" aria-hidden="true"></span>
                    </a>
                  </h4>
                </div>
                <div id="collapse_2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_2">
                  <div class="panel-body">
                      <a href="">Pre-Req E-learning  prior to train</a></br>                   
                  </div>
                </div>
              </div>

              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="heading_3">
                  <h4 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" data-parent="#collapse_3" href="#collapse_3" aria-expanded="false" aria-controls="collapse_3">
                      Activation
                      <span class="glyphicon glyphicon-flag pull-right bg-not-attempted" aria-hidden="true"></span>
                    </a>
                  </h4>
                </div>
                <div id="collapse_3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_3">
                  <div class="panel-body">
                      <a href="">Pre-Req E-Learning prior to activation</a></br>
                      <a href="">Onsite Education Agenda(s)</a></br> 
                      <a href="" class="internal-doc">Instructor Guides </a></br>
                      <a href="" class="internal-doc">Immersion Scenarios</a></br> 
                  </div>
                </div>
              </div>

              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="heading_4">
                  <h4 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" data-parent="#collapse_4" href="#collapse_4" aria-expanded="false" aria-controls="collapse_4">
                      Adoption
                      <span class="glyphicon glyphicon-flag pull-right bg-not-attempted" aria-hidden="true"></span>
                    </a>
                  </h4>
                </div>
                <div id="collapse_4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_4">
                  <div class="panel-body">
                    Anim pariatur cliche.
                  </div>
                </div>
              </div>

              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="heading_5">
                  <h4 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" data-parent="#collapse_5" href="#collapse_5" aria-expanded="false" aria-controls="collapse_5">
                      Utilization
                      <span class="glyphicon glyphicon-flag pull-right bg-not-attempted" aria-hidden="true"></span>
                    </a>
                  </h4>
                </div>
                <div id="collapse_5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_5">
                  <div class="panel-body">
                    Anim pariatur cliche.
                  </div>
                </div>
              </div>
              
              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="heading_6">
                  <h4 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" data-parent="#collapse_6" href="#collapse_6" aria-expanded="false" aria-controls="collapse_6">
                      Best Practices
                      <span class="glyphicon glyphicon-flag pull-right bg-not-attempted" aria-hidden="true"></span>
                    </a>
                  </h4>
                </div>
                <div id="collapse_6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_6 ">
                  <div class="panel-body">
                    Anim pariatur cliche.
                  </div>
                </div>
              </div>

            </div> <!-- END OF ACCORDIION  -->

         

      </div><!-- END OF LEFT SIDE NAV COLUMN -->

      <div class="col-sm-9" id="stageContent">
        <div class="row">
          <div class="col-md-12">
            <h2>Design/Build <small>How to access/set up E-Learning</small></h2>
          </div>
          <div class="col-md-12">
              <p class="text-justify">SVG is a language for describing 2D graphics in XML.Canvas draws 2D graphics, on the fly (with a JavaScript). VG is XML based, which means that every element is available within the SVG DOM. You can attach JavaScript event handlers for an element.In SVG, each drawn shape is remembered as an object. If attributes of an SVG object are changed, the browser can automatically re-render the shape.Canvas is rendered pixel by pixel. In canvas, once the graphic is drawn, it is forgotten by the browser. If its position should be changed, the entire scene needs to be redrawn, including any objects that might have been covered by the graphic. <abbr title="attribute">attr</abbr></p>    

              <h3><a href=""><span class="glyphicon glyphicon-globe " aria-hidden="true"></span> URL</a></h3>       
          </div>

        </div>

        <div class="row">        
           <!--  <div class="col-md-12">
                <p class="text-justify">SVG is a language for describing 2D graphics in XML.Canvas draws 2D graphics, on the fly (with a JavaScript). VG is XML based, which means that every element is available within the SVG DOM. You can attach JavaScript event handlers for an element.In SVG, each drawn shape is remembered as an object. If attributes of an SVG object are changed, the browser can automatically re-render the shape.Canvas is rendered pixel by pixel. In canvas, once the graphic is drawn, it is forgotten by the browser. If its position should be changed, the entire scene needs to be redrawn, including any objects that might have been covered by the graphic. <abbr title="attribute">attr</abbr>  for describing 2D graphics in XML.Canvas draws 2D graphics, on the fly (with a JavaScript). VG is XML based, which means that every element is available within the SVG DOM. You can attach JavaScript event handlers for an element.In SVG, each drawn shape is remembered as an object. If attributes of an SVG object are changed, the browser can automatically re-render the shape.Canvas is rendered pixel by pixel. In canvas, once the graphic is drawn, it is forgotten by the browser. If its posit</p>
                <dl class="">
                <dt>Description Title</dt>
                <dd>ing any objects th pixel. In canvas,</dd>
              </dl>
            </div>
             <div class="col-md-12">
                <p class="text-justify">SVG is a language for describing 2D graphics in XML.Canvas draws 2D graphics, on the fly (with a JavaScript). VG is XML based, which means that every element is available within the SVG DOM. You can attach JavaScript event handlers for an element.In SVG, each drawn shape is remembered as an object. If attributes of an SVG object are changed, the browser can automatically re-render the shape.Canvas is rendered pixel by pixel. In canvas, once the graphic is drawn, it is forgotten by the browser. If its position should be changed, the entire scene needs to be redrawn, including any objects that might have been covered by the graphic. <abbr title="attribute">attr</abbr>  for describing 2D graphics in XML.Canvas draws 2D graphics, on the fly (with a JavaScript). VG is XML based, which means that every element is available within the SVG DOM. You can attach JavaScript event handlers for an element.In SVG, each drawn shape is remembered as an object. If attributes of an SVG object are changed, the browser can automatically re-render the shape.Canvas is rendered pixel by pixel. In canvas, once the graphic is drawn, it is forgotten by the browser. If its positive</p>
                <dl class="">
                  <dt>Description Title</dt>
                  <dd>ing any objects th pixel. In canvas.</dd>
              </dl>
            </div> -->
            
        </div><!-- END OF RIGHT SIDE PARENT ROW  -->


      </div><!-- END OF FULL PAGE SECOND COLUMN -->



  </div> <!-- END OF PAGE DIVISION ROW -- >



</div><!-- End of Container -->





<script type="text/javascript">  
  $(document).ready(function(){
      $("#myNav").affix({
          offset: { 
              top: 195 
          }
      });
  });
  
  function GoBack(){
    window.history.go(-1);
  }

</script>