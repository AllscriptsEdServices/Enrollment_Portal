<nav class="navbar-fixed-top" id="myNavbar" style="display:block; border-bottom:1px solid #bbb; ">
  <div class="row container-fluid" style="background-color:#82AC0F; color:#fff;">
    <div class="col-md-8 h3">
      <!-- <img src="<?php echo base_url("assets/img/proj_connect_logo_trans.png"); ?>" />   -->
      <?php echo $firstPageData["surveyTitle"]; ?>           
    </div>
    <!-- <div class="col-md-4 text-right hidden-xs">        
      <h3><?php echo $firstPageData["organizationName"]; ?></span> </h3>      
    </div> -->
  </div>

  

  <div class="row container-fluid nav_elements" style="background-color:#444;">

    <div class="col-sm-2 col-xs-6">
      <button id="save_PM" onclick="fnPreviousTopic()" class="btn btn-md"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true" ></span> Back</button>
    </div>

    <div class="col-sm-8 text-center hidden-xs">  
      
      <ul id="topicList" class="pagination"  style="margin-top:0px; margin-bottom:2px">     
        <li><a class="largePagination" href="javascript:fnIntroPage()" data-toggle="tooltip" data-placement="bottom" title="">Intro</a></li>  
        <?php foreach ($firstPageData["topicDefArray"] as $topic): ?>                        
          <?php   
          //'echo json_encode(base_url("index.php/questionnaire/form/getTopic")/'.$firstPageData["surveyId"].'/'.$topic["topicId"].'/'.$firstPageData["projectId"].''
          $absPPath = json_encode(base_url("index.php/questionnaire/form/getTopic"));

           //echo ' <li><a class="largePagination" href="'.$absPPath.'/'.$firstPageData["surveyId"].'/'.$topic["topicId"].'/'.$firstPageData["projectId"].'" data-toggle="tooltip" data-placement="bottom" title="'.$topic["topicName"].'">'.$topic["topicSequenceNum"].'</a></li>'; 
          echo ' <li><a class="largePagination" href="javascript:fnLoadTopic('.$topic["topicId"].')"  data-toggle="tooltip" data-placement="bottom" title="'.$topic["topicName"].'">'.$topic["topicSequenceNum"].'</a></li>'; 
       
            
          ?>              
        <?php endforeach ?> 
        <li class="active"><a class="largePagination" href="javascript:fnSummaryPage()" data-toggle="tooltip" data-placement="bottom" title="Completion">Completion</a></li>        
      </ul>

    </div>

    <div class="col-sm-2 col-xs-6 text-right">
      <button id="save_PM" onclick="fnNextTopic()" class="btn btn-md" disabled>Next <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></button>
    </div>
  </div>

  <div id="info_bar" class="row container-fluid nav_elements hidden" style="background-color:#F7AF34; ">
    <div class="column col-xs-12 text-center">
     <?php echo $checkInDetails["checkInUserName"] ?> is currently editing the questionnaire, hence you won't be able to make any changes.
    </div>
  </div>

  
</nav>



<div id="main_body" class="container-fluid" style="margin-top:120px">

  <div class="col-md-8 well col-md-offset-2" id="intro">    
    
    
    <div class="row">
       <div class="column col-md-12">
          <?php echo $firstPageData["surveySummary"]; ?>
          <br>

          
          <?php 

            // Variable that checks if this user is checked in, and then according disables or enables the submit button as an attribute
            $submit_disabled_lock = ($checkInDetails["lock"]) ? "disabled" : "";

            if($userType =="external"){

              echo '<p>If you have answered all the questions relevant to your organization, click the <strong>Submit Questionnaire</strong> button to complete the questionnare.</p>
          <p>Please review your answers once before submitting the Questionnaire. After this step, your Implementation Consultant will discuss the questionnaire with you during the Design Call.</p>';
              if(sizeof($surveyStatus["client"])<1){                
                 
                 echo '<button class="btn btn-md btn-success center-block" '.$submit_disabled_lock.' onclick="fnSubmitAssessment()">Submit Questionnaire</button>';
              }else{               
                echo '<button class="btn btn-md btn-success center-block" onclick="fnSubmitAssessment()" disabled>Submit Questionnaire</button>';
             
            ?>
                  <table class="table table-bordered bg-white" style="margin-top:20px">
                      <tr>
                        <th>Step</th>
                        <th>Status</th>
                        <th>User</th>
                        <th>Date Completed</th>
                      </tr>

                      <tr>
                        <?php
                          if(sizeof($surveyStatus["client"])>0){    
                            for($i=0;$i<sizeof($surveyStatus["client"]); $i++){
                              echo '<tr>';
                              echo '<td>Questionnaire Submission</td>';
                              echo '<td>'.$surveyStatus["client"][$i]["status"].'</td>';
                              echo '<td>'.$surveyStatus["client"][$i]["client_userName"].'</td>';
                              echo '<td>'.$surveyStatus["client"][$i]["date"].'</td>';                              
                              echo '</tr>';                       
                            }
                            
                          }else{
                              echo '<tr>';
                              echo '<td>Questionnaire Submission</td>';
                              echo '<td>Pending</td>';
                              echo '<td>NA</td>';
                              echo '<td>NA</td>';  
                              echo '</tr>'; 
                          }
                          if(sizeof($surveyStatus["ic"])>0){
                              echo '<td>Questionnaire Approval</td>';
                              echo '<td>'.$surveyStatus["ic"][0]["status"].'</td>';
                              echo '<td>'.$surveyStatus["ic"][0]["ic_userName"].'</td>';
                              echo '<td>'.$surveyStatus["ic"][0]["date"].'</td>';
                  
                          } else{
                              echo '<td>Questionnaire Approval</td>';
                              echo '<td>Pending</td>';
                              echo '<td>NA</td>';
                              echo '<td>NA</td>'; 
                          }
                        ?>
                      </tr>           

                  </table>
                  <br><br>
                  
                  <?php 
                    if(sizeof($surveyStatus["ic"])<=0){
                      echo 'If you would like to make changes to this Design Client Interview, you may make the edits and Resubmit the questionnaire before the Design Call.<br><br>';
                      echo '<button class="btn btn-md btn-success center-block" '.$submit_disabled_lock.' onclick="fnSubmitAssessment()">Resubmit</button>';
                    }else{
                      echo "The questionnaire has been approved by your Implementation Consultant. Hence you won't be able to make further edits to the questionnaire. You can save/print this questionnaire using the <strong>Print</strong> button below.<br><br>";
                    }
                  ?>
                <?php
              }
            }
          ?>
            

          <?php 
            if($userType =="internal"){
          ?>
                <table class="table table-bordered bg-white" style="margin-top:20px">
                      <tr>
                        <th>Step</th>
                        <th>Status</th>
                        <th>User</th>
                        <th>Date Completed</th>
                      </tr>

                      <tr>
                        <?php
                          if(sizeof($surveyStatus["client"])>0){    
                            for($i=0;$i<sizeof($surveyStatus["client"]); $i++){
                              echo '<tr>';
                              echo '<td>Questionnaire Submission</td>';
                              echo '<td>'.$surveyStatus["client"][$i]["status"].'</td>';
                              echo '<td>'.$surveyStatus["client"][$i]["client_userName"].'</td>';
                              echo '<td>'.$surveyStatus["client"][$i]["date"].'</td>';                              
                              echo '</tr>';                       
                            }
                            
                          }else{
                              echo '<tr>';
                              echo '<td>Questionnaire Submission</td>';
                              echo '<td>Pending</td>';
                              echo '<td>NA</td>';
                              echo '<td>NA</td>';  
                              echo '</tr>'; 
                          }
                        ?>
                      </tr>

                      <tr>
                        <?php
                          if(sizeof($surveyStatus["ic"])>0){
                              echo '<td>Questionnaire Approval</td>';
                              echo '<td>'.$surveyStatus["ic"][0]["status"].'</td>';
                              echo '<td>'.$surveyStatus["ic"][0]["ic_userName"].'</td>';
                              echo '<td>'.$surveyStatus["ic"][0]["date"].'</td>';
                  
                          } else{
                              echo '<td>Questionnaire Approval</td>';
                              echo '<td>Pending</td>';
                              echo '<td>NA</td>';
                              echo '<td>NA</td>'; 
                          }

                        ?>

                      </tr>

                  </table>

            <?php    
                echo '<div class="col col-xs-12 text-center top-buffer">'   ; 
                  if(sizeof($surveyStatus["client"])>0 && sizeof($surveyStatus["ic"])<=0){
                    echo '<button class="btn btn-primary" onclick="fnApproveAssessment()">Approve Questionnaire</button>';
                 }else{
                    echo '<button class="btn btn-primary" disabled>Approve Questionnaire</button>';
                 }

                echo '</div>';
            ?>
           

          <?php 
            }
          ?>
       </div>
    </div>

    <div class="row">
      <div class="column col-xs-12 text-right">
        <a class="print_btn" href="javascript:fnPrint()"><span class="glyphicon glyphicon-print" aria-hidden="true" data-toggle="tooltip" data-placement="bottom" title="Print the Questionnaire"></a>
      </div>
    </div>





    

    <!--  <p><b>CONTACT INFO:</b></p>
    <?php

      if( sizeof($firstPageData["consultantsArray"]) == 1){

        echo "Allscripts Implementation Consultant: ".$firstPageData["consultantsArray"][0]["name"]."<br>";
        echo "Office Phone: ".$firstPageData["consultantsArray"][0]["phone"]."<br>";
        echo "Email Address: ".$firstPageData["consultantsArray"][0]["mail"];
      
      }else{
        echo '<div class="row">';
        echo '<div class="col-xs-6">';
        echo '<table class="table table-bordered"><tr class="bg-primary"><th>Allscripts Implementation Consultant</th><th>Office Phone</th><th>Email Address</th></tr>';
        for($i=0;$i<sizeof($firstPageData["consultantsArray"]);$i++){
           echo '<tr class="info"><td>'.$firstPageData["consultantsArray"][$i]["name"].'</td><td>'.$firstPageData["consultantsArray"][$i]["phone"].'</td><td>'.$firstPageData["consultantsArray"][$i]["mail"].'</td></tr>';
        }
         echo '<table>';
         echo '</div></div> ';
      }

    ?> -->
    
  </div>

</div> <!-- END of Main Container -->

<script type="text/javascript">
  var quest_id =  <?php echo ($quest_id) ?>; 
  var projectId =  <?php echo ($projectId) ?>; 
  var topicsDefArray = <?php echo json_encode($firstPageData["topicDefArray"]) ?>; 
  var firstTopicId = <?php echo json_encode($firstPageData["topicDefArray"][0]['topicId']) ?>; 
  var totalTopics = <?php echo sizeof($firstPageData["topicDefArray"]) ?>;
  var lastTopicId = topicsDefArray[topicsDefArray.length-1]["topicId"];
  var baseURL = <?php echo json_encode(base_url("index.php/questionnaire/form/")) ?>;
  var clientSubmitArray = <?php echo json_encode($surveyStatus["client"]) ?>;

  var userType = <?php echo json_encode($userType) ?>; 
  var checkInDetails = <?php echo json_encode($checkInDetails) ?>;
  var locked_assessment_offset = 0;
  var isRedirect = false;

  $(function () {
    $('[data-toggle="tooltip"]').tooltip();
  })

  function fnNextTopic(){ 
    isRedirect = true;
      location.href = <?php echo json_encode(base_url("index.php/questionnaire/form/getTopic")) ?> +"/" + quest_id +"/" + firstTopicId  +"/" + projectId;   
  }

  function fnLoadTopic(topicId){
    isRedirect = true;    
    location.href = baseURL + "/getTopic/" + quest_id +"/" + topicId +"/" + projectId;;
  }

  function fnIntroPage(){
    isRedirect = true;
    location.href = <?php echo json_encode(base_url("index.php/questionnaire/form/getQuest")) ?> +"/" + quest_id +"/" + projectId;
  }

  function fnSummaryPage(){
    isRedirect = true;
    location.href = <?php echo json_encode(base_url("index.php/questionnaire/form/getSummary")) ?> +"/" + quest_id +"/" + projectId;
  }

  function fnPreviousTopic(){  
    isRedirect = true;   
    location.href = <?php echo json_encode(base_url("index.php/questionnaire/form/getTopic")) ?> +"/" + quest_id +"/" + lastTopicId +"/" + projectId;
     
  }

  function fnPrint(){
    var url = <?php echo json_encode(base_url("index.php/questionnaire/exportpdf/getpdf")) ?> +"/" + quest_id +"/" + projectId;
   // alert("The print functionality will be added shortly.");
    window.open(url);
  }

  function fnSubmitAssessment(){

    var submitLabel = "Submitted";
    if(clientSubmitArray.length>=1){
      var submitLabel = "Resubmitted";
    } 

    var proceed = confirm("Do you want to submit the questionnaire?");

    if(proceed){
      var action = baseURL + "/submitAssessment";
      var form_data = {
        'projectId': projectId,
        'surveyId': quest_id,
        'submitLabel': submitLabel       
      };    

      $.ajax({
        type: "POST",
        url: action,
        data: form_data,
        success: function(response)
        {                     
          //alert(response);   
          document.location.reload(true);
        }
      });

    }

  }

  function fnApproveAssessment(){
    var submitLabel = "Approved";
    var proceed = confirm("Once you approve, the questionnaire will no longer be available for editing or adding notes. Do you want to Approve the questionnaire? ");

    if(proceed){
      var action = baseURL + "/approveAssessment";
      var form_data = {
        'projectId': projectId,
        'surveyId': quest_id,
        'submitLabel': submitLabel       
      };    

      $.ajax({
        type: "POST",
        url: action,
        data: form_data,
        success: function(response)
        {                     
          //alert(response);   
          document.location.reload(true);
        }
      });

    }

  }

  if(userType=="external" && checkInDetails["lock"]){    
    $("#info_bar").removeClass("hidden");
    locked_assessment_offset = 20;
  }


  $(document).ready(function() {
    // Optimalisation: Store the references outside the event handler:
      var $window = $(window);
      var $pane = $('#pane1');
      var small_window_offset = 40;      

      function checkWidth() {
          var windowsize = $window.width();
          if (totalTopics>15 && windowsize < 1420) {
            //alert("here");
            $("#main_body").css("margin-top", 120 + small_window_offset + locked_assessment_offset + "px");
             
          }else{
             $("#main_body").css("margin-top", 120 + locked_assessment_offset + "px");
          }
      }
      // Execute on load
      checkWidth();
      // Bind event listener
      $(window).resize(checkWidth);
  });


  // Before closing the window, clear the user session and databse entry for checkedInUser 
   window.onbeforeunload = function(e) {    
      if(isRedirect == false){
         $.ajax({
            type: "POST",
            url: baseURL + "/exitQuestionnaire",     
            success: function(response)
            {             

            }
        });
      }
     
   }



</script>

