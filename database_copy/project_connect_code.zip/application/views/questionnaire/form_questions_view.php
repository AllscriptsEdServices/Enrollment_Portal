

<nav class="navbar-fixed-top" id="myNavbar" style="display:block; border-bottom:1px solid #bbb; ">
  <div class="row container-fluid" style="background-color:#82AC0F; color:#fff; ">
    <div class="col-md-8 h3">
      <!-- <img src="<?php echo base_url("assets/img/proj_connect_logo_trans.png"); ?>" />   -->
      <?php echo $firstPageData["surveyTitle"]; ?>           
    </div>
    <!-- <div class="col-md-4 text-right hidden-xs">        
      <h3><?php echo $firstPageData["organizationName"]; ?></span> </h3>      
    </div> -->
  </div>
 

  <div class="row container-fluid nav_elements" style="background-color:#444;">

    <div class="col-sm-2 col-xs-6">
      <button id="save_PM" onclick="fnPreviousTopic()" type="button" class="btn btn-md"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span> Back</button>
    </div>

    <div class="col-sm-8 text-center hidden-xs"> 

      <ul id="topicList" class="pagination"  style="margin-top:0px; margin-bottom:2px">
        <li><a class="largePagination" href="javascript:fnIntroPage()" type="button" data-toggle="tooltip" data-placement="bottom" title="Intro">Intro</a></li>    
        <?php foreach ($firstPageData["topicDefArray"] as $topic): ?>                        
          <?php       
          if($currentTopicId==$topic["topicId"]) {
            echo ' <li class="active"><a class="largePagination" type="button" href="javascript:fnLoadTopic('.$topic["topicId"].')" data-toggle="tooltip" data-placement="bottom" title="'.$topic["topicName"].'">'.$topic["topicSequenceNum"].'</a></li>'; 
          } else{
            echo ' <li><a class="largePagination" type="button" href="javascript:fnLoadTopic('.$topic["topicId"].')" data-toggle="tooltip" data-placement="bottom" title="'.$topic["topicName"].'">'.$topic["topicSequenceNum"].'</a></li>'; 
          }    
            
          ?>              
        <?php endforeach ?>   
        <li><a class="largePagination" type="button" href="javascript:fnSummaryPage()" data-toggle="tooltip" data-placement="bottom" title="Completion">Completion</a></li>   
      </ul>      

    </div>

    <div class="col-sm-2 col-xs-6 text-right">
      <button id="save_PM" onclick="fnNextTopic()" type="button" class="btn btn-md">Next <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></button>
    </div>
  </div>  

   <div id="info_bar" class="row container-fluid nav_elements hidden" style="background-color:#F7AF34; ">
    <div class="column col-xs-12 text-center">
     <?php echo $checkInDetails["checkInUserName"] ?> is currently editing the questionnaire, hence you won't be able to make any changes.
    </div>
  </div>
   

<!-- PROGRESS BAR ROW -->
  <!-- <div class="row container-fluid nav_elements" style="background-color:#444; ">
    <div class="col-sm-8 col-sm-offset-2">

      <div class="progress" id="progressBarDiv">
        <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="min-width: 2em; width: 2%">
          
        </div>
      </div>

    </div>
  </div> -->

</nav>

<div id="main_body" class="container" style="margin-top:120px">
  <div class="row">    
    <?php foreach ($firstPageData["topicDefArray"] as $topic): ?> 
     <?php       
          if($currentTopicId==$topic["topicId"]) {
            echo '<h3 ><b>'.$topic["topicName"].'</b></h3>';
            echo '<h5 class="topicDescription">'.$topic["topicDescription"].'</h5>';
          }
      ?> 
    <?php endforeach ?>  
  </div>


  <div id="questionBody" class="row" style="margin-top:0px">
    
  </div>

</div>

<!-- File Uplaod Modal -->
<div class="modal fade" id="myModal" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Upload Files</h4>
        </div>
        <div class="modal-body">
            <p>Upload the supporting files for this question.</p>            

            <iframe id="fileLoaderFrame" width="100%" height="200px" src="" frameborder="0"></iframe>

        </div>
        <div class="modal-footer">          
          <!-- <button id="forgot_submit_btn" type="button" class="btn btn-primary" onclick="fnForgotPassword()">Submit</button> -->
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->

<div class="container-fluid" style="margin-top:120px">

 <!--  <?php foreach ($topicData as $question): ?>
    <?php
      echo json_encode($question) .'<br>END OF Question<br><br>';
    ?>
  <?php endforeach ?> -->

</div> <!-- END of Main Container -->



<script type="text/javascript" src="<?php echo base_url("assets/js/formFunctions.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/questionBuilder.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/questionValidate.js"); ?>"></script>




<script type="text/javascript">
  var topicDataArray = <?php echo json_encode($topicData) ?>;  
  var currentTopicId = <?php echo ($currentTopicId) ?>; 
  var quest_id = <?php echo ($quest_id) ?>; 
  var projectId = <?php echo ($projectId) ?>; 
  var topicsDefArray = <?php echo json_encode(($firstPageData["topicDefArray"])) ?>;
  var totalTopics = <?php echo sizeof($firstPageData["topicDefArray"]) ?>;
  var baseURL = <?php echo json_encode(base_url("index.php/questionnaire/form/")) ?>;
  var lastTopicId = topicsDefArray[topicsDefArray.length-1]["topicId"];
  var lockQuestions = <?php echo json_encode($lockQuestions) ?>;


  var checkInDetails = <?php echo json_encode($checkInDetails) ?>;
  var locked_assessment_offset = 0;
  var userType = <?php echo json_encode($userType) ?>; 


  var row_questions_array = Array();
  var tabIndex = 1;

  
  $(document).ready(function() {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-green',
      radioClass: 'iradio_square-green',      
      increaseArea: '20%' // optional
    });

    // To Restrict Numeric Fields to only numbers and "-"
    $('.numbersOnly').keyup(function () {  
      if (this.value != this.value.replace(/[^0-9-\.]/g, '')) {
         this.value = this.value.replace(/[^0-9-\.]/g, '');
      } 
    });

    $('input').on('ifClicked', function(event){
        fnValidateAnswers();
        var radioGroupName = event.target.name;
        var qid = radioGroupName.substring((radioGroupName.indexOf("_")+1),radioGroupName.length);

        fnRuntime_InputClicked(qid, event.target.value);

        //alert(event.target.value);
        //alert(event.target.name);
        //alert(event.type + ' callback'); 
        /*var radioGroupName = event.target.name;
        var qid = radioGroupName.substring((radioGroupName.indexOf("_")+1),radioGroupName.length);
        fnToggleOtherText(qid,event.target.value);*/
      });

    // Optimalisation: Store the references outside the event handler:
      var $window = $(window);
      var $pane = $('#pane1');
      var small_window_offset = 40;      

      function checkWidth() {
          var windowsize = $window.width();
          if (totalTopics>15 && windowsize < 1420) {
            //alert("here");
            $("#main_body").css("margin-top", 120 + small_window_offset + locked_assessment_offset + "px");
             
          }else{
             $("#main_body").css("margin-top", 120 + locked_assessment_offset + "px");
          }
      }
      // Execute on load
      checkWidth();
      // Bind event listener
      $(window).resize(checkWidth);


  });

//Prevent the Tab key default behaviour
  $(document).keydown(function(objEvent) {
    if (objEvent.keyCode == 9) {  //tab pressed
        objEvent.preventDefault(); // stops its action
    }
  })


  $(function() {
    $('[data-toggle="tooltip"]').tooltip();
    $('input, textarea').placeholder();
  })

  
  $(document).on('click','.addMoreBtn',function() {
    //alert($(this).attr("data-tableName"));
    var qId = $(this).attr("data-qId");
    fnAddRows(qId);    
  });



  function fnToggleComment(qId){
    $("#ic_comment_"+qId).toggleClass("hidden");
  }
    

  function fnSetFiles_IFrame(qId){    
    url = <?php echo json_encode(base_url("index.php/questionnaire/fileupload/displayPage")) ?> +"/" + qId +"/" + projectId;
    $("#fileLoaderFrame").attr('src',url);    
  }



  $('#myModal').on('hidden.bs.modal', function(){
      fnValidateAnswers();
      document.location.reload(true);
  })

  fnBuildPage();
  //fnGetProgress();



if(userType=="external" && checkInDetails["lock"]){
  disableInputs();  
  $("#info_bar").removeClass("hidden");
  locked_assessment_offset = 20;
}

if(lockQuestions){
  disableInputs();
}

function showInfoBar(){

}
  
// TO DISABLE ALL THE INPUT ELEMENTS 
function disableInputs(){
  $('input').attr('readonly', 'readonly');
  $('input:radio').attr('disabled', 'true');
  $('input:checkbox').attr('disabled', 'true');
  $('textarea').attr('disabled', 'true');
}




</script>