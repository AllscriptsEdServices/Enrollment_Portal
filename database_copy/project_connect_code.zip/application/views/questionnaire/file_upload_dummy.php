<!Doctype HTML>

<html>

<head>
<title>File Uploader Dialog</title>
<!-- <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>"> -->
<link rel="stylesheet" href="<?php echo base_url("assets/css/app_main.css"); ?>">

</head>

<body>

	<!-- <h2>File Uploader</h2> -->


<!-- <a href="http://localhost/Project_Connect/uploads/brainshark_folder.jpg" target="_blank">Get File</a> -->
<!-- <form action="<?php echo (base_url("index.php/questionnaire/fileupload/do_upload")) ?> " method="POST" enctype="multipart/form-data" > -->
<?php echo form_open_multipart('/questionnaire/fileupload/do_upload');?>

	Select File To Upload:<br />

	<input type="file"  name="userfile" multiple="multiple" /><br><br>

	<input type="hidden" name="projectId" value="<?php echo $projectId?>" />
	<input type="hidden" name="questionId" value="<?php echo $questionId?>" />	

	<input id="submitBtn" type="submit" name="submit" value="Upload" class="btn btn-success" />
	<img id="loader" style="display:none" src="<?php echo base_url("assets/img/loader.gif"); ?>">

</form>

<br>
 <?php echo $message?>

<script src="<?php echo base_url("assets/js/jquery-1.11.0.js"); ?>"></script> 
<!--<script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>"></script> -->

<script type="text/javascript">
	$('#submitBtn').click(function(e){        
        $("#loader").show();       
        $('#submitBtn').attr("disabled", true);
   });

</script>

</body>