<nav class="navbar-fixed-top" id="myNavbar" style="display:block; border-bottom:1px solid #bbb; ">
  <div class="row container-fluid" style="background-color:#82AC0F; color:#fff;">
    <div class="col-md-8 h3">
      <!-- <img src="<?php echo base_url("assets/img/proj_connect_logo_trans.png"); ?>" />   -->
      <?php echo $firstPageData["surveyTitle"]; ?>           
    </div>
    <!-- <div class="col-md-4 text-right hidden-xs">        
      <h3><?php echo $firstPageData["organizationName"]; ?></span> </h3>      
    </div> -->
  </div>

  

  <div class="row container-fluid nav_elements" style="background-color:#444; ">

    <div class="col-sm-2 col-xs-6">
      <button id="save_PM" onclick="fnPreviousTopic()" class="btn btn-md" disabled><span class="glyphicon glyphicon-chevron-left" aria-hidden="true" ></span> Back</button>
    </div>

    <div class="col-sm-8 text-center hidden-xs">  
      
      <ul id="topicList" class="pagination"  style="margin-top:0px; margin-bottom:2px">     
        <li class="active"><a class="largePagination" href="javascript:fnIntroPage()" data-toggle="tooltip" data-placement="bottom" title="">Intro</a></li>  
        <?php foreach ($firstPageData["topicDefArray"] as $topic): ?>                        
          <?php   
          //'echo json_encode(base_url("index.php/questionnaire/form/getTopic")/'.$firstPageData["surveyId"].'/'.$topic["topicId"].'/'.$firstPageData["projectId"].''
          $absPPath = json_encode(base_url("index.php/questionnaire/form/getTopic"));

           //echo ' <li><a class="largePagination" href="'.$absPPath.'/'.$firstPageData["surveyId"].'/'.$topic["topicId"].'/'.$firstPageData["projectId"].'" data-toggle="tooltip" data-placement="bottom" title="'.$topic["topicName"].'">'.$topic["topicSequenceNum"].'</a></li>'; 
          echo ' <li><a class="largePagination" href="javascript:fnLoadTopic('.$topic["topicId"].')" data-toggle="tooltip" data-placement="bottom" title="'.$topic["topicName"].'">'.$topic["topicSequenceNum"].'</a></li>'; 
       
            
          ?>              
        <?php endforeach ?>    
        <li><a class="largePagination" href="javascript:fnSummaryPage()" data-toggle="tooltip" data-placement="bottom" title="Completion">Completion</a></li>     
      </ul>

    </div>

    <div class="col-sm-2 col-xs-6 text-right">
      <button id="save_PM" onclick="fnNextTopic()" class="btn btn-md">Next <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></button>
    </div>
  </div>  

  <div id="info_bar" class="row container-fluid nav_elements hidden" style="background-color:#F7AF34; ">
    <div class="column col-xs-12 text-center">
     <?php echo $checkInDetails["checkInUserName"] ?> is currently editing the questionnaire, hence you won't be able to make any changes.
    </div>
  </div>

</nav>



<div id="main_body" class="container-fluid" style="margin-top:120px">
  
  <div class=" col-md-12 well" id="intro">

    <?php echo $firstPageData["surveyIntro"]; ?>
    <br>
    <p><b>CONTACT INFO:</b></p>
    <?php

     /* if( sizeof($firstPageData["consultantsArray"]) == 1){

        echo "Allscripts Implementation Consultant: ".$firstPageData["consultantsArray"][0]["name"]."<br>";
        echo "Office Phone: ".$firstPageData["consultantsArray"][0]["phone"]."<br>";
        echo "Email Address: ".$firstPageData["consultantsArray"][0]["mail"];
      
      }else{*/
        echo '<div class="row">';
        echo '<div class="col-xs-6">';
        echo '<table class="table table-bordered"><tr class="bg-primary"><th>Allscripts Implementation Consultant</th><th>Phone Number</th><th>Email Address</th></tr>';
        
        foreach ($firstPageData["consolidatedConsultants"] as $consultant) {
          if($consultant["projectRole"] == $quest_id){
            echo '<tr class="info"><td>'.$consultant["name"].'</td><td>'.$consultant["phone"].'</td><td>'.$consultant["mail"].'</td></tr>';
          }
           
        }
         echo '<table>';
         echo '</div></div> ';  
      //}

    ?>

  </div>

</div> <!-- END of Main Container -->

<script type="text/javascript">
  var quest_id =  <?php echo ($quest_id) ?>; 
  var projectId =  <?php echo ($projectId) ?>; 
  var firstTopicId = <?php echo json_encode($firstPageData["topicDefArray"][0]['topicId']) ?>; 
  var totalTopics = <?php echo json_encode(count($firstPageData["topicDefArray"])) ?>;
  var baseURL = <?php echo json_encode(base_url("index.php/questionnaire/form/")) ?>;

  var userType = <?php echo json_encode($userType) ?>; 
  var checkInDetails = <?php echo json_encode($checkInDetails) ?>;
  var locked_assessment_offset = 0;
  var isRedirect = false;

  $(function () {
    $('[data-toggle="tooltip"]').tooltip();
  })

  function fnNextTopic(){     
    isRedirect = true;
    location.href = <?php echo json_encode(base_url("index.php/questionnaire/form/getTopic")) ?> +"/" + quest_id +"/" + firstTopicId  +"/" + projectId;   
  }

  function fnLoadTopic(topicId){
    isRedirect = true;    
    location.href = baseURL + "/getTopic/" + quest_id +"/" + topicId +"/" + projectId;;
  }



  function fnIntroPage(){
    isRedirect = true;
    location.href = <?php echo json_encode(base_url("index.php/questionnaire/form/getQuest")) ?> +"/" + quest_id +"/" + projectId;
  }

  function fnSummaryPage(){
    isRedirect = true;
    location.href = <?php echo json_encode(base_url("index.php/questionnaire/form/getSummary")) ?> +"/" + quest_id +"/" + projectId;
  }
  
  
  if(userType=="external" && checkInDetails["lock"]){    
    $("#info_bar").removeClass("hidden");
    locked_assessment_offset = 20;
  }

 
   // Before closing the window, clear the user session and databse entry for checkedInUser 
   window.onbeforeunload = function(e) {  
      if(isRedirect == false){
         $.ajax({
            type: "POST",
            url: baseURL + "/exitQuestionnaire",     
            success: function(response)
            {             

            }
        });
      }
     
   }


   $(document).ready(function() {
    // Optimalisation: Store the references outside the event handler:
      var $window = $(window);
      var $pane = $('#pane1');
      var small_window_offset = 40;      

      function checkWidth() {
          var windowsize = $window.width();
          if (totalTopics>15 && windowsize < 1420) {
            //alert("here");
            $("#main_body").css("margin-top", 120 + small_window_offset + locked_assessment_offset + "px");
             
          }else{
             $("#main_body").css("margin-top", 120 + locked_assessment_offset + "px");
          }
      }
      // Execute on load
      checkWidth();
      // Bind event listener
      $(window).resize(checkWidth);
  });


</script>