<?php
//require_once("application\views\questionnaire\pdf_formatter.php");

$style_td = 'border-bottom:0.25px solid #333; border-right:0.25px solid #333; padding:5px';

$printDiv = '';
$printDiv .= '<body style="font-family:Arial;font-size:12px;margin:0px; padding:0px; color:#333">';
$logo_url = base_url("assets/img/proj_connect_logo.png");
$printDiv .= '<img class="hidden-xs" src="'.$logo_url.'" />';
$printDiv .= '<h2 style="color:#42A629">'.$firstPageData["surveyTitle"].'</h2>';
//$printDiv .=  '<div style="width:720px; height: 100px; border:0.25px solid #999"><a href="#anchor">Go To Page</a></div>';

$printDiv .= '<div style="width:610px; margin:auto; margin-top:30px; margin-bottom:15px">';
$printDiv .= '<table id="myTable" cellspacing="0px" style="width:600px; border-top:0.25px solid #333; border-left:0.25px solid #333; font-size:16px">';
$printDiv .= '<tr>';
$printDiv .= '<th style="width:150px; '.$style_td.'">Organization</th>';
$printDiv .= '<td style="width:400px; '.$style_td.'">'.$firstPageData["organizationName"].'</td>';
$printDiv .= '</tr>';
$printDiv .= '<tr>';
$printDiv .= '<th style="'.$style_td.'">Product</th>';
$printDiv .= '<td style="'.$style_td.'">Professional EHR</td>';
$printDiv .= '</tr>';
$printDiv .= '<tr>';
$printDiv .= '<th style="'.$style_td.'">CDH Number</th>';
$printDiv .= '<td style="'.$style_td.'">'.$firstPageData["cdhNum"].'</td>';
$printDiv .= '</tr>';
$printDiv .= '<tr>';
$printDiv .= '<th style="'.$style_td.'">Location</th>';
$printDiv .= '<td style="'.$style_td.'">'.$firstPageData["address"].'</td>';
$printDiv .= '</tr>';
$printDiv .= '<tr>';
$printDiv .= '<th style="'.$style_td.'">Client Type</th>';
$printDiv .= '<td style="'.$style_td.'">'.$firstPageData["hostingType"].'</td>';
$printDiv .= '</tr>';
$printDiv .= '<tr>';
$printDiv .= '<th style="'.$style_td.'">Questionnaire Submitted by</th>';
if(sizeof($surveyStatus["client"])>0){
	$counter = sizeof($surveyStatus["client"])-1;
	
	$printDiv .= '<td style="'.$style_td.'">'.$surveyStatus["client"][$counter]["client_userName"].'</td>';
}else{
	$printDiv .= '<td style="'.$style_td.'">Not Submitted</td>';
}
$printDiv .= '</tr>';

$printDiv .= '<tr>';
$printDiv .= '<th style="'.$style_td.'">Questionnaire Submitted on</th>';
if(sizeof($surveyStatus["client"])>0){
	$counter = sizeof($surveyStatus["client"])-1;
	
	$printDiv .= '<td style="'.$style_td.'">'.$surveyStatus["client"][$counter]["date"].'</td>';
}else{
	$printDiv .= '<td style="'.$style_td.'">NA</td>';
}
$printDiv .= '</tr>';

$printDiv .= '<tr>';
$printDiv .= '<th style="'.$style_td.'">Questionnaire Approved by</th>';
if(sizeof($surveyStatus["ic"])>0){
	$printDiv .= '<td style="'.$style_td.'">'.$surveyStatus["ic"][0]["ic_userName"].'</td>';	
}else{
	$printDiv .= '<td style="'.$style_td.'">NA</td>';
}
$printDiv .= '</tr>';

$printDiv .= '<tr>';
$printDiv .= '<th style="'.$style_td.'">Questionnaire Approved on</th>';
if(sizeof($surveyStatus["ic"])>0){	
	$printDiv .= '<td style="'.$style_td.'">'.$surveyStatus["ic"][0]["date"].'</td>';
}else{
	$printDiv .= '<td style="'.$style_td.'">NA</td>';
}
$printDiv .= '</tr>';

$printDiv .= '</table>';
$printDiv .= '</div>';


// ************************** Team Table **********************************************************//
$printDiv .= '<div style="width:610px; margin:auto; margin-top:15px; margin-bottom:30px">';
$printDiv .= '<table id="team_Table" cellspacing="0px" style="width:600px; border-top:0.25px solid #333; border-left:0.25px solid #333; font-size:16px">';
$printDiv .= '<tr>';
$printDiv .= '<th style="width:550px; background-color:#337AB7; color:#ffffff; '.$style_td.'" colspan="2">Allscripts Team</th>';
$printDiv .= '</tr>';

$management_string = $firstPageData["allscriptsPMName"]."<br>".$firstPageData["allscriptsAPMName"];
$printDiv .= '<tr>';
$printDiv .= '<th style="width:150px; '.$style_td.'">Project Management</th>';
$printDiv .= '<td style="width:400px; '.$style_td.'">'.$management_string.'</td>';
$printDiv .= '</tr>';

$consultants_string = "";
foreach ($firstPageData["consolidatedConsultants"] as $consultant) {
  if($consultant["projectRole"] == $quest_id){    
    $consultants_string .= $consultant["name"].' ('.$consultant["mail"].') - '.$consultant["phone"].'<br>';
  }   
}

$printDiv .= '<tr>';
$printDiv .= '<th style="width:150px; '.$style_td.'">Consultants</th>';
$printDiv .= '<td style="width:400px; '.$style_td.'">'.$consultants_string.'</td>';
$printDiv .= '</tr>';

$printDiv .= '</table>';
$printDiv .= '</div>';





//************** TOPIC WISE INFO *********************
$topicsDiv = '';
$topicArray = $firstPageData["topicDefArray"];
$mainCounter = 1;
$asciiCounter = 97;
$questionTitleNum = "";

for($i = 0; $i<sizeof($topicArray); $i++){
	$topicsDiv .= '<div style="margin-top:40px;">';
	$topicsDiv .= '<div style="display:block; padding:2px; background-color:#337AB7; color:#fff"><h4>'.($i+1).'. '.$topicArray[$i]["topicName"].'</h4></div>';

	
	$thisTopicQuestions = $questionBlock[$i];
	$mainCounter = 1;

	for($j=0; $j<sizeof($thisTopicQuestions); $j++){
		$currentQuestion = $thisTopicQuestions[$j];
		$displayQuestion = true;
		
		/*$topicsDiv .= '<tr style="background-color:#B0C6AA"><th style="width:40px; '.$style_td.'">Q Num</th><th style="width:440px; '.$style_td.'">Question</th><th style="width:180px; '.$style_td.'">Response</th></tr>';*/


		if($currentQuestion["qGroupNext"]==0 && $currentQuestion["qDependentQId"]>0){
			if(fnDisplayConditionalQuestion($currentQuestion["qDependentQId"], $currentQuestion["qDependentOption"], $thisTopicQuestions) == true){					
				$questionTitleNum = ($mainCounter-1).chr($asciiCounter);	
				$asciiCounter++;
			}else{
				$displayQuestion = false;
			}
		}else if($currentQuestion["qGroupNext"]==1 && $currentQuestion["qDependentQId"]==0){
			$questionTitleNum = $mainCounter;
			$asciiCounter = 97;
			$mainCounter++;
		}else{
			$questionTitleNum = $mainCounter;
			$mainCounter++;
		}

		if($displayQuestion){
			$topicsDiv .= '<div style="margin-top:10px;">';
			$topicsDiv .= '<table cellspacing="0px" style="width:740px; border-top:0.25px solid #333; border-left:0.25px solid #333; ">';
			$topicsDiv .= '<tr>';
			if($currentQuestion["qType"]=="multiple_row_headers"){
				$topicsDiv .= '<td style="width:40px;'.$style_td.'">'.$questionTitleNum.'</td>';
				$topicsDiv .= '<td style="width:640px;'.$style_td.'">'.$currentQuestion["qText"].'</td>';
				$topicsDiv .= '</tr>';
				$topicsDiv .= '<tr>';
				$topicsDiv .= '<td style="width:40px;'.$style_td.'"></td>';
				$topicsDiv .= '<td style="width:640px;'.$style_td.'">'.getMultiHeadResponse($currentQuestion["response"], $currentQuestion["qType"], $currentQuestion["qOptions"]).'</td>';
			}else if($currentQuestion["qType"]=="multiple_text_entry"){
				$topicsDiv .= '<td style="width:40px;'.$style_td.'">'.$questionTitleNum.'</td>';
				$topicsDiv .= '<td style="width:640px;'.$style_td.'">'.$currentQuestion["qText"].'</td>';
				$topicsDiv .= '</tr>';
				$topicsDiv .= '<tr>';
				$topicsDiv .= '<td style="width:40px;'.$style_td.'"></td>';
				$topicsDiv .= '<td style="width:640px;'.$style_td.'">'.getMultipleTextEntry($currentQuestion["response"]).'</td>';
				//$topicsDiv .= '<tr>';
			}else if($currentQuestion["qType"]=="info_check_multiple"){
				$topicsDiv .= '<td style="width:40px;'.$style_td.'">'.$questionTitleNum.'</td>';
				$topicsDiv .= '<td style="width:440px;'.$style_td.'">'.$currentQuestion["qText"].'</td>';
				$topicsDiv .= '<td style="width:180px;'.$style_td.'">'.getResponse_info_check_multiple($currentQuestion["response"]).'</td>';
			}else{
				$topicsDiv .= '<td style="width:40px;'.$style_td.'">'.$questionTitleNum.'</td>';
				$topicsDiv .= '<td style="width:440px;'.$style_td.'">'.$currentQuestion["qText"].'</td>';
				$topicsDiv .= '<td style="width:180px;'.$style_td.'">'.getResponse($currentQuestion["response"], $currentQuestion["qType"]).'</td>';
			}
			
			$topicsDiv .= '</tr>';

			if($currentQuestion["noteText"] != null){
				$topicsDiv .= '<tr style="background-color:#94DDEE">';
				$topicsDiv .= '<td colspan="2" style="width:680px;'.$style_td.'"><b>IC Note - '.$currentQuestion["noteText"]["author"].'</b><br>'.$currentQuestion["noteText"]["text"].'</td>';
				//$topicsDiv .= '<td style="width:400px;'.$style_td.'">'.$currentQuestion["noteText"]["text"] .'</td>';
				$topicsDiv .= '</tr>';
			}

			$topicsDiv .= '</table>';
			$topicsDiv .= '</div>';

		}// end of $displayQuestion Check
		
		
	}

	
	$topicsDiv .= '</div>';
}


$printDiv .= $topicsDiv;

$printDiv .= '</body>';

function fnDisplayConditionalQuestion($qId, $dependentResponse, $topicArray){
	for($i=0; $i<count($topicArray); $i++){
	    if($topicArray[$i]["qId"] == $qId) {
	      
		    $responseRawString = $topicArray[$i]["response"];
		    $responseArray = explode("$", $responseRawString);
		    $displayFlag = false;

		    $dependentResponseArray = explode("$", $dependentResponse); 
	      
			for($j=0;$j<count($dependentResponseArray);$j++){
		      	if(in_array($dependentResponseArray[$j], $responseArray)){
		      		$displayFlag = true;
		      	}	        
		    }
	      
	      	//echo $qId." || ".$displayFlag."<br>";
	      	return $displayFlag;
	  
	    }
  	}
}

function getResponse_info_check_multiple($response){
	//Jacob John||O%$%Eve John||O%$%Jake Doe||R%$%Jill Doe||R%$%Samuel Bill||O%$%Cara Bill||O%$%Empty|| %$%Empty|| %$%Empty|| %$%Empty|| %$%
	$returnString = "";
	$response_breakdown_array = explode("%$%", $response);
	
	for($i=0; $i<count($response_breakdown_array)-1; $i++){
		$single_response_array = explode("||", $response_breakdown_array[$i]);
		if($single_response_array[0]!="Empty"){
			$returnString .= $single_response_array[1]." - ".$single_response_array[0]."<br>";
		}
	}

	return $returnString;
}

function getMultiHeadResponse($response, $qType, $qOptions){

	$responseArray = explode("$", $response);
	$returnString = "";
	
	$tableHeaders = explode("||", $qOptions);
	$rawResponseString = $response;
	$tempArray1 = explode("%$%", $rawResponseString);
	$rowCounter = count($tempArray1)-1;
	for($m=0; $m<$rowCounter; $m++){
		$responseArray[$m] = array();
		$tempArray2 = explode("||", $tempArray1[$m]);
		
		for($n=0; $n<count($tableHeaders); $n++){
			$responseArray[$m][$n] = $tempArray2[$n];
		}
	}

	$returnString .= '<table border="0.1px" cellspacing="0px">';
	$returnString .= '<thead>';
	$returnString .= '<tr>';
	
	for( $i=0;$i<count($tableHeaders); $i++){
		$returnString .= '<th>'.$tableHeaders[$i].'</th>';
	}

	$returnString .= '</tr>';
	$returnString .= '</thead>';
	$returnString .= '<tbody>';

	for( $i=0;$i<$rowCounter; $i++){
		$returnString .= '<tr>';
		for( $j=0;$j<count($tableHeaders); $j++){
			$returnString .= '<td style="padding:5px">'.$responseArray[$i][$j].'</td>';
		}
		$returnString .= '</tr>';
	}

	$returnString .= '</tbody>';
	$returnString .= '</table>';
	
	return $returnString;
}


function getMultipleTextEntry($response){
	$responseArray = explode("|#|", $response);
	$returnString = "<ul>";

	foreach ($responseArray as $single_response) {		
		if(trim($single_response) !== ""){
			$returnString .= '<li>'.$single_response.'</li>';
		}
	}

	$returnString .= '</ul>';

	return $returnString;
}


function getResponse($response, $qType){
	
	$responseArray = explode("$", $response);
	$returnString = "";

	if($qType=="multi_select_other" || $qType=="multi_select"){
		$returnString .= "<ul>";
		for($i=0; $i<count($responseArray); $i++){
			if($responseArray[$i]!== "Empty" && $responseArray[$i] !="null"){
				$returnString .= "<li>".$responseArray[$i]."</li>";
			}			
		}

		$returnString .= "</ul>";

	}else{
		for($i=0; $i<count($responseArray); $i++){
			if($responseArray[$i]!== "Empty" && $responseArray[$i] !="null"){
				$returnString .= $responseArray[$i]."<br>";
			}			
		}
	}
	
	return $returnString;
}

//echo $printDiv;


require_once("assets/js/html2pdf/html2pdf.class.php");
//require_once('../scripts/html2pdf/html2pdf.class.php');
  try
  { 
      $html2pdf = new HTML2PDF('P', 'A4', 'en', true, 'UTF-8', array(10,10, 10, 10));
      $html2pdf->pdf->SetDisplayMode('fullpage');
      $html2pdf->writeHTML($printDiv, isset($_GET['vuehtml']));
      $pdf_name = "Submitted_".$firstPageData["surveyTitle"]."_".$firstPageData["cdhNum"].".pdf";
      $html2pdf->Output($pdf_name);
  }
  catch(HTML2PDF_exception $e) {
      echo $e;
      exit;
  }


?>