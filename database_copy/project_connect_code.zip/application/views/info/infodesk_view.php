
<div class="container-fluid">
	<div class="row">
		<div class="col col-sm-6">
			<h2>Important Links</h2>
			<?php if($userType =="external"){ ?>
				<table class="table table-bordered">
					<tr class="bg-primary">
						<th>Website</th>
						<th>Address</th>
					</tr>
					<tr>
						<td>GFI Faxmaker</td>
						<td><a href="http://www.gfi.com/pages/fmo-allscripts.asp" target="_blank">http://www.gfi.com/pages/fmo-allscripts.asp</a></td>
					</tr>
					<tr>
						<td>Allscripts Central</td>
						<td><a href="https://central.allscripts.com/AC/GetStarted/Index" target="_blank">https://central.allscripts.com/AC/GetStarted/Index</a></td>
					</tr>
					<tr>
						<td>Alpha II</td>
						<td><a href="https://www.alphaii.net" target="_blank">https://www.alphaii.net</a></td>
					</tr>
				</table>

			<?php }else{ ?>

				<table class="table table-bordered">
					<tr class="bg-primary">
						<th>Website</th>
						<th>Address</th>
					</tr>
					<tr>
						<td>Allscripts Central - SFDC</td>
						<td><a href="https://central.allscripts.com/AC/GetStarted/Index" target="_blank">https://central.allscripts.com/AC/GetStarted/Index</a></td>
					</tr>
					<tr>
						<td>Alpha II</td>
						<td><a href="https://www.alphaii.net" target="_blank">https://www.alphaii.net</a></td>
					</tr>
					<tr>
						<td>BCD Travel</td>
						<td><a href="https://www2.concursolutions.com/Default.asp" target="_blank">https://www2.concursolutions.com/Default.asp</a></td>
					</tr>
					<tr>
						<td>Clarity - project info and documents</td>
						<td><a href="https://clarity.corp.allscripts.com/niku/nu" target="_blank">https://clarity.corp.allscripts.com/niku/nu</a></td>
					</tr>
					<tr>
						<td>Oracle - contract info</td>
						<td><a href="https://oraebsprod.allscripts.com/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE" target="_blank">https://oraebsprod.allscripts.com/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE</a></td>
					</tr><tr>
						<td>Sharepoint - Team Page</td>
						<td><a href="https://services.inside.allscripts.com/educationservices/Professional/Education%20%20Optimization/Forms/AllItems.aspx" target="_blank">https://services.inside.allscripts.com/educationservices/Professional/Education%20%20Optimization/</a></td>
					</tr>
					<tr>
						<td>Web App - IC Schedules</td>
						<td><a href="http://clarityscheduler.corp.allscripts.com/" target="_blank">http://clarityscheduler.corp.allscripts.com/</a></td>
					</tr>

				</table>

			<?php } ?>

		</div>

	</div>


	<!--<?php if($userType =="internal"){ ?>
		<div class="row">
			<div class="col col-sm-6">
				<h2>Allscripts ICCE Schedule</h2>
				<table class="table table-bordered">
					<tr class="bg-primary">
						<th>ICCE Session</th>
						<th>Date</th>
						<th>Time</th>
						<th>Location</th>
						<th>#Hours</th>
					</tr>
					<tr>
						<td>Onsite Session I</td>
						<td>May 7 - 8 2015</td>
						<td>All-Day</td>
						<td>Raleigh</td>
						<td>16</td>
					</tr>
					<tr>
						<td>June</td>
						<td>June 19, 2015</td>
						<td>8-12pm</td>
						<td>Virtual</td>
						<td></td>
					</tr>
					<tr>
						<td></td>
						<td>June 26, 2015</td>
						<td>1-5pm</td>
						<td>Virtual</td>
						<td></td>
					</tr>
					<tr>
						<td>July</td>
						<td>July 10, 2015</td>
						<td>8-12pm</td>
						<td>Virtual</td>
						<td>4</td>
					</tr>
					<tr>
						<td></td>
						<td>July 17, 2015</td>
						<td>1-5pm</td>
						<td>Virtual</td>
						<td></td>
					</tr>	
					<tr>
						<td>Onsite Session II</td>
						<td>August 27-28, 2015</td>
						<td>All-Day</td>
						<td>Raleigh</td>
						<td>16</td>
					</tr>
					<tr>
						<td></td>
						<td>Sept 10-11, 2015</td>
						<td>All-Day</td>
						<td>Raleigh</td>
						<td>16</td>
					</tr>
				</table>
			</div>

		</div>

	<?php } ?> -->



</div>
