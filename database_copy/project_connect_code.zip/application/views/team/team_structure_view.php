<style type="text/css">
	#selected_consultants_div>div{
		font-size: 12px;
		font-weight: bold;
		margin-left:15px;
		color:#85B207;
	}
</style>

<div class="container-fluid">

	<button onclick="GoBack()" class="btn btn-default"><span class="glyphicon glyphicon-search" aria-hidden="true"></span> Back to Search</button>

	<div class="row well top-buffer">

		<p class="lead">Project Specifics</p>

		<div class="col-md-4">		
			<table class="table table-striped table-bordered">
				<tr>
					<td>Organization</td>
					<td><strong><?php echo $projectInfo["organizationName"] ?></strong></td>
				</tr>
				<tr>
					<td>Product</td>
					<td><?php echo $projectInfo["productName"] ?></td>
				</tr>
				<tr>
					<td>Hosting Type</td>
					<td><?php echo $projectInfo["hostingType"] ?></td>
				</tr>
			</table>
		</div> <!-- END OF COLUMN  -->



		<div class="col-md-4">
			<table class="table table-striped table-bordered">
				<tr>
					<td>Contact Name</td>
					<td><?php echo $projectInfo["primaryContactName"] ?></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><?php echo $projectInfo["primaryContactEmail"] ?></td>
				</tr>
				<tr>
					<td>Phone</td>
					<td><?php echo $projectInfo["primaryContactPhone"] ?></td>
				</tr>
			</table>
		</div>

		<div class="col-md-4">
			<?php
				echo '<h4>Activation Status</h4>';
				if($projectInfo["mailDetails"]["status"] == "Not Sent"){
					echo '<p id="mailStatus_para">Activation Mail: '.$projectInfo["mailDetails"]["status"].'</p>';
				}else{
					echo '<p id="mailStatus_para">Activation Mail: Sent on '.$projectInfo["mailDetails"]["date"].'</p>';
				}
				/*echo '<p id="mailStatus_para">Activation Mail: '.$projectInfo["mailDetails"]["status"].'</p>';
				echo '<p id="mailSent_para">Mail Sent Date: '.$projectInfo["mailDetails"]["date"].'</p>';*/

				if($projectInfo["submitEnabled"]){
					echo '<button onclick="fnSendMail()" class="btn btn-success"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> Send Activation Mail</button>';
				}else{
					echo '<button onclick="fnSendMail()" class="btn btn-success" disabled><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> Send Activation Mail</button>';
					echo '</br><span style="font-size:80%; font-style:italic">Associate/Project Manager and product-specific Consultant(s) should be assigned before activating the client.</span>';
				}

			?>
			
			
		</div> <!-- END OF COLUMN  -->

	</div> <!-- END OF ROW  -->


	<div class="row">

		<div class="col-md-12">
			<p class="lead">Team Structure</p>
		</div>

		
		<div class="col-md-4">	

			<div class="panel panel-primary">
			  <div class="panel-heading">
			    <h3 class="panel-title">
			    	Project Management <a href="javascript:void" id="editsButton_3" data-toggle="modal" data-target="#myModalProjectMgmt"><span class="glyphicon glyphicon-plus pull-right" aria-hidden="true"></span></a>
			    </h3>
			  </div>
			  
				<div class="panel-body">
					<table class="table lineless-table">
					<?php foreach ($projectInfo["pm_InfoArray"] as $resource): ?>
						<tr>						
					    	<td width="180px"><span class="team-swatch" aria-hidden="true">Project Manager</span></td>
					   		<td><?php echo $resource["name"] ?></td>
				   		</tr>	
			  		<?php endforeach ?>			 
			  
					<?php foreach ($projectInfo["apm_InfoArray"] as $resource): ?>					
						<tr>						
			    			<td width="180px"><span class="team-swatch" aria-hidden="true">Assoc Project Manager</span></td>
			   				<td><?php echo $resource["name"] ?></td>
				   		</tr>			
			  		<?php endforeach ?>	

					</table>

			  	</div> <!-- END OF PANEL BODY -- >


			</div> <!-- END OF PANEL TOTAL -- >

		</div> <!-- END OF COLUMN  -->	
</div> 
</div> 


		<div class="col-md-4 ">	

			<div class="panel panel-primary">
			  <div class="panel-heading">
			    <h3 class="panel-title">
			    	Consultants <a href="javascript:void" id="editsButton_3" data-toggle="modal" data-target="#myModalConsultants"><span class="glyphicon glyphicon-plus pull-right" aria-hidden="true"></span></a>
			    </h3>
			  </div>
			  
			<div class="panel-body">
				<table class="table lineless-table">
					<?php 
						foreach ($projectInfo["consolidatedConsultants"] as $consultant){
							$swatchText = "";												

							$swatchText .= ($consultant["rights"] == "Consultant") ? "IMP " : "EDU ";
							if($consultant["projectRole"]=="1"){ 
								$swatchText .= "EHR";
							}else if($consultant["projectRole"]=="2"){								
								$swatchText .= "PM";
							}

							/*if($consultant["expertise"]=="1"){ 
								$swatchText .= "EHR";
							}else if($consultant["expertise"]=="2"){								
								$swatchText .= "PM";
							}else if($consultant["expertise"]=="3"){								
								$swatchText .= "EHR/PM";
							}*/

							echo '<tr>';	

							echo '<td width="105px">';
							echo '<span class="team-swatch" aria-hidden="true">'.$swatchText.'</span>';
							echo '</td>';

							echo '<td>'.$consultant["name"].'</td>';

							echo '</tr>';
						}
					?>				

				</table>

		  	</div> <!-- END OF PANEL BODY -- >


			</div> <!-- END OF PANEL TOTAL -- >

		</div> <!-- END OF COLUMN  -->		


	</div> <!-- END OF ROW  -->


	

<!-- Consultant Modal -->

<div class="modal fade" id="myModalConsultants" data-keyboard="false" data-backdrop="static">

    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Select Consultants for this Project</h4>
        </div>

        <div class="modal-body" style="max-height: 500px; overflow:auto">
            <!-- <p>Select the Consultants who will work on this project.</p>   -->

            <form class="form-inline">
	            <div class="form-group">
					<label class="control-label-horizontal" for="search_consultant">Search By: </label>
	            	<input type="text" class="form-control" id="search_consultant" placeholder="Consultant Name"></input>
	            	&nbsp;&nbsp;<a href="javascript:clear_search_field('consultant')" style="font-size:85%">Clear</a>
	            </div>
	        </form>

            <table id="consultant_table" class="table table-bordered top-buffer">
            	<tr class="bg-success">
            		<th></th>
            		<th>Name</th>
            		<th>Type</th>
            		<th>Expertise</th>            		
            		<th>Project Role</th>
            	</tr>

            	<?php 
            		//Loop through all internal users
            		$selected_consultants_display = "";
            		foreach ($internalResources as $resource){		

            			//Check for only Imp Consultants and Education Consultants
						if($resource["rights"]=="Consultant" || $resource["rights"]=="EduConsultant"){

							//Check if only relevant consultants as per the client product is shown
						 	if($projectInfo["productId"]==3 || (($projectInfo["productId"] == $resource["expertise"]) || $resource["expertise"]==3) ){
								echo '<tr>';
								
								echo '<td>';
							
								$resourceType = ($resource["rights"]=="Consultant") ?  'Implementation' : 'Education';

								if($resource["isAssigned"]=="true"){								
									echo '<input type="checkbox" name="options_Consultant" id="options_Consultant_'.$resource["id"].'" value="'.$resource["id"].'" data-type="'.$resourceType.'" data-expertise="'.$resource["expertise"].'" data-res-name="'.$resource["name"].'" checked ></input>';
									$selected_consultants_display .= '<div id="span_display_'.$resource["id"].'">'.$resource["name"].'</div>';
								}else{
									echo '<input type="checkbox" name="options_Consultant" id="options_Consultant_'.$resource["id"].'" value="'.$resource["id"].'" data-type="'.$resourceType.'" data-expertise="'.$resource["expertise"].'" data-res-name="'.$resource["name"].'" /></input>';
								}
						
								echo '</td>';

								echo '<td>'.$resource["name"].'</td>';
															
								echo '<td>'.$resourceType.'</td>';
								
								if($resource["expertise"]==1){	
									echo "<td>Professional EHR</td>";
									echo '<td>EHR</td>';
								}else if($resource["expertise"]==2){
									echo "<td>Allscripts PM</td>";
									echo '<td>PM</td>';
								}else if($resource["expertise"]==3){
									echo "<td>Professional EHR & Allscripts PM</td>";
									if($resource["isAssigned"]=="true"){
										if($resource["projectRole"] == "EHR"){
											echo '<td><select id="consultant_prod_'.$resource["id"].'"><option selected value="EHR">EHR</option><option value="PM">PM</option></select></td>';
										}else{
											echo '<td><select id="consultant_prod_'.$resource["id"].'"><option value="EHR">EHR</option><option selected value="PM">PM</option></select></td>';
										}
									}else{
										echo '<td><select id="consultant_prod_'.$resource["id"].'"><option selected value="EHR">EHR</option><option value="PM">PM</option></select></td>';
									}
									
								}
								
								
								echo '</tr>';

							} // End of Relevant Consultants IF Loop

						} // End of consultants IF Loop

					} //End of For Loop

				?>					

			
			</table>		

            

        </div>

        <div class="modal-footer">
        	<div id="selected_consultants_div" class="text-left">
        		<strong>Selected Consultant(s):</strong>
        		<?php echo $selected_consultants_display ?>
        	</div>
        	<button id="save_Consultant" onclick="fnSaveConsultant()" class="btn btn-default" disabled><span class="glyphicon glyphicon-floppy-disk" aria-hidden="true"></span> Save</button>
          <!-- <button id="forgot_submit_btn" type="button" class="btn btn-primary" onclick="fnForgotPassword()">Submit</button> -->

        </div>

      </div><!-- /.modal-content -->

    </div><!-- /.modal-dialog -->

  </div><!-- /.modal -->

  <!-- Consultant Modal -->

<div class="modal fade" id="myModalProjectMgmt" data-keyboard="false" data-backdrop="static">

    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Select Project Management for this Project</h4>
        </div>

        <div class="modal-body">
            <!-- <p>Select the Project Management team who will work on this project.</p> -->   
            <form class="form-inline">
	            <div class="form-group">
					<label class="control-label-horizontal" for="search_project_mgmt">Search By: </label>
	            	<input type="text" class="form-control" id="search_project_mgmt" placeholder="Manager Name"></input>
	            	&nbsp;&nbsp;<a href="javascript:clear_search_field('project_mgmt')" style="font-size:85%">Clear</a>
	            </div>
	        </form>

            <table id="project_mgmt_table" class="table table-bordered top-buffer">
            	<tr class="bg-success">
            		<th></th>
            		<th>Name</th>
            		 <th>Type</th>
            		<!--<th>Expertise</th> -->
            	</tr>

            <?php foreach ($internalResources as $resource): ?>				  							

					<?php 

						if($resource["rights"]=="PM" || $resource["rights"]=="APM"){
							echo '<tr>';
							echo '<td>';
							//echo '<label>';
							$resourceType = ($resource["rights"]=="PM") ?  'Project Manager' : 'Associate Project Manager';

							if($resource["isAssigned"]=="true"){								
								echo '<input type="checkbox" name="options_ProjectMgmt" id="options_ProjectMgmt'.$resource["id"].'" value="'.$resource["id"].'" data-type="'.$resourceType.'" checked ></input>';
							}else{
								echo '<input type="checkbox" name="options_ProjectMgmt" id="options_ProjectMgmt'.$resource["id"].'" value="'.$resource["id"].'" data-type="'.$resourceType.'" /></input>';
							}

							//echo '</label>';
							echo '</td>';
							echo '<td>'.$resource["name"].'</td>';
							
							
							echo '<td>'.$resourceType.'</td>';

							/*echo '<td>';
							if($resource["expertise"]==1){	
								echo "Professional EHR";
							}else if($resource["expertise"]==2){
								echo "Allscripts PM";
							}else if($resource["expertise"]==3){
								echo "Professional EHR & Allscripts PM";
							}*/
							echo '</tr>';
						}
					?>					

			<?php endforeach ?>
			</table>

			

            <!--<iframe id="fileLoaderFrame" width="100%" height="200px" src="" frameborder="0"></iframe>-->

        </div>

        <div class="modal-footer">
        	<button id="save_ProjectMgmt" onclick="fnSaveProjMgmt()" class="btn btn-default" disabled><span class="glyphicon glyphicon-floppy-disk" aria-hidden="true"></span> Save</button>
          <!-- <button id="forgot_submit_btn" type="button" class="btn btn-primary" onclick="fnForgotPassword()">Submit</button> -->

        </div>

      </div><!-- /.modal-content -->

    </div><!-- /.modal-dialog -->

  </div><!-- /.modal -->




</div> <!-- END OF CONTAINER  -->





<script type="text/javascript">

	$('input, textarea').placeholder();

	var projectId = <?php echo $projectInfo["projectId"] ?>;
	var productId = <?php echo $projectInfo["productId"] ?>;
	var baseURL = <?php echo json_encode(base_url("index.php/team/teamstructure/")) ?>;

	function GoBack(){
		window.history.go(-1);
		//location.href = baseURL + "/team";
	}

	function fnSaveConsultant(){		
		var ehr_consultants_string = "";
		var pm_consultants_string = "";
		$.each($("input[name=options_Consultant]:checked"), function(){
			var expertise = $(this).attr("data-expertise");

			if(expertise==1){

				ehr_consultants_string += $(this).val() + "_";

			}else if(expertise == 2){

				pm_consultants_string += $(this).val() + "_";

			}else{

				resourceId = $(this).val();
				if( $("#consultant_prod_"+resourceId).val() == "EHR" ){
					ehr_consultants_string += $(this).val() + "_";					
				}else{
					pm_consultants_string += $(this).val() + "_";
					
				}

			}
		});  

		var ehr_consultants_string = ehr_consultants_string.replace(/(^_)|(_$)/g, "");
		var pm_consultants_string = pm_consultants_string.replace(/(^_)|(_$)/g, "");

		//alert(ehr_consultants_string + " <---> " + pm_consultants_string);

		var action = baseURL + "/updateConsultants";
	    var form_data = {		      
	      'ehr_consultants_string': ehr_consultants_string,		      
	      'pm_consultants_string': pm_consultants_string,		      
	      'projectId': projectId,
	      'productId': productId,
	    };

	    $.ajax({
	      	type: "POST",
	      	url: action,
	      	data: form_data,
	      	success: function(response)
	      	{	
	      		//alert(response);
	      		window.location.reload();      		

	      	}
	    });

	}

	

	function fnSaveProjMgmt(){
		var pmArray = [];
		var apmArray = [];
		
		$.each($("input[name=options_ProjectMgmt]:checked"), function(){   
			if($(this).attr("data-type")== "Project Manager"){
				pmArray.push($(this).val());
			}else{
				apmArray.push($(this).val());
			}		    
        });       

		var selectedResources_PM = (pmArray.join("_") != "") ? pmArray.join("_") : "Empty";
		var selectedResources_APM = (apmArray.join("_") != "") ? apmArray.join("_") : "Empty";

		location.href = <?php echo json_encode(base_url("index.php/team/teamstructure/saveResource")) ?>+"/" + selectedResources_PM + "/" + projectId + "/allscriptsPM";
		location.href = <?php echo json_encode(base_url("index.php/team/teamstructure/saveResource")) ?>+"/" + selectedResources_APM +"/"+projectId + "/allscriptsAPM";
    
	}

	function fnSendMail(){		
		var action = baseURL + "/fnSendActivationMail";
	    var form_data = {
	      'projectId': projectId	  
	    };

	    $.ajax({
	      type: "POST",
	      url: action,
	      data: form_data,
	      success: function(response)
	      { 	     
	     
	      	if(response!="Fail"){
	      		alert("Mail successfully sent!");
	      		//$("#mailSent_para").html("Mail Sent Date: "+response);
	      		$("#mailStatus_para").html("Activation Mail Sent: Sent on "+response);	      		
	      	}else{
	      		alert("An error occured. Please check the try resending.");
	      	}
	      }
	    });
	}

	$('input').on('click', function(event){	
		console.log("check clicked" + $(this).attr('data-res-name'));
		console.log(this.value);
		
		if(this.checked){
			var new_consultant_name = '<div id="span_display_' + this.value + '">' + $(this).attr('data-res-name') +'</div>';
			$("#selected_consultants_div").append(new_consultant_name);
		}else{
			$("#span_display_" + this.value).remove();
		}
	    var radioGroupName = event.target.name;	
	    var targetGroup = radioGroupName.split("_");
	    $("#save_"+targetGroup[1]).attr("disabled", false);	 
  	});

	/*$(document).on('change','.groups_checkbox',function() {
    	//$('input[name="chk[]"]:checked').length
    	console.log( ($('input[name="groups_checkbox"]:checked').length)  );
    	if ($('input[name="groups_checkbox"]:checked').length>0 ){
    		$("#recommend_btn").attr("disabled", false);
    	}else{
    		$("#recommend_btn").attr("disabled", true);
    	}

    });*/

	//Live search function for the Consultants List
	$("#search_consultant").on("keyup", function() {
	    var value = $(this).val().toLowerCase();

	    $("#consultant_table tr").each(function(index) {
	        if (index !== 0) {

	            $row = $(this);

	            //var id = $row.find("td:first").text();
	            var id = $row.find("td:nth-child(2)").text().toLowerCase();

	            //alert(id.indexOf(value));
	            if (id.indexOf(value) < 0) {
	                $row.hide();
	            }
	            else {
	                $row.show();
	            }
	        }
	    });

	});

	//Live search function for the Project Managers List
	$("#search_project_mgmt").on("keyup", function() {
	    var value = $(this).val().toLowerCase();

	    $("#project_mgmt_table tr").each(function(index) {
	        if (index !== 0) {

	            $row = $(this);

	            //var id = $row.find("td:first").text();
	            var id = $row.find("td:nth-child(2)").text().toLowerCase();

	            //alert(id.indexOf(value));
	            if (id.indexOf(value) < 0) {
	                $row.hide();
	            }
	            else {
	                $row.show();
	            }
	        }
	    });

	});

	function clear_search_field(category){
		$("#search_" + category).val("");
		show_all_table_rows(category);
	}

	function show_all_table_rows(table_name){
		
		$("#" + table_name + "_table tr").each(function(index) {
			$(this).show();
		});
	}

</script>