<div class="container-fluid">

	<div class="row">		

		<div class="well ">		
			<h4 class="text-center">Search Projects</h4>	
			<table align="center" width="90%">
				<tr>
					<td align="center"	>
						<form class="form-inline"  method="post" action="<?php echo base_url("index.php/team/team/searchOrgName");?>">
						<?php echo form_open('projects/newproject/fnAddNewProject'); ?>
						  	<div class="form-group">
						    	<label for="organizationName">Organization Name</label>
						    	<input type="text" class="form-control" id="organizationName" name="organizationName" value="<?php echo $orgNameSearchString ?>" placeholder="Allscripts">
						  	</div>			  
						  	<button type="submit" class="btn btn-default">Org Search</button>
						</form>
					</td>
					
					<td align="center">

						<form class="form-inline" method="post" action="<?php echo base_url("index.php/team/team/searchCDH");?>">
						  	<div class="form-group">
						    	<label for="cdhNum">CDH Number</label>
						    	<input type="text" class="form-control" id="cdhNum" name="cdhNum" placeholder="e.g. 10XX" value="<?php echo $cdhSearchString ?>">
						  	</div>			  
						  	<button type="submit" class="btn btn-default">CDH Search</button>
						</form>						
					</td>
					
				</tr>	
				<!-- <tr>
					<td align="center">
						<div class="col-sm-10">
						    <div class="input-group">
						      <input type="text" class="form-control" placeholder="Search for...">
						      <span class="input-group-btn">
						        <button class="btn btn-default" type="submit">CDH Search</button>
						      </span>
						    </div>
						</div>
					</td>					
				</tr>		 -->
			</table>
		</div> <!-- END OF WELL -->

	</div> <!-- END OF ROW -->
	<div class="row">	
		<?php if(sizeof($projectsList)>0){?>

			<div class="col-lg-12">
				<table class="table table-striped table-responsive table-bordered">
					<thead>
						 <tr>
						 	<th>Organization</th>
						 	<th>CDH Number</th>
						 	<th>Product</th>							 	
						 	<!-- <th class="hidden-xs">Allscripts PM</th>
						 	<th class="hidden-xs">Start Date</th> -->
						 	<th></th>
						 </tr>
					</thead>
					<tbody>
						<?php foreach ($projectsList as $project): ?>							
							<tr>
								<td><?php echo $project["organizationName"] ?></td>
								<td><?php echo $project["cdhNum"] ?></td>
								<td><?php echo $project["productName"] ?></td>								
								<!-- <td class="hidden-xs"><?php echo $project["allscriptsPM"] ?></td>
								<td class="hidden-xs"><?php echo $project["projectStartedDate"] ?></td> -->
								<td>
									<button type="button" onclick="fnShowTeam(<?php echo $project["projectId"] ?>)" class="btn btn-default btn-sm" aria-label="Left Align">
								  	<span class="glyphicon glyphicon-th-large" aria-hidden="true"></span>
								  	Team	
								</button>
							</td>
							</tr>
						<?php endforeach ?>				
					</tbody>
				</table>
			</div>
		<?php }else{	?>

			<div class="col-lg-12">
				No results!
			</div>

		<?php }	?>
	</div>

</div> <!-- END OF CONTAINER  -->


<script type="text/javascript">
	$('input, textarea').placeholder();

	function fnShowTeam(projectId){
		//alert(<?php echo base_url("index.php/team/teamstructure/showCurrentTeam");?>)
		//location.href=<?php echo base_url("index.php/team/teamstructure/showCurrentTeam");?>+"/"+projectId;
		location.href="../teamstructure/showCurrentTeam/"+projectId;
	}
</script>