 var isRedirect = false;
 
 // Before closing the window, clear the user session and databse entry for checkedInUser 
  window.onbeforeunload = function(e) {
    if(isRedirect == false){
       $.ajax({
          type: "POST",
          url: baseURL + "/exitQuestionnaire",     
          success: function(response)
          {             

          }
      });
    }
   
 }

 function fnNextTopic(){ 
  isRedirect = true;
  fnValidateAnswers(); 

  if(currentTopicId < topicsDefArray[topicsDefArray.length-1]["topicId"]){
  //if(currentTopicId < totalTopics){          
    location.href = baseURL + "/getTopic/" + quest_id +"/" + (currentTopicId+1) +"/" + projectId;
  }else{
    fnSummaryPage();
  }  
}

function fnPreviousTopic(){ 
  isRedirect = true;
  fnValidateAnswers();
  if(currentTopicId > topicsDefArray[0]["topicId"]){    
    location.href = location.href = baseURL + "/getTopic/" + quest_id +"/" + (currentTopicId-1) +"/" + projectId;
  }else{
    fnIntroPage();
  }
}

function fnLoadTopic(topicId){
  isRedirect = true;
  fnValidateAnswers();  
  location.href = baseURL + "/getTopic/" + quest_id +"/" + topicId +"/" + projectId;;
}

function fnIntroPage(){  
  isRedirect = true;
  location.href =  baseURL + "/getQuest/" + quest_id +"/" + projectId;;
}


function fnSummaryPage(){
  isRedirect = true;
  location.href =  baseURL + "/getSummary/" + quest_id +"/" + projectId;;
}



function fnRuntime_InputClicked(qId, userResponse){  
  var arrayNum =  fnReturnArrayNumber(qId);  
  var asciiCounter = 97;  
  
  // @@@@@@@@ STEM QUESTION CHECK AND PROCESS @@@@@@@@@@@@
  if(topicDataArray[arrayNum]["qGroupNext"]>0) {
    var mainQCounter = $("#qDiv_"+qId).attr("data-counter");

    //** CASE A: For Radio Button questions ************************
    if(topicDataArray[arrayNum]["qType"]=="yes_no" || topicDataArray[arrayNum]["qType"]=="yes_no_other" || topicDataArray[arrayNum]["qType"]=="single_select" || topicDataArray[arrayNum]["qType"]=="single_select_other"){

      //Loop for dependent questions
      $('.dependentDiv_'+qId).each(function() {
        //Array that holds all options that the question's visiblity is dependent on
        var dependentOptionsArray = String($(this).attr("data-dep-option")).split("$");    
        //(dependentOptionsArray.indexOf(userResponse)!=-1) ?    $(this).removeClass("hidden") : $(this).addClass("hidden");
        if(dependentOptionsArray.indexOf(userResponse)!=-1){
          var dependentQId = $(this).attr("data-qId");
          $("#dep_qNum_"+dependentQId).html(mainQCounter + String.fromCharCode(asciiCounter) +". ");
          asciiCounter++;
          $(this).removeClass("hidden");
        }else{
          $(this).addClass("hidden");
        }

      }); // END of Dependent Questions Loop for CASE A


    }

    //** CASE B: For Check Box questions ************************
    else if(topicDataArray[arrayNum]["qType"]=="multi_select" || topicDataArray[arrayNum]["qType"]=="multi_select_other"){

      //Creating Array for the selected checkboxes for the Stem Question
      var selectedOptions = [];
      $.each($("input[name='optionsCheck_"+qId+"']:checked"), function(){
          selectedOptions.push($(this).val());
      });

      //This function "fnRuntime_InputClicked" was fired on the click of a checkbox. So the Value of the Checkbox group is not updated for this particular checkbox
      //Hence adjust array to accomodate the choice and predict the final value of the Check Group
      if(selectedOptions.indexOf(userResponse)>= 0){
          var targetIndex = selectedOptions.indexOf(userResponse);
          selectedOptions.splice(targetIndex, 1);
      }else{
        selectedOptions.push(userResponse);
      }
      
      //Loop through all dependent questions
      $('.dependentDiv_'+qId).each(function() {
        //Array that holds all options that the question's visiblity is dependent on
        var dependentOptionsArray = String($(this).attr("data-dep-option")).split("$");
        
        // If any of the Dependent Options is present in the selectedOptions array of the Stem question, make showQuestion TRUE
        var showQuestion = false;
        for(var j=0; j<dependentOptionsArray.length; j++){
          if(selectedOptions.indexOf(dependentOptionsArray[j]) >= 0){                
            showQuestion = true;
          }

        }

        
        //(showQuestion)? $(this).removeClass("hidden") : $(this).addClass("hidden");
        if(showQuestion){
          var dependentQId = $(this).attr("data-qId");
          $("#dep_qNum_"+dependentQId).html(mainQCounter + String.fromCharCode(asciiCounter) +". ");
          asciiCounter++;
          $(this).removeClass("hidden")
        }else{
          $(this).addClass("hidden");
        }
        

      }); // END of Dependent Questions Loop for CASE B

    }
    
  
  } //  END OF THE STEM QUESTION IF LOOP ****************************

  // @@@@@@@@ CONIDTIONAL COMMENT BOX CHECK AND PROCESS @@@@@@@@@@@@
  // Loop for Conditional Comment Box
  if(topicDataArray[arrayNum]["qConditionalComment"] == 1) {
    //alert($("#yesno_comment_"+qId));
    if(userResponse == topicDataArray[arrayNum]["qCorrectAnswer"]){
      $("#conditionalComment_"+qId).removeClass("hidden");
    }else{
      $("#conditionalComment_"+qId).addClass("hidden");
    }

  }// END OF CONDITIONAL COMMENTS LOOP


  // @@@@@@@@ ALL OF THE ABOVE QUESTION CHECK AND PROCESS @@@@@@@@@@@@
  // Check of Multi Choice Questions with the "All of the above" option
  if(topicDataArray[arrayNum]["qType"]=="multi_select" || topicDataArray[arrayNum]["qType"]=="multi_select_other"){
    var optionsArray = topicDataArray[arrayNum]["qOptions"].split("$");    

    //Check if it's an All of above questions by looking at the optionsArray
    if(optionsArray.indexOf("All of the above")>=0){
        var checkName = "optionsCheck_" +  qId;
        var multiOptions = [];
        $.each($("input[name='optionsCheck_"+topicDataArray[arrayNum]["qId"]+"']:checked"), function(){
            multiOptions.push($(this).val());
        });

        //Has the "All of the above" checkbox been CLICKED?
        if(userResponse=="All of the above"){
          //Has the "All of the above" checkbox been CHECKED? If so, check all the other checkboxes within the group
            if(multiOptions.indexOf(userResponse)< 0){
              multiOptions.push(userResponse);
              $('input:checkbox[name='+checkName+']').iCheck('check');          
            }
        }
        // A Different options has been clicked
        else{
             if(multiOptions.indexOf("All of the above")>= 0){
                  //Since a different option is selected, identify and deselect the "All of the above" checkbox
                  for(var checkNum=0; checkNum<optionsArray.length; checkNum++){
                      if($("#optionsCheck_"+qId+"_"+checkNum).val()=="All of the above"){
                        $("#optionsCheck_"+qId+"_"+checkNum).iCheck('uncheck');
                      }
                  }
             }
        }

    }

  } // END OF ALL OF ABOVE QUESTION LOOP


   
} // End of Function



function fnIntial_ConditionDisplay(qId, dependentResponse){
  for(var i=0; i<topicDataArray.length; i++){
    if(topicDataArray[i]["qId"] == qId) {
      
      var responseRawString = topicDataArray[i]["response"];
      var responseArray = responseRawString.split("$");
      var displayFlag = false;

      var dependentResponseArray = dependentResponse.split('$');
      
      for(var i=0;i<dependentResponseArray.length;i++){
        if(responseArray.indexOf(dependentResponseArray[i]) != -1){
          displayFlag = true;
        }
      }

      //alert(qId + " - " +  displayFlag);
      return displayFlag;
  
    }

  }

}

function fnResetRadio(qId){  
  var radioName = "optionsRadios_" +  qId;
  var arrayNumber = fnReturnArrayNumber(qId);

  $('input:radio[name='+radioName+']').iCheck('uncheck');

  if(topicDataArray[arrayNumber]["qType"] == "yes_no_other"){

    (topicDataArray[arrayNumber]["qConditionalComment"] == 1) ?  $("#conditionalComment_"+qId).addClass("hidden") : $("#conditionalComment_"+qId).addClass("");    
    CKEDITOR.instances["yesno_comment_"+qId].setData("");

  }else if(topicDataArray[arrayNumber]["qType"] == "single_select_other"){

    (topicDataArray[arrayNumber]["qConditionalComment"] == 1) ?  $("#conditionalComment_"+qId).addClass("hidden") : $("#conditionalComment_"+qId).addClass("");
    CKEDITOR.instances["ssq_comment_"+qId].setData("");

  }

  $('.dependentDiv_'+qId).addClass("hidden");
  
}


function fnReturnArrayNumber(qId){
  for(var i=0; i<topicDataArray.length; i++){
    if(topicDataArray[i]["qId"] == qId) {
      return i;
      break;
    }
  }

}




function fnAddRows(qId){
  // $.grep
  //Function to search an  array of objects by matching an object propertty. e.qID in this case
  //It returns an array of the object found 
  var result = $.grep(row_questions_array, function(e){ return e.qId == qId; });

  //alert(result[0]["arrayNumber"]);

  var appendString = "<tr>";

  for(var colNum = 0; colNum<result[0]["numOfColumns"]; colNum++){
    //Naming conventions of inputbox id ==> <_row_+> <_qId_> + <_rowNumber_> + <_columnNumber_>
    appendString += '<td><input class="form-control" type="text" id="_row_'+qId+'_'+result[0]["lastRow"]+'_'+colNum+'" value="" data-questionId="" placeholder=""></input></td>'
  }

  appendString += "</tr>";
  
  $("#"+result[0]["tableId"]+" > tbody:last").append(appendString);


  // Increment the lastRow number in the object for next time's reference.
  result[0]["lastRow"] = Number(result[0]["lastRow"]) + 1;
  //$(tableId+" > tbody:last").append('<tr><td><input class="form-control" type="text" id="row_0_1"></input></td> <td><input class="form-control" type="text" id="row_0_2"></input></td> <td><input class="form-control" type="text" id="row_0_3"></input></td></tr>');
}

function fnGetProgress(){

  var action = baseURL + "/checkSurveyProgress";
    var form_data = {
      'projectId': projectId,
      'surveyId': quest_id     
    };    

    $.ajax({
      type: "POST",
      url: action,
      data: form_data,
      success: function(response)
      {           
        //alert(response);
        //fnUpdateProgressBar(response);
      }

    });
}

function fnUpdateProgressBar(perc){
  var progressContents = '<div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="'+perc+'" aria-valuemin="0" aria-valuemax="100" style="min-width: 2em; width: '+perc+'%">'+perc+'%</div>';
  $("#progressBarDiv").html(progressContents);
  /*<div class="progress" id="progressBarDiv">
        <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="52" aria-valuemin="0" aria-valuemax="100" style="min-width: 2em; width: 52%">
          52%
        </div>
      </div>*/
}
