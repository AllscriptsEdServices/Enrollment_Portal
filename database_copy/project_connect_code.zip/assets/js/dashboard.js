function GoBack(){
    window.history.go(-1);
  }

  function fnOpenNew(){
    //alert(screen.height);
    window.open('http://localhost/Project_Connect/index.php/questionnaire/form/getTopic/2/29/1','winname','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no, width='+(screen.width-40)+',height='+(screen.height-130)+'');
  }


  function fnShowTab(selectedTabNum){
    $(".tabContent").hide();
    $("#product_tab_"+selectedTabNum).show();
    if(selectedTabNum!=currentSelectedTab){      
      fn_RefreshTabs();
    }
  
    currentSelectedTab = selectedTabNum;
  }

  function fn_RefreshTabs(){
    $('.resource-normal').removeClass("resource-active");
    $("#templateTitle").html("");
    $("#templateContent").html('<p class="text-justify"><i>Click on any of the stages in the left to view details.</i></p>' );
  }

  function openWindow(){
    var browser=navigator.appName;
    if (browser=="Microsoft Internet Explorer") {
      window.opener=self;
    }
    window.open('http://localhost/Project_Connect/index.php/questionnaire/form/getTopic/2/29/1','null','width=900,height=750, toolbar=no,scrollbars=no,location=no,resizable =yes');
    window.moveTo(0,0);
    window.resizeTo(screen.width,screen.height-100);
    //self.close();
  }

  function fnShowTemplate(resourceId){
    $("#loader_div").show();
    var action = baseURL + "/getTemplateDetails";
    var form_data = {
      'resourceId': resourceId,
      'projectId':projectId,
      'productId':productId
    };

    $.ajax({
      type: "POST",
      url: action,
      data: form_data,
      success: function(response)
      {
          var responseObj = $.parseJSON(response);
          var arr = $.map(responseObj, function(el) { return el; }); 

          var main_content_body = "";
          main_content_body += get_individual_items(responseObj[0], "parent");
          console.log(responseObj[0].resourceName);
          
          var child_objects_array = responseObj[1];
          
          for(var i=0; i<child_objects_array.length; i++){            
            console.log(child_objects_array[i].resourceName);
            main_content_body += get_individual_items(child_objects_array[i], "child");
          }

          /*for(item in responseObj[1]){
            console.log(responseObj[1][item].resourceName);
            main_content_body += get_individual_items(responseObj[1][item], "child");
          }*/
         

          $("#templateTitle").html(responseObj[0].resourceName);
          $("#templateContent").html(main_content_body);
          
          $(".resource-normal").removeClass("resource-active");
          $("#resourceLink_"+resourceId).addClass("resource-active");
          initiate_date_plugin();
          $('[data-toggle="tooltip"]').tooltip();
          $("#loader_div").hide();          
      }

    });

  }


  function get_individual_items(single_response_obj, item_type){
    var content_body = "";

    if(item_type == "child"){
      content_body += "<p></p>";
      content_body += '<h3>' + single_response_obj.resourceName + '</h3>';
    }

    switch(single_response_obj.resourceType){
        case "info_date":
          content_body += single_response_obj.resourceDescription;
          content_body += get_date_template(single_response_obj);
          break;

        case "survey":
          content_body += single_response_obj.resourceDescription + "<br>";
          content_body += single_response_obj.gotoURL;
          break;

        case "external_survey":
          content_body += single_response_obj.resourceDescription + "";
          content_body += get_external_assessment_body(single_response_obj.assessment_details);
          break;

        default:
          content_body += single_response_obj.resourceDescription;

    }

    return content_body;

  }

  //Structure of assessment_details
  /*assessment_details = array( 
                              "assignId"=>0, 
                              "completion_status"=>0, 
                              "completed_date"=>0, 
                              "entry_exists"=>"false", 
                              "survey_url"=>"", 
                              "survey_report"=>""
                            );*/
  function get_external_assessment_body(assessment_details){
    var body_string = "";

    body_string
    body_string += '<div class="" style="margin-top:10px;">';
    body_string += '<table class="table table-bordered bg-info"> <tr>';
    if(assessment_details.entry_exists == "true"){
        if(assessment_details.completion_status == 1){  

          //Show the Survey URL only to internal people
          if(userType == "internal"){
            body_string += '<td width="50%"><a href="'+ assessment_details.survey_url +'" target="_blank" style="font-size:18px">Go to Questionnaire</a> <span class="glyphicon glyphicon-ok" style="color:green; font-size:18px" aria-hidden="true"></span></td>';
          }
          
          body_string += '<td width="50%"><a href="'+ assessment_details.survey_report +'" target="_blank" style="font-size:18px">View Report</a></td>';

        }else{

          if(userType == "internal"){
            body_string += '<td width="50%"><a href="'+ assessment_details.survey_url +'" target="_blank" style="font-size:18px">Go to Questionnaire</a></td>';
          }
          body_string += '<td width="50%">Report not generated.</td>';
          //body_string += '<a href="'+ assessment_details.survey_report +'" target="_blank" style="font-size:18px">View Report</a>';
        }
    }else{
      // If the entry doesn't exist for some reason.
      body_string += 'This assessment was not found due to some system issue. Please contact the Project Connect Administrator.'
    }
    
    body_string += '</tr></table> ';
    body_string += '</div>';

    return body_string;    
  }


  function get_date_template(responseObj){
    //alert(responseObj.preset_date);
    
    if(responseObj.preset_date == "false" || responseObj.preset_date == false){
      var return_string = '<div id="date_set_div" class="column col-sm-10 well well-info">';
      return_string += '<div class="column col-xs-12" style="margin-bottom:20px;">';
      return_string += '<span id="design_date_label" class="lead">Design Call Date: Not Scheduled</span>';
    }else{
      var return_string = '<div id="date_set_div" class="column col-sm-10 well">';
      return_string += '<div class="column col-xs-12" style="margin-bottom:20px;">';
      return_string += '<span id="design_date_label" class="lead">Design Call Date: ' + responseObj.preset_date + ' </span>';
    }
    
    return_string += '</div>';
    if(userType == "internal"){
      return_string += '<div class="column col-xs-6">';
      return_string += '<div class="input-group date"> ';
      return_string += '<input id="my_date" type="text" placeholder="Change date" data-resourceId="' + responseObj.resourceId + '" class="form-control"><span class="input-group-addon" style="cursor:pointer"><i class="glyphicon glyphicon-th"></i></span> ';
      return_string += '</div>';
       return_string += '</div>';
      return_string += '<div class="column col-xs-3"> <button class="btn btn-primary" onclick="set_date()">Set Date</button> </div>';
    }
   
    return_string += '</div>';

    return return_string;
  }

  function initiate_date_plugin(){  
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!
    var yyyy = today.getFullYear();

    if(dd<10) {
        dd='0'+dd
    } 

    if(mm<10) {
        mm='0'+mm
    } 
    
    today = yyyy +"-" + mm + "-" + dd;
    //alert(today);

    $('.input-group.date').datepicker({
        format: "yyyy-mm-dd",
        startDate: today,
        //daysOfWeekDisabled: "0,6",
        autoclose: true,
        //datesDisabled: ['10/06/2015', '10/21/2015']
    });

  }

  function set_date(){    
      //alert($('.datepicker').datepicker('getFormattedDate'));
      //alert($("#my_date").attr("data-resourceId"));
      if($("#my_date").val() !=""){
        var action = baseURL + "/set_date";
        var form_data = {
          'call_date': $("#my_date").val(),
          'dateType':'design_call',
          'resourceId': $("#my_date").attr("data-resourceId"),
          'projectId':projectId
        };

        $.ajax({
          type: "POST",
          url: action,
          data: form_data,
          success: function(response)
          {
              //alert(response);
              $("#date_set_div").removeClass("well-info");
              $("#design_date_label").html("Design Call Date: " + response);
              $("#my_date").val("");       
              
          }
        });
      }
  }
