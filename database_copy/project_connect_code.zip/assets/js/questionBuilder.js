 /*
	QUESTION TYPES
multiple_row_headers
number_entry
yes_no
multi_select_other
yes_no_other
acknowledge
comment
single_select
single_select_other
multiple_text_entry
info_check_multiple

 */

 function fnBuildPage(){
 	var pageMarkup = "";
 	var mainQuestionCounter = 1;
 	// ASCII value of "a"
 	var asciiCounter = 96;
 	//String.fromCharCode(asciiCounter)

 	for(var i=0; i <topicDataArray.length; i++){
 		/*topicDataArray[i]["qDependentQId"]
 		topicDataArray[i]["qDependentOption"] 		
 		topicDataArray[i]["qGroupNext"]*/


 		//Normal Question
 		if(topicDataArray[i]["qGroupNext"]==0 && topicDataArray[i]["qDependentQId"]==0){ 			
 			pageMarkup += '<div class="col-md-12 col-xs-12 column bgq" data-qId="'+topicDataArray[i]["qId"]+'">';
 			pageMarkup += fnAddIntroText(i);
 			//pageMarkup += topicDataArray[i]["qId"] + " - Normal Question";
 			pageMarkup += '<p><span class="questionNumber">'+mainQuestionCounter+'. </span>'+topicDataArray[i]["qText"]+'</p>';
		    pageMarkup += this["fnBuild_"+topicDataArray[i]["qType"]](i,topicDataArray[i]["qId"]);
		    pageMarkup += '</div>';		  

		    mainQuestionCounter++;
 		}

 		// Stem Question
 		if(topicDataArray[i]["qGroupNext"]==1 && topicDataArray[i]["qDependentQId"]==0){
 			pageMarkup += '<div class="col-md-12 col-xs-12 column bgq" id="qDiv_'+topicDataArray[i]["qId"]+'" data-qId="'+topicDataArray[i]["qId"]+'" data-counter="'+mainQuestionCounter+'">';
 			pageMarkup += fnAddIntroText(i);
 			//pageMarkup += topicDataArray[i]["qId"] + " - Stem ONLY";
 			pageMarkup += '<p><span class="questionNumber">'+mainQuestionCounter+'. </span>'+topicDataArray[i]["qText"]+'</p>';
		    pageMarkup += this["fnBuild_"+topicDataArray[i]["qType"]](i,topicDataArray[i]["qId"]);
		    pageMarkup += '</div>';

		    asciiCounter = 96;
		    mainQuestionCounter++;
 		} 	

 		// Is a Dependent Question Only
 		if(topicDataArray[i]["qGroupNext"]==0 && topicDataArray[i]["qDependentQId"]>0){
 			if(fnIntial_ConditionDisplay(topicDataArray[i]["qDependentQId"], topicDataArray[i]["qDependentOption"]) == true){
	 			pageMarkup += '<div class="col-md-12 col-xs-12 column bgq dependentDiv_'+topicDataArray[i]["qDependentQId"]+'" data-qId="'+topicDataArray[i]["qId"]+'" data-dep-option="'+topicDataArray[i]["qDependentOption"] +'">';
	 			asciiCounter++;
	 		}else{
	 			pageMarkup += '<div class="col-md-12 col-xs-12 column bgq hidden dependentDiv_'+topicDataArray[i]["qDependentQId"]+'" data-qId="'+topicDataArray[i]["qId"]+'" data-dep-option="'+topicDataArray[i]["qDependentOption"] +'">';
	 		}
 			pageMarkup += '<div class="dependendDiv " id="dependentDiv_'+topicDataArray[i]["qId"]+'">';
 			pageMarkup += fnAddIntroText(i);
 			//pageMarkup += topicDataArray[i]["qId"] + " - Dependent Only";
 			//pageMarkup += '<p><span class="questionNumber">'+mainQuestionCounter+'. </span>'+topicDataArray[i]["qText"]+'</p>';
 			pageMarkup += '<p><span id="dep_qNum_'+topicDataArray[i]["qId"]+'" class="questionNumber">'+(mainQuestionCounter-1)+String.fromCharCode(asciiCounter)+'. </span>'+topicDataArray[i]["qText"]+'</p>';
		    pageMarkup += this["fnBuild_"+topicDataArray[i]["qType"]](i,topicDataArray[i]["qId"]);
		    pageMarkup += '</div>';
		    pageMarkup += '</div>';


			
 		}


 		  
 	}

 	 $("#questionBody").html(pageMarkup);

 }



//*****************************************************************************************
// YES NO
//*****************************************************************************************
 function fnBuild_yes_no(arrayNum , qId){

 	var questionBlock = "";
 	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>';
 	questionBlock += '<div class="optionsDiv">';
 	questionBlock += '<span class="glyphicon glyphicon-refresh pull-right" style="cursor:pointer; z-index:100"aria-hidden="true" data-toggle="tooltip" data-placement="bottom" title="Clear the selected options." onclick="fnResetRadio('+qId+')"></span>';
 	questionBlock += '<div class="radio"><label>';
 	if(topicDataArray[arrayNum]["isAnswered"] == "true" && topicDataArray[arrayNum]["response"] == "Yes"){
 		questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios1"  value="Yes" checked> Yes';
 	}else{
 		questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" class="radioclass_'+qId+'" id="optionsRadios1"  value="Yes"> Yes';
 	} 	
 	
 	questionBlock += '</label></div>';
 	questionBlock += '<div class="radio"><label>';
 	if(topicDataArray[arrayNum]["isAnswered"] == "true" && topicDataArray[arrayNum]["response"] == "No"){
 		questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios2"  value="No" checked> No';
 	}else{
 		questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios2"  value="No"> No';
 	}
 	
 	questionBlock += '</label></div>'; 
 	
 	questionBlock += '</div>'; 	
 	questionBlock += fnReturnFilesBlock(arrayNum, qId); 
 	questionBlock += fnReturnNotesBlock(arrayNum, qId); 	
 	
 	return(questionBlock);
 }


//*****************************************************************************************
// COMMENT
//*****************************************************************************************
 function fnBuild_comment(arrayNum , qId){ 

 	var questionBlock = "";
 	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>';

 	if(topicDataArray[arrayNum]["isAnswered"] == "true"){
 		questionBlock += '<div class="optionsDiv"><textarea class="form-control ckeditor" type="text" id="comment_'+qId+'" name="comment_'+qId+'"data-questionId="" placeholder=""  rows="3">'+topicDataArray[arrayNum]["response"]+'</textarea></div>';
 	}else{
 		questionBlock += '<div class="optionsDiv"><textarea class="form-control ckeditor" type="text" id="comment_'+qId+'" name="comment_'+qId+'"data-questionId="" placeholder=""  rows="3"></textarea></div>';
 	}
 	
 	questionBlock += fnReturnFilesBlock(arrayNum, qId); 
 	questionBlock += fnReturnNotesBlock(arrayNum, qId);
 	
 	return questionBlock;
 }

//*****************************************************************************************
// NUMBER ENTRY
//*****************************************************************************************
 function fnBuild_number_entry(arrayNum , qId){

 	var questionBlock = "";
 	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>';

 	if(topicDataArray[arrayNum]["isAnswered"] == "true"){
 		questionBlock += '<div class="optionsDiv"><input type="number" id="numeric_'+qId+'" data-questionId="" class="numbersOnly" placeholder=""  value="'+topicDataArray[arrayNum]["response"]+'"></input></div>';
 	}else{
 		questionBlock += '<div class="optionsDiv"><input type="number" id="numeric_'+qId+'" data-questionId="" class="numbersOnly" placeholder="" ></input></div>';
 	}
 	
 	questionBlock += fnReturnFilesBlock(arrayNum, qId); 
 	questionBlock += fnReturnNotesBlock(arrayNum, qId);
 	return questionBlock;
 }

//*****************************************************************************************
// MULTI SELECT OTHER
//*****************************************************************************************
 function fnBuild_multi_select_other(arrayNum , qId){
 	
 	var optionsArray = topicDataArray[arrayNum]["qOptions"].split("$");
 	var responseRawString = topicDataArray[arrayNum]["response"];
 	var responseArray = responseRawString.split("$");

 	if(optionsArray.indexOf("All of the above")>=0){
 		var allAboveQuestion = "true";
 	}else{
 		var allAboveQuestion = "false";
 	}
 	
 	var questionBlock = "";
 	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>';
 	questionBlock += '<div class="optionsDiv">';

 	for(var i=0;i<topicDataArray[arrayNum]["qNumOfOptions"]; i++){
 		questionBlock += '<div class="checkbox"><label>';

 		if(topicDataArray[arrayNum]["isAnswered"] == "true"){
 			if(responseRawString.indexOf(optionsArray[i]) >= 0){
 				questionBlock += '<input type="checkbox" name="optionsCheck_'+qId+'" data-allabove="'+allAboveQuestion+'" id="optionsCheck_'+qId+'_'+i+'"  value="'+optionsArray[i]+'" checked> '+optionsArray[i]+'';
 			}else{
 				questionBlock += '<input type="checkbox" name="optionsCheck_'+qId+'" data-allabove="'+allAboveQuestion+'" id="optionsCheck_'+qId+'_'+i+'"  value="'+optionsArray[i]+'"> '+optionsArray[i]+'';
 			}
 		}else{
 			questionBlock += '<input type="checkbox" name="optionsCheck_'+qId+'" data-allabove="'+allAboveQuestion+'" id="optionsCheck_'+qId+'_'+i+'"  value="'+optionsArray[i]+'" > '+optionsArray[i]+'';
 		}
 		
 		questionBlock += '</label></div>'; 
 	}

 	if(responseArray[responseArray.length-1] != undefined && responseArray[responseArray.length-1]  != "Empty"){
 		questionBlock += '<label>'+optionsArray[optionsArray.length-1]+'</label><textarea class="form-control ckeditor" type="text" id="mcq_comment_'+qId+'" name="mcq_comment_'+qId+'" placeholder=""  rows="3">'+responseArray[responseArray.length-1] +'</textarea>';
 	}else{
 		questionBlock += '<label>'+optionsArray[optionsArray.length-1]+'</label><textarea class="form-control ckeditor" type="text" id="mcq_comment_'+qId+'" name="mcq_comment_'+qId+'" placeholder=""  rows="3"></textarea>';
 	}

 	questionBlock += '</div>';	

 	questionBlock += fnReturnFilesBlock(arrayNum, qId); 
 	questionBlock += fnReturnNotesBlock(arrayNum, qId);
 	//return "multi_select_other";
 	return questionBlock;

 }	

 function fnBuild_multi_select(arrayNum , qId){
 	
 	var optionsArray = topicDataArray[arrayNum]["qOptions"].split("$");
 	var responseRawString = topicDataArray[arrayNum]["response"];
 	var responseArray = responseRawString.split("$");
 	
 	var questionBlock = "";
 	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>';
 	questionBlock += '<div class="optionsDiv">';

 	for(var i=0;i<topicDataArray[arrayNum]["qNumOfOptions"]; i++){
 		questionBlock += '<div class="checkbox"><label>';

 		if(topicDataArray[arrayNum]["isAnswered"] == "true"){
 			if(responseRawString.indexOf(optionsArray[i]) >= 0){
 				questionBlock += '<input type="checkbox" name="optionsCheck_'+qId+'" id="optionsCheck_'+i+'"  value="'+optionsArray[i]+'" checked> '+optionsArray[i]+'';
 			}else{
 				questionBlock += '<input type="checkbox" name="optionsCheck_'+qId+'" id="optionsCheck_'+i+'"  value="'+optionsArray[i]+'"> '+optionsArray[i]+'';
 			}
 		}else{
 			questionBlock += '<input type="checkbox" name="optionsCheck_'+qId+'" id="optionsCheck_'+i+'"  value="'+optionsArray[i]+'" > '+optionsArray[i]+'';
 		}
 		
 		questionBlock += '</label></div>'; 
 	}

 	/*if(responseArray[responseArray.length-1] != undefined && responseArray[responseArray.length-1]  != "Empty"){
 		questionBlock += '<label>'+optionsArray[optionsArray.length-1]+'</label><textarea class="form-control ckeditor" type="text" id="mcq_comment_'+qId+'" name="mcq_comment_'+qId+'" placeholder=""  rows="3">'+responseArray[responseArray.length-1] +'</textarea>';
 	}else{
 		questionBlock += '<label>'+optionsArray[optionsArray.length-1]+'</label><textarea class="form-control ckeditor" type="text" id="mcq_comment_'+qId+'" name="mcq_comment_'+qId+'" placeholder=""  rows="3"></textarea>';
 	}*/

 	questionBlock += '</div>';	

 	questionBlock += fnReturnFilesBlock(arrayNum, qId); 
 	questionBlock += fnReturnNotesBlock(arrayNum, qId);
 	//return "multi_select_other";
 	return questionBlock;

 }


//*****************************************************************************************
// ACKNOWLEDGE
//*****************************************************************************************
 function fnBuild_acknowledge(arrayNum, qId){ 

 	var questionBlock = "";
 	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>';
 	questionBlock += '<div class="optionsDiv">';
 	questionBlock += '<div class="radio"><label>';

 	if(topicDataArray[arrayNum]["isAnswered"] == "true" && topicDataArray[arrayNum]["response"] == "Acknowledged"){
 		questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios1"  value="Acknowledged" checked> Acknowledged';
 	}else{
 		questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios1"  value="Acknowledged"> Acknowledged';
 	}
 	
 	questionBlock += '</label></div>';
 	questionBlock += '</div>';

 	questionBlock += fnReturnFilesBlock(arrayNum, qId);
 	questionBlock += fnReturnNotesBlock(arrayNum, qId);

 	return(questionBlock);
 }

//*****************************************************************************************
// MULTIPLE ROW HEADERS
//*****************************************************************************************
function fnBuild_multiple_row_headers(arrayNum , qId){
	//INFO about question set up in database
	//topicDataArray[arrayNum]["qNumOfOptions"] - Used to define default minimum empty rows to be provided
	//topicDataArray[arrayNum]["qOptions"].split("||") gives the number of parameters/columns

	var questionBlock = "";
	var tableId= String('infoTable_'+qId);
	var tableHeaders = topicDataArray[arrayNum]["qOptions"].split("||");
	var responseArray = Array();

	// Is a variable that keeps count of the total number of rows to render.
	// If question is answered, it takes it's value from the response's length viz tempArray1's length
	var rowCounter = topicDataArray[arrayNum]["qNumOfOptions"];
	
	// Converting the response String into a usable 2 dimensional array if question has been answered
	if(topicDataArray[arrayNum]["isAnswered"] == "true"){
		//**  Sample String Structure from Database
		//** 'Person A||9875||p@a.com||%$%Person B||9875||p@b.com||%$%Person C||Empty||p@c.com||%$%';

		var rawResponseString = topicDataArray[arrayNum]["response"];						

		var tempArray1 = rawResponseString.split("%$%");
		rowCounter = tempArray1.length-1;
		
		
		for(var m=0; m<rowCounter; m++){
			responseArray[m] = Array();
			var tempArray2 = String(tempArray1[m]).split("||");
			
			for(var n=0; n<tableHeaders.length; n++){
				responseArray[m][n] = tempArray2[n];
			}
		}
	}
	
	
	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>';
	questionBlock += '<table id="'+tableId+'" class="table table-bordered table-striped">';
	questionBlock += '<thead>';
	questionBlock += '<tr class="bg-primary">';


	for(var i=0;i<tableHeaders.length; i++){
		questionBlock += '<th>'+tableHeaders[i]+'</th>';
	}
	questionBlock += '</tr>';
	questionBlock += '</thead>';
	questionBlock += '<tbody>';

	
	for(var i=0;i<rowCounter; i++){
		questionBlock += '<tr>';
		for(var j=0;j<tableHeaders.length; j++){
			if(topicDataArray[arrayNum]["isAnswered"] == "true" && responseArray[i][j] != "Empty"){
				questionBlock += '<td><input class="form-control" type="text" id="_row_'+qId+'_'+i+'_'+j+'"  value="'+responseArray[i][j]+'" data-questionId="" placeholder=""></input></td>';
			}else{
				questionBlock += '<td><input class="form-control" type="text" id="_row_'+qId+'_'+i+'_'+j+'"  value="" data-questionId="" placeholder=""></input></td>';
			}
			
		}
		questionBlock += '</tr>';
	}
	questionBlock += '</tbody>';
	questionBlock += '</table>';
	
	questionBlock += '<button class="btn btn-xs btn-info addMoreBtn" type="button" data-tablename="'+tableId+'" data-qId="'+qId+'" href="">Add Rows</button>';
	

	questionBlock += fnReturnFilesBlock(arrayNum, qId); 
	questionBlock += fnReturnNotesBlock(arrayNum, qId);

	// Creating an object and pushing it into the row_questions_array. This array keeps track of the multiple_row_header questions on the current page.
	// Main function is to keep track for the "Add Rows" funcionality
	var myObject = new Object();
	myObject.qId = qId;
	myObject.arrayNumber = arrayNum;
	myObject.tableId = tableId;
	myObject.numOfColumns = tableHeaders.length;
	myObject.defaultRows = topicDataArray[arrayNum]["qNumOfOptions"];	
	myObject.lastRow = rowCounter;		
	
	row_questions_array.push(myObject);


	return questionBlock;        
}


function fnBuild_single_select_other(arrayNum , qId){
	var optionsArray = topicDataArray[arrayNum]["qOptions"].split("$");
 	var responseRawString = topicDataArray[arrayNum]["response"];
 	var responseArray = responseRawString.split("$");
 	
 	var questionBlock = "";
 	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>';
 	questionBlock += '<div class="optionsDiv">';
 	questionBlock += '<span class="glyphicon glyphicon-refresh pull-right" style="cursor:pointer; z-index:100" aria-hidden="true" data-toggle="tooltip" data-placement="bottom" title="Clear the selected options." onclick="fnResetRadio('+qId+')"></span>';

 	for(var i=0;i<topicDataArray[arrayNum]["qNumOfOptions"]; i++){
 		questionBlock += '<div class="radio"><label>';

 		if(topicDataArray[arrayNum]["isAnswered"] == "true"){
 			if(responseRawString.indexOf(optionsArray[i]) >= 0){
 				questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios_'+i+'"  value="'+optionsArray[i]+'" checked> '+optionsArray[i]+'';
 			}else{
 				questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios_'+i+'"  value="'+optionsArray[i]+'"> '+optionsArray[i]+'';
 			}
 		}else{
 			questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios_'+i+'"  value="'+optionsArray[i]+'" > '+optionsArray[i]+'';
 		}
 		
 		questionBlock += '</label></div>'; 
 	}

 	//Check if this is a conditional question
 	if(topicDataArray[arrayNum]["qConditionalComment"] == 1){
 		//Checking that if a Conditional Comment, show if correct answer has been given. CSS variable
 		var toShowCommentBox = (responseArray[0] == topicDataArray[arrayNum]["qCorrectAnswer"]) ? "" : "hidden";
 		if(responseArray[responseArray.length-1] != undefined && responseArray[responseArray.length-1]  != "Empty"){
 		questionBlock += '<div id="conditionalComment_'+qId+'" class="'+toShowCommentBox+'"><label>'+optionsArray[optionsArray.length-1]+'</label><textarea class="form-control ckeditor" type="text" id="ssq_comment_'+qId+'" name="ssq_comment_'+qId+'" placeholder=""  rows="3">'+responseArray[responseArray.length-1] +'</textarea></div>';
	 	}else{
	 		questionBlock += '<div id="conditionalComment_'+qId+'" class="'+toShowCommentBox+'"><label>'+optionsArray[optionsArray.length-1]+'</label><textarea class="form-control ckeditor" type="text" id="ssq_comment_'+qId+'" name="ssq_comment_'+qId+'" placeholder=""  rows="3"></textarea></div>';
	 	}
 	}else{
 		if(responseArray[responseArray.length-1] != undefined && responseArray[responseArray.length-1]  != "Empty"){
 		questionBlock += '<div id="conditionalComment_'+qId+'" ><label>'+optionsArray[optionsArray.length-1]+'</label><textarea class="form-control ckeditor" type="text" id="ssq_comment_'+qId+'" name="ssq_comment_'+qId+'" placeholder=""  rows="3">'+responseArray[responseArray.length-1] +'</textarea></div>';
	 	}else{
	 		questionBlock += '<div id="conditionalComment_'+qId+'" ><label>'+optionsArray[optionsArray.length-1]+'</label><textarea class="form-control ckeditor" type="text" id="ssq_comment_'+qId+'" name="ssq_comment_'+qId+'" placeholder=""  rows="3"></textarea></div>';
	 	}

 	}
 	

 	questionBlock += '</div>';	

 	questionBlock += fnReturnFilesBlock(arrayNum, qId); 
 	questionBlock += fnReturnNotesBlock(arrayNum, qId);
 	//return "multi_select_other";
 	return questionBlock;
}

function fnBuild_single_select(arrayNum , qId){
	var optionsArray = topicDataArray[arrayNum]["qOptions"].split("$");
 	var responseRawString = topicDataArray[arrayNum]["response"];
 	var responseArray = responseRawString.split("$");
 	
 	var questionBlock = "";
 	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>';
 	questionBlock += '<div class="optionsDiv">';
 	questionBlock += '<span class="glyphicon glyphicon-refresh pull-right" style="cursor:pointer; z-index:100" aria-hidden="true" data-toggle="tooltip" data-placement="bottom" title="Clear the selected options." onclick="fnResetRadio('+qId+')"></span>';

 	for(var i=0;i<topicDataArray[arrayNum]["qNumOfOptions"]; i++){
 		questionBlock += '<div class="radio"><label>';

 		if(topicDataArray[arrayNum]["isAnswered"] == "true"){
 			if(responseRawString.indexOf(optionsArray[i]) >= 0){
 				questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios_'+i+'"  value="'+optionsArray[i]+'" checked> '+optionsArray[i]+'';
 			}else{
 				questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios_'+i+'"  value="'+optionsArray[i]+'"> '+optionsArray[i]+'';
 			}
 		}else{
 			questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios_'+i+'"  value="'+optionsArray[i]+'" > '+optionsArray[i]+'';
 		}
 		
 		questionBlock += '</label></div>'; 
 	}

 	/*if(responseArray[responseArray.length-1] != undefined && responseArray[responseArray.length-1]  != "Empty"){
 		questionBlock += '<label>'+optionsArray[optionsArray.length-1]+'</label><textarea class="form-control ckeditor" type="text" id="ssq_comment_'+qId+'" name="ssq_comment_'+qId+'" placeholder=""  rows="3">'+responseArray[responseArray.length-1] +'</textarea>';
 	}else{
 		questionBlock += '<label>'+optionsArray[optionsArray.length-1]+'</label><textarea class="form-control ckeditor" type="text" id="ssq_comment_'+qId+'" name="ssq_comment_'+qId+'" placeholder=""  rows="3"></textarea>';
 	}*/

 	questionBlock += '</div>';	

 	questionBlock += fnReturnFilesBlock(arrayNum, qId); 
 	questionBlock += fnReturnNotesBlock(arrayNum, qId);
 	//return "multi_select_other";
 	return questionBlock;
}



function fnBuild_yes_no_other(arrayNum , qId){
	var commentsIntro = topicDataArray[arrayNum]["qOptions"];
 	var responseRawString = topicDataArray[arrayNum]["response"];
 	var responseArray = responseRawString.split("$");

	var questionBlock = "";
 	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>';
 	questionBlock += '<div class="optionsDiv">';
 	questionBlock += '<span class="glyphicon glyphicon-refresh pull-right" style="cursor:pointer; z-index:100" aria-hidden="true" data-toggle="tooltip" data-placement="bottom" title="Clear the selected options." onclick="fnResetRadio('+qId+')"></span>';
 	
 	questionBlock += '<div class="radio"><label>';

 	if(topicDataArray[arrayNum]["isAnswered"] == "true" && responseArray[0] == "Yes"){
 		questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios1"  value="Yes" checked> Yes';
 	}else{
 		questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios1"  value="Yes"> Yes';
 	}
 	questionBlock += '</label></div>';

 	questionBlock += '<div class="radio"><label>';
 	if(topicDataArray[arrayNum]["isAnswered"] == "true" && responseArray[0]  == "No"){
 		questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios2"  value="No" checked> No';
 	}else{
 		questionBlock += '<input type="radio" name="optionsRadios_'+qId+'" id="optionsRadios2"  value="No"> No';
 	} 	
 	questionBlock += '</label></div>'; 


 	//Check if this is a conditional question
 	if(topicDataArray[arrayNum]["qConditionalComment"] == 1){
 		//Checking that if a Conditional Comment, show if correct answer has been given. CSS variable
 		var toShowCommentBox = (responseArray[0] == topicDataArray[arrayNum]["qCorrectAnswer"]) ? "" : "hidden";
 		if(responseArray[1] != undefined && responseArray[1]  != "Empty"){
 			questionBlock += '<div id="conditionalComment_'+qId+'" class="'+toShowCommentBox+'"><label>'+commentsIntro+'</label><textarea class="form-control ckeditor" type="text" id="yesno_comment_'+qId+'" name="yesno_comment_'+qId+'" placeholder=""  rows="3">'+responseArray[1] +'</textarea></div>';
	 	}else{
	 		questionBlock += '<div id="conditionalComment_'+qId+'" class="'+toShowCommentBox+'"><label>'+commentsIntro+'</label><textarea class="form-control ckeditor" type="text" id="yesno_comment_'+qId+'" name="yesno_comment_'+qId+'" placeholder=""  rows="3"></textarea></div>';
	 	}

 	}else{
 		if(responseArray[1] != undefined && responseArray[1]  != "Empty"){
 		questionBlock += '<div id="conditionalComment_'+qId+'" ><label>'+commentsIntro+'</label><textarea class="form-control ckeditor" type="text" id="yesno_comment_'+qId+'" name="yesno_comment_'+qId+'" placeholder=""  rows="3">'+responseArray[1] +'</textarea></div>';
	 	}else{
	 		questionBlock += '<div id="conditionalComment_'+qId+'" ><label>'+commentsIntro+'</label><textarea class="form-control ckeditor" type="text" id="yesno_comment_'+qId+'" name="yesno_comment_'+qId+'" placeholder=""  rows="3"></textarea></div>';
	 	}
 	}
 	

 	questionBlock += '</div>'; 

 	questionBlock += fnReturnFilesBlock(arrayNum, qId); 
 	questionBlock += fnReturnNotesBlock(arrayNum, qId); 	
 	
 	return(questionBlock);
	
}


function fnBuild_info_check_multiple(arrayNum , qId){	
	var responseRawString = topicDataArray[arrayNum]["response"];
 	var responseArray = responseRawString.split("%$%");
 	
	var questionBlock = "";
	
	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>';
	questionBlock += '<div class="column col-md-8">';
	questionBlock += '<table class="table table-bordered bg-white">';
	questionBlock += '<tr>';
	questionBlock += '<th>Name </th>';
	questionBlock += '<th>O/R</th>';
	questionBlock += '</tr>';

	for(var i=0;i<topicDataArray[arrayNum]["qNumOfOptions"]; i++){			
		questionBlock += '<tr>';
		questionBlock += '<td>';

		if(topicDataArray[arrayNum]["isAnswered"] == "true"){
			var currentRowResponse = responseArray[i].split("||");
			if(currentRowResponse[0]  != "Empty"){
				questionBlock += '<input type="text" class="form-control" id="info_comment_'+qId+'_'+i+'" value="'+currentRowResponse[0]+'" aria-label="">';
			}else{
				questionBlock += '<input type="text" class="form-control" id="info_comment_'+qId+'_'+i+'" aria-label="">';
			}				
		}else{
			questionBlock += '<input type="text" class="form-control" id="info_comment_'+qId+'_'+i+'" aria-label="">';
		}	
		questionBlock += '</td>';


		questionBlock += '<td>';
		if(topicDataArray[arrayNum]["isAnswered"] == "true"){
			var currentRowResponse = responseArray[i].split("||");
			if(currentRowResponse[1]  == "O"){
				questionBlock += '<label class="radio-inline"><input type="radio" name="inforadio'+i+'_'+qId+'" id="info_radio_'+qId+'_op1" value="O" checked> O</label>';
			}else{
				questionBlock += '<label class="radio-inline"><input type="radio" name="inforadio'+i+'_'+qId+'" id="info_radio_'+qId+'_op1" value="O"> O</label>';
			}

			if(currentRowResponse[1]  == "R"){
				questionBlock += '<label class="radio-inline"><input type="radio" name="inforadio'+i+'_'+qId+'" id="info_radio_'+qId+'_op2" value="R" checked> R</label>';
			}else{
				questionBlock += '<label class="radio-inline"><input type="radio" name="inforadio'+i+'_'+qId+'" id="info_radio_'+qId+'_op2" value="R"> R</label>';
			}
			
		}else{
			questionBlock += '<label class="radio-inline"><input type="radio" name="inforadio'+i+'_'+qId+'" id="info_radio_'+qId+'_op1" value="O"> O</label>';
			questionBlock += '<label class="radio-inline"><input type="radio" name="inforadio'+i+'_'+qId+'" id="info_radio_'+qId+'_op2" value="R"> R</label>';
		}

		questionBlock += '</td>';
		questionBlock += '</tr>';
	}

	questionBlock += '</table>';
	
	questionBlock += fnReturnFilesBlock(arrayNum, qId);
 	questionBlock += fnReturnNotesBlock(arrayNum, qId);

	questionBlock += '</div>';

	

  	return questionBlock;
}

function fnBuild_multiple_text_entry(arrayNum , qId){	
	var responseRawString = topicDataArray[arrayNum]["response"];
 	var responseArray = responseRawString.split("|#|");

	var questionBlock = '';
 	//questionBlock += '<p><span class="questionNumber">'+(topicDataArray[arrayNum]["qSequenceNum"])+'. </span>'+topicDataArray[arrayNum]["qText"]+'</p>'; 	
 	questionBlock += '<div class="optionsDiv">';
 	if(topicDataArray[arrayNum]["isAnswered"] == "true"){
 		for(var i=0;i<topicDataArray[arrayNum]["qNumOfOptions"]; i++){
 			questionBlock += '<input type="text" id="multi_entry_'+qId+'_'+ i+'" data-questionId="" class="form-control" style="margin-bottom:6px" placeholder=""  value="'+responseArray[i]+'"></input>';
 		} 		
 	}else{
 		for(var i=0;i<topicDataArray[arrayNum]["qNumOfOptions"]; i++){
 			questionBlock += '<input type="text" id="multi_entry_'+qId+'_'+ i+'" data-questionId="" class="form-control" style="margin-bottom:6px" placeholder=""  value=""></input>';
 		}
 	}
 	
 	questionBlock += '</div>'; 	

 	questionBlock += fnReturnFilesBlock(arrayNum, qId); 
 	questionBlock += fnReturnNotesBlock(arrayNum, qId); 
 	return questionBlock;
}

function fnBuild_date(arrayNum , qId){
	return '<input type="text" size="12" id="inputField" />';
}



function fnAddIntroText(arrayNum){
	if(topicDataArray[arrayNum]["qIntroLine"]!= "NA" && topicDataArray[arrayNum]["qIntroLine"] != ""){
		return ('<p class="qIntroLine">'+topicDataArray[arrayNum]["qIntroLine"]+'</p>');
	}else{
		return "";
	}
}

function fnReturnNotesBlock(arrayNum, qId){

	notesBlock = '';
	notesBlock += '<div class="row notesBlock" style="margin-right:12px">';

	if(userType == "internal"){
		notesBlock += '<a href="javascript:fnToggleComment('+qId+')" class="ic_comment pull-right" style="margin-right:12px">Allscripts IC <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a> ';
	}
	
	
	if(topicDataArray[arrayNum]["noteText"] == null){
		notesBlock += ' <textarea class="form-control pull-right hidden" type="text" id="ic_comment_'+qId+'" data-questionId="" placeholder="Allscripts IC Comment" rows="2"></textarea></div>';
	}else{
		
		if(userType == "external"){
			notesBlock += '<span class="pull-right">' + topicDataArray[arrayNum]["noteText"]["author"] + '</span> ';
			notesBlock += ' <textarea class="form-control pull-right" type="text" id="ic_comment_'+qId+'" data-questionId="" placeholder="Allscripts IC Comment" rows="2" readonly>'+topicDataArray[arrayNum]["noteText"]["text"] +'</textarea>';
		}else{
			notesBlock += ' <textarea class="form-control pull-right " type="text" id="ic_comment_'+qId+'" data-questionId="" placeholder="Allscripts IC Comment" rows="2">'+topicDataArray[arrayNum]["noteText"]["text"] +'</textarea>';
		}
		
	}
 	
 	notesBlock += '</div>';
 	return(notesBlock);
}

function fnReturnFilesBlock(arrayNum, qId){
	filesBlock = "";

	if(topicDataArray[arrayNum]["qFileUploads"] == 1 ){
		filesBlock += '<div class="row" style="margin:10px"><div class="col-md-8">';
		filesBlock += '<a href="#" onclick="fnSetFiles_IFrame('+qId+')" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span> Add Supporting Files</a>';

		if(topicDataArray[arrayNum]["filesArray"] != null){
			filesBlock += '<table class="table table-bordered bg-white"><tr>';
			filesBlock += '<td>Number</td>';
			filesBlock += '<td>File Name</td>';
			filesBlock += '<td>Date</td>';
			filesBlock += '</tr>';

			for(var i=0; i<topicDataArray[arrayNum]["filesArray"].length; i++){
				filesBlock += '<tr>';
				filesBlock += '<td>'+(i+1)+'</td>';
				filesBlock += '<td><a href="'+topicDataArray[arrayNum]["filesArray"][i]["filePath"]+'" target="_blank">'+topicDataArray[arrayNum]["filesArray"][i]["fileName"]+'</a></td>';
				filesBlock += '<td>'+topicDataArray[arrayNum]["filesArray"][i]["fileDate"]+'</td>';	
				filesBlock += '</tr>';
			}
			
			
		}

		filesBlock += '</table>';
		filesBlock += '</div></div>';
		
	}

	return filesBlock;
}

