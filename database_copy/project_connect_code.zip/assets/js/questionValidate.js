

function fnValidateAnswers(){
	var responseString = "";
	var questionIdString = "";
	var masterQuestionString = "";
	var notesString = "";
	var successFlag = false;
	
	
	for(var i=0; i <topicDataArray.length; i++){
		//if(this["fnValidate_"+topicDataArray[i]["qType"]](i,topicDataArray[i]["qId"]) != null){
			questionIdString += topicDataArray[i]["qId"] + "|$|";
			responseString += this["fnValidate_"+topicDataArray[i]["qType"]](i,topicDataArray[i]["qId"]) + "|$|";
			
			if($("#ic_comment_"+topicDataArray[i]["qId"]).val() != ""){
				//alert($("#ic_comment_"+topicDataArray[i]["qId"]).val());
				notesString += $("#ic_comment_"+topicDataArray[i]["qId"]).val();
			}else{
				notesString += null;
			}
			notesString += "|$|";
		
		//}
	}
	
	var action = baseURL + "/submitAnswers";
    var form_data = {
      'projectId': projectId,
      'surveyId': quest_id,
      'responseString': responseString,
      'questionIdString': questionIdString,
      'notesString': notesString,
      'masterQuestionString': masterQuestionString
    };

    $.ajax({
      type: "POST",
      url: action,
      data: form_data,
      success: function(response)
      {   
      		//fnGetProgress();
      		//alert(response);
      }
    });

	//alert(action)
}


function fnValidate_yes_no(arrayNum, qId){
	var response = null;
    var radioName = "optionsRadios_"+qId;

    if( $('input[name='+radioName+']:checked' ).val() != undefined){
      response = $('input[name='+radioName+']:checked').val();
    }
    return response;
}


function fnValidate_comment(arrayNum, qId){
	var response = null;
	var commentValue = CKEDITOR.instances["comment_"+qId].getData();

	if(commentValue.length > 0){
		response = commentValue;
	}
	return response;
}


function fnValidate_number_entry(arrayNum , qId){
	var response = null;
	if($("#numeric_"+qId).val() != ""){
		response = $("#numeric_"+qId).val();
	}
	return response;
}


function fnValidate_multi_select_other(arrayNum , qId){
	var response = null;
	var selectedOptions = [];
	$.each($("input[name='optionsCheck_"+qId+"']:checked"), function(){
	    selectedOptions.push($(this).val());
	});
	
	response = selectedOptions.join("$");
	var cment = CKEDITOR.instances["mcq_comment_"+qId].getData();
	if(CKEDITOR.instances["mcq_comment_"+qId].getData() == ""){
		response += "$Empty";
	}else{
		response += "$" + CKEDITOR.instances["mcq_comment_"+qId].getData();
	}
	
	if(response=="null$Empty" || response=="$Empty"){
		return null;
	}else{
		return response;
	}
}

function fnValidate_multi_select(arrayNum , qId){
	var response = null;
	var selectedOptions = [];
	$.each($("input[name='optionsCheck_"+qId+"']:checked"), function(){
	    selectedOptions.push($(this).val());
	});
	
	response = selectedOptions.join("$");
	/*var cment = CKEDITOR.instances["mcq_comment_"+qId].getData();
	if(CKEDITOR.instances["mcq_comment_"+qId].getData() == ""){
		response += "$Empty";
	}else{
		response += "$" + CKEDITOR.instances["mcq_comment_"+qId].getData();
	}*/
	
	return response;
}


function fnValidate_acknowledge(arrayNum, qId){ 
	var response = null;
    var radioName = "optionsRadios_"+qId;

    if( $('input[name='+radioName+']:checked' ).val() != undefined){
      response = $('input[name='+radioName+']:checked').val();
    }
    return response;
}


function fnValidate_multiple_row_headers(arrayNum , qId){	
	var response = "";
	var noEntriesFlag = true;
	var tableHeaders = topicDataArray[arrayNum]["qOptions"].split("||");

	//Check the internally calculated array to check if any rows have been added.
	var result = $.grep(row_questions_array, function(e){ return e.qId == qId; });
	//alert(result[0]["lastRow"]);

	//for(var i=0;i<topicDataArray[arrayNum]["qNumOfOptions"]; i++){
	for(var i=0;i<result[0]["lastRow"]; i++){
		
		for(var j=0;j<tableHeaders.length; j++){
			
			if($("#_row_"+qId+"_"+i+"_"+j).val()!=""){
				response += $("#_row_"+qId+"_"+i+"_"+j).val() + "||";
				noEntriesFlag = false;
			}else{
				response += "Empty" + "||";
			}
			
		}
		response += "%$%";
	}	
	

	if(noEntriesFlag){
		response =  null;
	}

	//alert(response);
	return response;
	
}

function fnValidate_single_select_other(arrayNum, qId){ 
	var response = null;
    var radioName = "optionsRadios_"+qId;

    if( $('input[name='+radioName+']:checked' ).val() != undefined){
      response = $('input[name='+radioName+']:checked').val();
    }

    var cment = CKEDITOR.instances["ssq_comment_"+qId].getData();
	if(CKEDITOR.instances["ssq_comment_"+qId].getData() == ""){
		response += "$Empty";
	}else{
		response += "$" + CKEDITOR.instances["ssq_comment_"+qId].getData();
	}
    
    if(response=="null$Empty"){
		return null;
	}else{
		return response;
	}
}

function fnValidate_single_select(arrayNum, qId){ 
	var response = null;
    var radioName = "optionsRadios_"+qId;

    if( $('input[name='+radioName+']:checked' ).val() != undefined){
      response = $('input[name='+radioName+']:checked').val();
    }
  
    return response;
}



function fnValidate_yes_no_other(arrayNum, qId){ 
	var response = null;
    var radioName = "optionsRadios_"+qId;

    if( $('input[name='+radioName+']:checked' ).val() != undefined){
      response = $('input[name='+radioName+']:checked').val();
    }
    

    var cment = CKEDITOR.instances["yesno_comment_"+qId].getData();
	if(CKEDITOR.instances["yesno_comment_"+qId].getData() == ""){
		response += "$Empty";
	}else{
		response += "$" + CKEDITOR.instances["yesno_comment_"+qId].getData();
	}

	if(response=="null$Empty"){
		return null;
	}else{
		return response;
	}
    
}


function fnValidate_info_check_multiple(arrayNum, qId){ 
	var response = "";
	var noEntriesFlag = true;

	
	for(var i=0;i<topicDataArray[arrayNum]["qNumOfOptions"]; i++){
		if($("#info_comment_"+qId+"_"+i).val()!=""){
			response += $("#info_comment_"+qId+"_"+i).val() + "||";
			noEntriesFlag = false;
		}else{
			response += "Empty" + "||";
		}

		var radioName = "inforadio" + i + "_" + qId ;
		if( $('input[name='+radioName+']:checked' ).val() != undefined){
	      response += $('input[name='+radioName+']:checked').val();
	    }else{
	    	response += " ";
	    }

	    response += "%$%";
	}

	if(noEntriesFlag){
		response =  null;
	}

    return response;
}




function fnValidate_multiple_text_entry(arrayNum, qId){
	var response = "";
	var noEntriesFlag = true;	

	for(var i=0;i<topicDataArray[arrayNum]["qNumOfOptions"]; i++){			
		if($("#multi_entry_"+qId+"_"+i).val()!=""){
			response += $("#multi_entry_"+qId+"_"+i).val() + "|#|";
			noEntriesFlag = false;
		}else{
			response += " " + "|#|";
		}	
	}		

	if(noEntriesFlag){
		response =  null;
	}
	
    return response;
}


function fnValidate_date(arrayNum , qId){
	var response = null;  
    return response;
}